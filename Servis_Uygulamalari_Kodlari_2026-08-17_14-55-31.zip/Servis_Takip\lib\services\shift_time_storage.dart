import '../models/shift_definition.dart';
import 'company_cloud_storage.dart';

class ShiftTimeStorage {
  ShiftTimeStorage._();

  static const _collection = 'shiftTimes';

  static Future<List<ShiftTimeSlot>> readAll() async {
    final data = await CompanyCloudStorage.readCollection(_collection);
    final items = data.map(ShiftTimeSlot.fromJson).toList()
      ..sort((a, b) => a.startMinutes.compareTo(b.startMinutes));
    return items;
  }

  static Future<void> saveAll(List<ShiftTimeSlot> items) {
    return CompanyCloudStorage.replaceCollection(
      collectionName: _collection,
      items: items.map((item) => item.toJson()).toList(),
    );
  }
}
