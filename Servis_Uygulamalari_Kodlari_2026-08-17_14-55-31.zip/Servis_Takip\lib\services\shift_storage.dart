import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/work_shift.dart';
import 'company_cloud_storage.dart';

class ShiftStorage {
  ShiftStorage._();

  static const _key = 'work_shifts';
  static const _storage = FlutterSecureStorage();

  static const defaultShifts = [
    WorkShift(id: 'default_24_08', name: '24 / 08', order: 1),
    WorkShift(id: 'default_08_16', name: '08 / 16', order: 2),
    WorkShift(id: 'default_16_24', name: '16 / 24', order: 3),
  ];

  static Future<List<WorkShift>> readAll() async {
    final cloudData = await CompanyCloudStorage.readCollection('shifts');
    if (cloudData.isNotEmpty) {
      final shifts = cloudData.map(WorkShift.fromJson).toList()
        ..sort((a, b) => a.order.compareTo(b.order));
      await _writeCache(shifts);
      await CompanyCloudStorage.markCloudInitialized('shifts');
      return shifts;
    }
    if (await CompanyCloudStorage.isCloudInitialized('shifts')) {
      return const [];
    }
    final value =
        await _storage.read(key: await CompanyCloudStorage.cacheKey(_key)) ??
        await _storage.read(key: _key);
    if (value == null || value.isEmpty) {
      await saveAll(defaultShifts);
      return [...defaultShifts];
    }

    final shifts =
        (jsonDecode(value) as List<dynamic>)
            .map((item) => WorkShift.fromJson(item as Map<String, dynamic>))
            .toList()
          ..sort((a, b) => a.order.compareTo(b.order));
    if (await CompanyCloudStorage.canClaimLegacyData()) {
      await CompanyCloudStorage.replaceCollection(
        collectionName: 'shifts',
        items: shifts.map((shift) => shift.toJson()).toList(),
      );
    }
    await CompanyCloudStorage.markCloudInitialized('shifts');
    return shifts;
  }

  static Future<void> saveAll(List<WorkShift> shifts) async {
    final ordered = [
      for (var index = 0; index < shifts.length; index++)
        shifts[index].copyWith(order: index + 1),
    ];
    await CompanyCloudStorage.replaceCollection(
      collectionName: 'shifts',
      items: ordered.map((shift) => shift.toJson()).toList(),
    );
    await _writeCache(ordered);
    await CompanyCloudStorage.markCloudInitialized('shifts');
  }

  static Future<void> _writeCache(List<WorkShift> shifts) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_key),
      value: jsonEncode(shifts.map((shift) => shift.toJson()).toList()),
    );
  }
}
