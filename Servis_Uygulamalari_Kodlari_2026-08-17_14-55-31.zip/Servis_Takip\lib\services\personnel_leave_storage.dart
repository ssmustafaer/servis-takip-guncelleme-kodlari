import '../models/personnel_leave.dart';
import 'company_cloud_storage.dart';

class PersonnelLeaveStorage {
  PersonnelLeaveStorage._();

  static Future<List<PersonnelLeave>> readAll() async {
    final data = await CompanyCloudStorage.readCollection('personnelLeaves');
    final leaves = data.map(PersonnelLeave.fromJson).toList()
      ..sort((a, b) => a.startDate.compareTo(b.startDate));
    return leaves;
  }

  static Future<void> saveAll(List<PersonnelLeave> leaves) {
    return CompanyCloudStorage.replaceCollection(
      collectionName: 'personnelLeaves',
      items: leaves.map((leave) => leave.toJson()).toList(),
    );
  }

  static Future<void> saveOne(PersonnelLeave leave) {
    return CompanyCloudStorage.writeDocument(
      collectionName: 'personnelLeaves',
      documentId: leave.id,
      data: leave.toJson(),
    );
  }

  static Future<void> deleteOne(String id) {
    return CompanyCloudStorage.deleteDocument(
      collectionName: 'personnelLeaves',
      documentId: id,
    );
  }
}
