import 'package:flutter/material.dart';

import '../models/driver.dart';
import '../services/driver_storage.dart';

class DriversScreen extends StatefulWidget {
  const DriversScreen({super.key});

  @override
  State<DriversScreen> createState() => _DriversScreenState();
}

class _DriversScreenState extends State<DriversScreen> {
  final _nameController = TextEditingController();
  List<Driver> _drivers = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadDrivers();
  }

  Future<void> _loadDrivers() async {
    final drivers = await DriverStorage.readAll();
    if (!mounted) return;
    setState(() {
      _drivers = drivers;
      _loading = false;
    });
  }

  Future<void> _addDriver() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) return;
    final updated = [
      ..._drivers,
      Driver(id: DateTime.now().microsecondsSinceEpoch.toString(), name: name),
    ];
    await DriverStorage.saveAll(updated);
    if (!mounted) return;
    setState(() {
      _drivers = updated;
      _nameController.clear();
    });
  }

  Future<void> _removeDriver(Driver driver) async {
    final updated = _drivers.where((item) => item.id != driver.id).toList();
    await DriverStorage.saveAll(updated);
    if (mounted) setState(() => _drivers = updated);
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Şoför Kaydı')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _nameController,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(
                          labelText: 'Şoför adı',
                          prefixIcon: Icon(Icons.drive_eta_rounded),
                          border: OutlineInputBorder(),
                        ),
                        onSubmitted: (_) => _addDriver(),
                      ),
                    ),
                    const SizedBox(width: 8),
                    FilledButton(
                      onPressed: _addDriver,
                      style: FilledButton.styleFrom(
                        minimumSize: const Size(56, 56),
                      ),
                      child: const Icon(Icons.add_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (_drivers.isEmpty)
                  const Text(
                    'Henüz şoför kaydı yok.',
                    style: TextStyle(color: Color(0xFF718196)),
                  )
                else
                  ..._drivers.map(
                    (driver) => Card(
                      child: ListTile(
                        leading: const Icon(Icons.drive_eta_rounded),
                        title: Text(driver.name),
                        trailing: IconButton(
                          onPressed: () => _removeDriver(driver),
                          icon: const Icon(Icons.delete_outline_rounded),
                          color: Colors.red,
                          tooltip: 'Şoförü sil',
                        ),
                      ),
                    ),
                  ),
              ],
            ),
    );
  }
}
