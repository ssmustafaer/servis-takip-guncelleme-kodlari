import 'package:flutter_test/flutter_test.dart';
import 'package:servis_takip/models/personnel.dart';
import 'package:servis_takip/services/shift_calculator.dart';

Personnel _person({
  required String workType,
  required String shift,
  required List<int> leaveWeekdays,
  String leaveMode = Personnel.weeklyLeaveMode,
  int workDaysCount = 6,
  int leaveDaysCount = 1,
  String shiftDirection = Personnel.shiftBackward,
}) {
  return Personnel(
    id: 'test',
    fullName: 'Test Personel',
    phone: '',
    whatsApp: '',
    stopName: 'Durak',
    stopOrder: 1,
    shift: shift,
    workType: workType,
    leaveWeekdays: leaveWeekdays,
    leaveMode: leaveMode,
    workDaysCount: workDaysCount,
    leaveDaysCount: leaveDaysCount,
    shiftDirection: shiftDirection,
    institutionId: 'kurum',
    institutionName: 'Test Kurum',
    referenceDate: '2026-07-20',
    cycleDay: 1,
    note: '',
  );
}

void main() {
  test('Vardiya her izin gününden sonra 8 saat geri döner', () {
    final person = _person(
      workType: Personnel.rotatingWorkType,
      shift: '16 / 24',
      leaveWeekdays: const [3, 7],
    );

    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 21)).shift,
      '16 / 24',
    );
    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 22)).isLeave,
      isTrue,
    );
    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 23)).shift,
      '08 / 16',
    );
    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 27)).shift,
      '24 / 08',
    );
  });

  test('Dinlendirici de izin sonrasında geriye döner', () {
    final person = _person(
      workType: Personnel.reliefWorkType,
      shift: '08 / 16',
      leaveWeekdays: const [3],
    );

    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 23)).shift,
      '24 / 08',
    );
  });

  test('Sabit personel izin sonrasında aynı vardiyada kalır', () {
    final person = _person(
      workType: Personnel.fixedWorkType,
      shift: '08 / 16',
      leaveWeekdays: const [3, 7],
    );

    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 23)).shift,
      '08 / 16',
    );
    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 27)).shift,
      '08 / 16',
    );
  });

  test('3 gün çalışma 1 gün izin döngüsü vardiyayı geri götürür', () {
    final person = _person(
      workType: Personnel.rotatingWorkType,
      shift: '16 / 24',
      leaveWeekdays: const [],
      leaveMode: Personnel.cycleLeaveMode,
      workDaysCount: 3,
      leaveDaysCount: 1,
    );

    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 23)).isLeave,
      isTrue,
    );
    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 24)).shift,
      '08 / 16',
    );
  });

  test('Vardiya ileri yönü seçildiğinde bir kademe ileri gider', () {
    final person = _person(
      workType: Personnel.rotatingWorkType,
      shift: '08 / 16',
      leaveWeekdays: const [],
      leaveMode: Personnel.cycleLeaveMode,
      workDaysCount: 1,
      leaveDaysCount: 1,
      shiftDirection: Personnel.shiftForward,
    );

    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 21)).isLeave,
      isTrue,
    );
    expect(
      ShiftCalculator.forDate(person, DateTime(2026, 7, 22)).shift,
      '16 / 24',
    );
  });
}
