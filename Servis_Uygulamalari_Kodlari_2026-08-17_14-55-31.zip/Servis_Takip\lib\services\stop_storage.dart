import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/stop.dart';
import 'company_cloud_storage.dart';

class StopStorage {
  StopStorage._();

  static const _stopsKey = 'stops_list';
  static const _storage = FlutterSecureStorage();

  static int _compareStops(Stop a, Stop b) {
    final group = a.institutionName.toLowerCase().compareTo(
      b.institutionName.toLowerCase(),
    );
    return group != 0 ? group : a.order.compareTo(b.order);
  }

  static Future<List<Stop>> readAll() async {
    final cloudData = await CompanyCloudStorage.readCollection('stops');
    if (cloudData.isNotEmpty) {
      final stops = cloudData
          .where((item) => item['deletedAt'] == null)
          .map(Stop.fromJson)
          .toList()
        ..sort(_compareStops);
      await _writeCache(stops);
      await CompanyCloudStorage.markCloudInitialized('stops');
      return stops;
    }
    if (await CompanyCloudStorage.isCloudInitialized('stops')) return [];
    final savedValue =
        await _storage.read(
          key: await CompanyCloudStorage.cacheKey(_stopsKey),
        ) ??
        await _storage.read(key: _stopsKey);
    if (savedValue == null || savedValue.isEmpty) {
      await CompanyCloudStorage.markCloudInitialized('stops');
      return [];
    }
    final stops =
        (jsonDecode(savedValue) as List<dynamic>)
            .map((item) => Stop.fromJson(item as Map<String, dynamic>))
            .toList()
          ..sort(_compareStops);
    if (await CompanyCloudStorage.canClaimLegacyData()) {
      await CompanyCloudStorage.replaceCollection(
        collectionName: 'stops',
        items: stops.map((stop) => stop.toJson()).toList(),
        limitField: 'maxStops',
        usageField: 'stops',
      );
    }
    await CompanyCloudStorage.markCloudInitialized('stops');
    return stops;
  }

  static Future<void> saveAll(List<Stop> stops) async {
    await CompanyCloudStorage.replaceCollection(
      collectionName: 'stops',
      items: stops.map((stop) => stop.toJson()).toList(),
      limitField: 'maxStops',
      usageField: 'stops',
    );
    await _writeCache(stops);
    await CompanyCloudStorage.markCloudInitialized('stops');
  }

  static Future<void> _writeCache(List<Stop> stops) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_stopsKey),
      value: jsonEncode(stops.map((stop) => stop.toJson()).toList()),
    );
  }
}
