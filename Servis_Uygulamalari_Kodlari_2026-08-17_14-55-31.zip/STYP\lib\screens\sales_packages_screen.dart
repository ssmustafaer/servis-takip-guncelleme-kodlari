import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class SalesPackage {
  const SalesPackage({
    required this.id,
    required this.name,
    required this.annualPrice,
    required this.institutionLimit,
    required this.vehicleLimit,
    required this.driverLimit,
    required this.personnelLimit,
    required this.monthlyMapLimit,
    required this.monthlyWhatsAppLimit,
    required this.reportHistoryDays,
    required this.allReports,
    required this.excelPdfReports,
    required this.brandedReports,
    required this.automaticReports,
    required this.adsEnabled,
    required this.prioritySupport,
    required this.deletedRecordsDays,
    required this.sortOrder,
    this.imageAsset = '',
    this.imageUrl = '',
    this.imageDocumentId = '',
    this.imageData = '',
    this.imageMimeType = '',
  });

  final String id;
  final String name;
  final int annualPrice;
  final int institutionLimit;
  final int vehicleLimit;
  final int driverLimit;
  final int personnelLimit;
  final int monthlyMapLimit;
  final int monthlyWhatsAppLimit;
  final int reportHistoryDays;
  final bool allReports;
  final bool excelPdfReports;
  final bool brandedReports;
  final bool automaticReports;
  final bool adsEnabled;
  final bool prioritySupport;
  final int deletedRecordsDays;
  final int sortOrder;
  final String imageAsset;
  final String imageUrl;
  final String imageDocumentId;
  final String imageData;
  final String imageMimeType;

  bool get unlimitedMap => monthlyMapLimit == 0;
  bool get unlimitedWhatsApp => monthlyWhatsAppLimit == 0;
  bool get unlimitedReportHistory => reportHistoryDays == 0;
  bool get unlimitedDeletedRecords => deletedRecordsDays == 0;

  Map<String, Object> toMap() => {
    'id': id,
    'name': name,
    'annualPrice': annualPrice,
    'durationDays': id == 'free' ? 0 : 365,
    'institutionLimit': institutionLimit,
    'vehicleLimit': vehicleLimit,
    'driverLimit': driverLimit,
    'personnelLimit': personnelLimit,
    'monthlyMapLimit': monthlyMapLimit,
    'monthlyWhatsAppLimit': monthlyWhatsAppLimit,
    'reportHistoryDays': reportHistoryDays,
    'allReports': allReports,
    'excelPdfReports': excelPdfReports,
    'brandedReports': brandedReports,
    'automaticReports': automaticReports,
    'adsEnabled': adsEnabled,
    'prioritySupport': prioritySupport,
    'deletedRecordsDays': deletedRecordsDays,
    'active': true,
    'sortOrder': sortOrder,
    'imageAsset': imageAsset,
    'imageUrl': imageUrl,
    'imageDocumentId': imageDocumentId,
  };

  factory SalesPackage.fromMap(
    Map<String, dynamic> map, {
    String imageData = '',
    String imageMimeType = '',
  }) => SalesPackage(
    id: map['id']?.toString() ?? '',
    name: map['name']?.toString() ?? '',
    annualPrice: (map['annualPrice'] as num?)?.toInt() ?? 0,
    institutionLimit: (map['institutionLimit'] as num?)?.toInt() ?? 0,
    vehicleLimit: (map['vehicleLimit'] as num?)?.toInt() ?? 0,
    driverLimit: (map['driverLimit'] as num?)?.toInt() ?? 0,
    personnelLimit: (map['personnelLimit'] as num?)?.toInt() ?? 0,
    monthlyMapLimit: (map['monthlyMapLimit'] as num?)?.toInt() ?? 0,
    monthlyWhatsAppLimit: (map['monthlyWhatsAppLimit'] as num?)?.toInt() ?? 0,
    reportHistoryDays: (map['reportHistoryDays'] as num?)?.toInt() ?? 0,
    allReports: map['allReports'] as bool? ?? false,
    excelPdfReports: map['excelPdfReports'] as bool? ?? false,
    brandedReports: map['brandedReports'] as bool? ?? false,
    automaticReports: map['automaticReports'] as bool? ?? false,
    adsEnabled: map['adsEnabled'] as bool? ?? true,
    prioritySupport: map['prioritySupport'] as bool? ?? false,
    deletedRecordsDays: (map['deletedRecordsDays'] as num?)?.toInt() ?? 0,
    sortOrder: (map['sortOrder'] as num?)?.toInt() ?? 0,
    imageAsset: map['imageAsset']?.toString() ?? '',
    imageUrl: map['imageUrl']?.toString() ?? '',
    imageDocumentId: map['imageDocumentId']?.toString() ?? '',
    imageData: imageData,
    imageMimeType: imageMimeType,
  );
}

class SalesPackagesScreen extends StatefulWidget {
  const SalesPackagesScreen({super.key});

  @override
  State<SalesPackagesScreen> createState() => _SalesPackagesScreenState();
}

class _SalesPackagesScreenState extends State<SalesPackagesScreen> {
  final _document = FirebaseFirestore.instance
      .collection('systemSettings')
      .doc('salesPackages');
  final _imagePicker = ImagePicker();
  List<SalesPackage> _packages = const [];
  bool _loading = true;
  bool _saving = false;

  static const _defaults = [
    SalesPackage(
      id: 'free',
      name: 'Ücretsiz',
      annualPrice: 0,
      institutionLimit: 2,
      vehicleLimit: 1,
      driverLimit: 1,
      personnelLimit: 50,
      monthlyMapLimit: 5,
      monthlyWhatsAppLimit: 5,
      reportHistoryDays: 7,
      allReports: false,
      excelPdfReports: false,
      brandedReports: false,
      automaticReports: false,
      adsEnabled: true,
      prioritySupport: false,
      deletedRecordsDays: 7,
      sortOrder: 1,
    ),
    SalesPackage(
      id: 'standard',
      name: 'Standart',
      annualPrice: 2000,
      institutionLimit: 10,
      vehicleLimit: 3,
      driverLimit: 6,
      personnelLimit: 200,
      monthlyMapLimit: 0,
      monthlyWhatsAppLimit: 0,
      reportHistoryDays: 0,
      allReports: true,
      excelPdfReports: false,
      brandedReports: false,
      automaticReports: false,
      adsEnabled: true,
      prioritySupport: false,
      deletedRecordsDays: 0,
      sortOrder: 2,
    ),
    SalesPackage(
      id: 'professional',
      name: 'Profesyonel',
      annualPrice: 5000,
      institutionLimit: 30,
      vehicleLimit: 10,
      driverLimit: 20,
      personnelLimit: 750,
      monthlyMapLimit: 0,
      monthlyWhatsAppLimit: 0,
      reportHistoryDays: 0,
      allReports: true,
      excelPdfReports: true,
      brandedReports: true,
      automaticReports: true,
      adsEnabled: false,
      prioritySupport: true,
      deletedRecordsDays: 0,
      sortOrder: 3,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final snapshot = await _document.get();
      final raw = snapshot.data()?['packages'] as List<dynamic>?;
      final packageMaps =
          raw
              ?.whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .where((item) => (item['id']?.toString() ?? '').isNotEmpty)
              .toList() ??
          <Map<String, dynamic>>[];
      var packages = <SalesPackage>[];
      for (final map in packageMaps) {
        final imageDocumentId = map['imageDocumentId']?.toString() ?? '';
        var imageData = '';
        var imageMimeType = '';
        if (imageDocumentId.isNotEmpty) {
          final imageSnapshot = await FirebaseFirestore.instance
              .collection('systemSettings')
              .doc(imageDocumentId)
              .get();
          imageData = imageSnapshot.data()?['data']?.toString() ?? '';
          imageMimeType = imageSnapshot.data()?['mimeType']?.toString() ?? '';
        }
        packages.add(
          SalesPackage.fromMap(
            map,
            imageData: imageData,
            imageMimeType: imageMimeType,
          ),
        );
      }
      if (packages.isEmpty) {
        packages = List<SalesPackage>.from(_defaults);
        await _save(packages, showMessage: false);
      }
      packages.sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
      if (mounted) setState(() => _packages = packages);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Paketler alınamadı: $error')));
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save(
    List<SalesPackage> packages, {
    bool showMessage = true,
  }) async {
    setState(() => _saving = true);
    try {
      await _document.set({
        'packages': packages.map((item) => item.toMap()).toList(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (mounted) setState(() => _packages = packages);
      if (showMessage && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Satış paketi kaydedildi.')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _edit(SalesPackage package) async {
    final price = TextEditingController(text: '${package.annualPrice}');
    final institutions = TextEditingController(
      text: '${package.institutionLimit}',
    );
    final vehicles = TextEditingController(text: '${package.vehicleLimit}');
    final drivers = TextEditingController(text: '${package.driverLimit}');
    final personnel = TextEditingController(text: '${package.personnelLimit}');
    final mapLimit = TextEditingController(text: '${package.monthlyMapLimit}');
    final whatsAppLimit = TextEditingController(
      text: '${package.monthlyWhatsAppLimit}',
    );
    final reportDays = TextEditingController(
      text: '${package.reportHistoryDays}',
    );
    final deletedDays = TextEditingController(
      text: '${package.deletedRecordsDays}',
    );
    var allReports = package.allReports;
    var excelPdf = package.excelPdfReports;
    var branded = package.brandedReports;
    var automatic = package.automaticReports;
    var ads = package.adsEnabled;
    var priority = package.prioritySupport;
    var imageAsset = package.imageAsset;
    var imageUrl = package.imageUrl;
    var imageDocumentId = package.imageDocumentId;
    var imageData = package.imageData;
    var imageMimeType = package.imageMimeType;
    var uploadingImage = false;

    final result = await showDialog<SalesPackage>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text('${package.name} Paketini Düzenle'),
          content: SizedBox(
            width: 520,
            child: SingleChildScrollView(
              child: Column(
                children: [
                  _numberField(price, 'Yıllık ücret (TL)'),
                  _numberField(institutions, 'Kurum sınırı'),
                  _numberField(vehicles, 'Araç sınırı'),
                  _numberField(drivers, 'Şoför hesabı sınırı'),
                  _numberField(personnel, 'Personel sınırı'),
                  _numberField(mapLimit, 'Aylık harita (0 = sınırsız)'),
                  _numberField(whatsAppLimit, 'Aylık WhatsApp (0 = sınırsız)'),
                  _numberField(reportDays, 'Rapor geçmişi (0 = sınırsız)'),
                  _numberField(
                    deletedDays,
                    'Silinen kayıt süresi (0 = sınırsız)',
                  ),
                  SwitchListTile(
                    value: allReports,
                    onChanged: (v) => setDialogState(() => allReports = v),
                    title: const Text('Tüm raporlar'),
                  ),
                  SwitchListTile(
                    value: excelPdf,
                    onChanged: (v) => setDialogState(() => excelPdf = v),
                    title: const Text('Excel/PDF raporları'),
                  ),
                  SwitchListTile(
                    value: branded,
                    onChanged: (v) => setDialogState(() => branded = v),
                    title: const Text('Şirket logolu rapor'),
                  ),
                  SwitchListTile(
                    value: automatic,
                    onChanged: (v) => setDialogState(() => automatic = v),
                    title: const Text('Otomatik rapor gönderimi'),
                  ),
                  SwitchListTile(
                    value: ads,
                    onChanged: (v) => setDialogState(() => ads = v),
                    title: const Text('Reklam göster'),
                  ),
                  SwitchListTile(
                    value: priority,
                    onChanged: (v) => setDialogState(() => priority = v),
                    title: const Text('Öncelikli destek'),
                  ),
                  const SizedBox(height: 12),
                  if (imageAsset.isNotEmpty ||
                      imageUrl.isNotEmpty ||
                      imageData.isNotEmpty) ...[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: _packageImage(
                        imageAsset: imageAsset,
                        imageUrl: imageUrl,
                        imageData: imageData,
                        errorText: 'Görsel önizlemesi açılamadı.',
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: uploadingImage
                              ? null
                              : () async {
                                  setDialogState(() => uploadingImage = true);
                                  try {
                                    final selected = await _pickImage();
                                    if (selected != null &&
                                        dialogContext.mounted) {
                                      setDialogState(() {
                                        imageData = selected.data;
                                        imageMimeType = selected.mimeType;
                                        imageDocumentId =
                                            'salesPackageImage_${package.id}';
                                        imageAsset = '';
                                        imageUrl = '';
                                      });
                                    }
                                  } catch (error) {
                                    if (dialogContext.mounted) {
                                      ScaffoldMessenger.of(
                                        dialogContext,
                                      ).showSnackBar(
                                        SnackBar(
                                          content: Text(
                                            'Görsel yüklenemedi: $error',
                                          ),
                                        ),
                                      );
                                    }
                                  } finally {
                                    if (dialogContext.mounted) {
                                      setDialogState(
                                        () => uploadingImage = false,
                                      );
                                    }
                                  }
                                },
                          icon: uploadingImage
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Icon(Icons.add_photo_alternate_rounded),
                          label: Text(
                            uploadingImage
                                ? 'YÜKLENİYOR...'
                                : imageAsset.isEmpty &&
                                      imageUrl.isEmpty &&
                                      imageData.isEmpty
                                ? 'GÖRSEL YÜKLE'
                                : 'GÖRSELİ YENİDEN YÜKLE',
                          ),
                        ),
                      ),
                      if (imageAsset.isNotEmpty ||
                          imageUrl.isNotEmpty ||
                          imageData.isNotEmpty) ...[
                        const SizedBox(width: 8),
                        IconButton.filledTonal(
                          onPressed: uploadingImage
                              ? null
                              : () => setDialogState(() {
                                  imageAsset = '';
                                  imageUrl = '';
                                  imageDocumentId = '';
                                  imageData = '';
                                  imageMimeType = '';
                                }),
                          icon: const Icon(Icons.delete_outline_rounded),
                          tooltip: 'Görseli kaldır',
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('VAZGEÇ'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(
                dialogContext,
                SalesPackage(
                  id: package.id,
                  name: package.name,
                  annualPrice: _int(price),
                  institutionLimit: _int(institutions),
                  vehicleLimit: _int(vehicles),
                  driverLimit: _int(drivers),
                  personnelLimit: _int(personnel),
                  monthlyMapLimit: _int(mapLimit),
                  monthlyWhatsAppLimit: _int(whatsAppLimit),
                  reportHistoryDays: _int(reportDays),
                  allReports: allReports,
                  excelPdfReports: excelPdf,
                  brandedReports: branded,
                  automaticReports: automatic,
                  adsEnabled: ads,
                  prioritySupport: priority,
                  deletedRecordsDays: _int(deletedDays),
                  sortOrder: package.sortOrder,
                  imageAsset: imageAsset,
                  imageUrl: imageUrl,
                  imageDocumentId: imageDocumentId,
                  imageData: imageData,
                  imageMimeType: imageMimeType,
                ),
              ),
              child: const Text('KAYDET'),
            ),
          ],
        ),
      ),
    );
    if (result == null) return;
    final updated = [
      for (final item in _packages) item.id == result.id ? result : item,
    ];
    await _savePackageImage(result);
    await _save(updated);
  }

  int _int(TextEditingController controller) =>
      int.tryParse(controller.text.trim()) ?? 0;

  Future<({String data, String mimeType})?> _pickImage() async {
    final image = await _imagePicker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1400,
      imageQuality: 75,
    );
    if (image == null) return null;
    final bytes = await image.readAsBytes();
    if (bytes.length > 700000) {
      throw Exception('Görsel çok büyük. Daha küçük bir görsel seçin.');
    }
    final mimeType = image.name.toLowerCase().endsWith('.png')
        ? 'image/png'
        : 'image/jpeg';
    return (data: base64Encode(bytes), mimeType: mimeType);
  }

  Future<void> _savePackageImage(SalesPackage package) async {
    final imageDocument = FirebaseFirestore.instance
        .collection('systemSettings')
        .doc('salesPackageImage_${package.id}');
    if (package.imageData.isEmpty) {
      final snapshot = await imageDocument.get();
      if (snapshot.exists) await imageDocument.delete();
      return;
    }
    await imageDocument.set({
      'data': package.imageData,
      'mimeType': package.imageMimeType,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Widget _packageImage({
    required String imageAsset,
    required String imageUrl,
    required String imageData,
    required String errorText,
    double? width,
  }) {
    final error = SizedBox(height: 120, child: Center(child: Text(errorText)));
    if (imageData.isNotEmpty) {
      return Image.memory(
        base64Decode(imageData),
        width: width,
        fit: BoxFit.contain,
        errorBuilder: (_, _, _) => error,
      );
    }
    if (imageUrl.isNotEmpty) {
      return Image.network(
        imageUrl,
        width: width,
        fit: BoxFit.contain,
        errorBuilder: (_, _, _) => error,
      );
    }
    return Image.asset(
      imageAsset,
      width: width,
      fit: BoxFit.contain,
      errorBuilder: (_, _, _) => error,
    );
  }

  Widget _numberField(TextEditingController controller, String label) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: label),
        ),
      );

  String _limit(int value, {String suffix = ''}) =>
      value == 0 ? 'Sınırsız' : '$value$suffix';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Satış Paketleri')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: _packages.length,
                itemBuilder: (context, index) {
                  final package = _packages[index];
                  return Card(
                    child: ExpansionTile(
                      leading: CircleAvatar(
                        child: Text('${package.sortOrder}'),
                      ),
                      title: Text(
                        package.name,
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      subtitle: Text(
                        package.annualPrice == 0
                            ? 'Ücretsiz'
                            : '${package.annualPrice} TL / yıl',
                      ),
                      trailing: IconButton(
                        onPressed: _saving ? null : () => _edit(package),
                        icon: const Icon(Icons.edit_rounded),
                        tooltip: 'Düzenle',
                      ),
                      childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 16),
                      children: [
                        if (package.imageAsset.isNotEmpty ||
                            package.imageUrl.isNotEmpty ||
                            package.imageData.isNotEmpty) ...[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: _packageImage(
                              imageAsset: package.imageAsset,
                              imageUrl: package.imageUrl,
                              imageData: package.imageData,
                              width: double.infinity,
                              errorText: 'Paket görseli açılamadı.',
                            ),
                          ),
                          const SizedBox(height: 12),
                        ],
                        _row('Kurum', '${package.institutionLimit}'),
                        _row('Araç', '${package.vehicleLimit}'),
                        _row('Şoför hesabı', '${package.driverLimit}'),
                        _row('Personel', '${package.personnelLimit}'),
                        _row(
                          'Harita',
                          _limit(package.monthlyMapLimit, suffix: '/ay'),
                        ),
                        _row(
                          'WhatsApp',
                          _limit(package.monthlyWhatsAppLimit, suffix: '/ay'),
                        ),
                        _row(
                          'Rapor geçmişi',
                          _limit(package.reportHistoryDays, suffix: ' gün'),
                        ),
                        _row(
                          'Tüm raporlar',
                          package.allReports ? 'Var' : 'Yok',
                        ),
                        _row(
                          'Excel/PDF',
                          package.excelPdfReports ? 'Var' : 'Yok',
                        ),
                        _row('Reklam', package.adsEnabled ? 'Var' : 'Yok'),
                        _row(
                          'Öncelikli destek',
                          package.prioritySupport ? 'Var' : 'Yok',
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
    );
  }

  Widget _row(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      children: [
        Expanded(child: Text(label)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
      ],
    ),
  );
}
