import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/driver.dart';
import 'company_cloud_storage.dart';

class DriverStorage {
  DriverStorage._();

  static const _key = 'drivers';
  static const _selectedDriverKey = 'selected_driver_id';
  static const _storage = FlutterSecureStorage();

  static Future<List<Driver>> readAll() async {
    final cloudData = await CompanyCloudStorage.readCollection('drivers');
    if (cloudData.isNotEmpty) {
      final drivers = cloudData.map(Driver.fromJson).toList();
      await _writeCache(drivers);
      await CompanyCloudStorage.markCloudInitialized('drivers');
      return drivers;
    }
    if (await CompanyCloudStorage.isCloudInitialized('drivers')) return [];
    final saved =
        await _storage.read(key: await CompanyCloudStorage.cacheKey(_key)) ??
        await _storage.read(key: _key);
    if (saved == null || saved.isEmpty) {
      await CompanyCloudStorage.markCloudInitialized('drivers');
      return [];
    }
    final drivers = (jsonDecode(saved) as List<dynamic>)
        .map((item) => Driver.fromJson(item as Map<String, dynamic>))
        .toList();
    if (await CompanyCloudStorage.canClaimLegacyData()) {
      await CompanyCloudStorage.replaceCollection(
        collectionName: 'drivers',
        items: drivers.map((driver) => driver.toJson()).toList(),
      );
    }
    await CompanyCloudStorage.markCloudInitialized('drivers');
    return drivers;
  }

  static Future<void> saveAll(List<Driver> drivers) async {
    await CompanyCloudStorage.replaceCollection(
      collectionName: 'drivers',
      items: drivers.map((driver) => driver.toJson()).toList(),
    );
    await _writeCache(drivers);
    await CompanyCloudStorage.markCloudInitialized('drivers');
  }

  static Future<void> _writeCache(List<Driver> drivers) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_key),
      value: jsonEncode(drivers.map((driver) => driver.toJson()).toList()),
    );
  }

  static Future<String?> readSelectedId() async => _storage.read(
    key: await CompanyCloudStorage.cacheKey(_selectedDriverKey),
  );

  static Future<void> saveSelectedId(String id) async => _storage.write(
    key: await CompanyCloudStorage.cacheKey(_selectedDriverKey),
    value: id,
  );
}
