import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import '../models/stop.dart';
import '../models/institution.dart';
import '../services/institution_storage.dart';
import '../services/stop_preference_storage.dart';
import 'map_picker_screen.dart';

class StopFormScreen extends StatefulWidget {
  const StopFormScreen({this.stop, this.initialInstitutionId, super.key});

  final Stop? stop;
  final String? initialInstitutionId;

  @override
  State<StopFormScreen> createState() => _StopFormScreenState();
}

class _StopFormScreenState extends State<StopFormScreen> {
  static const _bayrakliMunicipality = LatLng(38.461926, 27.189566);

  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _orderController = TextEditingController();
  final _noteController = TextEditingController();
  LatLng? _location;
  bool _gettingLocation = false;
  bool _loadingInstitutions = true;
  List<Institution> _institutions = [];
  String? _rootInstitutionId;
  String? _childInstitutionId;
  String? _grandchildInstitutionId;
  Institution? _selectedInstitution;

  @override
  void initState() {
    super.initState();
    final stop = widget.stop;
    if (stop != null) {
      _nameController.text = stop.name;
      _orderController.text = stop.order.toString();
      _noteController.text = stop.note;
      if (stop.hasLocation) {
        _location = LatLng(stop.latitude, stop.longitude);
      }
    }
    _loadInstitutions();
  }

  List<Institution> _children(String? parentId) {
    return Institution.childrenOf(
      _institutions,
      parentId,
    ).where((item) => item.active).toList();
  }

  List<Institution> _pathFor(Institution institution) {
    final byId = {for (final item in _institutions) item.id: item};
    final path = <Institution>[institution];
    var parentId = institution.parentId;
    final visited = <String>{institution.id};
    while (parentId != null && parentId.isNotEmpty && visited.add(parentId)) {
      final parent = byId[parentId];
      if (parent == null) break;
      path.insert(0, parent);
      parentId = parent.parentId;
    }
    return path;
  }

  Future<void> _loadInstitutions() async {
    final institutions = await InstitutionStorage.readAll();
    final preferredId = widget.stop?.institutionId.isNotEmpty == true
        ? widget.stop!.institutionId
        : widget.initialInstitutionId ??
              await StopPreferenceStorage.readInstitutionId();
    if (!mounted) return;
    setState(() {
      _institutions = institutions;
      Institution? selected;
      for (final item in institutions) {
        if (item.id == preferredId) {
          selected = item;
          break;
        }
      }
      if (selected != null) {
        final path = _pathFor(selected);
        _rootInstitutionId = path.isNotEmpty ? path[0].id : null;
        _childInstitutionId = path.length > 1 ? path[1].id : null;
        _grandchildInstitutionId = path.length > 2 ? path[2].id : null;
        _selectedInstitution = selected;
      }
      _loadingInstitutions = false;
    });
  }

  void _selectRoot(String? id) {
    setState(() {
      _rootInstitutionId = id;
      _childInstitutionId = null;
      _grandchildInstitutionId = null;
      _selectedInstitution = null;
      if (id != null && _children(id).isEmpty) {
        _selectedInstitution = _institutions.firstWhere(
          (item) => item.id == id,
        );
      }
    });
  }

  void _selectChild(String? id) {
    setState(() {
      _childInstitutionId = id;
      _grandchildInstitutionId = null;
      _selectedInstitution = id == null
          ? null
          : _institutions.firstWhere((item) => item.id == id);
    });
  }

  void _selectGrandchild(String? id) {
    setState(() {
      _grandchildInstitutionId = id == null || id.isEmpty ? null : id;
      final selectedId = _grandchildInstitutionId ?? _childInstitutionId;
      _selectedInstitution = selectedId == null
          ? null
          : _institutions.firstWhere((item) => item.id == selectedId);
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _orderController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _chooseOnMap() async {
    final location = await Navigator.of(context).push<LatLng>(
      MaterialPageRoute(
        builder: (_) => MapPickerScreen(
          initialLocation: _location ?? _bayrakliMunicipality,
          selectedLocation: _location,
        ),
      ),
    );
    if (location != null && mounted) setState(() => _location = location);
  }

  Future<void> _useCurrentLocation() async {
    if (_gettingLocation) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        content: const Text(
          'Mevcut konumu bu durak için kaydetmek istediğinize emin misiniz?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('İptal'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Evet, Kaydet'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    if (!await Geolocator.isLocationServiceEnabled()) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Telefonun konum hizmetini açın.')),
      );
      return;
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Konum izni verilmedi.')));
      return;
    }

    if (mounted) setState(() => _gettingLocation = true);
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      if (!mounted) return;
      setState(() => _location = LatLng(position.latitude, position.longitude));
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Mevcut konum alınamadı.')));
    } finally {
      if (mounted) setState(() => _gettingLocation = false);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final institution = _selectedInstitution;
    if (institution == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Durak için kayıt grubunu seçin.')),
      );
      return;
    }
    await StopPreferenceStorage.saveInstitutionId(institution.id);
    if (!mounted) return;
    Navigator.of(context).pop(
      Stop(
        id: widget.stop?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        name: _nameController.text.trim(),
        order: int.parse(_orderController.text),
        latitude: _location?.latitude ?? 0,
        longitude: _location?.longitude ?? 0,
        note: _noteController.text.trim(),
        institutionId: institution.id,
        institutionName: Institution.pathLabel(_institutions, institution),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final roots = _children(null);
    final children = _rootInstitutionId == null
        ? <Institution>[]
        : _children(_rootInstitutionId);
    final grandchildren = _childInstitutionId == null
        ? <Institution>[]
        : _children(_childInstitutionId);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.stop == null ? 'Durak Ekle' : 'Durağı Düzenle'),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              if (_loadingInstitutions)
                const LinearProgressIndicator()
              else ...[
                DropdownButtonFormField<String>(
                  key: ValueKey('stop-root-$_rootInstitutionId'),
                  initialValue: _rootInstitutionId,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Kurum Seçimi',
                    prefixIcon: Icon(Icons.domain_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: roots
                      .map(
                        (item) => DropdownMenuItem(
                          value: item.id,
                          child: Text(item.name),
                        ),
                      )
                      .toList(),
                  onChanged: _selectRoot,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  key: ValueKey(
                    'stop-child-$_rootInstitutionId-$_childInstitutionId',
                  ),
                  initialValue: _childInstitutionId,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Bölge Seçimi',
                    prefixIcon: Icon(Icons.account_tree_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: children
                      .map(
                        (item) => DropdownMenuItem(
                          value: item.id,
                          child: Text(item.name),
                        ),
                      )
                      .toList(),
                  onChanged: children.isEmpty ? null : _selectChild,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  key: ValueKey(
                    'stop-grandchild-$_childInstitutionId-$_grandchildInstitutionId',
                  ),
                  initialValue: _grandchildInstitutionId,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Takım Seçimi (İsteğe Bağlı)',
                    prefixIcon: Icon(Icons.subdirectory_arrow_right_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    const DropdownMenuItem(
                      value: '',
                      child: Text('Takım seçmeden devam et'),
                    ),
                    ...grandchildren.map(
                        (item) => DropdownMenuItem(
                          value: item.id,
                          child: Text(item.name),
                        ),
                      ),
                  ],
                  onChanged: grandchildren.isEmpty ? null : _selectGrandchild,
                ),
                const SizedBox(height: 16),
              ],
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Durak Adı',
                  prefixIcon: Icon(Icons.location_on_outlined),
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Durak adı girin.'
                    : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _orderController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(
                  labelText: 'Güzergâh Sırası',
                  prefixIcon: Icon(Icons.format_list_numbered_rounded),
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    value == null || int.tryParse(value) == null
                    ? 'Güzergâh sırası için sayı girin.'
                    : null,
              ),
              const SizedBox(height: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  OutlinedButton.icon(
                    onPressed: _gettingLocation ? null : _chooseOnMap,
                    icon: const Icon(Icons.map_outlined),
                    label: const Text('KONUM AYARLA'),
                  ),
                  const SizedBox(height: 10),
                  FilledButton.tonalIcon(
                    onPressed: _gettingLocation ? null : _useCurrentLocation,
                    icon: const Icon(Icons.my_location_rounded),
                    label: Text(
                      _gettingLocation
                          ? 'KONUM ALINIYOR...'
                          : 'MEVCUT KONUMU KAYDET',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ],
              ),
              if (_location == null)
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text(
                    'Konum isteğe bağlıdır; konumsuz durak güzergahta görünmez.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Color(0xFF52657B)),
                  ),
                ),
              if (_location != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(
                    'Konum: ${_location!.latitude.toStringAsFixed(5)}, ${_location!.longitude.toStringAsFixed(5)}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Color(0xFF0B6E4F)),
                  ),
                ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _noteController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Açıklama (isteğe bağlı)',
                  prefixIcon: Icon(Icons.note_alt_outlined),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                height: 54,
                child: FilledButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.save_rounded),
                  label: Text(
                    widget.stop == null
                        ? 'DURAĞI KAYDET'
                        : 'DEĞİŞİKLİKLERİ KAYDET',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
