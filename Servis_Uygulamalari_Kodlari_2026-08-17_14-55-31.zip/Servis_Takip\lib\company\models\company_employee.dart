import 'package:cloud_firestore/cloud_firestore.dart';

class CompanyEmployee {
  const CompanyEmployee({
    required this.id,
    required this.displayName,
    required this.phone,
    required this.role,
    required this.active,
    required this.permissions,
    required this.allowedInstitutionIds,
    required this.allInstitutions,
    required this.allowedVehicleIds,
    required this.allVehicles,
    this.address = '',
    this.district = '',
    this.city = '',
    this.latitude,
    this.longitude,
  });

  static const ownerRole = 'owner';
  static const administrativeRole = 'administrative';
  static const driverRole = 'driver';

  final String id;
  final String displayName;
  final String phone;
  final String role;
  final bool active;
  final Map<String, bool> permissions;
  final List<String> allowedInstitutionIds;
  final bool allInstitutions;
  final List<String> allowedVehicleIds;
  final bool allVehicles;
  final String address;
  final String district;
  final String city;
  final double? latitude;
  final double? longitude;

  bool get isOwner => role == ownerRole || role == 'company_admin';

  String get positionName => switch (role) {
    ownerRole || 'company_admin' => 'Sahibi',
    administrativeRole => 'İdari Personel',
    _ => 'Şoför',
  };

  factory CompanyEmployee.fromDocument(
    DocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data() ?? const <String, dynamic>{};
    return CompanyEmployee(
      id: document.id,
      displayName: data['displayName'] as String? ?? 'İsimsiz Kullanıcı',
      phone: data['phone'] as String? ?? '',
      role: data['role'] as String? ?? driverRole,
      active: data['active'] as bool? ?? false,
      permissions: (data['permissions'] as Map<String, dynamic>? ?? const {})
          .map((key, value) => MapEntry(key, value == true)),
      allowedInstitutionIds:
          (data['allowedInstitutionIds'] as List<dynamic>? ?? const [])
              .map((value) => value.toString())
              .toList(),
      allInstitutions: data['allInstitutions'] as bool? ?? true,
      allowedVehicleIds:
          (data['allowedVehicleIds'] as List<dynamic>? ?? const [])
              .map((value) => value.toString())
              .toList(),
      allVehicles: data['allVehicles'] as bool? ?? true,
      address: data['address'] as String? ?? '',
      district: data['district'] as String? ?? '',
      city: data['city'] as String? ?? '',
      latitude: (data['latitude'] as num?)?.toDouble(),
      longitude: (data['longitude'] as num?)?.toDouble(),
    );
  }
}
