import 'package:flutter/material.dart';

import '../models/shift_definition.dart';
import '../services/shift_definition_storage.dart';
import '../services/shift_time_storage.dart';

class ShiftTimesScreen extends StatefulWidget {
  const ShiftTimesScreen({super.key});

  @override
  State<ShiftTimesScreen> createState() => _ShiftTimesScreenState();
}

class _ShiftTimesScreenState extends State<ShiftTimesScreen> {
  bool _loading = true;
  List<ShiftTimeSlot> _items = [];
  List<ShiftDefinition> _definitions = [];

  static final _choices = [
    for (var value = 0; value < 24 * 60; value += 30) value,
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final definitions = await ShiftDefinitionStorage.readAll();
      var items = await ShiftTimeStorage.readAll();
      if (items.isEmpty) {
        final byTime = <String, ShiftTimeSlot>{};
        for (final definition in definitions) {
          for (final slot in definition.slots) {
            final key = '${slot.startMinutes}_${slot.endMinutes}';
            byTime[key] = ShiftTimeSlot(
              id: key,
              startMinutes: slot.startMinutes,
              endMinutes: slot.endMinutes,
              workdayOffset: slot.workdayOffset,
            );
          }
        }
        items = byTime.values.toList();
        if (items.isNotEmpty) {
          try {
            await ShiftTimeStorage.saveAll(items);
          } catch (_) {
            // Kurallar henüz yayınlanmadıysa liste yine de ekranda gösterilir.
          }
        }
      }
      if (!mounted) return;
      setState(() {
        _definitions = definitions;
        _items = items
          ..sort((a, b) => a.startMinutes.compareTo(b.startMinutes));
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      _message('Vardiya saatleri yüklenemedi: $error');
    }
  }

  String _clock(int minutes) {
    final hour = minutes ~/ 60;
    final minute = minutes % 60;
    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }

  Future<void> _edit([ShiftTimeSlot? existing]) async {
    var start = existing?.startMinutes ?? 8 * 60;
    var end = existing?.endMinutes ?? 16 * 60;
    var workdayOffset = existing?.workdayOffset ?? 0;
    final result = await showDialog<(int, int, int)>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(
            existing == null ? 'Vardiya Saati Ekle' : 'Saati Düzenle',
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<int>(
                initialValue: start,
                decoration: const InputDecoration(
                  labelText: 'Giriş',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (final value in _choices)
                    DropdownMenuItem(value: value, child: Text(_clock(value))),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setDialogState(() {
                      start = value;
                      workdayOffset = end != 0 && end < start ? 1 : 0;
                    });
                  }
                },
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<int>(
                initialValue: end,
                decoration: const InputDecoration(
                  labelText: 'Çıkış',
                  border: OutlineInputBorder(),
                ),
                items: [
                  for (final value in _choices)
                    DropdownMenuItem(value: value, child: Text(_clock(value))),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setDialogState(() {
                      end = value;
                      workdayOffset = end != 0 && end < start ? 1 : 0;
                    });
                  }
                },
              ),
              const SizedBox(height: 16),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Vardiya Çalışma Kuralı',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
              RadioListTile<int>(
                value: 0,
                groupValue: workdayOffset,
                contentPadding: EdgeInsets.zero,
                title: const Text(
                  'Vardiya bugünün içerisinde değerlendirilir.',
                ),
                onChanged: (value) {
                  if (value != null) {
                    setDialogState(() => workdayOffset = value);
                  }
                },
              ),
              RadioListTile<int>(
                value: 1,
                groupValue: workdayOffset,
                contentPadding: EdgeInsets.zero,
                title: const Text(
                  'Vardiya yarınki gün içerisinde değerlendirilir.',
                ),
                onChanged: (value) {
                  if (value != null) {
                    setDialogState(() => workdayOffset = value);
                  }
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('VAZGEÇ'),
            ),
            FilledButton(
              onPressed: start == end
                  ? null
                  : () => Navigator.pop(context, (start, end, workdayOffset)),
              child: const Text('KAYDET'),
            ),
          ],
        ),
      ),
    );
    if (result == null) return;
    if (_items.any(
      (item) =>
          item.id != existing?.id &&
          item.startMinutes == result.$1 &&
          item.endMinutes == result.$2,
    )) {
      _message('Bu vardiya saati zaten kayıtlı.');
      return;
    }
    final updatedSlot = ShiftTimeSlot(
      id: existing?.id ?? '${result.$1}_${result.$2}',
      startMinutes: result.$1,
      endMinutes: result.$2,
      workdayOffset: result.$3,
    );
    final updatedItems = [
      for (final item in _items)
        if (item.id == existing?.id) updatedSlot else item,
      if (existing == null) updatedSlot,
    ];
    if (existing != null) {
      _definitions = [
        for (final definition in _definitions)
          definition.copyWith(
            slots: [
              for (final slot in definition.slots)
                if (slot.startMinutes == existing.startMinutes &&
                    slot.endMinutes == existing.endMinutes)
                  ShiftTimeSlot(
                    id: slot.id,
                    startMinutes: updatedSlot.startMinutes,
                    endMinutes: updatedSlot.endMinutes,
                    workdayOffset: updatedSlot.workdayOffset,
                  )
                else
                  slot,
            ],
          ),
      ];
      await ShiftDefinitionStorage.saveAll(_definitions);
    }
    await ShiftTimeStorage.saveAll(updatedItems);
    if (!mounted) return;
    setState(() => _items = updatedItems);
  }

  Future<void> _delete(ShiftTimeSlot item) async {
    final used = _definitions.any(
      (definition) => definition.slots.any(
        (slot) =>
            slot.startMinutes == item.startMinutes &&
            slot.endMinutes == item.endMinutes,
      ),
    );
    if (used) {
      _message(
        'Bu saat bir vardiya sisteminde kullanılıyor. Önce sistemden çıkarın.',
      );
      return;
    }
    await ShiftTimeStorage.saveAll(
      _items.where((value) => value.id != item.id).toList(),
    );
    if (mounted) {
      setState(() => _items.removeWhere((value) => value.id == item.id));
    }
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vardiya Saatleri')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _edit,
        icon: const Icon(Icons.add_alarm_rounded),
        label: const Text('Saat Ekle'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
          ? const Center(child: Text('Henüz vardiya saati eklenmedi.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
              itemCount: _items.length,
              itemBuilder: (context, index) {
                final item = _items[index];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(child: Text('${index + 1}')),
                    title: Text(
                      item.label,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${_clock(item.startMinutes)} - ${_clock(item.endMinutes)} • '
                      '${item.workdayOffset == 1 ? 'Yarının çalışma günü' : 'Bugünün çalışma günü'}',
                    ),
                    onTap: () => _edit(item),
                    trailing: IconButton(
                      onPressed: () => _delete(item),
                      icon: const Icon(Icons.delete_outline),
                    ),
                  ),
                );
              },
            ),
    );
  }
}
