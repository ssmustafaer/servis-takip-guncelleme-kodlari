import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../company/models/company_session.dart';

class MyPackageScreen extends StatefulWidget {
  const MyPackageScreen({required this.session, super.key});

  final CompanySession session;

  @override
  State<MyPackageScreen> createState() => _MyPackageScreenState();
}

class _MyPackageScreenState extends State<MyPackageScreen> {
  bool _loading = true;
  String? _error;
  Map<String, dynamic> _company = const {};
  List<Map<String, dynamic>> _packages = const [];
  final Set<String> _expandedPackageIds = <String>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final results = await Future.wait([
        FirebaseFirestore.instance
            .collection('companies')
            .doc(widget.session.companyId)
            .get(),
        FirebaseFirestore.instance
            .collection('systemSettings')
            .doc('salesPackages')
            .get(),
      ]);
      final companySnapshot =
          results[0] as DocumentSnapshot<Map<String, dynamic>>;
      final packageSnapshot =
          results[1] as DocumentSnapshot<Map<String, dynamic>>;
      var packages =
          (packageSnapshot.data()?['packages'] as List<dynamic>? ?? const [])
              .whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .where((item) => item['active'] != false)
              .toList();
      packages = await Future.wait(
        packages.map((package) async {
          final imageDocumentId =
              package['imageDocumentId']?.toString().trim() ?? '';
          if (imageDocumentId.isEmpty) return package;
          final imageSnapshot = await FirebaseFirestore.instance
              .collection('systemSettings')
              .doc(imageDocumentId)
              .get();
          return <String, dynamic>{
            ...package,
            'imageData': imageSnapshot.data()?['data']?.toString() ?? '',
            'imageMimeType':
                imageSnapshot.data()?['mimeType']?.toString() ?? '',
          };
        }),
      );
      packages.sort(
        (a, b) => ((a['sortOrder'] as num?)?.toInt() ?? 0).compareTo(
          (b['sortOrder'] as num?)?.toInt() ?? 0,
        ),
      );
      if (!mounted) return;
      setState(() {
        _company = companySnapshot.data() ?? const {};
        _packages = packages;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = 'Paket bilgileri alınamadı: $error';
        _loading = false;
      });
    }
  }

  Map<String, dynamic> get _activePackage {
    final packageId = _company['packageId']?.toString().trim().toLowerCase();
    final planName = _company['planName']?.toString().trim().toLowerCase();
    for (final package in _packages) {
      if (package['id']?.toString().toLowerCase() == packageId ||
          package['name']?.toString().toLowerCase() == planName) {
        return package;
      }
    }
    if ((_company['packageId']?.toString().trim() ?? '').isEmpty &&
        _company.isNotEmpty) {
      final limits = Map<String, dynamic>.from(
        _company['limits'] as Map? ?? const {},
      );
      return <String, dynamic>{
        'id': 'legacy',
        'name': _company['planName']?.toString().trim().isNotEmpty == true
            ? _company['planName'].toString()
            : 'Mevcut Özel Paket',
        'annualPrice': 0,
        'institutionLimit': (limits['maxInstitutions'] as num?)?.toInt() ?? 0,
        'vehicleLimit': (limits['maxVehicles'] as num?)?.toInt() ?? 0,
        'driverLimit': (limits['maxUsers'] as num?)?.toInt() ?? 0,
        'personnelLimit': (limits['maxPersonnel'] as num?)?.toInt() ?? 0,
        'monthlyMapLimit': 0,
        'monthlyWhatsAppLimit': 0,
        'reportHistoryDays': 0,
        'adsEnabled': true,
      };
    }
    return _packages.cast<Map<String, dynamic>?>().firstWhere(
          (item) => item?['id'] == 'free',
          orElse: () => null,
        ) ??
        const <String, dynamic>{
          'id': 'free',
          'name': 'Ücretsiz',
          'annualPrice': 0,
          'institutionLimit': 2,
          'vehicleLimit': 1,
          'driverLimit': 1,
          'personnelLimit': 50,
          'monthlyMapLimit': 5,
          'monthlyWhatsAppLimit': 5,
          'reportHistoryDays': 7,
          'adsEnabled': true,
        };
  }

  Map<String, dynamic> get _usage =>
      Map<String, dynamic>.from(_company['usage'] as Map? ?? const {});

  Map<String, dynamic> get _monthlyUsage {
    final usage = Map<String, dynamic>.from(
      _company['packageUsage'] as Map? ?? const {},
    );
    final now = DateTime.now();
    final month = '${now.year}-${now.month.toString().padLeft(2, '0')}';
    return usage['month'] == month ? usage : const {};
  }

  int _number(Map<String, dynamic> source, String key) =>
      (source[key] as num?)?.toInt() ?? 0;

  String _date(dynamic value) {
    if (value is! Timestamp) return 'Süresiz';
    final date = value.toDate();
    return '${date.day.toString().padLeft(2, '0')}.'
        '${date.month.toString().padLeft(2, '0')}.${date.year}';
  }

  int? get _remainingDays {
    final value = _company['expiresAt'];
    if (value is! Timestamp) return null;
    final difference = value.toDate().difference(DateTime.now());
    return difference.isNegative ? 0 : difference.inDays + 1;
  }

  String _limit(int value, {String suffix = ''}) =>
      value == 0 ? 'Sınırsız' : '$value$suffix';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Paketim')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_error!, textAlign: TextAlign.center),
                    const SizedBox(height: 12),
                    FilledButton(
                      onPressed: _load,
                      child: const Text('TEKRAR DENE'),
                    ),
                  ],
                ),
              ),
            )
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  _currentPackageCard(),
                  const SizedBox(height: 20),
                  const Text(
                    'Paket Seçenekleri',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 10),
                  for (final package in _packages) _packageOption(package),
                ],
              ),
            ),
    );
  }

  Widget _currentPackageCard() {
    final package = _activePackage;
    final name = package['name']?.toString() ?? 'Ücretsiz';
    return Card(
      color: const Color(0xFFEAF3FF),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'MEVCUT PAKET',
              style: TextStyle(color: Colors.blueGrey),
            ),
            const SizedBox(height: 5),
            Text(
              name,
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900),
            ),
            Text('Şirket: ${widget.session.companyName}'),
            Text('Bitiş tarihi: ${_date(_company['expiresAt'])}'),
            if (_remainingDays != null && _remainingDays! <= 30) ...[
              const SizedBox(height: 10),
              _expiryWarning(_remainingDays!),
            ],
            const Divider(height: 28),
            _usageRow(
              'Kurum',
              _number(_usage, 'institutions'),
              _number(package, 'institutionLimit'),
            ),
            _usageRow(
              'Araç',
              _number(_usage, 'vehicles'),
              _number(package, 'vehicleLimit'),
            ),
            _usageRow(
              'Şoför hesabı',
              _number(_usage, 'users'),
              _number(package, 'driverLimit'),
            ),
            _usageRow(
              'Personel',
              _number(_usage, 'personnel'),
              _number(package, 'personnelLimit'),
            ),
            const Divider(height: 28),
            _line(
              'Harita',
              _monthlyFeature(
                used: _number(_monthlyUsage, 'mapCount'),
                limit: _number(package, 'monthlyMapLimit'),
              ),
            ),
            _line(
              'WhatsApp',
              _monthlyFeature(
                used: _number(_monthlyUsage, 'whatsappCount'),
                limit: _number(package, 'monthlyWhatsAppLimit'),
              ),
            ),
            _line(
              'Rapor geçmişi',
              _limit(_number(package, 'reportHistoryDays'), suffix: ' gün'),
            ),
            _line('Reklam', package['adsEnabled'] == false ? 'Yok' : 'Var'),
          ],
        ),
      ),
    );
  }

  Widget _usageRow(String label, int used, int limit) {
    final safeLimit = limit <= 0 ? 1 : limit;
    final progress = (used / safeLimit).clamp(0.0, 1.0);
    return Padding(
      padding: const EdgeInsets.only(bottom: 11),
      child: Column(
        children: [
          _line(label, '$used / $limit'),
          const SizedBox(height: 5),
          LinearProgressIndicator(value: progress),
        ],
      ),
    );
  }

  Widget _expiryWarning(int days) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(
      color: days <= 7 ? const Color(0xFFFFE7E7) : const Color(0xFFFFF3D6),
      borderRadius: BorderRadius.circular(10),
    ),
    child: Text(
      days == 0
          ? 'Paket süreniz doldu. Hesabınız Ücretsiz pakete geçirilecek.'
          : 'Paketinizin bitmesine $days gün kaldı.',
      style: const TextStyle(fontWeight: FontWeight.w800),
    ),
  );

  String _monthlyFeature({required int used, required int limit}) =>
      limit == 0 ? 'Sınırsız' : '$used / $limit kullanıldı';

  Widget _line(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        Expanded(child: Text(label)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
      ],
    ),
  );

  Widget _packageOption(Map<String, dynamic> package) {
    final packageId = package['id']?.toString() ?? '';
    final active = package['id'] == _activePackage['id'];
    final price = _number(package, 'annualPrice');
    final imageAsset = package['imageAsset']?.toString().trim() ?? '';
    final imageUrl = package['imageUrl']?.toString().trim() ?? '';
    final imageData = package['imageData']?.toString().trim() ?? '';
    final canPurchase = !active && price > 0;
    final expanded = _expandedPackageIds.contains(packageId);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF0D477B), Color(0xFF2469A8)],
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    package['name']?.toString() ?? '',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Colors.white,
                    ),
                  ),
                ),
                if (canPurchase) _purchaseButton(package, onHeader: true),
              ],
            ),
          ),
          if (imageAsset.isNotEmpty ||
              imageUrl.isNotEmpty ||
              imageData.isNotEmpty)
            Container(
              padding: const EdgeInsets.fromLTRB(12, 2, 12, 12),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF0D477B), Color(0xFF2469A8)],
                ),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(14),
                  onTap: () => setState(() {
                    if (expanded) {
                      _expandedPackageIds.remove(packageId);
                    } else {
                      _expandedPackageIds.add(packageId);
                    }
                  }),
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: const Color(0xFF008FC7),
                        width: 3,
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: imageData.isNotEmpty
                        ? Image.memory(
                            base64Decode(imageData),
                            width: double.infinity,
                            fit: BoxFit.fitWidth,
                            errorBuilder: (_, _, _) => const SizedBox.shrink(),
                          )
                        : imageUrl.isNotEmpty
                        ? Image.network(
                            imageUrl,
                            width: double.infinity,
                            fit: BoxFit.fitWidth,
                            loadingBuilder: (context, child, progress) =>
                                progress == null
                                ? child
                                : const SizedBox(
                                    height: 160,
                                    child: Center(
                                      child: CircularProgressIndicator(),
                                    ),
                                  ),
                            errorBuilder: (_, _, _) => const SizedBox.shrink(),
                          )
                        : Image.asset(
                            imageAsset,
                            width: double.infinity,
                            fit: BoxFit.fitWidth,
                            errorBuilder: (_, _, _) => const SizedBox.shrink(),
                          ),
                  ),
                ),
              ),
            ),
          if (imageAsset.isNotEmpty ||
              imageUrl.isNotEmpty ||
              imageData.isNotEmpty)
            InkWell(
              onTap: () => setState(() {
                if (expanded) {
                  _expandedPackageIds.remove(packageId);
                } else {
                  _expandedPackageIds.add(packageId);
                }
              }),
              child: Container(
                padding: const EdgeInsets.fromLTRB(12, 5, 12, 9),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF0D477B), Color(0xFF2469A8)],
                  ),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: Colors.white,
                    ),
                    SizedBox(width: 6),
                    Text(
                      'Ayrıntılar',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(width: 6),
                    Icon(
                      Icons.keyboard_arrow_down_rounded,
                      color: Colors.white,
                    ),
                  ],
                ),
              ),
            ),
          AnimatedSize(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeInOut,
            child: expanded
                ? _packageDetailsPanel(package, canPurchase: canPurchase)
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }

  Widget _purchaseButton(
    Map<String, dynamic> package, {
    bool onHeader = false,
  }) => FilledButton.icon(
    style: FilledButton.styleFrom(
      backgroundColor: onHeader ? Colors.white : const Color(0xFF17609C),
      foregroundColor: onHeader ? const Color(0xFF155A93) : Colors.white,
      elevation: onHeader ? 2 : 0,
      side: onHeader ? const BorderSide(color: Colors.white, width: 1.5) : null,
    ),
    onPressed: () => _showPurchasePreparation(package),
    icon: const Icon(Icons.shopping_cart_checkout_rounded),
    label: const Text('SATIN AL'),
  );

  Widget _packageDetailsPanel(
    Map<String, dynamic> package, {
    required bool canPurchase,
  }) => Container(
    margin: const EdgeInsets.fromLTRB(12, 10, 12, 12),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        colors: [Color(0xFF0D477B), Color(0xFF2469A8)],
      ),
      border: Border.all(color: const Color(0xFF4D91C5)),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Column(
      children: [
        _detailRow('Kurum', _limit(_number(package, 'institutionLimit'))),
        _detailRow('Araç', _limit(_number(package, 'vehicleLimit'))),
        _detailRow('Şoför hesabı', _limit(_number(package, 'driverLimit'))),
        _detailRow('Personel', _limit(_number(package, 'personnelLimit'))),
        _detailRow(
          'Harita',
          _limit(_number(package, 'monthlyMapLimit'), suffix: ' / ay'),
        ),
        _detailRow(
          'WhatsApp',
          _limit(_number(package, 'monthlyWhatsAppLimit'), suffix: ' / ay'),
        ),
        _detailRow(
          'Rapor geçmişi',
          _limit(_number(package, 'reportHistoryDays'), suffix: ' gün'),
        ),
        _detailRow(
          'Tüm raporlar',
          package['allReports'] == true ? 'Var' : 'Yok',
        ),
        _detailRow(
          'Excel/PDF',
          package['excelPdfReports'] == true ? 'Var' : 'Yok',
        ),
        _detailRow('Reklam', package['adsEnabled'] == false ? 'Yok' : 'Var'),
        _detailRow(
          'Öncelikli destek',
          package['prioritySupport'] == true ? 'Var' : 'Yok',
        ),
        if (canPurchase) ...[
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerRight,
            child: _purchaseButton(package, onHeader: true),
          ),
        ],
      ],
    ),
  );

  Widget _detailRow(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(
      children: [
        Expanded(
          child: Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.w900,
          ),
        ),
      ],
    ),
  );

  Future<void> _showPurchasePreparation(Map<String, dynamic> package) async {
    final name = package['name']?.toString() ?? 'Paket';
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('$name paketi'),
        content: const Text(
          'Yıllık satın alma Google Play üzerinden yapılacak. Güvenli ödeme '
          'bağlantısı, uygulama Google Play Console’da kalıcı kimliğiyle '
          'oluşturulduktan sonra etkinleşecek.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('TAMAM'),
          ),
        ],
      ),
    );
  }
}
