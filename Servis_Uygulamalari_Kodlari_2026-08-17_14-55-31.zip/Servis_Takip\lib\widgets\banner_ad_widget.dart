import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

import '../services/company_cloud_storage.dart';
import '../services/package_access_service.dart';

/// Ana sayfanın altında gösterilen banner reklam alanı.
///
/// Geliştirme sırasında Google'ın Android test reklam kimliği kullanılır.
/// Uygulama yayınlanmadan önce [adUnitId] gerçek AdMob banner kimliğiyle
/// değiştirilmelidir.
class BannerAdWidget extends StatefulWidget {
  const BannerAdWidget({super.key});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  static const _testAdUnitId =
      'ca-app-pub-3940256099942544/6300978111';
  static const _productionAdUnitId =
      'ca-app-pub-1797921619566606/4386585060';

  static String get adUnitId =>
      kReleaseMode ? _productionAdUnitId : _testAdUnitId;

  BannerAd? _bannerAd;
  bool _isLoaded = false;
  Timer? _retryTimer;
  StreamSubscription<User?>? _authSubscription;
  bool _adsAllowed = true;

  @override
  void initState() {
    super.initState();
    _authSubscription = FirebaseAuth.instance.authStateChanges().listen((_) {
      _refreshAdPermission();
    });
  }

  Future<void> _refreshAdPermission() async {
    var allowed = true;
    try {
      final companyId = await CompanyCloudStorage.companyId();
      if (companyId != null && companyId.isNotEmpty) {
        allowed = await PackageAccessService.adsEnabled(companyId);
      }
    } catch (_) {
      allowed = true;
    }
    if (!mounted) return;
    if (!allowed) {
      _retryTimer?.cancel();
      _bannerAd?.dispose();
      setState(() {
        _adsAllowed = false;
        _bannerAd = null;
        _isLoaded = false;
      });
      return;
    }
    setState(() => _adsAllowed = true);
    if (_bannerAd == null) _loadAd();
  }

  void _loadAd() {
    if (!_adsAllowed) return;
    final ad = BannerAd(
      adUnitId: adUnitId,
      request: const AdRequest(),
      size: AdSize.banner,
      listener: BannerAdListener(
        onAdLoaded: (loadedAd) {
          if (!mounted) {
            loadedAd.dispose();
            return;
          }
          setState(() => _isLoaded = true);
        },
        onAdFailedToLoad: (failedAd, error) {
          failedAd.dispose();
          if (mounted) {
            setState(() {
              _bannerAd = null;
              _isLoaded = false;
            });
            _retryTimer?.cancel();
            _retryTimer = Timer(const Duration(seconds: 2), () {
              if (_adsAllowed) _loadAd();
            });
          }
        },
      ),
    );

    _bannerAd = ad;
    ad.load();
  }

  @override
  void dispose() {
    _authSubscription?.cancel();
    _retryTimer?.cancel();
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ad = _bannerAd;
    if (!_adsAllowed || !_isLoaded || ad == null) {
      return const SizedBox.shrink();
    }

    return SizedBox(
      height: 50,
      child: ColoredBox(
        color: Colors.white,
        child: Center(
          child: ClipRect(
            child: SizedBox(
              width: 320,
              height: 50,
              child: AdWidget(ad: ad),
            ),
          ),
        ),
      ),
    );
  }
}
