@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
title Servis Uygulamalari Menusu

set "WORKSPACE=C:\Users\Mustafa ER\Documents\Codex\2026-08-12\referenced-chatgpt-conversation-this-is-an-2"
set "SERVIS=%WORKSPACE%\Servis_Takip"
set "STYP=%WORKSPACE%\STYP"
set "FLUTTER=C:\src\flutter\bin\flutter.bat"
set "ADB=C:\Users\Mustafa ER\AppData\Local\Android\Sdk\platform-tools\adb.exe"
set "SALES_IMAGES=%STYP%\assets\sales_packages"
set "PHONE_IMAGES=/sdcard/Pictures/Servis_Takip"
set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
set "PATH=%JAVA_HOME%\bin;%PATH%"
set "ORIGINAL_LOCALAPPDATA=%LOCALAPPDATA%"
set "APK_SOURCE=%SERVIS%\build\app\outputs\flutter-apk\app-client-release.apk"
set "APK_TARGET_NAME=Servis_Takip.apk"
set "GITHUB_RELEASE_URL=https://github.com/ssmustafaer/servis-takip-guncelleme/releases/new"
set "GITHUB_APK_URL=https://github.com/ssmustafaer/servis-takip-guncelleme/releases/latest/download/Servis_Takip.apk"
set "GITHUB_REPO=ssmustafaer/servis-takip-guncelleme"
set "GH_DIR=%WORKSPACE%\.tools"
set "GH_EXE=%GH_DIR%\gh.exe"
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('Desktop')"`) do set "DESKTOP=%%D"

if not exist "%FLUTTER%" (
  echo HATA: Flutter bulunamadi: %FLUTTER%
  pause
  exit /b 1
)

:menu
cls
echo =====================================================
echo              SERVIS UYGULAMALARI MENUSU
echo =====================================================
echo.
echo  [1] Servis Takip'i telefonda calistir
echo  [2] STYP'yi telefonda calistir
echo  [3] Masaustune Servis Takip APK olustur
echo  [4] Masaustundeki APK'yi GitHub guncelleme yayinina hazirlar ve gonderir
echo  [5] Resimleri telefona aktar
echo  [0] Cikis
echo.
set /p "SECIM=Seciminiz: "

if "%SECIM%"=="1" goto servis_run
if "%SECIM%"=="2" goto styp_run
if "%SECIM%"=="3" goto apk_build
if "%SECIM%"=="4" goto firebase_publish
if "%SECIM%"=="5" goto transfer_images
if "%SECIM%"=="0" exit /b 0
echo Gecersiz secim.
pause
goto menu

:servis_run
cd /d "%SERVIS%"
call "%FLUTTER%" pub get
if errorlevel 1 goto error
call "%FLUTTER%" run --flavor client -t lib\main.dart
if errorlevel 1 goto error
goto menu

:styp_run
cd /d "%STYP%"
if not exist "%STYP%\.localappdata" mkdir "%STYP%\.localappdata"
set "LOCALAPPDATA=%STYP%\.localappdata"
call "%FLUTTER%" pub get
if errorlevel 1 goto error
call "%FLUTTER%" run
if errorlevel 1 (
  set "LOCALAPPDATA=%ORIGINAL_LOCALAPPDATA%"
  goto error
)
set "LOCALAPPDATA=%ORIGINAL_LOCALAPPDATA%"
goto menu

:transfer_images
if not exist "%ADB%" (
  echo.
  echo HATA: Telefon aktarim araci bulunamadi:
  echo %ADB%
  pause
  goto menu
)
if not exist "%SALES_IMAGES%" (
  echo.
  echo HATA: Gorsel klasoru bulunamadi:
  echo %SALES_IMAGES%
  pause
  goto menu
)
"%ADB%" get-state 1>nul 2>nul
if errorlevel 1 (
  echo.
  echo HATA: Kullanilabilir telefon bulunamadi.
  echo Telefonu USB kablosuyla baglayin ve USB hata ayiklama iznini onaylayin.
  pause
  goto menu
)
"%ADB%" shell mkdir -p "%PHONE_IMAGES%"
if errorlevel 1 goto error
set /a TRANSFER_COUNT=0
for %%E in (png jpg jpeg webp) do (
  for %%F in ("%SALES_IMAGES%\*.%%E") do (
    if exist "%%~fF" (
      echo Aktariliyor: %%~nxF
      "%ADB%" push "%%~fF" "%PHONE_IMAGES%/%%~nxF" 1>nul
      if errorlevel 1 goto error
      "%ADB%" shell am broadcast -a android.intent.action.MEDIA_SCANNER_SCAN_FILE -d "file://%PHONE_IMAGES%/%%~nxF" 1>nul 2>nul
      set /a TRANSFER_COUNT+=1
    )
  )
)
echo.
if !TRANSFER_COUNT! EQU 0 (
  echo Aktarilacak PNG, JPG, JPEG veya WEBP gorseli bulunamadi.
) else (
  echo !TRANSFER_COUNT! gorsel telefona aktarildi.
  echo Telefonda: Pictures/Servis_Takip
)
pause
goto menu

:apk_build
call :build_apk
if errorlevel 1 goto error
set "APK_TARGET=%DESKTOP%\%APK_TARGET_NAME%"
copy /Y "%APK_SOURCE%" "%APK_TARGET%" >nul
if errorlevel 1 goto error
echo.
echo APK masaustune olusturuldu:
echo %APK_TARGET%
pause
goto menu

:firebase_publish
set "APK_TARGET=%DESKTOP%\%APK_TARGET_NAME%"
if not exist "%APK_TARGET%" (
  echo.
  echo HATA: Masaustunde %APK_TARGET_NAME% bulunamadi.
  echo Once 3. secenekle APK olusturun.
  pause
  goto menu
)
cd /d "%SERVIS%"
for /f "tokens=2 delims=: " %%V in ('findstr /b /c:"version:" pubspec.yaml') do set "FULL_VERSION=%%V"
for /f "tokens=1,2 delims=+" %%A in ("!FULL_VERSION!") do (
  set "APP_VERSION=%%A"
  set "BUILD_NUMBER=%%B"
)
call :ensure_gh
if errorlevel 1 goto error
"%GH_EXE%" auth status >nul 2>nul
if errorlevel 1 (
  echo.
  echo GitHub hesabiniza bir kez giris yapin.
  "%GH_EXE%" auth login --hostname github.com --git-protocol https --web
  if errorlevel 1 goto error
)
echo.
echo GitHub'a guncelleme gonderiliyor:
echo %APK_TARGET%
"%GH_EXE%" release view "v!APP_VERSION!-!BUILD_NUMBER!" --repo "%GITHUB_REPO%" >nul 2>nul
if errorlevel 1 (
  "%GH_EXE%" release create "v!APP_VERSION!-!BUILD_NUMBER!" "%APK_TARGET%#%APK_TARGET_NAME%" --repo "%GITHUB_REPO%" --title "Servis Takip !APP_VERSION!" --notes "Servis Takip guncellemesi - yapi !BUILD_NUMBER!" --latest
) else (
  echo Bu surum zaten mevcut. APK dosyasi yenisiyle degistiriliyor...
  "%GH_EXE%" release upload "v!APP_VERSION!-!BUILD_NUMBER!" "%APK_TARGET%#%APK_TARGET_NAME%" --repo "%GITHUB_REPO%" --clobber
  if not errorlevel 1 "%GH_EXE%" release edit "v!APP_VERSION!-!BUILD_NUMBER!" --repo "%GITHUB_REPO%" --latest
)
if errorlevel 1 goto error
echo.
echo Guncelleme GitHub'da yayinlandi.
echo Uygulamalar yeni surumu otomatik olarak gorecek.
pause
goto menu

:ensure_gh
if exist "%GH_EXE%" exit /b 0
echo GitHub yayin araci ilk kez kuruluyor...
if not exist "%GH_DIR%" mkdir "%GH_DIR%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $api=Invoke-RestMethod 'https://api.github.com/repos/cli/cli/releases/latest'; $asset=$api.assets | Where-Object { $_.name -match 'windows_amd64.zip$' } | Select-Object -First 1; if(-not $asset){throw 'GitHub araci bulunamadi'}; $zip=Join-Path '%GH_DIR%' 'gh.zip'; $tmp=Join-Path '%GH_DIR%' 'gh-unpack'; Invoke-WebRequest $asset.browser_download_url -OutFile $zip; if(Test-Path $tmp){Remove-Item $tmp -Recurse -Force}; Expand-Archive $zip $tmp -Force; $exe=Get-ChildItem $tmp -Recurse -Filter gh.exe | Select-Object -First 1; Copy-Item $exe.FullName '%GH_EXE%' -Force; Remove-Item $zip -Force; Remove-Item $tmp -Recurse -Force"
if errorlevel 1 exit /b 1
if not exist "%GH_EXE%" exit /b 1
exit /b 0

:build_apk
cd /d "%SERVIS%"
for /f "tokens=2 delims=: " %%V in ('findstr /b /c:"version:" pubspec.yaml') do set "FULL_VERSION=%%V"
for /f "tokens=1,2 delims=+" %%A in ("!FULL_VERSION!") do (
  set "APP_VERSION=%%A"
  set /a BUILD_NUMBER=%%B+1
)
if "!APP_VERSION!"=="" exit /b 1
if "!BUILD_NUMBER!"=="" exit /b 1
echo Yeni surum: !APP_VERSION!+!BUILD_NUMBER!
call "%FLUTTER%" build apk --release --no-shrink --flavor client -t lib\main.dart --build-name=!APP_VERSION! --build-number=!BUILD_NUMBER! --no-pub
if errorlevel 1 exit /b 1
if not exist "%APK_SOURCE%" exit /b 1
powershell -NoProfile -Command "$p='pubspec.yaml'; $c=[IO.File]::ReadAllText($p); $c=[regex]::Replace($c,'(?m)^^version:[^^\r\n]*','version: !APP_VERSION!+!BUILD_NUMBER!'); [IO.File]::WriteAllText($p,$c,(New-Object Text.UTF8Encoding($false)))"
if errorlevel 1 exit /b 1
exit /b 0

:error
set "LOCALAPPDATA=%ORIGINAL_LOCALAPPDATA%"
echo.
echo ISLEM TAMAMLANAMADI.
echo Ekrandaki son hata mesajini kontrol edin.
pause
goto menu
