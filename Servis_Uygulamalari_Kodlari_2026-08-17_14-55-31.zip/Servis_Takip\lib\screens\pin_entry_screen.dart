import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/pin_storage.dart';
import 'home_screen.dart';

class PinEntryScreen extends StatefulWidget {
  const PinEntryScreen({super.key});

  @override
  State<PinEntryScreen> createState() => _PinEntryScreenState();
}

class _PinEntryScreenState extends State<PinEntryScreen> {
  final _pinController = TextEditingController();
  bool _loading = true;
  bool _hasExistingPin = false;
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _loadPinStatus();
  }

  Future<void> _loadPinStatus() async {
    final hasPin = await PinStorage.hasPin();
    if (!mounted) return;
    setState(() {
      _hasExistingPin = hasPin;
      _loading = false;
    });
  }

  @override
  void dispose() {
    _pinController.dispose();
    super.dispose();
  }

  Future<void> _continue() async {
    final pin = _pinController.text;
    if (pin.length != 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Lütfen 4 haneli PIN girin.')),
      );
      return;
    }

    setState(() => _submitting = true);
    final isValid = _hasExistingPin ? await PinStorage.verifyPin(pin) : true;

    if (!_hasExistingPin) {
      await PinStorage.savePin(pin);
    }

    if (!mounted) return;
    setState(() => _submitting = false);

    if (!isValid) {
      _pinController.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('PIN kodu doğru değil. Tekrar deneyin.')),
      );
      return;
    }

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute<void>(builder: (_) => const HomeScreen()),
      (_) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF082A52);
    final title = _hasExistingPin ? 'PIN kodunuzu girin' : '4 haneli PIN oluşturun';
    final detail = _hasExistingPin
        ? 'Servis Takip uygulamasına güvenli giriş yapın.'
        : 'Bu PIN, uygulamayı açarken sizden istenecek.';

    return Scaffold(
      appBar: AppBar(title: const Text('Güvenli Giriş')),
      body: SafeArea(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 32),
                    const Icon(Icons.lock_rounded, size: 72, color: navy),
                    const SizedBox(height: 24),
                    Text(
                      title,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            color: navy,
                            fontWeight: FontWeight.w700,
                          ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      detail,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Color(0xFF52657B)),
                    ),
                    const SizedBox(height: 40),
                    TextField(
                      controller: _pinController,
                      autofocus: true,
                      keyboardType: TextInputType.number,
                      obscureText: true,
                      obscuringCharacter: '•',
                      maxLength: 4,
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 30, letterSpacing: 14),
                      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                      decoration: const InputDecoration(
                        counterText: '',
                        hintText: '••••',
                        border: OutlineInputBorder(),
                        contentPadding: EdgeInsets.symmetric(vertical: 18),
                      ),
                      onSubmitted: (_) => _continue(),
                    ),
                    const SizedBox(height: 24),
                    SizedBox(
                      height: 56,
                      child: FilledButton(
                        onPressed: _submitting ? null : _continue,
                        style: FilledButton.styleFrom(backgroundColor: navy),
                        child: _submitting
                            ? const SizedBox(
                                width: 24,
                                height: 24,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2.5,
                                  color: Colors.white,
                                ),
                              )
                            : Text(_hasExistingPin ? 'GİRİŞ YAP' : 'PIN KAYDET'),
                      ),
                    ),
                    const Spacer(),
                    const Text(
                      'Servis Takip v1.1',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Color(0xFF718196)),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
