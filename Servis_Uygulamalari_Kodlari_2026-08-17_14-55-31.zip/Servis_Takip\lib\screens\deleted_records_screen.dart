import 'package:flutter/material.dart';

import '../models/personnel.dart';
import '../models/stop.dart';
import '../services/deleted_records_storage.dart';
import '../services/personnel_storage.dart';
import '../services/stop_storage.dart';

class DeletedRecordsScreen extends StatefulWidget {
  const DeletedRecordsScreen({super.key});

  @override
  State<DeletedRecordsScreen> createState() => _DeletedRecordsScreenState();
}

class _DeletedRecordsScreenState extends State<DeletedRecordsScreen> {
  late Future<(
    List<DeletedRecord<Personnel>>,
    List<DeletedRecord<Stop>>,
  )> _records;

  @override
  void initState() {
    super.initState();
    _records = _load();
  }

  Future<(
    List<DeletedRecord<Personnel>>,
    List<DeletedRecord<Stop>>,
  )> _load() async {
    final results = await Future.wait([
      DeletedRecordsStorage.readPersonnel(),
      DeletedRecordsStorage.readStops(),
    ]);
    return (
      results[0] as List<DeletedRecord<Personnel>>,
      results[1] as List<DeletedRecord<Stop>>,
    );
  }

  String _date(DateTime value) {
    if (value.millisecondsSinceEpoch == 0) return 'Silinme tarihi bilinmiyor';
    String two(int number) => number.toString().padLeft(2, '0');
    return '${two(value.day)}.${two(value.month)}.${value.year} '
        '${two(value.hour)}:${two(value.minute)}';
  }

  Widget _empty(String label) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Text('Silinen $label kaydı bulunmuyor.'),
        ),
      );

  Future<bool> _confirmRestore(String name) async {
    return await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Kaydı Geri Yükle'),
            content: Text('$name eski bilgileriyle geri yüklensin mi?'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(false),
                child: const Text('VAZGEÇ'),
              ),
              FilledButton.icon(
                onPressed: () => Navigator.of(dialogContext).pop(true),
                icon: const Icon(Icons.restore_rounded),
                label: const Text('GERİ YÜKLE'),
              ),
            ],
          ),
        ) ??
        false;
  }

  Future<void> _restorePersonnel(Personnel person) async {
    if (!await _confirmRestore(person.fullName)) return;
    final current = await PersonnelStorage.readAll();
    if (current.any((item) => item.id == person.id)) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bu personel zaten aktif listede.')),
      );
      return;
    }
    await PersonnelStorage.saveAll([...current, person]);
    await DeletedRecordsStorage.removePersonnel(person.id);
    if (!mounted) return;
    setState(() => _records = _load());
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${person.fullName} geri yüklendi.')),
    );
  }

  Future<void> _restoreStop(Stop stop) async {
    if (!await _confirmRestore(stop.name)) return;
    final current = await StopStorage.readAll();
    if (current.any((item) => item.id == stop.id)) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bu durak zaten aktif listede.')),
      );
      return;
    }
    await StopStorage.saveAll([...current, stop]);
    await DeletedRecordsStorage.removeStop(stop.id);
    if (!mounted) return;
    setState(() => _records = _load());
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${stop.name} durağı geri yüklendi.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Silinen Kayıtlar'),
          bottom: const TabBar(
            tabs: [
              Tab(icon: Icon(Icons.people_alt_rounded), text: 'Personel'),
              Tab(icon: Icon(Icons.location_on_rounded), text: 'Duraklar'),
            ],
          ),
        ),
        body: FutureBuilder<(
          List<DeletedRecord<Personnel>>,
          List<DeletedRecord<Stop>>,
        )>(
          future: _records,
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return const Center(
                child: Text('Silinen kayıtlar yüklenemedi.'),
              );
            }
            final personnel = snapshot.data!.$1;
            final stops = snapshot.data!.$2;
            return TabBarView(
              children: [
                personnel.isEmpty
                    ? _empty('personel')
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: personnel.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 8),
                        itemBuilder: (context, index) {
                          final item = personnel[index];
                          return Card(
                            child: ListTile(
                              leading: const CircleAvatar(
                                child: Icon(Icons.person_rounded),
                              ),
                              title: Text(item.record.fullName),
                              subtitle: Text(
                                '${item.record.institutionName}\n'
                                '${item.record.stopName} • ${_date(item.deletedAt)}',
                              ),
                              isThreeLine: true,
                              trailing: IconButton(
                                onPressed: () =>
                                    _restorePersonnel(item.record),
                                icon: const Icon(Icons.restore_rounded),
                                tooltip: 'Geri yükle',
                              ),
                            ),
                          );
                        },
                      ),
                stops.isEmpty
                    ? _empty('durak')
                    : ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: stops.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 8),
                        itemBuilder: (context, index) {
                          final item = stops[index];
                          return Card(
                            child: ListTile(
                              leading: const CircleAvatar(
                                child: Icon(Icons.location_on_rounded),
                              ),
                              title: Text(item.record.name),
                              subtitle: Text(
                                '${item.record.institutionName}\n'
                                'Silindi: ${_date(item.deletedAt)}',
                              ),
                              isThreeLine: true,
                              trailing: IconButton(
                                onPressed: () => _restoreStop(item.record),
                                icon: const Icon(Icons.restore_rounded),
                                tooltip: 'Geri yükle',
                              ),
                            ),
                          );
                        },
                      ),
              ],
            );
          },
        ),
      ),
    );
  }
}
