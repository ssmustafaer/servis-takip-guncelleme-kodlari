import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'company_cloud_storage.dart';

class ServicePreferenceStorage {
  ServicePreferenceStorage._();

  static const _storage = FlutterSecureStorage();

  static Future<String?> read(String field) async {
    return _storage.read(
      key: await CompanyCloudStorage.cacheKey('service_preference_$field'),
    );
  }

  static Future<void> save({
    required String driverId,
    required String vehicleId,
    required String institutionId,
    required String listMode,
  }) async {
    await Future.wait([
      _storage.write(
        key: await CompanyCloudStorage.cacheKey('service_preference_driver'),
        value: driverId,
      ),
      _storage.write(
        key: await CompanyCloudStorage.cacheKey('service_preference_vehicle'),
        value: vehicleId,
      ),
      _storage.write(
        key: await CompanyCloudStorage.cacheKey(
          'service_preference_institution',
        ),
        value: institutionId,
      ),
      _storage.write(
        key: await CompanyCloudStorage.cacheKey('service_preference_listMode'),
        value: listMode,
      ),
    ]);
  }
}
