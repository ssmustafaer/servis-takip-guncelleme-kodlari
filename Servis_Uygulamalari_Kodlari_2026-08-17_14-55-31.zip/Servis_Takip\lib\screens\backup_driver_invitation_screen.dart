import 'dart:convert';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../company/models/company_employee.dart';
import '../company/models/company_session.dart';
import '../company/services/company_employee_repository.dart';
import '../models/institution.dart';
import '../models/vehicle.dart';
import '../services/institution_storage.dart';
import '../services/payment_approval_request_service.dart';
import '../services/temporary_invitation_config_service.dart';
import '../services/vehicle_storage.dart';
import 'company_employees_screen.dart';

class BackupDriverInvitationScreen extends StatefulWidget {
  const BackupDriverInvitationScreen({required this.session, super.key});

  final CompanySession session;

  @override
  State<BackupDriverInvitationScreen> createState() =>
      _BackupDriverInvitationScreenState();
}

class _BackupDriverInvitationScreenState
    extends State<BackupDriverInvitationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _repository = CompanyEmployeeRepository();
  final _configService = TemporaryInvitationConfigService();
  final _approvalService = PaymentApprovalRequestService();

  List<Institution> _institutions = const [];
  List<Vehicle> _vehicles = const [];
  TemporaryInvitationConfig? _config;
  String? _selectedEmployeeId;
  String? _selectedCampaignId;
  String? _selectedIbanId;
  String? _selectedContactId;
  bool _loading = true;
  bool _sending = false;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final result = await Future.wait([
      InstitutionStorage.readAll(),
      VehicleStorage.readAll(),
      _configService.read(),
    ]);
    if (!mounted) return;
    final config = result[2] as TemporaryInvitationConfig;
    setState(() {
      _institutions = result[0] as List<Institution>;
      _vehicles = result[1] as List<Vehicle>;
      _config = config;
      _selectedCampaignId = config.campaigns.firstOrNull?.id;
      _selectedIbanId = config.ibans.firstOrNull?.id;
      _selectedContactId = config.collectionContacts.firstOrNull?.id;
      _loading = false;
    });
  }

  TemporaryAccessCampaign? get _selectedCampaign {
    for (final campaign in _config?.campaigns ?? const []) {
      if (campaign.id == _selectedCampaignId) return campaign;
    }
    return null;
  }

  InvitationIban? get _selectedIban {
    for (final item in _config?.ibans ?? const []) {
      if (item.id == _selectedIbanId) return item;
    }
    return null;
  }

  InvitationCollectionContact? get _selectedContact {
    for (final item in _config?.collectionContacts ?? const []) {
      if (item.id == _selectedContactId) return item;
    }
    return null;
  }

  String _formatPrice(num value) {
    final whole = value.toInt();
    final sign = whole < 0 ? '-' : '';
    final digits = whole.abs().toString();
    final grouped = StringBuffer();
    for (var index = 0; index < digits.length; index++) {
      if (index > 0 && (digits.length - index) % 3 == 0) grouped.write('.');
      grouped.write(digits[index]);
    }
    final integerPart = '$sign$grouped';
    if (value == whole) return '$integerPart TL';
    final decimalPart = value.abs().toStringAsFixed(2).split('.').last;
    return '$integerPart,$decimalPart TL';
  }

  String _campaignDisplayTitle(TemporaryAccessCampaign campaign) {
    final title = campaign.title.trim();
    final duration = title.toLowerCase().contains('gün')
        ? title
        : '${campaign.days} Günlük Kullanım';
    return '${campaign.groupTitle} - $duration';
  }

  Widget? _campaignImage(TemporaryAccessCampaign campaign) {
    if (campaign.imageBase64.isEmpty) return null;
    try {
      final encoded = campaign.imageBase64.contains(',')
          ? campaign.imageBase64.split(',').last
          : campaign.imageBase64;
      return ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Image.memory(
          base64Decode(encoded),
          width: double.infinity,
          height: 145,
          fit: BoxFit.cover,
          errorBuilder: (_, _, _) => const SizedBox.shrink(),
        ),
      );
    } catch (_) {
      return null;
    }
  }

  String _paymentCode(CompanyEmployee employee) {
    final timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    final suffix = timestamp.substring(timestamp.length - 6);
    final initials = employee.displayName
        .trim()
        .split(RegExp(r'\s+'))
        .where((part) => part.isNotEmpty)
        .take(2)
        .map((part) => part[0].toUpperCase())
        .join();
    return 'ST-$initials-$suffix';
  }

  String _normalizedPhone(String value) {
    var digits = value.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.startsWith('0')) digits = '90${digits.substring(1)}';
    if (!digits.startsWith('90') && digits.length == 10) digits = '90$digits';
    return digits;
  }

  String _institutionSummary(CompanyEmployee employee) {
    if (employee.allInstitutions) return 'Tüm kurumlar';
    final names = _institutions
        .where((item) => employee.allowedInstitutionIds.contains(item.id))
        .map((item) => item.name)
        .toList();
    return names.isEmpty ? 'Kurum yetkisi verilmemiş' : names.join(', ');
  }

  String _vehicleSummary(CompanyEmployee employee) {
    if (employee.allVehicles) return 'Tüm araçlar';
    final names = _vehicles
        .where((item) => employee.allowedVehicleIds.contains(item.id))
        .map((item) => item.plate)
        .toList();
    return names.isEmpty ? 'Araç yetkisi verilmemiş' : names.join(', ');
  }

  Future<void> _openEmployeeCreation() async {
    await Navigator.push(
      context,
      MaterialPageRoute<void>(
        builder: (_) => CompanyEmployeesScreen(
          session: widget.session,
          openAddOnStart: true,
        ),
      ),
    );
  }

  Future<void> _sendPaymentNotification(CompanyEmployee employee) async {
    if (!_formKey.currentState!.validate() || _sending) return;
    final config = _config;
    final campaign = _selectedCampaign;
    final selectedIban = _selectedIban;
    final selectedContact = _selectedContact;
    if (config == null ||
        campaign == null ||
        selectedIban == null ||
        selectedContact == null ||
        !config.hasPaymentDetails) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'STTY uygulamasında kampanya, IBAN ve tahsilat yetkilisi seçilmelidir.',
          ),
        ),
      );
      return;
    }

    setState(() => _sending = true);
    try {
      final code = _paymentCode(employee);
      final driverPhone = _normalizedPhone(employee.phone);
      await _approvalService.create(
        companyId: widget.session.companyId,
        companyName: widget.session.companyName,
        requestedByName: widget.session.displayName,
        driverId: employee.id,
        driverName: employee.displayName,
        driverPhone: driverPhone,
        campaignId: campaign.id,
        campaignTitle: _campaignDisplayTitle(campaign),
        campaignDays: campaign.days,
        amount: campaign.price,
        paymentCode: code,
        loginName: employee.displayName,
        temporaryPassword: '',
      );
      final message =
          '''Servis Takip geçici kullanıcı paketi ödemesi tamamlandı.

Şirket: ${widget.session.companyName}
Ödemeyi yapan: ${widget.session.displayName}
Yedek şoför: ${employee.displayName}
Paket: ${_campaignDisplayTitle(campaign)}
Tutar: ${_formatPrice(campaign.price)}
Ödeme kodu: $code

Tahsilat yetkilisi: ${selectedContact.name}
Lütfen dekontu bu WhatsApp görüşmesine yükleyiniz.''';
      final phone = _normalizedPhone(selectedContact.phone);
      final uri = Uri.parse(
        'https://wa.me/$phone?text=${Uri.encodeComponent(message)}',
      );
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw Exception('WhatsApp açılamadı.');
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('WhatsApp açıldı. Dekontu ekleyin. Ödeme kodu: $code'),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Ödeme bildirimi hazırlanamadı: $error')),
      );
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Yedek Şoför Daveti Hazırla')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : StreamBuilder<List<CompanyEmployee>>(
              stream: _repository.watchEmployees(widget.session.companyId),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Center(
                    child: Text('Çalışanlar yüklenemedi:\n${snapshot.error}'),
                  );
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final employees = snapshot.data!
                    .where((employee) => employee.active)
                    .toList();
                CompanyEmployee? selected;
                for (final employee in employees) {
                  if (employee.id == _selectedEmployeeId) selected = employee;
                }
                if (selected == null && employees.isNotEmpty) {
                  selected = employees.first;
                  final firstEmployee = selected;
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    if (!mounted || _selectedEmployeeId != null) return;
                    setState(() => _selectedEmployeeId = firstEmployee.id);
                  });
                }
                return _buildForm(employees, selected);
              },
            ),
    );
  }

  Widget _buildForm(
    List<CompanyEmployee> employees,
    CompanyEmployee? selected,
  ) {
    final config = _config!;
    final campaignGroups = <String, List<TemporaryAccessCampaign>>{};
    for (final campaign in config.campaigns) {
      campaignGroups.putIfAbsent(campaign.groupTitle, () => []).add(campaign);
    }
    return Form(
      key: _formKey,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Davet Edilecek Personel',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  initialValue:
                      employees.any((item) => item.id == _selectedEmployeeId)
                      ? _selectedEmployeeId
                      : null,
                  decoration: const InputDecoration(
                    labelText: 'Personel Seç',
                    prefixIcon: Icon(Icons.drive_eta_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: employees
                      .map(
                        (employee) => DropdownMenuItem(
                          value: employee.id,
                          child: Text(employee.displayName),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    setState(() => _selectedEmployeeId = value);
                  },
                  validator: (value) =>
                      value == null ? 'Davet edilecek personeli seçin.' : null,
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(
                onPressed: _openEmployeeCreation,
                tooltip: 'Çalışan ekle ve yetkilendir',
                icon: const Icon(Icons.person_add_alt_1_rounded),
              ),
            ],
          ),
          if (employees.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 10),
              child: Text(
                'Aktif çalışan bulunamadı. Ekle simgesinden çalışan oluşturup yetkilendirin.',
                style: TextStyle(color: Colors.redAccent),
              ),
            ),
          if (selected != null) ...[
            const SizedBox(height: 12),
            Card(
              color: const Color(0xFFF3F7FC),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Mevcut Yetkiler',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 8),
                    Text('Kurumlar: ${_institutionSummary(selected)}'),
                    const SizedBox(height: 6),
                    Text('Araçlar: ${_vehicleSummary(selected)}'),
                  ],
                ),
              ),
            ),
          ],
          const SizedBox(height: 22),
          const Text(
            'Kullanım Paketi',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 14),
          RadioGroup<String>(
            groupValue: _selectedCampaignId,
            onChanged: (value) => setState(() => _selectedCampaignId = value),
            child: Column(
              children: campaignGroups.entries.map((group) {
                final groupSelected = group.value.any(
                  (campaign) => campaign.id == _selectedCampaignId,
                );
                return Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(
                    color: groupSelected
                        ? const Color(0xFFF5F8FE)
                        : Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: groupSelected
                          ? const Color(0xFF123B70)
                          : const Color(0xFFCAD6E4),
                      width: groupSelected ? 2 : 1,
                    ),
                  ),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(10, 16, 10, 6),
                        child: Column(
                          children: [
                            for (
                              var index = 0;
                              index < group.value.length;
                              index++
                            ) ...[
                              if (index > 0) const Divider(height: 18),
                              if (_campaignImage(group.value[index])
                                  case final image?)
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                    6,
                                    6,
                                    6,
                                    4,
                                  ),
                                  child: image,
                                ),
                              RadioListTile<String>(
                                value: group.value[index].id,
                                contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 4,
                                ),
                                title: Text(
                                  group.value[index].title,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w700,
                                  ),
                                ),
                                subtitle: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${group.value[index].days} Günlük Kullanım • ${_formatPrice(group.value[index].price)}',
                                    ),
                                    if (group
                                        .value[index]
                                        .description
                                        .isNotEmpty) ...[
                                      const SizedBox(height: 4),
                                      Text(
                                        group.value[index].description,
                                        style: const TextStyle(
                                          color: Color(0xFFB3261E),
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            ],
                          ],
                        ),
                      ),
                      Positioned(
                        left: 14,
                        top: -12,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: groupSelected
                                ? const Color(0xFFF5F8FE)
                                : Colors.white,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 8),
                            child: Text(
                              group.key,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFF123B70),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 18),
          Container(
            decoration: BoxDecoration(
              border: Border.all(color: const Color(0xFFCAD6E4)),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Transform.translate(
                    offset: const Offset(0, -12),
                    child: DecoratedBox(
                      decoration: const BoxDecoration(color: Colors.white),
                      child: const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8),
                        child: Text(
                          'Ödeme',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ),
                    ),
                  ),
                  if (!config.remoteConfigured)
                    const Padding(
                      padding: EdgeInsets.only(bottom: 12),
                      child: Text(
                        'STTY ortak ayarı henüz yayınlanmadığı için geçici yerel bilgiler gösteriliyor.',
                        style: TextStyle(color: Colors.orange),
                      ),
                    ),
                  DropdownButtonFormField<String>(
                    initialValue: _selectedIbanId,
                    decoration: const InputDecoration(
                      labelText: 'Ödeme yapılacak IBAN',
                      prefixIcon: Icon(Icons.account_balance_rounded),
                    ),
                    items: config.ibans
                        .map(
                          (item) => DropdownMenuItem(
                            value: item.id,
                            child: Text(item.title),
                          ),
                        )
                        .toList(),
                    onChanged: (value) =>
                        setState(() => _selectedIbanId = value),
                  ),
                  const SizedBox(height: 6),
                  if (_selectedIban != null) ...[
                    Text(
                      _selectedIban!.recipientName,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    Row(
                      children: [
                        Expanded(child: SelectableText(_selectedIban!.iban)),
                        IconButton(
                          tooltip: 'IBAN kopyala',
                          onPressed: () async {
                            await Clipboard.setData(
                              ClipboardData(text: _selectedIban!.iban),
                            );
                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('IBAN kopyalandı.')),
                            );
                          },
                          icon: const Icon(Icons.copy_rounded),
                        ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    initialValue: _selectedContactId,
                    decoration: const InputDecoration(
                      labelText: 'Tahsilat kontrol yetkilisi',
                      prefixIcon: Icon(Icons.verified_user_rounded),
                    ),
                    items: config.collectionContacts
                        .map(
                          (item) => DropdownMenuItem(
                            value: item.id,
                            child: Text(item.name),
                          ),
                        )
                        .toList(),
                    onChanged: (value) =>
                        setState(() => _selectedContactId = value),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'Paket tutarını yukarıdaki IBAN’a yatırdıktan sonra '
                    'ÖDEME TAMAM düğmesine basınız. WhatsApp açıldığında '
                    'ödeme dekontunu görüşmeye ekleyiniz.',
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF1FAF5A),
                        foregroundColor: Colors.white,
                      ),
                      onPressed:
                          selected == null ||
                              _selectedCampaign == null ||
                              _selectedIban == null ||
                              _selectedContact == null ||
                              _sending
                          ? null
                          : () => _sendPaymentNotification(selected),
                      icon: _sending
                          ? const SizedBox.square(
                              dimension: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const FaIcon(FontAwesomeIcons.whatsapp),
                      label: const Text('ÖDEME TAMAM'),
                    ),
                  ),
                  if (_selectedContact != null) ...[
                    const SizedBox(height: 10),
                    Text(
                      'Bildirim: ${_selectedContact!.name}',
                      style: const TextStyle(color: Color(0xFF52657B)),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Ödeme sistem yöneticisi tarafından onaylandıktan sonra yedek '
            'şoföre davet gönderme işlemi açılacaktır.',
            textAlign: TextAlign.center,
            style: TextStyle(color: Color(0xFF52657B)),
          ),
        ],
      ),
    );
  }
}
