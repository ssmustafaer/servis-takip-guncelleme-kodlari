import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/service_record.dart';
import 'company_cloud_storage.dart';

class ServiceRecordStorage {
  ServiceRecordStorage._();

  static const _key = 'service_records';
  static const _pendingKey = 'service_records_pending_sync';
  static const _storage = FlutterSecureStorage();

  static Future<List<ServiceRecord>> readAll() async {
    final cached = await _readCache();
    if (await hasPendingSync()) {
      await syncPending();
      return cached;
    }
    try {
      final cloudData = await CompanyCloudStorage.readCollection(
        'serviceRecords',
      );
      if (cloudData.isNotEmpty) {
        final records = cloudData.map(ServiceRecord.fromJson).toList();
        await _writeCache(records);
        await CompanyCloudStorage.markCloudInitialized('serviceRecords');
        return records;
      }
      if (await CompanyCloudStorage.isCloudInitialized('serviceRecords')) {
        await _writeCache(const []);
        return [];
      }
    } catch (_) {
      return cached;
    }
    if (cached.isEmpty) {
      await CompanyCloudStorage.markCloudInitialized('serviceRecords');
      return [];
    }
    if (await CompanyCloudStorage.canClaimLegacyData()) {
      await saveAll(cached);
    }
    await CompanyCloudStorage.markCloudInitialized('serviceRecords');
    return cached;
  }

  static Future<bool> saveAll(
    List<ServiceRecord> records, {
    bool syncNow = true,
  }) async {
    final previous = await _readCache();
    await _writeCache(records);
    await _queueChanges(
      previous: previous,
      current: records,
      deferred: !syncNow,
    );
    if (!syncNow) return true;
    try {
      await _syncQueuedChanges();
      await CompanyCloudStorage.markCloudInitialized('serviceRecords');
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> hasPendingSync() async => !{null, '', 'false'}.contains(
    await _storage.read(key: await CompanyCloudStorage.cacheKey(_pendingKey)),
  );

  static Future<bool> syncPending() async {
    if (!await hasPendingSync()) return true;
    if (await _isDeferred()) return false;
    try {
      await _syncQueuedChanges();
      await CompanyCloudStorage.markCloudInitialized('serviceRecords');
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<void> _queueChanges({
    required List<ServiceRecord> previous,
    required List<ServiceRecord> current,
    required bool deferred,
  }) async {
    final pending = await _readPending();
    final oldById = {for (final item in previous) item.id: item};
    final newById = {for (final item in current) item.id: item};
    final upserts = Map<String, dynamic>.from(pending['upserts'] as Map);
    final deletes = (pending['deletes'] as List<dynamic>)
        .map((item) => item.toString())
        .toSet();
    for (final entry in newById.entries) {
      final old = oldById[entry.key];
      if (old == null ||
          jsonEncode(old.toJson()) != jsonEncode(entry.value.toJson())) {
        upserts[entry.key] = entry.value.toJson();
        deletes.remove(entry.key);
      }
    }
    for (final id in oldById.keys.where((id) => !newById.containsKey(id))) {
      upserts.remove(id);
      deletes.add(id);
    }
    await _writePending(upserts: upserts, deletes: deletes, deferred: deferred);
  }

  static Future<void> _syncQueuedChanges() async {
    final key = await CompanyCloudStorage.cacheKey(_pendingKey);
    final queuedValue = await _storage.read(key: key);
    final pending = await _decodePending(queuedValue);
    final upserts = (pending['upserts'] as Map).map(
      (key, value) =>
          MapEntry(key.toString(), Map<String, dynamic>.from(value as Map)),
    );
    final deletes = (pending['deletes'] as List<dynamic>)
        .map((item) => item.toString())
        .toSet();
    await CompanyCloudStorage.applyDocumentChanges(
      collectionName: 'serviceRecords',
      upserts: upserts,
      deletes: deletes,
    );
    if (await _storage.read(key: key) == queuedValue) {
      await _storage.delete(key: key);
    }
  }

  static Future<void> _writeCache(List<ServiceRecord> records) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_key),
      value: jsonEncode(records.map((record) => record.toJson()).toList()),
    );
  }

  static Future<List<ServiceRecord>> _readCache() async {
    final saved =
        await _storage.read(key: await CompanyCloudStorage.cacheKey(_key)) ??
        await _storage.read(key: _key);
    if (saved == null || saved.isEmpty) return [];
    return (jsonDecode(saved) as List<dynamic>)
        .map((item) => ServiceRecord.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  static Future<Map<String, dynamic>> _readPending() async {
    final key = await CompanyCloudStorage.cacheKey(_pendingKey);
    return _decodePending(await _storage.read(key: key));
  }

  static Future<Map<String, dynamic>> _decodePending(String? value) async {
    if (value == null || value.isEmpty || value == 'false') {
      return {
        'upserts': <String, dynamic>{},
        'deletes': <String>[],
        'deferred': false,
      };
    }
    if (value == 'true') {
      final records = await _readCache();
      return {
        'upserts': {for (final record in records) record.id: record.toJson()},
        'deletes': <String>[],
        'deferred': false,
      };
    }
    return Map<String, dynamic>.from(jsonDecode(value) as Map);
  }

  static Future<void> _writePending({
    required Map<String, dynamic> upserts,
    required Set<String> deletes,
    required bool deferred,
  }) async {
    final key = await CompanyCloudStorage.cacheKey(_pendingKey);
    if (upserts.isEmpty && deletes.isEmpty) {
      await _storage.delete(key: key);
      return;
    }
    await _storage.write(
      key: key,
      value: jsonEncode({
        'upserts': upserts,
        'deletes': deletes.toList(),
        'deferred': deferred,
      }),
    );
  }

  static Future<bool> _isDeferred() async {
    final pending = await _readPending();
    return pending['deferred'] == true;
  }
}
