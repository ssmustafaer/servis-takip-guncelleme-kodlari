import '../models/personnel.dart';
import '../models/stop.dart';
import 'company_cloud_storage.dart';

class DeletedRecord<T> {
  const DeletedRecord({required this.record, required this.deletedAt});

  final T record;
  final DateTime deletedAt;
}

class DeletedRecordsStorage {
  DeletedRecordsStorage._();

  static const _personnelCollection = 'personnel';
  static const _stopsCollection = 'stops';
  static String _archiveId(String id) => '_deleted_$id';

  static Future<void> archivePersonnel(Personnel person) {
    return CompanyCloudStorage.writeDocument(
      collectionName: _personnelCollection,
      documentId: _archiveId(person.id),
      data: {...person.toJson(), 'deletedAt': DateTime.now().toIso8601String()},
    );
  }

  static Future<void> archiveStop(Stop stop) {
    return CompanyCloudStorage.writeDocument(
      collectionName: _stopsCollection,
      documentId: _archiveId(stop.id),
      data: {...stop.toJson(), 'deletedAt': DateTime.now().toIso8601String()},
    );
  }

  static Future<List<DeletedRecord<Personnel>>> readPersonnel() async {
    final data = await CompanyCloudStorage.readCollection(_personnelCollection);
    final records = data.where((json) => json['deletedAt'] != null).map((json) {
      return DeletedRecord(
        record: Personnel.fromJson(json),
        deletedAt: DateTime.tryParse(json['deletedAt'] as String? ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0),
      );
    }).toList();
    records.sort((a, b) => b.deletedAt.compareTo(a.deletedAt));
    return records;
  }

  static Future<List<DeletedRecord<Stop>>> readStops() async {
    final data = await CompanyCloudStorage.readCollection(_stopsCollection);
    final records = data.where((json) => json['deletedAt'] != null).map((json) {
      return DeletedRecord(
        record: Stop.fromJson(json),
        deletedAt: DateTime.tryParse(json['deletedAt'] as String? ?? '') ??
            DateTime.fromMillisecondsSinceEpoch(0),
      );
    }).toList();
    records.sort((a, b) => b.deletedAt.compareTo(a.deletedAt));
    return records;
  }

  static Future<void> removePersonnel(String id) {
    return CompanyCloudStorage.deleteDocument(
      collectionName: _personnelCollection,
      documentId: _archiveId(id),
    );
  }

  static Future<void> removeStop(String id) {
    return CompanyCloudStorage.deleteDocument(
      collectionName: _stopsCollection,
      documentId: _archiveId(id),
    );
  }
}
