import 'package:flutter/material.dart';

import '../models/vehicle.dart';
import '../services/vehicle_storage.dart';

class VehiclesScreen extends StatefulWidget {
  const VehiclesScreen({super.key});

  @override
  State<VehiclesScreen> createState() => _VehiclesScreenState();
}

class _VehiclesScreenState extends State<VehiclesScreen> {
  var _loading = true;
  List<Vehicle> _vehicles = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final items = await VehicleStorage.readAll();
    if (!mounted) return;
    setState(() {
      _vehicles = items;
      _loading = false;
    });
  }

  Future<void> _openEditor([Vehicle? vehicle]) async {
    final result = await showDialog<Vehicle>(
      context: context,
      builder: (_) => _VehicleDialog(vehicle: vehicle),
    );
    if (result == null) return;
    final updated = [
      for (final item in _vehicles)
        if (item.id != result.id) item,
      result,
    ];
    try {
      await VehicleStorage.saveAll(updated);
      if (mounted) setState(() => _vehicles = updated);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Araç kaydedilemedi: $error')));
    }
  }

  Future<void> _delete(Vehicle vehicle) async {
    final updated = _vehicles.where((item) => item.id != vehicle.id).toList();
    await VehicleStorage.saveAll(updated);
    if (mounted) setState(() => _vehicles = updated);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Araç Kayıtları')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openEditor,
        icon: const Icon(Icons.add_road_rounded),
        label: const Text('Araç Ekle'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _vehicles.isEmpty
          ? const Center(child: Text('Henüz araç kaydı yok.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              itemCount: _vehicles.length,
              itemBuilder: (context, index) {
                final vehicle = _vehicles[index];
                return Card(
                  child: ListTile(
                    leading: Icon(
                      Icons.directions_bus_rounded,
                      color: vehicle.active ? Colors.green : Colors.grey,
                    ),
                    title: Text(
                      vehicle.plate,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${vehicle.brandModel.isEmpty ? 'Marka/model girilmedi' : vehicle.brandModel}'
                      ' • ${vehicle.capacity} kişilik',
                    ),
                    onTap: () => _openEditor(vehicle),
                    trailing: Wrap(
                      spacing: 2,
                      children: [
                        IconButton(
                          onPressed: () => _openEditor(vehicle),
                          icon: const Icon(Icons.edit_rounded),
                          tooltip: 'Aracı düzenle',
                        ),
                        IconButton(
                          onPressed: () => _delete(vehicle),
                          icon: const Icon(Icons.delete_outline_rounded),
                          color: Colors.red,
                          tooltip: 'Aracı sil',
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class _VehicleDialog extends StatefulWidget {
  const _VehicleDialog({this.vehicle});

  final Vehicle? vehicle;

  @override
  State<_VehicleDialog> createState() => _VehicleDialogState();
}

class _VehicleDialogState extends State<_VehicleDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _plateController;
  late final TextEditingController _brandModelController;
  late final TextEditingController _capacityController;
  late bool _active;

  @override
  void initState() {
    super.initState();
    _plateController = TextEditingController(text: widget.vehicle?.plate);
    _brandModelController = TextEditingController(
      text: widget.vehicle?.brandModel,
    );
    _capacityController = TextEditingController(
      text: widget.vehicle?.capacity.toString(),
    );
    _active = widget.vehicle?.active ?? true;
  }

  @override
  void dispose() {
    _plateController.dispose();
    _brandModelController.dispose();
    _capacityController.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.pop(
      context,
      Vehicle(
        id:
            widget.vehicle?.id ??
            DateTime.now().microsecondsSinceEpoch.toString(),
        plate: _plateController.text.trim().toUpperCase(),
        brandModel: _brandModelController.text.trim(),
        capacity: int.parse(_capacityController.text),
        active: _active,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.vehicle == null ? 'Araç Ekle' : 'Aracı Düzenle'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _plateController,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(labelText: 'Plaka'),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Plakayı girin.'
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _brandModelController,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(labelText: 'Marka / model'),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _capacityController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Koltuk kapasitesi',
                ),
                validator: (value) {
                  final number = int.tryParse(value ?? '');
                  return number == null || number <= 0
                      ? 'Geçerli kapasite girin.'
                      : null;
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Aktif'),
                value: _active,
                onChanged: (value) => setState(() => _active = value),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton(onPressed: _save, child: const Text('Kaydet')),
      ],
    );
  }
}
