class Vehicle {
  const Vehicle({
    required this.id,
    required this.plate,
    required this.brandModel,
    required this.capacity,
    this.active = true,
  });

  final String id;
  final String plate;
  final String brandModel;
  final int capacity;
  final bool active;

  Map<String, dynamic> toJson() => {
    'id': id,
    'plate': plate,
    'brandModel': brandModel,
    'capacity': capacity,
    'active': active,
  };

  factory Vehicle.fromJson(Map<String, dynamic> json) => Vehicle(
    id: json['id'] as String,
    plate: json['plate'] as String,
    brandModel: json['brandModel'] as String? ?? '',
    capacity: (json['capacity'] as num?)?.toInt() ?? 0,
    active: json['active'] as bool? ?? true,
  );
}
