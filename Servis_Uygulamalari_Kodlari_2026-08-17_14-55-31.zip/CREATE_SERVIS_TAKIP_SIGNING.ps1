$ErrorActionPreference = 'Stop'

$keytool = 'C:\Program Files\Android\Android Studio\jbr\bin\keytool.exe'
$signingDirectory = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Codex\Servis_Takip_Signing'
$keystore = Join-Path $signingDirectory 'servis-takip-release.p12'
$properties = Join-Path $signingDirectory 'key.properties'
$backupNote = Join-Path $signingDirectory 'YEDEKLEME_BILGISI.txt'
$alias = 'servis-takip-release'

if (-not (Test-Path -LiteralPath $keytool)) {
    throw "keytool bulunamadi: $keytool"
}
if ((Test-Path -LiteralPath $keystore) -or (Test-Path -LiteralPath $properties)) {
    throw "Mevcut imza dosyalarinin uzerine yazilmadi: $signingDirectory"
}

New-Item -ItemType Directory -Path $signingDirectory -Force | Out-Null

$alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
$passwordBytes = [byte[]]::new(40)
[Security.Cryptography.RandomNumberGenerator]::Fill($passwordBytes)
$password = -join ($passwordBytes | ForEach-Object { $alphabet[$_ % $alphabet.Length] })

& $keytool -genkeypair `
    -keystore $keystore `
    -storetype PKCS12 `
    -storepass $password `
    -keypass $password `
    -alias $alias `
    -keyalg RSA `
    -keysize 4096 `
    -validity 10000 `
    -dname 'CN=Servis Takip, OU=Mobil Uygulama, O=Servis Takip, L=Izmir, C=TR'
if ($LASTEXITCODE -ne 0) {
    throw 'Kalici yayin anahtari olusturulamadi.'
}

$propertyContent = @(
    "storeFile=$($keystore -replace '\\', '/')"
    "storePassword=$password"
    "keyAlias=$alias"
    "keyPassword=$password"
) -join [Environment]::NewLine
[IO.File]::WriteAllText($properties, $propertyContent, [Text.UTF8Encoding]::new($false))

$noteContent = @"
SERVIS TAKIP KALICI YAYIN ANAHTARI

Bu klasordeki servis-takip-release.p12 ve key.properties dosyalari birlikte yedeklenmelidir.
Bu dosyalar kaybolursa mevcut uygulamanin uzerine yeni guncelleme kurulamaz.
Dosyalari GitHub'a, e-postaya veya herkese acik bir konuma yuklemeyin.
En az bir sifreli harici bellek veya guvenli sifre kasasinda ikinci kopya saklayin.

Olusturulma: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')
"@
[IO.File]::WriteAllText($backupNote, $noteContent, [Text.UTF8Encoding]::new($false))

$desktopUser = "${env:COMPUTERNAME}\$(Split-Path $env:USERPROFILE -Leaf)"
$processIdentity = [Security.Principal.WindowsIdentity]::GetCurrent().Name
& icacls.exe $signingDirectory /inheritance:r `
    /grant:r "${desktopUser}:(OI)(CI)F" `
    "${processIdentity}:(OI)(CI)F" `
    'NT AUTHORITY\SYSTEM:(OI)(CI)F' `
    'BUILTIN\Administrators:(OI)(CI)F' | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw 'Imza klasoru erisim izinleri ayarlanamadi.'
}

Write-Output "Kalici yayin anahtari olusturuldu: $signingDirectory"
Write-Output 'Gizli anahtar veya sifre ekrana yazdirilmadi.'
