import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import '../models/company.dart';
import '../models/company_user.dart';

class AdminRepository {
  AdminRepository({FirebaseAuth? auth, FirebaseFirestore? firestore})
    : _auth = auth ?? FirebaseAuth.instance,
      _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _firestore;

  User? get currentUser => _auth.currentUser;

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  Future<void> signIn({required String email, required String password}) async {
    await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
  }

  Future<void> signOut() => _auth.signOut();

  Future<bool> isSystemAdmin() async {
    final user = _auth.currentUser;
    if (user == null) return false;

    final token = await user.getIdTokenResult();
    if (token.claims?['role'] == 'system_admin') return true;

    final profile = await _firestore.collection('users').doc(user.uid).get();
    return profile.data()?['role'] == 'system_admin';
  }

  Stream<List<Company>> watchCompanies() {
    return _firestore
        .collection('companies')
        .orderBy('name')
        .snapshots()
        .map(
          (snapshot) => snapshot.docs
              .map((document) => Company.fromDocument(document))
              .toList(),
        );
  }

  Stream<List<CompanyUser>> watchCompanyUsers(String companyId) {
    return _firestore
        .collection('users')
        .where('companyId', isEqualTo: companyId)
        .snapshots()
        .map((snapshot) {
          final users = snapshot.docs
              .map((document) => CompanyUser.fromDocument(document))
              .toList();
          users.sort(
            (first, second) => first.displayName.toLowerCase().compareTo(
              second.displayName.toLowerCase(),
            ),
          );
          return users;
        });
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchRegisteredDevices() =>
      _firestore.collection('users').snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> watchDeviceExemptions() =>
      _firestore.collection('deviceExemptions').snapshots();

  Future<void> setDeviceExemption({
    required String userId,
    required String deviceId,
    required String deviceName,
    required bool active,
  }) async {
    final reference = _firestore
        .collection('deviceExemptions')
        .doc('${userId}_$deviceId');
    if (!active) {
      await reference.delete();
      return;
    }
    await reference.set({
      'userId': userId,
      'deviceId': deviceId,
      'deviceName': deviceName,
      'active': true,
      'updatedAt': FieldValue.serverTimestamp(),
      'updatedBy': _auth.currentUser?.uid,
    }, SetOptions(merge: true));
  }

  Future<void> createCompanyUser({
    required Company company,
    required String displayName,
    required String password,
    required String role,
  }) async {
    await ensureCompanyLoginCode(company);
    final internalEmail = _internalEmail(
      companyId: company.id,
      displayName: displayName,
    );
    final secondaryApp = await Firebase.initializeApp(
      name: 'user-creation-${DateTime.now().microsecondsSinceEpoch}',
      options: Firebase.app().options,
    );
    final secondaryAuth = FirebaseAuth.instanceFor(app: secondaryApp);
    User? createdUser;

    try {
      final credential = await secondaryAuth.createUserWithEmailAndPassword(
        email: internalEmail,
        password: password,
      );
      createdUser = credential.user;
      if (createdUser == null) {
        throw StateError('Kullanıcı hesabı oluşturulamadı.');
      }
      await createdUser.updateDisplayName(displayName.trim());

      final companyReference = _firestore
          .collection('companies')
          .doc(company.id);
      final userReference = _firestore.collection('users').doc(createdUser.uid);

      await _firestore.runTransaction((transaction) async {
        final companySnapshot = await transaction.get(companyReference);
        if (!companySnapshot.exists) {
          throw StateError('Şirket bulunamadı.');
        }
        final currentCompany = Company.fromDocument(companySnapshot);
        if (!currentCompany.active || currentCompany.isExpired) {
          throw StateError('Şirket aktif değil.');
        }
        if (currentCompany.usage.users >= currentCompany.limits.maxUsers) {
          throw StateError(
            'Bu şirketin kullanıcı sınırı doldu '
            '(${currentCompany.usage.users}/${currentCompany.limits.maxUsers}).',
          );
        }

        final userData = <String, dynamic>{
          'companyId': company.id,
          'displayName': displayName.trim(),
          'email': internalEmail,
          'loginName': _normalizeLoginName(displayName),
          'role': role,
          'permissions': _defaultPermissions(role),
          'allInstitutions': true,
          'allowedInstitutionIds': <String>[],
          'active': true,
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        };
        transaction.set(userReference, userData);
        transaction.update(companyReference, {
          'usage.users': currentCompany.usage.users + 1,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      });
    } catch (_) {
      if (createdUser != null) {
        await createdUser.delete().catchError((_) {});
      }
      rethrow;
    } finally {
      await secondaryAuth.signOut();
      await secondaryApp.delete();
    }
  }

  Future<String> ensureCompanyLoginCode(Company company) async {
    final code = company.loginCode.trim().toUpperCase();
    final companyReference = _firestore.collection('companies').doc(company.id);
    final codeReference = _firestore.collection('companyLoginCodes').doc(code);

    await _firestore.runTransaction((transaction) async {
      final codeSnapshot = await transaction.get(codeReference);
      if (codeSnapshot.exists &&
          codeSnapshot.data()?['companyId'] != company.id) {
        throw StateError(
          'Şirket giriş kodu başka bir şirket tarafından kullanılıyor.',
        );
      }
      transaction.set(codeReference, {
        'companyId': company.id,
        'companyName': company.name,
        'active': company.active && !company.isExpired,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      transaction.update(companyReference, {
        'loginCode': code,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
    return code;
  }

  Future<void> updateCompanyUser({
    required CompanyUser user,
    required String role,
    required bool active,
  }) async {
    await _firestore.collection('users').doc(user.id).update({
      'role': role,
      'permissions': _defaultPermissions(role),
      'active': active,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> resetCompanyUserDevice(CompanyUser user) async {
    await _firestore.collection('users').doc(user.id).update({
      'deviceId': FieldValue.delete(),
      'deviceName': FieldValue.delete(),
      'deviceBoundAt': FieldValue.delete(),
      'deviceLastSeenAt': FieldValue.delete(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Map<String, bool> _defaultPermissions(String role) {
    final canManage = role == 'company_admin' || role == 'owner';
    return {
      'canViewSettings': canManage,
      'canManageInstitutions': canManage,
      'canManageVehicles': canManage,
      'canManageEmployees': canManage,
      'canManagePersonnel': canManage,
      'canManageStops': canManage,
      'canManageShifts': canManage,
      'canViewReports': canManage,
    };
  }

  String _internalEmail({
    required String companyId,
    required String displayName,
  }) {
    final loginName = _normalizeLoginName(displayName);
    return '$loginName.$companyId@servistakip.local';
  }

  String _normalizeLoginName(String value) {
    var normalized = value.trim().toLowerCase();
    const replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((source, target) {
      normalized = normalized.replaceAll(source, target);
    });
    normalized = normalized
        .replaceAll(RegExp(r'[^a-z0-9]+'), '.')
        .replaceAll(RegExp(r'^\.+|\.+$'), '');
    return normalized.isEmpty ? 'kullanici' : normalized;
  }

  Future<void> createCompany({
    required String name,
    required String planName,
    required CompanyLimits limits,
    DateTime? expiresAt,
  }) async {
    final reference = _firestore.collection('companies').doc();
    await reference.set({
      'name': name.trim(),
      'nameLower': name.trim().toLowerCase(),
      'active': true,
      'planName': planName.trim(),
      'limits': limits.toJson(),
      'usage': {
        'users': 0,
        'institutions': 0,
        'personnel': 0,
        'stops': 0,
        'vehicles': 0,
      },
      'expiresAt': expiresAt == null ? null : Timestamp.fromDate(expiresAt),
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> updateCompany({
    required String companyId,
    required String planName,
    required CompanyLimits limits,
    required bool active,
    DateTime? expiresAt,
  }) async {
    await _firestore.collection('companies').doc(companyId).update({
      'active': active,
      'planName': planName.trim(),
      'limits': limits.toJson(),
      'expiresAt': expiresAt == null ? null : Timestamp.fromDate(expiresAt),
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }
}
