import 'package:flutter/material.dart';

import '../models/shift_definition.dart';
import '../services/shift_definition_storage.dart';
import 'shift_definition_form_screen.dart';

class ShiftsScreen extends StatefulWidget {
  const ShiftsScreen({super.key});

  @override
  State<ShiftsScreen> createState() => _ShiftsScreenState();
}

class _ShiftsScreenState extends State<ShiftsScreen> {
  bool _loading = true;
  List<ShiftDefinition> _definitions = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final items = await ShiftDefinitionStorage.readAll();
    if (!mounted) return;
    setState(() {
      _definitions = items;
      _loading = false;
    });
  }

  Future<void> _openEditor([ShiftDefinition? definition]) async {
    final result = await Navigator.push<ShiftDefinition>(
      context,
      MaterialPageRoute(
        builder: (_) => ShiftDefinitionFormScreen(definition: definition),
      ),
    );
    if (result == null) return;
    final updated = definition == null
        ? [..._definitions, result]
        : [
            for (final item in _definitions)
              if (item.id == definition.id) result else item,
          ];
    await _save(updated);
  }

  Future<void> _delete(ShiftDefinition definition) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Vardiya sistemi silinsin mi?'),
        content: Text('${definition.name} buluttan silinecek.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('SİL'),
          ),
        ],
      ),
    );
    if (approved == true) {
      await _save(
        _definitions.where((item) => item.id != definition.id).toList(),
      );
    }
  }

  Future<void> _save(List<ShiftDefinition> items) async {
    await ShiftDefinitionStorage.saveAll(items);
    if (!mounted) return;
    setState(() => _definitions = items);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Vardiyalar buluta kaydedildi.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Vardiyalar')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _openEditor,
        icon: const Icon(Icons.add),
        label: const Text('Vardiya Sistemi Ekle'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _definitions.isEmpty
          ? const Center(child: Text('Henüz vardiya sistemi oluşturulmadı.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
              itemCount: _definitions.length,
              itemBuilder: (context, index) {
                final definition = _definitions[index];
                return Card(
                  child: ExpansionTile(
                    leading: CircleAvatar(child: Text('${index + 1}')),
                    title: Text(
                      definition.name,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${definition.slots.length} vardiya • ${definition.directionLabel}',
                    ),
                    children: [
                      for (final slot in definition.slots)
                        ListTile(
                          dense: true,
                          leading: const Icon(Icons.schedule_outlined),
                          title: Text(slot.label),
                        ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton.icon(
                            onPressed: () => _openEditor(definition),
                            icon: const Icon(Icons.edit_outlined),
                            label: const Text('Düzenle'),
                          ),
                          TextButton.icon(
                            onPressed: () => _delete(definition),
                            icon: const Icon(Icons.delete_outline),
                            label: const Text('Sil'),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
