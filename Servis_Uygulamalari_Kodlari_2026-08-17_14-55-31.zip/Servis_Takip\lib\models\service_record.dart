class ServiceRecord {
  const ServiceRecord({
    required this.id,
    required this.date,
    required this.shift,
    required this.driverId,
    required this.driverName,
    required this.startedAt,
    this.institutionId = '',
    this.institutionName = '',
    this.vehicleId = '',
    this.vehiclePlate = '',
    this.endedAt,
    this.boardedCount,
    this.absentCount,
    this.expectedCount,
    this.unmarkedCount,
    this.serviceType = pickupType,
    this.reportingEnabled = true,
  });

  static const pickupType = 'Toplama';
  static const distributionType = 'Dağıtım';

  final String id;
  final String date;
  final String shift;
  final String driverId;
  final String driverName;
  final String startedAt;
  final String institutionId;
  final String institutionName;
  final String vehicleId;
  final String vehiclePlate;
  final String? endedAt;
  final int? boardedCount;
  final int? absentCount;
  final int? expectedCount;
  final int? unmarkedCount;
  final String serviceType;
  final bool reportingEnabled;

  ServiceRecord copyWith({
    String? endedAt,
    int? boardedCount,
    int? absentCount,
    int? expectedCount,
    int? unmarkedCount,
  }) => ServiceRecord(
    id: id,
    date: date,
    shift: shift,
    driverId: driverId,
    driverName: driverName,
    startedAt: startedAt,
    institutionId: institutionId,
    institutionName: institutionName,
    vehicleId: vehicleId,
    vehiclePlate: vehiclePlate,
    endedAt: endedAt ?? this.endedAt,
    boardedCount: boardedCount ?? this.boardedCount,
    absentCount: absentCount ?? this.absentCount,
    expectedCount: expectedCount ?? this.expectedCount,
    unmarkedCount: unmarkedCount ?? this.unmarkedCount,
    serviceType: serviceType,
    reportingEnabled: reportingEnabled,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'date': date,
    'shift': shift,
    'driverId': driverId,
    'driverName': driverName,
    'startedAt': startedAt,
    'institutionId': institutionId,
    'institutionName': institutionName,
    'vehicleId': vehicleId,
    'vehiclePlate': vehiclePlate,
    'endedAt': endedAt,
    'boardedCount': boardedCount,
    'absentCount': absentCount,
    'expectedCount': expectedCount,
    'unmarkedCount': unmarkedCount,
    'serviceType': serviceType,
    'reportingEnabled': reportingEnabled,
  };

  factory ServiceRecord.fromJson(Map<String, dynamic> json) => ServiceRecord(
    id: json['id'] as String,
    date: json['date'] as String,
    shift: json['shift'] as String,
    driverId: json['driverId'] as String,
    driverName: json['driverName'] as String,
    startedAt: json['startedAt'] as String,
    institutionId: json['institutionId'] as String? ?? '',
    institutionName: json['institutionName'] as String? ?? '',
    vehicleId: json['vehicleId'] as String? ?? '',
    vehiclePlate: json['vehiclePlate'] as String? ?? '',
    endedAt: json['endedAt'] as String?,
    boardedCount: json['boardedCount'] as int?,
    absentCount: json['absentCount'] as int?,
    expectedCount: json['expectedCount'] as int?,
    unmarkedCount: json['unmarkedCount'] as int? ?? 0,
    serviceType: json['serviceType'] as String? ?? pickupType,
    reportingEnabled: json['reportingEnabled'] as bool? ?? false,
  );
}
