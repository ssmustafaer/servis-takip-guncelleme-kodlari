import 'package:flutter/material.dart';

import '../models/attendance_record.dart';
import '../models/institution.dart';
import '../models/personnel.dart';
import '../models/service_record.dart';
import '../models/work_shift.dart';
import '../services/attendance_storage.dart';
import '../services/company_cloud_storage.dart';
import '../services/institution_storage.dart';
import '../services/personnel_storage.dart';
import '../services/package_access_service.dart';
import '../services/service_record_storage.dart';
import '../services/shift_calculator.dart';
import '../services/shift_storage.dart';

enum _ReportFilter { all, completed, unmarked, missed, unfinished }

enum _DailyReportView { institution, vehicle, driver }

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  bool _menuVisible = true;
  bool _dailyReportVisible = false;
  bool _personnelReportVisible = false;
  DateTime _dailyReportDate = DateTime.now();
  _DailyReportView _dailyReportView = _DailyReportView.institution;
  String? _selectedDailyInstitution;
  String? _selectedReportDriver;
  DateTime _personnelStartDate = DateTime.now().subtract(
    const Duration(days: 29),
  );
  DateTime _personnelEndDate = DateTime.now();
  var _loading = true;
  var _periodDays = 7;
  var _filter = _ReportFilter.all;
  List<ServiceRecord> _records = [];
  List<Personnel> _personnel = [];
  List<WorkShift> _shifts = [];
  List<AttendanceRecord> _attendance = [];
  List<Institution> _institutions = [];
  bool _allReportsAllowed = true;
  int _reportHistoryDays = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final companyId = await CompanyCloudStorage.companyId();
      if (companyId != null && companyId.isNotEmpty) {
        final package = await PackageAccessService.entitlements(companyId);
        _allReportsAllowed = package['allReports'] as bool? ?? true;
        _reportHistoryDays =
            (package['reportHistoryDays'] as num?)?.toInt() ?? 0;
      }
    } catch (_) {
      _allReportsAllowed = true;
      _reportHistoryDays = 0;
    }
    final result = await Future.wait([
      ServiceRecordStorage.readAll(),
      PersonnelStorage.readAll(),
      ShiftStorage.readAll(),
      AttendanceStorage.readAll(),
      InstitutionStorage.readAll(),
    ]);
    if (!mounted) return;
    setState(() {
      _records = result[0] as List<ServiceRecord>;
      _personnel = result[1] as List<Personnel>;
      _shifts = result[2] as List<WorkShift>;
      _attendance = result[3] as List<AttendanceRecord>;
      _institutions = result[4] as List<Institution>;
      _loading = false;
    });
  }

  Future<void> _resetShiftRecords() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Vardiya kayıtlarını sıfırla'),
        content: const Text(
          'Başlatılan ve bitirilen servisler ile bütün Bindi/Yok kayıtları '
          'kalıcı olarak silinecek.\n\n'
          'Personel, kurum, durak, araç, çalışan ve vardiya tanımları '
          'silinmeyecek.\n\n'
          'Bu işlem geri alınamaz. Devam edilsin mi?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            icon: const Icon(Icons.delete_forever_rounded),
            label: const Text('KAYITLARI SİL'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    setState(() => _loading = true);
    try {
      await Future.wait([
        ServiceRecordStorage.saveAll(const []),
        AttendanceStorage.saveAll(const []),
      ]);
      if (!mounted) return;
      setState(() {
        _records = [];
        _attendance = [];
        _loading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Vardiya geçmişi sıfırlandı. Yeni kayıtlar bugünden itibaren başlayacak.',
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Kayıtlar silinemedi: $error')));
    }
  }

  DateTime _dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  DateTime? _dateFromIso(String value) {
    final parsed = DateTime.tryParse(value);
    return parsed == null ? null : _dateOnly(parsed);
  }

  DateTime _shiftEnd(DateTime date, String shift) {
    final base = shift.endsWith(' Sabit')
        ? shift.substring(0, shift.length - ' Sabit'.length)
        : shift;
    final end = int.tryParse(base.split('/').last.trim()) ?? 0;
    if (end == 24 || end == 0) {
      return _dateOnly(date).add(const Duration(days: 1));
    }
    return DateTime(date.year, date.month, date.day, end);
  }

  List<Personnel> _peopleFor(DateTime date, String shift) {
    final fixed = shift.endsWith(' Sabit');
    final base = fixed
        ? shift.substring(0, shift.length - ' Sabit'.length)
        : shift;
    return _personnel.where((person) {
      if (person.workType == Personnel.reliefWorkType) {
        final dayShifts = person.reliefShiftsForDate(date);
        return !fixed &&
            dayShifts.contains(base) &&
            person.serviceParticipationIncludes(date, base);
      }
      final status = ShiftCalculator.forDate(person, date);
      final combineSaturday =
          date.weekday == DateTime.saturday && base == '08 / 16';
      final typeMatches =
          combineSaturday ||
          (fixed && person.workType == Personnel.fixedWorkType) ||
          (!fixed && person.workType == Personnel.rotatingWorkType);
      return !status.isLeave &&
          status.shift == base &&
          typeMatches &&
          person.serviceParticipationIncludes(date, base);
    }).toList();
  }

  List<_ReportItem> get _items {
    final now = DateTime.now();
    final today = _dateOnly(now);
    var start = today.subtract(Duration(days: _periodDays - 1));
    final recordDates = _records
        .where((record) => record.reportingEnabled)
        .map((record) => _dateFromIso(record.date))
        .whereType<DateTime>()
        .toList();
    if (recordDates.isNotEmpty) {
      recordDates.sort();
      if (recordDates.first.isAfter(start)) start = recordDates.first;
    } else {
      start = today;
    }

    final periodRecords = _records.where((record) {
      final date = _dateFromIso(record.date);
      return date != null && !date.isBefore(start) && !date.isAfter(today);
    });

    final items = <_ReportItem>[
      for (final record in periodRecords)
        _ReportItem.fromService(record, _unmarkedNames(record)),
    ];

    for (
      var date = start;
      !date.isAfter(today);
      date = date.add(const Duration(days: 1))
    ) {
      final dateIso =
          '${date.year.toString().padLeft(4, '0')}-'
          '${date.month.toString().padLeft(2, '0')}-'
          '${date.day.toString().padLeft(2, '0')}';
      for (final shift in _shifts) {
        // Cumartesi günü sabit personel normal 08 / 16 listesine birleşir;
        // ayrıca ikinci bir "08 / 16 Sabit" servisi beklenmez.
        if (date.weekday == DateTime.saturday &&
            shift.name.endsWith(' Sabit')) {
          continue;
        }
        if (_shiftEnd(date, shift.name).isAfter(now)) continue;
        final expected = _peopleFor(date, shift.name).length;
        if (expected == 0) continue;
        for (final type in const [
          ServiceRecord.pickupType,
          ServiceRecord.distributionType,
        ]) {
          final exists = periodRecords.any(
            (record) =>
                record.date == dateIso &&
                record.shift == shift.name &&
                record.serviceType == type,
          );
          if (!exists) {
            items.add(
              _ReportItem.missed(
                date: dateIso,
                shift: shift.name,
                serviceType: type,
                expectedCount: expected,
              ),
            );
          }
        }
      }
    }
    items.sort((a, b) => b.sortDate.compareTo(a.sortDate));
    return items;
  }

  List<String> _unmarkedNames(ServiceRecord service) {
    final personnelById = {
      for (final person in _personnel) person.id: person.fullName,
    };
    return _attendance
        .where(
          (record) => record.serviceId == service.id && !record.markedByDriver,
        )
        .map((record) => personnelById[record.personId] ?? 'Silinmiş personel')
        .toList();
  }

  List<_ReportItem> get _filteredItems {
    return _items.where((item) {
      return switch (_filter) {
        _ReportFilter.all => true,
        _ReportFilter.completed => item.kind == _ReportKind.completed,
        _ReportFilter.unmarked => item.unmarkedCount > 0,
        _ReportFilter.missed => item.kind == _ReportKind.missed,
        _ReportFilter.unfinished => item.kind == _ReportKind.unfinished,
      };
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    if (_menuVisible) return _buildReportsMenu();
    if (_dailyReportVisible) return _buildDailyReport();
    if (_personnelReportVisible) return _buildPersonnelServiceReport();
    final allItems = _items;
    final completed = allItems
        .where((item) => item.kind == _ReportKind.completed)
        .length;
    final missed = allItems
        .where((item) => item.kind == _ReportKind.missed)
        .length;
    final unmarked = allItems.fold<int>(
      0,
      (total, item) => total + item.unmarkedCount,
    );
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => setState(() => _menuVisible = true),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: const Text('Servis Raporları'),
        actions: [
          IconButton(
            onPressed: _loading ? null : _resetShiftRecords,
            icon: const Icon(Icons.delete_sweep_rounded),
            tooltip: 'Vardiya kayıtlarını sıfırla',
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                children: [
                  DropdownButtonFormField<int>(
                    initialValue: _periodDays,
                    decoration: const InputDecoration(
                      labelText: 'Rapor dönemi',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.date_range_rounded),
                    ),
                    items: const [
                      DropdownMenuItem(value: 7, child: Text('Son 7 gün')),
                      DropdownMenuItem(value: 30, child: Text('Son 30 gün')),
                    ],
                    onChanged: (value) {
                      if (value != null) setState(() => _periodDays = value);
                    },
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _SummaryCard(
                        label: 'Tamamlanan',
                        value: completed,
                        color: const Color(0xFF0B6E4F),
                      ),
                      const SizedBox(width: 8),
                      _SummaryCard(
                        label: 'Başlatılmayan',
                        value: missed,
                        color: const Color(0xFFB3261E),
                      ),
                      const SizedBox(width: 8),
                      _SummaryCard(
                        label: 'İşaretlenmeyen',
                        value: unmarked,
                        color: const Color(0xFF9A6700),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      _filterChip('Tümü', _ReportFilter.all),
                      _filterChip('Tamamlanan', _ReportFilter.completed),
                      _filterChip('İşaretlenmeyen', _ReportFilter.unmarked),
                      _filterChip('Başlatılmayan', _ReportFilter.missed),
                      _filterChip('Bitirilmeyen', _ReportFilter.unfinished),
                    ],
                  ),
                  const SizedBox(height: 12),
                  if (_filteredItems.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(32),
                      child: Center(
                        child: Text('Bu ölçütlere uygun rapor kaydı yok.'),
                      ),
                    )
                  else
                    ..._filteredItems.map(_reportCard),
                ],
              ),
            ),
    );
  }

  Widget _buildReportsMenu() {
    return Scaffold(
      appBar: AppBar(title: const Text('Raporlar')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
        children: [
          const Text(
            'Görüntülemek istediğiniz raporu seçin',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: Color(0xFF082A52),
            ),
          ),
          const SizedBox(height: 14),
          _reportMenuTile(
            title: 'Kurum Servis Raporu',
            subtitle: 'Kurumlara göre günlük servis sonuçları',
            icon: Icons.business_rounded,
            color: const Color(0xFF1565C0),
            filter: _ReportFilter.all,
            periodDays: 7,
            dailyReport: true,
            dailyReportView: _DailyReportView.institution,
          ),
          _reportMenuTile(
            title: 'Personel Servis Raporu',
            subtitle: 'Personel binişleri ve işaretlenmeyen kayıtlar',
            icon: Icons.groups_rounded,
            color: const Color(0xFF0B6E4F),
            filter: _ReportFilter.unmarked,
            periodDays: 30,
            personnelReport: true,
            enabled: _allReportsAllowed,
          ),
          _reportMenuTile(
            title: 'Araç Servis Raporu',
            subtitle: 'Araçlara göre günlük servis sonuçları',
            icon: Icons.directions_bus_rounded,
            color: const Color(0xFF00838F),
            filter: _ReportFilter.all,
            periodDays: 7,
            dailyReport: true,
            dailyReportView: _DailyReportView.vehicle,
            enabled: _allReportsAllowed,
          ),
          _reportMenuTile(
            title: 'İzin ve Devamsızlık Raporu',
            subtitle: 'Başlatılmayan ve eksik tamamlanan servisler',
            icon: Icons.person_off_rounded,
            color: const Color(0xFFB3261E),
            filter: _ReportFilter.missed,
            periodDays: 30,
            enabled: _allReportsAllowed,
          ),
          _reportMenuTile(
            title: 'Servis Geçmişi',
            subtitle: 'Tamamlanan ve bitirilmeyen bütün servisler',
            icon: Icons.history_rounded,
            color: const Color(0xFF6A4C93),
            filter: _ReportFilter.all,
            periodDays: 30,
            enabled: _allReportsAllowed,
          ),
          Card(
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              minTileHeight: 78,
              leading: const CircleAvatar(
                radius: 24,
                backgroundColor: Color(0xFFE4F6F1),
                child: Icon(Icons.ios_share_rounded, color: Color(0xFF128C7E)),
              ),
              title: const Text(
                'Dışa aktar ve paylaş',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: const Text(
                'Raporları görüntüleyip paylaşmaya hazırlayın',
              ),
              trailing: Icon(
                _allReportsAllowed
                    ? Icons.chevron_right_rounded
                    : Icons.lock_rounded,
              ),
              onTap: _allReportsAllowed
                  ? () => setState(() {
                      _periodDays = 30;
                      _filter = _ReportFilter.all;
                      _dailyReportVisible = false;
                      _personnelReportVisible = false;
                      _menuVisible = false;
                    })
                  : _showPackageRequired,
            ),
          ),
        ],
      ),
    );
  }

  Widget _reportMenuTile({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required _ReportFilter filter,
    required int periodDays,
    bool dailyReport = false,
    bool personnelReport = false,
    _DailyReportView? dailyReportView,
    bool enabled = true,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        minTileHeight: 78,
        leading: CircleAvatar(
          radius: 24,
          backgroundColor: color.withValues(alpha: 0.12),
          child: Icon(icon, color: color),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        trailing: Icon(
          enabled ? Icons.chevron_right_rounded : Icons.lock_rounded,
        ),
        onTap: enabled
            ? () => setState(() {
                _periodDays = periodDays;
                _filter = filter;
                _dailyReportVisible = dailyReport;
                _personnelReportVisible = personnelReport;
                if (dailyReportView != null) {
                  _dailyReportView = dailyReportView;
                  if (dailyReportView != _DailyReportView.institution) {
                    _selectedDailyInstitution = null;
                  }
                }
                _menuVisible = false;
              })
            : _showPackageRequired,
      ),
    );
  }

  void _showPackageRequired() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Bu rapor Standart ve Profesyonel paketlerde kullanılabilir.',
        ),
      ),
    );
  }

  Widget _buildPersonnelServiceReport() {
    final startDate = _dateOnly(_personnelStartDate);
    final endDate = _dateOnly(_personnelEndDate);
    final periodRecords = _records.where((record) {
      final date = _dateFromIso(record.date);
      return date != null &&
          !date.isBefore(startDate) &&
          !date.isAfter(endDate) &&
          record.reportingEnabled &&
          record.driverName.trim().isNotEmpty;
    }).toList();
    final drivers = <String, String>{};
    for (final record in periodRecords) {
      final key = record.driverId.isEmpty ? record.driverName : record.driverId;
      drivers[key] = record.driverName;
    }
    final driverEntries = drivers.entries.toList()
      ..sort((a, b) => a.value.compareTo(b.value));
    final selectedDriver = drivers.containsKey(_selectedReportDriver)
        ? _selectedReportDriver
        : null;
    final selectedRecords = <ServiceRecord>[
      if (selectedDriver != null)
        ...periodRecords.where((record) {
          final key = record.driverId.isEmpty
              ? record.driverName
              : record.driverId;
          return key == selectedDriver;
        }),
    ]..sort((a, b) => b.startedAt.compareTo(a.startedAt));
    final shiftCounts = <String, int>{};
    for (final record in selectedRecords) {
      shiftCounts.update(record.shift, (count) => count + 1, ifAbsent: () => 1);
    }
    final shifts = shiftCounts.keys.toList()..sort();
    final vehicles =
        selectedRecords
            .map((item) => item.vehiclePlate)
            .where((item) => item.isNotEmpty)
            .toSet()
            .toList()
          ..sort();
    final regions =
        selectedRecords
            .map((record) => _institutionLevels(record).region)
            .where((name) => name != 'Belirtilmemiş')
            .toSet()
            .toList()
          ..sort();
    final institutions =
        selectedRecords
            .map(_serviceMainInstitutionName)
            .where((name) => name != 'Kurum belirtilmemiş')
            .toSet()
            .toList()
          ..sort();
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => setState(() {
            _personnelReportVisible = false;
            _menuVisible = true;
          }),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: const Text('Personel Servis Raporu'),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          children: [
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _choosePersonnelReportDate(true),
                    icon: const Icon(Icons.event_rounded),
                    label: Text(
                      'Başlangıç\n${_shortDate(_personnelStartDate)}',
                      textAlign: TextAlign.center,
                    ),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(58),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _choosePersonnelReportDate(false),
                    icon: const Icon(Icons.event_available_rounded),
                    label: Text(
                      'Bitiş\n${_shortDate(_personnelEndDate)}',
                      textAlign: TextAlign.center,
                    ),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(58),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              key: ValueKey(
                'report_driver_${_shortDate(_personnelStartDate)}_'
                '${_shortDate(_personnelEndDate)}_$selectedDriver',
              ),
              initialValue: selectedDriver,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Personel / Şoför Seç',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.badge_rounded),
              ),
              items: driverEntries
                  .map(
                    (entry) => DropdownMenuItem(
                      value: entry.key,
                      child: Text(entry.value),
                    ),
                  )
                  .toList(),
              onChanged: (value) =>
                  setState(() => _selectedReportDriver = value),
            ),
            const SizedBox(height: 16),
            if (selectedDriver == null)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(
                  child: Text('Raporu görmek için personel seçin.'),
                ),
              )
            else ...[
              Card(
                color: const Color(0xFFEAF4FF),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        drivers[selectedDriver]!,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: Color(0xFF082A52),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'KURUM: ${institutions.isEmpty ? '-' : institutions.join(', ')}',
                      ),
                      Text(
                        'BÖLGE: ${regions.isEmpty ? '-' : regions.join(', ')}',
                      ),
                      Text(
                        'ARAÇ: ${vehicles.isEmpty ? '-' : vehicles.join(', ')}',
                      ),
                      const SizedBox(height: 6),
                      Text('Yaptığı servis: ${selectedRecords.length}'),
                      const Text(
                        'Vardiyalar',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                      if (shifts.isEmpty)
                        const Text('-')
                      else
                        for (final shift in shifts)
                          Text('$shift: ${shiftCounts[shift]} servis'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 10),
              for (final record in selectedRecords)
                Card(
                  margin: const EdgeInsets.only(bottom: 9),
                  child: ExpansionTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.directions_bus_rounded),
                    ),
                    title: Text(
                      '${_reportDate(record.date)} • ${record.shift}',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${record.serviceType} • ${record.vehiclePlate.isEmpty ? 'Plaka yok' : record.vehiclePlate}',
                    ),
                    childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 14),
                    children: [_personnelRecordTable(record)],
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  String _shortDate(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}.'
      '${date.month.toString().padLeft(2, '0')}.${date.year}';

  Future<void> _choosePersonnelReportDate(bool start) async {
    final selected = await showDatePicker(
      context: context,
      initialDate: start ? _personnelStartDate : _personnelEndDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2040),
      helpText: start ? 'BAŞLANGIÇ TARİHİ' : 'BİTİŞ TARİHİ',
    );
    if (selected == null || !mounted) return;
    setState(() {
      if (start) {
        _personnelStartDate = selected;
        if (_personnelEndDate.isBefore(selected)) {
          _personnelEndDate = selected;
        }
      } else {
        _personnelEndDate = selected;
        if (_personnelStartDate.isAfter(selected)) {
          _personnelStartDate = selected;
        }
      }
      _selectedReportDriver = null;
    });
  }

  String _reportDate(String value) {
    final date = DateTime.tryParse(value);
    if (date == null) return value;
    return '${date.day.toString().padLeft(2, '0')}.'
        '${date.month.toString().padLeft(2, '0')}.${date.year}';
  }

  Widget _personnelRecordTable(ServiceRecord record) {
    final levels = _institutionLevels(record);
    final rows = <(String, String)>[
      ('Kurum', _serviceMainInstitutionName(record)),
      ('Bölge', levels.region),
      if (levels.team != 'Belirtilmemiş') ('Takım', levels.team),
      ('Vardiya', record.shift),
      (
        'Araç Plaka',
        record.vehiclePlate.isEmpty ? 'Belirtilmemiş' : record.vehiclePlate,
      ),
      ('Servis Türü', record.serviceType),
      ('Başlama', _reportTime(record.startedAt)),
      ('Bitiş', _reportTime(record.endedAt)),
      ('Toplam Yolcu', '${record.expectedCount ?? 0}'),
      ('Gelen', '${record.boardedCount ?? 0}'),
      ('Gelmeyen', '${record.absentCount ?? 0}'),
    ];
    return Table(
      border: TableBorder.all(color: const Color(0xFFD4DEE8)),
      columnWidths: const {0: FlexColumnWidth(1), 1: FlexColumnWidth(1.45)},
      children: [
        for (var index = 0; index < rows.length; index++)
          TableRow(
            decoration: BoxDecoration(
              color: index.isEven ? const Color(0xFFF4F7FA) : Colors.white,
            ),
            children: [
              Padding(
                padding: const EdgeInsets.all(9),
                child: Text(
                  rows[index].$1,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(9),
                child: Text(rows[index].$2),
              ),
            ],
          ),
      ],
    );
  }

  String get _dailyDateIso =>
      '${_dailyReportDate.year.toString().padLeft(4, '0')}-'
      '${_dailyReportDate.month.toString().padLeft(2, '0')}-'
      '${_dailyReportDate.day.toString().padLeft(2, '0')}';

  String get _dailyDateText =>
      '${_dailyReportDate.day.toString().padLeft(2, '0')}.'
      '${_dailyReportDate.month.toString().padLeft(2, '0')}.'
      '${_dailyReportDate.year}';

  Future<void> _chooseDailyReportDate() async {
    final now = DateTime.now();
    final firstAllowed = _reportHistoryDays <= 0
        ? DateTime(2020)
        : _dateOnly(now).subtract(Duration(days: _reportHistoryDays - 1));
    final selected = await showDatePicker(
      context: context,
      initialDate: _dailyReportDate,
      firstDate: firstAllowed,
      lastDate: DateTime(2040),
      helpText: 'RAPOR TARİHİ',
    );
    if (selected != null && mounted) {
      setState(() {
        _dailyReportDate = selected;
        _selectedDailyInstitution = null;
      });
    }
  }

  Widget _buildDailyReport() {
    final allRecords = _records
        .where(
          (record) => record.date == _dailyDateIso && record.reportingEnabled,
        )
        .toList();
    final institutionNames =
        allRecords.map(_mainInstitutionName).toSet().toList()..sort();
    final selectedInstitution =
        institutionNames.contains(_selectedDailyInstitution)
        ? _selectedDailyInstitution
        : null;
    final records =
        _dailyReportView == _DailyReportView.institution &&
            selectedInstitution != null
        ? allRecords.where((record) {
            final name = _mainInstitutionName(record);
            return name == selectedInstitution;
          }).toList()
        : allRecords;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => setState(() {
            _dailyReportVisible = false;
            _menuVisible = true;
          }),
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        title: Text(switch (_dailyReportView) {
          _DailyReportView.institution => 'Kurum Servis Raporu',
          _DailyReportView.vehicle => 'Araç Servis Raporu',
          _DailyReportView.driver => 'Şoför Servis Raporu',
        }),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
          children: [
            OutlinedButton.icon(
              onPressed: _chooseDailyReportDate,
              icon: const Icon(Icons.calendar_month_rounded),
              label: Text(_dailyDateText),
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
              ),
            ),
            const SizedBox(height: 12),
            SegmentedButton<_DailyReportView>(
              segments: const [
                ButtonSegment(
                  value: _DailyReportView.institution,
                  icon: Icon(Icons.business_rounded),
                  label: Text('Kurum'),
                ),
                ButtonSegment(
                  value: _DailyReportView.vehicle,
                  icon: Icon(Icons.directions_bus_rounded),
                  label: Text('Araç'),
                ),
                ButtonSegment(
                  value: _DailyReportView.driver,
                  icon: Icon(Icons.badge_rounded),
                  label: Text('Şoför'),
                ),
              ],
              selected: {_dailyReportView},
              onSelectionChanged: (selection) => setState(() {
                _dailyReportView = selection.first;
                if (_dailyReportView != _DailyReportView.institution) {
                  _selectedDailyInstitution = null;
                }
              }),
            ),
            const SizedBox(height: 16),
            if (_dailyReportView == _DailyReportView.institution &&
                institutionNames.isNotEmpty) ...[
              DropdownButtonFormField<String>(
                key: ValueKey(
                  'daily_institution_${_dailyDateIso}_$selectedInstitution',
                ),
                initialValue: selectedInstitution,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Kurum Seç',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.business_rounded),
                ),
                items: institutionNames
                    .map(
                      (name) => DropdownMenuItem(
                        value: name,
                        child: Text(name, overflow: TextOverflow.ellipsis),
                      ),
                    )
                    .toList(),
                onChanged: (value) =>
                    setState(() => _selectedDailyInstitution = value),
              ),
              const SizedBox(height: 16),
            ],
            if (allRecords.isEmpty)
              const Padding(
                padding: EdgeInsets.all(32),
                child: Center(
                  child: Text('Seçilen tarihte servis kaydı bulunmuyor.'),
                ),
              )
            else if (_dailyReportView == _DailyReportView.institution &&
                selectedInstitution == null)
              const Padding(
                padding: EdgeInsets.all(24),
                child: Center(
                  child: Text('Raporu görmek için bir kurum seçin.'),
                ),
              )
            else
              ..._dailyReportCards(records),
          ],
        ),
      ),
    );
  }

  List<Widget> _dailyReportCards(List<ServiceRecord> records) {
    final grouped = <String, List<ServiceRecord>>{};
    for (final record in records) {
      final key = switch (_dailyReportView) {
        _DailyReportView.institution => _mainInstitutionName(record),
        _DailyReportView.vehicle =>
          record.vehiclePlate.trim().isEmpty
              ? 'Araç belirtilmemiş'
              : record.vehiclePlate,
        _DailyReportView.driver =>
          record.driverName.trim().isEmpty
              ? 'Şoför belirtilmemiş'
              : record.driverName,
      };
      grouped.putIfAbsent(key, () => []).add(record);
    }
    final keys = grouped.keys.toList()..sort();
    return [for (final key in keys) _dailyGroupCard(key, grouped[key]!)];
  }

  Widget _dailyGroupCard(String title, List<ServiceRecord> records) {
    final totalPassengers = records.fold<int>(
      0,
      (total, record) =>
          total + (record.boardedCount ?? record.expectedCount ?? 0),
    );
    final detailGroups = <String, List<ServiceRecord>>{};
    for (final record in records) {
      final levels = _institutionLevels(record);
      final detail = switch (_dailyReportView) {
        _DailyReportView.institution =>
          'Bölge: ${levels.region}\n'
              'Takım: ${levels.team}\n'
              'Vardiyası: ${record.shift}\n'
              'Şoför: ${record.driverName.isEmpty ? 'Belirtilmemiş' : record.driverName}\n'
              'Araç Plaka: ${record.vehiclePlate.isEmpty ? 'Belirtilmemiş' : record.vehiclePlate}\n'
              'Servis Türü: ${record.serviceType}\n'
              'Başlama Saati: ${_reportTime(record.startedAt)}\n'
              'Bitiş Saati: ${_reportTime(record.endedAt)}',
        _DailyReportView.vehicle =>
          '${_mainInstitutionName(record)} • '
              '${record.driverName.isEmpty ? 'Şoför belirtilmemiş' : record.driverName} • '
              '${record.shift} • ${record.serviceType}',
        _DailyReportView.driver =>
          '${record.vehiclePlate.isEmpty ? 'Araç belirtilmemiş' : record.vehiclePlate} • '
              '${_mainInstitutionName(record)} • '
              '${record.shift} • ${record.serviceType}',
      };
      detailGroups.putIfAbsent(detail, () => []).add(record);
    }
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w900,
                color: Color(0xFF082A52),
              ),
            ),
            const SizedBox(height: 5),
            Text(
              '${records.length} servis • $totalPassengers yolcu',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            const Divider(height: 22),
            for (final entry in detailGroups.entries)
              _dailyDetail(entry.key, entry.value),
          ],
        ),
      ),
    );
  }

  String _mainInstitutionName(ServiceRecord record) {
    if (record.institutionId.isNotEmpty) {
      final byId = {for (final item in _institutions) item.id: item};
      var institution = byId[record.institutionId];
      final visited = <String>{};
      while (institution != null &&
          institution.parentId != null &&
          institution.parentId!.isNotEmpty &&
          visited.add(institution.id)) {
        institution = byId[institution.parentId] ?? institution;
        if (institution.parentId == null || institution.parentId!.isEmpty) {
          break;
        }
      }
      if (institution != null && institution.name.trim().isNotEmpty) {
        return institution.name;
      }
    }
    return record.institutionName.trim().isEmpty
        ? 'Kurum belirtilmemiş'
        : record.institutionName;
  }

  String _serviceMainInstitutionName(ServiceRecord record) {
    final direct = _mainInstitutionName(record);
    if (direct != 'Kurum belirtilmemiş') return direct;

    final byId = {for (final item in _institutions) item.id: item};
    final personnelById = {for (final item in _personnel) item.id: item};
    final roots = <String>{};
    final personIds = _attendance
        .where((item) => item.serviceId == record.id)
        .map((item) => item.personId)
        .toSet();
    for (final personId in personIds) {
      var institution = byId[personnelById[personId]?.institutionId];
      final visited = <String>{};
      while (institution != null && visited.add(institution.id)) {
        final parentId = institution.parentId;
        if (parentId == null || parentId.isEmpty) break;
        institution = byId[parentId] ?? institution;
        if (institution.parentId == null || institution.parentId!.isEmpty) {
          break;
        }
      }
      if (institution != null && institution.name.trim().isNotEmpty) {
        roots.add(institution.name);
      }
    }
    final sortedRoots = roots.toList()..sort();
    return sortedRoots.isEmpty ? 'Kurum belirtilmemiş' : sortedRoots.join(', ');
  }

  Widget _dailyDetail(String label, List<ServiceRecord> records) {
    final boarded = records.fold<int>(
      0,
      (sum, record) => sum + (record.boardedCount ?? 0),
    );
    final absent = records.fold<int>(
      0,
      (sum, record) => sum + (record.absentCount ?? 0),
    );
    final total = records.fold<int>(
      0,
      (sum, record) =>
          sum +
          (record.expectedCount ??
              ((record.boardedCount ?? 0) + (record.absentCount ?? 0))),
    );
    if (_dailyReportView != _DailyReportView.institution) {
      return Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: const Color(0xFFF4F7FA),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          '$label\nKaç Servis: ${records.length}\nToplam Yolcu: $total',
          style: const TextStyle(height: 1.45),
        ),
      );
    }
    final information = <(String, String)>[
      for (final line in label.split('\n'))
        if (line.contains(': '))
          (
            line.substring(0, line.indexOf(': ')),
            line.substring(line.indexOf(': ') + 2),
          ),
      ('Kaç Servis', '${records.length}'),
      ('Toplam Yolcu', '$total'),
      ('Gelen', '$boarded'),
      ('Gelmeyen', '$absent'),
    ];
    String valueOf(String name) {
      for (final item in information) {
        if (item.$1 == name) return item.$2;
      }
      return 'Belirtilmemiş';
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        leading: const CircleAvatar(
          backgroundColor: Color(0xFFE6EEF7),
          child: Icon(Icons.route_rounded, color: Color(0xFF1565C0)),
        ),
        title: Text(
          valueOf('Bölge'),
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
        subtitle: Text('Vardiya: ${valueOf('Vardiyası')}'),
        childrenPadding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
        children: [
          Container(
            width: double.infinity,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              border: Border.all(color: const Color(0xFFCAD5E0)),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Table(
              border: const TableBorder(
                horizontalInside: BorderSide(color: Color(0xFFDCE4EC)),
                verticalInside: BorderSide(color: Color(0xFFDCE4EC)),
              ),
              columnWidths: const {
                0: FlexColumnWidth(1.05),
                1: FlexColumnWidth(1.45),
              },
              children: [
                for (var index = 0; index < information.length; index++)
                  TableRow(
                    decoration: BoxDecoration(
                      color: index.isEven
                          ? const Color(0xFFF4F7FA)
                          : Colors.white,
                    ),
                    children: [
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 9,
                        ),
                        child: Text(
                          information[index].$1,
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF52657B),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 9,
                        ),
                        child: Text(
                          information[index].$2,
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: information[index].$1 == 'Gelen'
                                ? const Color(0xFF0B6E4F)
                                : information[index].$1 == 'Gelmeyen'
                                ? const Color(0xFFB3261E)
                                : const Color(0xFF082A52),
                          ),
                        ),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _reportTime(String? value) {
    if (value == null || value.isEmpty) return 'Henüz bitirilmedi';
    final date = DateTime.tryParse(value);
    if (date == null) return value;
    return '${date.hour.toString().padLeft(2, '0')}:'
        '${date.minute.toString().padLeft(2, '0')}';
  }

  ({String region, String team}) _institutionLevels(ServiceRecord record) {
    final byId = {for (final item in _institutions) item.id: item};
    final personnelById = {for (final item in _personnel) item.id: item};
    final regions = <String>{};
    final teams = <String>{};
    final servicePersonIds = _attendance
        .where((item) => item.serviceId == record.id)
        .map((item) => item.personId)
        .toSet();
    for (final personId in servicePersonIds) {
      final person = personnelById[personId];
      if (person == null) continue;
      final levels = _levelsForInstitution(person.institutionId, byId);
      if (levels.region != null) regions.add(levels.region!);
      if (levels.team != null) teams.add(levels.team!);
    }
    if (regions.isNotEmpty || teams.isNotEmpty) {
      final sortedRegions = regions.toList()..sort();
      final sortedTeams = teams.toList()..sort();
      return (
        region: sortedRegions.isEmpty
            ? 'Belirtilmemiş'
            : sortedRegions.join(', '),
        team: sortedTeams.isEmpty ? 'Belirtilmemiş' : sortedTeams.join(', '),
      );
    }

    final fallback = _levelsForInstitution(record.institutionId, byId);
    return (
      region:
          fallback.region ??
          (record.institutionName.trim().isEmpty
              ? 'Belirtilmemiş'
              : record.institutionName),
      team: fallback.team ?? 'Belirtilmemiş',
    );
  }

  ({String? region, String? team}) _levelsForInstitution(
    String institutionId,
    Map<String, Institution> byId,
  ) {
    final path = <Institution>[];
    var institution = byId[institutionId];
    final visited = <String>{};
    while (institution != null && visited.add(institution.id)) {
      path.insert(0, institution);
      final parentId = institution.parentId;
      if (parentId == null || parentId.isEmpty) break;
      institution = byId[parentId];
    }
    final descendants = path.length > 1
        ? path.sublist(1)
        : const <Institution>[];
    final region = descendants.isNotEmpty ? descendants.first.name : null;
    final team = descendants.length > 1
        ? descendants.sublist(1).map((item) => item.name).join(' › ')
        : null;
    return (region: region, team: team);
  }

  Widget _filterChip(String label, _ReportFilter value) {
    return ChoiceChip(
      label: Text(label),
      selected: _filter == value,
      onSelected: (_) => setState(() => _filter = value),
    );
  }

  Widget _reportCard(_ReportItem item) {
    final color = switch (item.kind) {
      _ReportKind.completed => const Color(0xFF0B6E4F),
      _ReportKind.missed => const Color(0xFFB3261E),
      _ReportKind.unfinished => const Color(0xFF9A6700),
    };
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color.withValues(alpha: 0.14),
          child: Icon(item.icon, color: color),
        ),
        title: Text(
          '${item.dateText} • ${item.shift} • ${item.serviceType}',
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
        subtitle: Text(item.description),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          children: [
            Text(
              '$value',
              style: TextStyle(
                color: color,
                fontSize: 22,
                fontWeight: FontWeight.w900,
              ),
            ),
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 10),
            ),
          ],
        ),
      ),
    );
  }
}

enum _ReportKind { completed, missed, unfinished }

class _ReportItem {
  const _ReportItem({
    required this.kind,
    required this.date,
    required this.shift,
    required this.serviceType,
    required this.driverName,
    required this.expectedCount,
    required this.boardedCount,
    required this.absentCount,
    required this.unmarkedCount,
    required this.startedAt,
    required this.endedAt,
    required this.unmarkedNames,
  });

  factory _ReportItem.fromService(
    ServiceRecord record,
    List<String> unmarkedNames,
  ) => _ReportItem(
    kind: record.endedAt == null
        ? _ReportKind.unfinished
        : _ReportKind.completed,
    date: record.date,
    shift: record.shift,
    serviceType: record.serviceType,
    driverName: record.driverName,
    expectedCount: record.expectedCount ?? 0,
    boardedCount: record.boardedCount ?? 0,
    absentCount: record.absentCount ?? 0,
    unmarkedCount: record.unmarkedCount ?? 0,
    startedAt: record.startedAt,
    endedAt: record.endedAt,
    unmarkedNames: unmarkedNames,
  );

  factory _ReportItem.missed({
    required String date,
    required String shift,
    required String serviceType,
    required int expectedCount,
  }) => _ReportItem(
    kind: _ReportKind.missed,
    date: date,
    shift: shift,
    serviceType: serviceType,
    driverName: '',
    expectedCount: expectedCount,
    boardedCount: 0,
    absentCount: 0,
    unmarkedCount: 0,
    startedAt: '',
    endedAt: null,
    unmarkedNames: const [],
  );

  final _ReportKind kind;
  final String date;
  final String shift;
  final String serviceType;
  final String driverName;
  final int expectedCount;
  final int boardedCount;
  final int absentCount;
  final int unmarkedCount;
  final String startedAt;
  final String? endedAt;
  final List<String> unmarkedNames;

  DateTime get sortDate =>
      DateTime.tryParse(endedAt ?? (startedAt.isEmpty ? date : startedAt)) ??
      DateTime(2000);

  String get dateText {
    final parsed = DateTime.tryParse(date);
    if (parsed == null) return date;
    return '${parsed.day.toString().padLeft(2, '0')}.'
        '${parsed.month.toString().padLeft(2, '0')}.${parsed.year}';
  }

  IconData get icon => switch (kind) {
    _ReportKind.completed => Icons.check_circle_rounded,
    _ReportKind.missed => Icons.event_busy_rounded,
    _ReportKind.unfinished => Icons.warning_amber_rounded,
  };

  String get description => switch (kind) {
    _ReportKind.missed =>
      'Programda servis başlatılmadı • Beklenen $expectedCount yolcu',
    _ReportKind.unfinished =>
      'Şoför: $driverName • Servis başlatıldı ancak bitirilmedi',
    _ReportKind.completed =>
      'Şoför: $driverName • Binen $boardedCount • Yok $absentCount'
          '${unmarkedCount > 0 ? ' • Şoförün işaretlemediği $unmarkedCount'
                    '${unmarkedNames.isEmpty ? '' : ': ${unmarkedNames.join(', ')}'}' : ''}',
  };
}
