import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class DeviceIdentity {
  const DeviceIdentity({required this.id, required this.name});

  final String id;
  final String name;
}

class DeviceIdentityService {
  DeviceIdentityService._();

  static const _storage = FlutterSecureStorage();
  static const _fallbackKey = 'servis_takip_device_id';

  static Future<DeviceIdentity> read() async {
    var identifier = await _storage.read(key: _fallbackKey);
    if (identifier == null || identifier.isEmpty) {
      final random = Random.secure();
      identifier = List.generate(
        24,
        (_) => random.nextInt(256).toRadixString(16).padLeft(2, '0'),
      ).join();
      await _storage.write(key: _fallbackKey, value: identifier);
    }
    return DeviceIdentity(
      id: '${defaultTargetPlatform.name}:$identifier',
      name: switch (defaultTargetPlatform) {
        TargetPlatform.android => 'Android telefon',
        TargetPlatform.iOS => 'iPhone',
        _ => defaultTargetPlatform.name,
      },
    );
  }
}
