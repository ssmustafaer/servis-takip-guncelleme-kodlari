import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class InvitationPaymentSettings {
  const InvitationPaymentSettings({
    required this.id,
    required this.title,
    required this.recipientName,
    required this.iban,
    required this.notificationPhone,
    this.active = true,
  });

  final String id;
  final String title;
  final String recipientName;
  final String iban;
  final String notificationPhone;
  final bool active;

  Map<String, Object?> toJson() => {
    'id': id,
    'title': title,
    'recipientName': recipientName,
    'iban': iban,
    'notificationPhone': notificationPhone,
    'active': active,
  };

  factory InvitationPaymentSettings.fromJson(Map<String, dynamic> json) {
    return InvitationPaymentSettings(
      id: json['id'] as String? ?? '',
      title: json['title'] as String? ?? '',
      recipientName: json['recipientName'] as String? ?? '',
      iban: json['iban'] as String? ?? '',
      notificationPhone: json['notificationPhone'] as String? ?? '',
      active: json['active'] as bool? ?? true,
    );
  }
}

class InvitationPaymentSettingsStorage {
  static const _storage = FlutterSecureStorage();
  static const _accountsKey = 'invitation_payment_accounts_v2';
  static const _recipientNameKey = 'invitation_payment_recipient_name';
  static const _ibanKey = 'invitation_payment_iban';
  static const _notificationPhoneKey = 'invitation_payment_phone';

  static Future<List<InvitationPaymentSettings>> readAll() async {
    final raw = await _storage.read(key: _accountsKey);
    if (raw != null && raw.isNotEmpty) {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .map(
            (item) => InvitationPaymentSettings.fromJson(
              Map<String, dynamic>.from(item as Map),
            ),
          )
          .where((item) => item.id.isNotEmpty)
          .toList();
    }

    final recipientName = await _storage.read(key: _recipientNameKey) ?? '';
    final iban = await _storage.read(key: _ibanKey) ?? '';
    final phone = await _storage.read(key: _notificationPhoneKey) ?? '';
    if (recipientName.isEmpty && iban.isEmpty && phone.isEmpty) return [];

    final migrated = InvitationPaymentSettings(
      id: 'legacy-payment-account',
      title: 'Varsayılan Hesap',
      recipientName: recipientName,
      iban: iban,
      notificationPhone: phone,
    );
    await saveAll([migrated]);
    return [migrated];
  }

  static Future<void> saveAll(List<InvitationPaymentSettings> accounts) {
    return _storage.write(
      key: _accountsKey,
      value: jsonEncode(accounts.map((item) => item.toJson()).toList()),
    );
  }
}
