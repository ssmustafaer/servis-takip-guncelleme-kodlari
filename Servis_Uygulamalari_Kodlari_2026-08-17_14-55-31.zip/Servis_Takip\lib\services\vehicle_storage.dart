import '../models/vehicle.dart';
import 'company_cloud_storage.dart';

class VehicleStorage {
  VehicleStorage._();

  static Future<List<Vehicle>> readAll() async {
    final data = await CompanyCloudStorage.readCollection('vehicles');
    final vehicles = data.map(Vehicle.fromJson).toList()
      ..sort((a, b) => a.plate.compareTo(b.plate));
    return vehicles;
  }

  static Future<void> saveAll(List<Vehicle> vehicles) {
    return CompanyCloudStorage.replaceCollection(
      collectionName: 'vehicles',
      items: vehicles.map((item) => item.toJson()).toList(),
      limitField: 'maxVehicles',
      usageField: 'vehicles',
    );
  }
}
