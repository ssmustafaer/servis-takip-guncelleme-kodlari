import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:latlong2/latlong.dart';

import '../company/models/company_employee.dart';
import '../company/models/company_session.dart';
import '../company/services/company_employee_repository.dart';
import '../models/institution.dart';
import '../models/vehicle.dart';
import '../widgets/institution_tree_selector.dart';
import '../services/institution_storage.dart';
import '../services/vehicle_storage.dart';
import 'map_picker_screen.dart';

class CompanyEmployeesScreen extends StatefulWidget {
  const CompanyEmployeesScreen({
    required this.session,
    this.openAddOnStart = false,
    super.key,
  });

  final CompanySession session;
  final bool openAddOnStart;

  @override
  State<CompanyEmployeesScreen> createState() => _CompanyEmployeesScreenState();
}

class _CompanyEmployeesScreenState extends State<CompanyEmployeesScreen> {
  final _repository = CompanyEmployeeRepository();
  List<Institution> _institutions = [];
  List<Vehicle> _vehicles = [];
  bool _automaticAddOpened = false;

  @override
  void initState() {
    super.initState();
    _loadReferenceData();
  }

  Future<void> _loadReferenceData() async {
    final result = await Future.wait([
      InstitutionStorage.readAll(),
      VehicleStorage.readAll(),
    ]);
    if (mounted) {
      setState(() {
        _institutions = result[0] as List<Institution>;
        _vehicles = result[1] as List<Vehicle>;
      });
      if (widget.openAddOnStart && !_automaticAddOpened) {
        _automaticAddOpened = true;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _addEmployee();
        });
      }
    }
  }

  Future<void> _edit(CompanyEmployee employee) async {
    final updated = await showDialog<CompanyEmployee>(
      context: context,
      builder: (_) => _EmployeeAccessDialog(
        employee: employee,
        institutions: _institutions,
        vehicles: _vehicles,
      ),
    );
    if (updated == null || !mounted) return;
    try {
      await _repository.updateEmployee(updated);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${updated.displayName} güncellendi.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Çalışan güncellenemedi: $error')));
    }
  }

  Future<void> _editRecord(CompanyEmployee employee) async {
    final updated = await showDialog<CompanyEmployee>(
      context: context,
      builder: (_) => _EmployeeDetailsDialog(employee: employee),
    );
    if (updated == null || !mounted) return;
    try {
      await _repository.updateEmployee(updated);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${employee.displayName} kaydı güncellendi.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Çalışan kaydı güncellenemedi: $error')),
      );
    }
  }

  Future<void> _addEmployee() async {
    final result = await showDialog<_NewEmployee>(
      context: context,
      barrierDismissible: false,
      builder: (_) =>
          _NewEmployeeDialog(institutions: _institutions, vehicles: _vehicles),
    );
    if (result == null || !mounted) return;
    try {
      await _repository.createEmployee(
        companyId: widget.session.companyId,
        displayName: result.displayName,
        phone: result.phone,
        password: result.password,
        role: result.role,
        allowedInstitutionIds: result.allowedInstitutionIds,
        allInstitutions: result.allInstitutions,
        allowedVehicleIds: result.allowedVehicleIds,
        allVehicles: result.allVehicles,
        address: result.address,
        district: result.district,
        city: result.city,
        latitude: result.latitude,
        longitude: result.longitude,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${result.displayName} hesabı oluşturuldu. '
            'Menü ve kurum yetkilerini Düzenle düğmesinden belirleyebilirsiniz.',
          ),
        ),
      );
    } on FirebaseAuthException catch (error) {
      if (!mounted) return;
      final message = switch (error.code) {
        'email-already-in-use' =>
          'Bu isimle bir çalışan hesabı zaten bulunuyor.',
        'weak-password' => 'Şifre en az 6 karakter olmalıdır.',
        _ => error.message ?? 'Çalışan hesabı oluşturulamadı.',
      };
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('$error')));
    }
  }

  Future<void> _resetPassword(CompanyEmployee employee) async {
    final password = await showDialog<String>(
      context: context,
      builder: (_) => _ResetPasswordDialog(employeeName: employee.displayName),
    );
    if (password == null || !mounted) return;
    try {
      await _repository.resetPassword(
        employeeId: employee.id,
        newPassword: password,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${employee.displayName} için yeni geçici şifre kaydedildi.',
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Şifre sıfırlanamadı: $error')));
    }
  }

  Future<void> _setActive(CompanyEmployee employee, bool active) async {
    if (employee.id == widget.session.userId) return;
    final action = active ? 'yeniden aktifleştirilsin' : 'pasife alınsın';
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(active ? 'Çalışanı Aktifleştir' : 'Çalışanı Pasife Al'),
        content: Text('${employee.displayName} $action mı?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(active ? 'Aktifleştir' : 'Pasife Al'),
          ),
        ],
      ),
    );
    if (approved != true || !mounted) return;
    try {
      await _repository.setEmployeeActive(
        employeeId: employee.id,
        active: active,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            active
                ? '${employee.displayName} aktifleştirildi.'
                : '${employee.displayName} pasife alındı.',
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('İşlem tamamlanamadı: $error')));
    }
  }

  Future<void> _deleteEmployee(CompanyEmployee employee) async {
    if (employee.id == widget.session.userId || employee.isOwner) return;
    final firstApproval = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.warning_amber_rounded, color: Colors.orange),
        title: const Text('Çalışanı Kalıcı Olarak Sil'),
        content: Text(
          '${employee.displayName} için önce pasife alma seçeneğini kullanmanız önerilir. '
          'Kalıcı silme işlemine devam etmek istiyor musunuz?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Vazgeç'),
          ),
          OutlinedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Devam Et'),
          ),
        ],
      ),
    );
    if (firstApproval != true || !mounted) return;

    final finalApproval = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.delete_forever_rounded, color: Colors.red),
        title: const Text('Son Onay'),
        content: Text(
          '${employee.displayName} ve giriş hesabı kalıcı olarak silinecek. '
          'Bu işlem geri alınamaz.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Silme'),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            icon: const Icon(Icons.delete_forever_rounded),
            label: const Text('Kalıcı Olarak Sil'),
          ),
        ],
      ),
    );
    if (finalApproval != true || !mounted) return;
    try {
      await _repository.deleteEmployee(
        companyId: widget.session.companyId,
        employeeId: employee.id,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${employee.displayName} kalıcı olarak silindi.'),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Çalışan silinemedi: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Şirket Çalışanları')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addEmployee,
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('Çalışan Ekle'),
      ),
      body: StreamBuilder<List<CompanyEmployee>>(
        stream: _repository.watchEmployees(widget.session.companyId),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Çalışanlar yüklenemedi:\n${snapshot.error}'),
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final employees = snapshot.data!;
          final firstInactiveIndex = employees.indexWhere(
            (employee) => !employee.active,
          );
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            itemCount: employees.length,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final employee = employees[index];
              final card = Card(
                color: employee.active ? null : const Color(0xFFFFE7E7),
                shape: employee.active
                    ? null
                    : RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                        side: const BorderSide(color: Color(0xFFB3261E)),
                      ),
                child: ListTile(
                  leading: CircleAvatar(
                    child: Icon(
                      employee.isOwner
                          ? Icons.workspace_premium_rounded
                          : employee.role == CompanyEmployee.administrativeRole
                          ? Icons.badge_rounded
                          : Icons.drive_eta_rounded,
                    ),
                  ),
                  title: Text(employee.displayName),
                  subtitle: Text(
                    [
                      employee.positionName,
                      employee.active ? 'Aktif' : 'Pasif',
                      if (employee.phone.isNotEmpty) employee.phone,
                    ].join(' • '),
                  ),
                  trailing: PopupMenuButton<String>(
                    enabled: employee.id != widget.session.userId,
                    onSelected: (value) {
                      if (value == 'record') _editRecord(employee);
                      if (value == 'edit') _edit(employee);
                      if (value == 'password') _resetPassword(employee);
                      if (value == 'deactivate') _setActive(employee, false);
                      if (value == 'activate') _setActive(employee, true);
                      if (value == 'delete') _deleteEmployee(employee);
                    },
                    itemBuilder: (_) => [
                      const PopupMenuItem(
                        value: 'record',
                        child: ListTile(
                          leading: Icon(Icons.manage_accounts_rounded),
                          title: Text('Kaydı Düzenle'),
                        ),
                      ),
                      const PopupMenuItem(
                        value: 'edit',
                        child: ListTile(
                          leading: Icon(Icons.edit_rounded),
                          title: Text('Yetkileri Düzenle'),
                        ),
                      ),
                      const PopupMenuItem(
                        value: 'password',
                        child: ListTile(
                          leading: Icon(Icons.lock_reset_rounded),
                          title: Text('Şifreyi Sıfırla'),
                        ),
                      ),
                      if (employee.active)
                        const PopupMenuItem(
                          value: 'deactivate',
                          child: ListTile(
                            leading: Icon(Icons.person_off_rounded),
                            title: Text('Pasife Al'),
                          ),
                        )
                      else
                        const PopupMenuItem(
                          value: 'activate',
                          child: ListTile(
                            leading: Icon(Icons.person_add_alt_1_rounded),
                            title: Text('Yeniden Aktifleştir'),
                          ),
                        ),
                      if (!employee.isOwner)
                        const PopupMenuItem(
                          value: 'delete',
                          child: ListTile(
                            leading: Icon(
                              Icons.delete_forever_rounded,
                              color: Colors.red,
                            ),
                            title: Text(
                              'Kalıcı Olarak Sil',
                              style: TextStyle(color: Colors.red),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              );
              if (index != firstInactiveIndex) return card;
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(4, 14, 4, 4),
                    child: Text(
                      'PASİF ÇALIŞANLAR',
                      style: TextStyle(
                        color: Color(0xFFB3261E),
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                  card,
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _EmployeeRecordDialog extends StatefulWidget {
  const _EmployeeRecordDialog({required this.employee});

  final CompanyEmployee employee;

  @override
  State<_EmployeeRecordDialog> createState() => _EmployeeRecordDialogState();
}

class _EmployeeRecordDialogState extends State<_EmployeeRecordDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _phoneController;

  @override
  void initState() {
    super.initState();
    _phoneController = TextEditingController(text: widget.employee.phone);
  }

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  Future<void> _pickPhone() async {
    try {
      final permission = await FlutterContacts.permissions.request(
        PermissionType.read,
      );
      if (permission != PermissionStatus.granted) return;
      final contact = await FlutterContacts.native.showPicker(
        properties: {ContactProperty.phone},
      );
      if (contact != null && contact.phones.isNotEmpty) {
        _phoneController.text = contact.phones.first.number;
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Rehber açılırken bir sorun oluştu.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Kaydı Düzenle'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.employee.displayName,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 4),
            const Text(
              'Çalışan adı giriş hesabına bağlıdır. Telefon numarasını buradan düzenleyebilirsiniz.',
              style: TextStyle(color: Color(0xFF52657B)),
            ),
            const SizedBox(height: 16),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _phoneController,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                      labelText: 'Telefon numarası',
                      prefixIcon: Icon(Icons.phone_rounded),
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      final digits =
                          value?.replaceAll(RegExp(r'[^0-9]'), '') ?? '';
                      return digits.length < 10
                          ? 'Geçerli telefon numarası girin.'
                          : null;
                    },
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filledTonal(
                  onPressed: _pickPhone,
                  tooltip: 'Rehberden seç',
                  icon: const Icon(Icons.contacts_rounded),
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('VAZGEÇ'),
        ),
        FilledButton(
          onPressed: () {
            if (!_formKey.currentState!.validate()) return;
            Navigator.pop(context, _phoneController.text.trim());
          },
          child: const Text('KAYDET'),
        ),
      ],
    );
  }
}

class _ResetPasswordDialog extends StatefulWidget {
  const _ResetPasswordDialog({required this.employeeName});

  final String employeeName;

  @override
  State<_ResetPasswordDialog> createState() => _ResetPasswordDialogState();
}

class _ResetPasswordDialogState extends State<_ResetPasswordDialog> {
  final _formKey = GlobalKey<FormState>();
  final _passwordController = TextEditingController();
  var _hidePassword = true;

  @override
  void dispose() {
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Şifreyi Sıfırla'),
      content: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('${widget.employeeName} için yeni geçici şifre belirleyin.'),
            const SizedBox(height: 16),
            TextFormField(
              controller: _passwordController,
              obscureText: _hidePassword,
              decoration: InputDecoration(
                labelText: 'Yeni geçici şifre',
                border: const OutlineInputBorder(),
                suffixIcon: IconButton(
                  onPressed: () =>
                      setState(() => _hidePassword = !_hidePassword),
                  icon: Icon(
                    _hidePassword ? Icons.visibility : Icons.visibility_off,
                  ),
                ),
              ),
              validator: (value) => (value?.length ?? 0) < 6
                  ? 'Şifre en az 6 karakter olmalıdır.'
                  : null,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton(
          onPressed: () {
            if (!_formKey.currentState!.validate()) return;
            Navigator.pop(context, _passwordController.text);
          },
          child: const Text('Şifreyi Sıfırla'),
        ),
      ],
    );
  }
}

class _EmployeeDetailsDialog extends StatefulWidget {
  const _EmployeeDetailsDialog({required this.employee});

  final CompanyEmployee employee;

  @override
  State<_EmployeeDetailsDialog> createState() => _EmployeeDetailsDialogState();
}

class _EmployeeDetailsDialogState extends State<_EmployeeDetailsDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _phoneController;
  late final TextEditingController _addressController;
  late final TextEditingController _districtController;
  late final TextEditingController _cityController;
  double? _latitude;
  double? _longitude;

  @override
  void initState() {
    super.initState();
    final employee = widget.employee;
    _nameController = TextEditingController(text: employee.displayName);
    _phoneController = TextEditingController(text: employee.phone);
    _addressController = TextEditingController(text: employee.address);
    _districtController = TextEditingController(text: employee.district);
    _cityController = TextEditingController(text: employee.city);
    _latitude = employee.latitude;
    _longitude = employee.longitude;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _addressController.dispose();
    _districtController.dispose();
    _cityController.dispose();
    super.dispose();
  }

  Future<void> _chooseLocation() async {
    final initial = LatLng(_latitude ?? 38.461926, _longitude ?? 27.189566);
    final selected = await Navigator.of(context).push<LatLng>(
      MaterialPageRoute(
        builder: (_) => MapPickerScreen(
          initialLocation: initial,
          selectedLocation: _latitude == null ? null : initial,
          title: 'Çalışan Konumunu Seç',
        ),
      ),
    );
    if (selected != null && mounted) {
      setState(() {
        _latitude = selected.latitude;
        _longitude = selected.longitude;
      });
    }
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    final employee = widget.employee;
    Navigator.pop(
      context,
      CompanyEmployee(
        id: employee.id,
        displayName: _nameController.text.trim(),
        phone: _phoneController.text.trim(),
        role: employee.role,
        active: employee.active,
        permissions: employee.permissions,
        allowedInstitutionIds: employee.allowedInstitutionIds,
        allInstitutions: employee.allInstitutions,
        allowedVehicleIds: employee.allowedVehicleIds,
        allVehicles: employee.allVehicles,
        address: _addressController.text.trim(),
        district: _districtController.text.trim(),
        city: _cityController.text.trim(),
        latitude: _latitude,
        longitude: _longitude,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Kaydı Düzenle'),
      content: SizedBox(
        width: 440,
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(
                    labelText: 'Çalışan adı soyadı',
                    prefixIcon: Icon(Icons.person_rounded),
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Çalışan adını girin.'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'Telefon numarası',
                    prefixIcon: Icon(Icons.phone_rounded),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _addressController,
                  textCapitalization: TextCapitalization.sentences,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Adres',
                    prefixIcon: Icon(Icons.home_rounded),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _districtController,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(
                          labelText: 'İlçe',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextFormField(
                        controller: _cityController,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(
                          labelText: 'İl',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _chooseLocation,
                    icon: Icon(
                      _latitude == null
                          ? Icons.add_location_alt_rounded
                          : Icons.location_on_rounded,
                    ),
                    label: Text(
                      _latitude == null
                          ? 'HARİTADAN KONUM SEÇ'
                          : 'KONUM KAYITLI • DEĞİŞTİR',
                    ),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('VAZGEÇ'),
        ),
        FilledButton(onPressed: _save, child: const Text('KAYDET')),
      ],
    );
  }
}

class _NewEmployee {
  const _NewEmployee({
    required this.displayName,
    required this.phone,
    required this.password,
    required this.role,
    required this.allowedInstitutionIds,
    required this.allInstitutions,
    required this.allowedVehicleIds,
    required this.allVehicles,
    required this.address,
    required this.district,
    required this.city,
    required this.latitude,
    required this.longitude,
  });

  final String displayName;
  final String phone;
  final String password;
  final String role;
  final List<String> allowedInstitutionIds;
  final bool allInstitutions;
  final List<String> allowedVehicleIds;
  final bool allVehicles;
  final String address;
  final String district;
  final String city;
  final double? latitude;
  final double? longitude;
}

class _NewEmployeeDialog extends StatefulWidget {
  const _NewEmployeeDialog({
    required this.institutions,
    required this.vehicles,
  });

  final List<Institution> institutions;
  final List<Vehicle> vehicles;

  @override
  State<_NewEmployeeDialog> createState() => _NewEmployeeDialogState();
}

class _NewEmployeeDialogState extends State<_NewEmployeeDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  final _addressController = TextEditingController();
  final _districtController = TextEditingController();
  final _cityController = TextEditingController();
  double? _latitude;
  double? _longitude;
  var _role = CompanyEmployee.driverRole;
  var _hidePassword = true;
  var _allInstitutions = false;
  var _allVehicles = false;
  final Set<String> _allowedInstitutionIds = {};
  final Set<String> _allowedVehicleIds = {};

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    _addressController.dispose();
    _districtController.dispose();
    _cityController.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.pop(
      context,
      _NewEmployee(
        displayName: _nameController.text.trim(),
        phone: _phoneController.text.trim(),
        password: _passwordController.text,
        role: _role,
        allowedInstitutionIds: _allowedInstitutionIds.toList(),
        allInstitutions: _role == CompanyEmployee.ownerRole || _allInstitutions,
        allowedVehicleIds: _allowedVehicleIds.toList(),
        allVehicles: _role == CompanyEmployee.ownerRole || _allVehicles,
        address: _addressController.text.trim(),
        district: _districtController.text.trim(),
        city: _cityController.text.trim(),
        latitude: _latitude,
        longitude: _longitude,
      ),
    );
  }

  Future<void> _chooseLocation() async {
    final initial = LatLng(_latitude ?? 38.461926, _longitude ?? 27.189566);
    final selected = await Navigator.of(context).push<LatLng>(
      MaterialPageRoute(
        builder: (_) => MapPickerScreen(
          initialLocation: initial,
          selectedLocation: _latitude == null ? null : initial,
          title: 'Çalışan Konumunu Seç',
        ),
      ),
    );
    if (selected != null && mounted) {
      setState(() {
        _latitude = selected.latitude;
        _longitude = selected.longitude;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Çalışan Hesabı Aç'),
      content: SizedBox(
        width: 430,
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _nameController,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(
                          labelText: 'Adı soyadı',
                          prefixIcon: Icon(Icons.person_rounded),
                          border: OutlineInputBorder(),
                        ),
                        validator: (value) =>
                            value == null || value.trim().isEmpty
                            ? 'Adı soyadı girin.'
                            : null,
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton.filledTonal(
                      onPressed: _pickFromContacts,
                      tooltip: 'Rehberden seç',
                      icon: const Icon(Icons.contacts_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'Telefon numarası',
                    prefixIcon: Icon(Icons.phone_rounded),
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (_role != CompanyEmployee.driverRole) return null;
                    final digits =
                        value?.replaceAll(RegExp(r'[^0-9]'), '') ?? '';
                    return digits.length < 10
                        ? 'Şoförün telefon numarasını girin.'
                        : null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _addressController,
                  textCapitalization: TextCapitalization.sentences,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Adres',
                    prefixIcon: Icon(Icons.home_rounded),
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        controller: _districtController,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(
                          labelText: 'İlçe',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextFormField(
                        controller: _cityController,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(
                          labelText: 'İl',
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _chooseLocation,
                    icon: Icon(
                      _latitude == null
                          ? Icons.add_location_alt_rounded
                          : Icons.location_on_rounded,
                    ),
                    label: Text(
                      _latitude == null
                          ? 'HARİTADAN KONUM SEÇ'
                          : 'KONUM KAYITLI • DEĞİŞTİR',
                    ),
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _passwordController,
                  obscureText: _hidePassword,
                  decoration: InputDecoration(
                    labelText: 'Giriş şifresi',
                    prefixIcon: const Icon(Icons.lock_rounded),
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      onPressed: () =>
                          setState(() => _hidePassword = !_hidePassword),
                      icon: Icon(
                        _hidePassword ? Icons.visibility : Icons.visibility_off,
                      ),
                    ),
                  ),
                  validator: (value) => (value?.length ?? 0) < 6
                      ? 'Şifre en az 6 karakter olmalıdır.'
                      : null,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: _role,
                  decoration: const InputDecoration(
                    labelText: 'Pozisyonu',
                    prefixIcon: Icon(Icons.badge_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: CompanyEmployee.ownerRole,
                      child: Text('Sahibi'),
                    ),
                    DropdownMenuItem(
                      value: CompanyEmployee.administrativeRole,
                      child: Text('İdari Personel'),
                    ),
                    DropdownMenuItem(
                      value: CompanyEmployee.driverRole,
                      child: Text('Şoför'),
                    ),
                  ],
                  onChanged: (value) {
                    if (value != null) {
                      setState(() {
                        _role = value;
                        if (value == CompanyEmployee.ownerRole) {
                          _allInstitutions = true;
                          _allVehicles = true;
                        }
                      });
                    }
                  },
                ),
                const Divider(height: 28),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Tüm kurumları görebilsin'),
                  value: _role == CompanyEmployee.ownerRole || _allInstitutions,
                  onChanged: _role == CompanyEmployee.ownerRole
                      ? null
                      : (value) => setState(() => _allInstitutions = value),
                ),
                if (_role != CompanyEmployee.ownerRole && !_allInstitutions)
                  InstitutionTreeSelector(
                    institutions: widget.institutions,
                    selectedIds: _allowedInstitutionIds,
                    onChanged: (value) => setState(() {
                      _allowedInstitutionIds
                        ..clear()
                        ..addAll(value);
                    }),
                  ),
                const Divider(height: 28),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Tüm araçları kullanabilsin'),
                  value: _role == CompanyEmployee.ownerRole || _allVehicles,
                  onChanged: _role == CompanyEmployee.ownerRole
                      ? null
                      : (value) => setState(() => _allVehicles = value),
                ),
                if (_role != CompanyEmployee.ownerRole && !_allVehicles)
                  for (final vehicle in widget.vehicles.where(
                    (item) => item.active,
                  ))
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      title: Text(vehicle.plate),
                      subtitle: vehicle.brandModel.isEmpty
                          ? null
                          : Text(vehicle.brandModel),
                      value: _allowedVehicleIds.contains(vehicle.id),
                      onChanged: (value) => setState(() {
                        if (value == true) {
                          _allowedVehicleIds.add(vehicle.id);
                        } else {
                          _allowedVehicleIds.remove(vehicle.id);
                        }
                      }),
                    ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton(onPressed: _save, child: const Text('Hesabı Oluştur')),
      ],
    );
  }

  Future<void> _pickFromContacts() async {
    try {
      final permission = await FlutterContacts.permissions.request(
        PermissionType.read,
      );
      if (permission != PermissionStatus.granted) {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Rehber izni verilmedi.')));
        return;
      }
      final contact = await FlutterContacts.native.showPicker(
        properties: {ContactProperty.phone},
      );
      if (contact == null) return;
      final displayName = contact.displayName?.trim();
      if (displayName != null && displayName.isNotEmpty) {
        _nameController.text = displayName;
      }
      if (contact.phones.isNotEmpty) {
        _phoneController.text = contact.phones.first.number;
      }
      if (mounted) setState(() {});
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Rehber açılırken bir sorun oluştu.')),
      );
    }
  }
}

class _EmployeeAccessDialog extends StatefulWidget {
  const _EmployeeAccessDialog({
    required this.employee,
    required this.institutions,
    required this.vehicles,
  });

  final CompanyEmployee employee;
  final List<Institution> institutions;
  final List<Vehicle> vehicles;

  @override
  State<_EmployeeAccessDialog> createState() => _EmployeeAccessDialogState();
}

class _EmployeeAccessDialogState extends State<_EmployeeAccessDialog> {
  late String _role;
  late bool _active;
  late bool _allInstitutions;
  late Set<String> _allowedInstitutionIds;
  late bool _allVehicles;
  late Set<String> _allowedVehicleIds;
  late Map<String, bool> _permissions;

  static const _permissionLabels = <String, String>{
    'canViewSettings': 'Ayarlar menüsünü görsün',
    'canManageInstitutions': 'Kurumları yönetsin',
    'canManageVehicles': 'Araçları yönetsin',
    'canManageEmployees': 'Şirket çalışanlarını yönetsin',
    'canManagePersonnel': 'Personeli yönetsin',
    'canManageStops': 'Durakları yönetsin',
    'canManageShifts': 'Vardiyaları yönetsin',
    'canViewReports': 'Raporları görsün',
  };

  @override
  void initState() {
    super.initState();
    _role = widget.employee.isOwner
        ? CompanyEmployee.ownerRole
        : widget.employee.role;
    _active = widget.employee.active;
    _allInstitutions = widget.employee.allInstitutions;
    _allowedInstitutionIds = widget.employee.allowedInstitutionIds.toSet();
    _allVehicles = widget.employee.allVehicles;
    _allowedVehicleIds = widget.employee.allowedVehicleIds.toSet();
    _permissions = {...widget.employee.permissions};
  }

  void _applyPositionDefaults(String role) {
    _role = role;
    if (role == CompanyEmployee.ownerRole) {
      for (final key in _permissionLabels.keys) {
        _permissions[key] = true;
      }
      _allInstitutions = true;
      _allVehicles = true;
    } else if (role == CompanyEmployee.driverRole) {
      for (final key in _permissionLabels.keys) {
        _permissions[key] = false;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final owner = _role == CompanyEmployee.ownerRole;
    return AlertDialog(
      title: Text(widget.employee.displayName),
      content: SizedBox(
        width: 460,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                initialValue: _role,
                decoration: const InputDecoration(
                  labelText: 'Pozisyonu',
                  border: OutlineInputBorder(),
                ),
                items: const [
                  DropdownMenuItem(
                    value: CompanyEmployee.ownerRole,
                    child: Text('Sahibi'),
                  ),
                  DropdownMenuItem(
                    value: CompanyEmployee.administrativeRole,
                    child: Text('İdari Personel'),
                  ),
                  DropdownMenuItem(
                    value: CompanyEmployee.driverRole,
                    child: Text('Şoför'),
                  ),
                ],
                onChanged: (value) {
                  if (value != null) {
                    setState(() => _applyPositionDefaults(value));
                  }
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Çalışan aktif'),
                value: _active,
                onChanged: (value) => setState(() => _active = value),
              ),
              const Divider(),
              for (final entry in _permissionLabels.entries)
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  title: Text(entry.value),
                  value: owner || (_permissions[entry.key] ?? false),
                  onChanged: owner
                      ? null
                      : (value) =>
                            setState(() => _permissions[entry.key] = value),
                ),
              const Divider(),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Tüm kurumların personelini görsün'),
                value: owner || _allInstitutions,
                onChanged: owner
                    ? null
                    : (value) => setState(() => _allInstitutions = value),
              ),
              if (!owner && !_allInstitutions)
                InstitutionTreeSelector(
                  institutions: widget.institutions,
                  selectedIds: _allowedInstitutionIds,
                  onChanged: (value) =>
                      setState(() => _allowedInstitutionIds = value),
                ),
              const Divider(),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Tüm araçları kullanabilsin'),
                value: owner || _allVehicles,
                onChanged: owner
                    ? null
                    : (value) => setState(() => _allVehicles = value),
              ),
              if (!owner && !_allVehicles)
                for (final vehicle in widget.vehicles.where(
                  (item) => item.active,
                ))
                  CheckboxListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text(vehicle.plate),
                    subtitle: vehicle.brandModel.isEmpty
                        ? null
                        : Text(vehicle.brandModel),
                    value: _allowedVehicleIds.contains(vehicle.id),
                    onChanged: (value) {
                      setState(() {
                        if (value == true) {
                          _allowedVehicleIds.add(vehicle.id);
                        } else {
                          _allowedVehicleIds.remove(vehicle.id);
                        }
                      });
                    },
                  ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(
            context,
            CompanyEmployee(
              id: widget.employee.id,
              displayName: widget.employee.displayName,
              phone: widget.employee.phone,
              role: _role,
              active: _active,
              permissions: _permissions,
              allowedInstitutionIds: _allowedInstitutionIds.toList(),
              allInstitutions: owner || _allInstitutions,
              allowedVehicleIds: _allowedVehicleIds.toList(),
              allVehicles: owner || _allVehicles,
              address: widget.employee.address,
              district: widget.employee.district,
              city: widget.employee.city,
              latitude: widget.employee.latitude,
              longitude: widget.employee.longitude,
            ),
          ),
          child: const Text('Kaydet'),
        ),
      ],
    );
  }
}
