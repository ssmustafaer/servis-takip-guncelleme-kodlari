# Servis Takip Yönetici Uygulaması

Bu yönetici uygulaması, Servis Takip kullanan şirketleri ve her şirketin
kullanım sınırlarını yönetmek için hazırlanmıştır.

## Yönetilebilen sınırlar

- Kullanıcı sayısı
- Personel sayısı
- Durak sayısı
- Araç sayısı
- Paket adı
- Paket bitiş tarihi
- Şirketin aktif veya pasif olması

Her şirketin verileri kendi `companyId` değeri altında tutulur. X şirketinin
kullanıcıları Y şirketinin kayıtlarını okuyamaz.

## Yönetici uygulamasını çalıştırma

Android üzerinde:

```bat
C:\src\flutter\bin\flutter.bat run --flavor admin -t lib\admin_main.dart
```

Normal Servis Takip uygulaması:

```bat
C:\src\flutter\bin\flutter.bat run --flavor client -t lib\main.dart
```

Yönetici sürümünün Android paket kimliği
`com.example.servis_takip.admin` değeridir. Bu kimlik Firebase Console'a
ayrı bir Android uygulaması olarak eklenmeli ve indirilen `google-services.json`
dosyası `android/app/src/admin/` klasörüne yerleştirilmelidir.

## Firebase kurulumu

1. Firebase Authentication içinde Email/Password açık olmalıdır.
2. Cloud Firestore oluşturulmalıdır.
3. `firestore.rules` kuralları Firebase'e yayımlanmalıdır.
4. İlk sistem yöneticisi Authentication bölümünde oluşturulmalıdır.
5. Aynı kullanıcının UID değeriyle `users/{uid}` belgesi oluşturulmalı ve
   `role` alanı `system_admin` yapılmalıdır.
6. Kullanım sınırlarını güvenli biçimde uygulayan `functions` klasöründeki
   Cloud Functions yayımlanmalıdır.

> Cloud Functions yayımlanmadan sınır kontrolleri sunucu tarafında aktif
> sayılmaz. Yalnızca ekranda görünen sınırlar güvenlik için yeterli değildir.
