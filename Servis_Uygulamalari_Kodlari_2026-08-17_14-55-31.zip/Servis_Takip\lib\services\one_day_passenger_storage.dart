import '../models/one_day_passenger.dart';
import 'company_cloud_storage.dart';

class OneDayPassengerStorage {
  OneDayPassengerStorage._();

  static const collectionName = 'oneDayPassengers';

  static Future<List<OneDayPassenger>> readAll() async {
    final data = await CompanyCloudStorage.readCollection(collectionName);
    return data.map(OneDayPassenger.fromJson).toList();
  }

  static Future<void> save(OneDayPassenger passenger) {
    return CompanyCloudStorage.writeDocument(
      collectionName: collectionName,
      documentId: passenger.id,
      data: passenger.toJson(),
    );
  }

  static Future<void> delete(String passengerId) {
    return CompanyCloudStorage.deleteDocument(
      collectionName: collectionName,
      documentId: passengerId,
    );
  }
}
