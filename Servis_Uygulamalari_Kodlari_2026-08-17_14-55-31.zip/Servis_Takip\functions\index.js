const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {initializeApp} = require("firebase-admin/app");
const {getAuth} = require("firebase-admin/auth");
const {
  FieldValue,
  Timestamp,
  getFirestore,
} = require("firebase-admin/firestore");

initializeApp();

const db = getFirestore();

function requireAuthentication(request) {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Önce giriş yapmalısınız.");
  }
}

async function userProfile(uid) {
  const snapshot = await db.collection("users").doc(uid).get();
  return snapshot.exists ? snapshot.data() : null;
}

async function requireSystemAdmin(request) {
  requireAuthentication(request);
  if (request.auth.token.role === "system_admin") return;
  const profile = await userProfile(request.auth.uid);
  if (profile?.role !== "system_admin") {
    throw new HttpsError(
        "permission-denied",
        "Bu işlem için sistem yöneticisi yetkisi gerekir.",
    );
  }
}

async function requireCompanyManager(request, companyId) {
  requireAuthentication(request);
  if (request.auth.token.role === "system_admin") return;
  const profile = await userProfile(request.auth.uid);
  if (
    profile?.companyId !== companyId ||
    !["company_admin", "owner"].includes(profile?.role)
  ) {
    throw new HttpsError(
        "permission-denied",
        "Bu şirketi yönetme yetkiniz yok.",
    );
  }
}

function requiredText(value, fieldName) {
  if (typeof value !== "string" || value.trim().length === 0) {
    throw new HttpsError(
        "invalid-argument",
        `${fieldName} boş bırakılamaz.`,
    );
  }
  return value.trim();
}

exports.bindCurrentDevice = onCall(async (request) => {
  requireAuthentication(request);
  const deviceId = requiredText(request.data?.deviceId, "Telefon kimliği");
  const deviceName = requiredText(request.data?.deviceName, "Telefon adı");
  const userReference = db.collection("users").doc(request.auth.uid);
  await db.runTransaction(async (transaction) => {
    const snapshot = await transaction.get(userReference);
    if (!snapshot.exists || snapshot.data()?.active !== true) {
      throw new HttpsError("permission-denied", "Kullanıcı aktif değil.");
    }
    const registeredDeviceId = snapshot.data()?.deviceId;
    const exemptionSnapshot = registeredDeviceId ? await transaction.get(
        db.collection("deviceExemptions")
            .doc(`${request.auth.uid}_${registeredDeviceId}`),
    ) : null;
    const isExempt = exemptionSnapshot?.data()?.active === true;
    if (
      !isExempt &&
      typeof registeredDeviceId === "string" &&
      registeredDeviceId.length > 0 &&
      registeredDeviceId !== deviceId
    ) {
      throw new HttpsError(
          "failed-precondition",
          "Bu hesap başka bir telefona kayıtlı.",
      );
    }
    transaction.update(userReference, {
      ...(registeredDeviceId ? {} : {deviceId, deviceName}),
      deviceBoundAt: snapshot.data()?.deviceBoundAt ??
        FieldValue.serverTimestamp(),
      deviceLastSeenAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
  });
  return {success: true};
});

async function reserveCompanyLimit({
  companyId,
  limitField,
  usageField,
  createReference,
  createData,
  additionalCreates = [],
}) {
  const companyReference = db.collection("companies").doc(companyId);
  await db.runTransaction(async (transaction) => {
    const companySnapshot = await transaction.get(companyReference);
    if (!companySnapshot.exists) {
      throw new HttpsError("not-found", "Şirket bulunamadı.");
    }

    const company = companySnapshot.data();
    if (company.active !== true) {
      throw new HttpsError(
          "failed-precondition",
          "Şirket hesabı aktif değil.",
      );
    }
    if (
      company.expiresAt instanceof Timestamp &&
      company.expiresAt.toMillis() < Date.now()
    ) {
      throw new HttpsError(
          "failed-precondition",
          "Şirket paketinin süresi dolmuş.",
      );
    }

    const limit = Number(company.limits?.[limitField] ?? 0);
    const used = Number(company.usage?.[usageField] ?? 0);
    if (limit <= 0 || used >= limit) {
      throw new HttpsError(
          "resource-exhausted",
          `${usageField} sınırına ulaşıldı.`,
      );
    }

    transaction.create(createReference, createData);
    for (const additionalCreate of additionalCreates) {
      transaction.create(
          additionalCreate.reference,
          additionalCreate.data,
      );
    }
    transaction.update(companyReference, {
      [`usage.${usageField}`]: used + 1,
      updatedAt: FieldValue.serverTimestamp(),
    });
  });
}

exports.createCompanyUser = onCall(async (request) => {
  const companyId = requiredText(request.data?.companyId, "Şirket");
  await requireCompanyManager(request, companyId);

  const email = requiredText(request.data?.email, "E-posta").toLowerCase();
  const password = requiredText(request.data?.password, "Şifre");
  const displayName = requiredText(request.data?.displayName, "Ad soyad");
  const requestedRole = request.data?.role;
  const role = ["company_admin", "owner", "administrative", "driver"]
      .includes(requestedRole)
    ? requestedRole
    : "driver";
  const canManage = role === "company_admin" || role === "owner";
  const permissions = {
    canViewSettings: canManage,
    canManageInstitutions: canManage,
    canManageVehicles: canManage,
    canManageEmployees: canManage,
    canManagePersonnel: canManage,
    canManageStops: canManage,
    canManageShifts: canManage,
    canViewReports: canManage,
  };

  let createdUser;
  try {
    createdUser = await getAuth().createUser({
      email,
      password,
      displayName,
      disabled: false,
    });
    await getAuth().setCustomUserClaims(createdUser.uid, {companyId, role});

    const userReference = db.collection("users").doc(createdUser.uid);
    const memberReference = db
        .collection("companies")
        .doc(companyId)
        .collection("members")
        .doc(createdUser.uid);
    await reserveCompanyLimit({
      companyId,
      limitField: "maxUsers",
      usageField: "users",
      createReference: userReference,
      createData: {
        companyId,
        role,
        email,
        displayName,
        active: true,
        permissions,
        allInstitutions: true,
        allowedInstitutionIds: [],
        createdAt: FieldValue.serverTimestamp(),
      },
      additionalCreates: [
        {
          reference: memberReference,
          data: {
            role,
            email,
            displayName,
            active: true,
            createdAt: FieldValue.serverTimestamp(),
          },
        },
      ],
    });
    return {uid: createdUser.uid};
  } catch (error) {
    if (createdUser) {
      await getAuth().deleteUser(createdUser.uid).catch(() => {});
    }
    throw error;
  }
});

exports.resetCompanyUserPassword = onCall(async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Oturum aÃ§manÄ±z gerekiyor.");
  }
  const targetUserId = requiredText(
      request.data?.targetUserId,
      "KullanÄ±cÄ±",
  );
  const newPassword = requiredText(request.data?.newPassword, "Yeni ÅŸifre");
  if (newPassword.length < 6) {
    throw new HttpsError(
        "invalid-argument",
        "Yeni ÅŸifre en az 6 karakter olmalÄ±dÄ±r.",
    );
  }

  const requesterSnapshot = await db
      .collection("users")
      .doc(request.auth.uid)
      .get();
  const requester = requesterSnapshot.data();
  if (
    !requester ||
    requester.active !== true ||
    !["company_admin", "owner"].includes(requester.role)
  ) {
    throw new HttpsError(
        "permission-denied",
        "Bu iÅŸlem iÃ§in ÅŸirket sahibi yetkisi gerekiyor.",
    );
  }

  const targetSnapshot = await db.collection("users").doc(targetUserId).get();
  const target = targetSnapshot.data();
  if (!target || target.companyId !== requester.companyId) {
    throw new HttpsError(
        "permission-denied",
        "YalnÄ±zca kendi ÅŸirketinizdeki Ã§alÄ±ÅŸanÄ±n ÅŸifresini sÄ±fÄ±rlayabilirsiniz.",
    );
  }
  if (targetUserId === request.auth.uid) {
    throw new HttpsError(
        "failed-precondition",
        "Kendi ÅŸifrenizi uygulamadaki Åifremi DeÄŸiÅŸtir bÃ¶lÃ¼mÃ¼nden deÄŸiÅŸtirin.",
    );
  }

  await getAuth().updateUser(targetUserId, {password: newPassword});
  await db.collection("users").doc(targetUserId).update({
    passwordResetAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });
  return {success: true};
});

exports.deleteCompanyEmployee = onCall(async (request) => {
  requireAuthentication(request);
  const companyId = requiredText(request.data?.companyId, "Şirket");
  const targetUserId = requiredText(
      request.data?.targetUserId,
      "Çalışan",
  );
  await requireCompanyManager(request, companyId);

  if (targetUserId === request.auth.uid) {
    throw new HttpsError(
        "failed-precondition",
        "Kendi hesabınızı silemezsiniz.",
    );
  }

  const userReference = db.collection("users").doc(targetUserId);
  const companyReference = db.collection("companies").doc(companyId);
  const memberReference = companyReference.collection("members").doc(
      targetUserId,
  );

  await db.runTransaction(async (transaction) => {
    const [targetSnapshot, companySnapshot] = await Promise.all([
      transaction.get(userReference),
      transaction.get(companyReference),
    ]);
    if (!targetSnapshot.exists) {
      throw new HttpsError("not-found", "Çalışan bulunamadı.");
    }
    const target = targetSnapshot.data();
    if (target.companyId !== companyId) {
      throw new HttpsError(
          "permission-denied",
          "Bu çalışan başka bir şirkete ait.",
      );
    }
    if (["owner", "company_admin"].includes(target.role)) {
      throw new HttpsError(
          "failed-precondition",
          "Şirket sahibi hesabı çalışan listesinden silinemez.",
      );
    }

    const company = companySnapshot.data() ?? {};
    const usedUsers = Number(company.usage?.users ?? 0);
    transaction.delete(userReference);
    transaction.delete(memberReference);
    transaction.update(companyReference, {
      "usage.users": Math.max(0, usedUsers - 1),
      updatedAt: FieldValue.serverTimestamp(),
    });
  });

  await getAuth().deleteUser(targetUserId).catch((error) => {
    if (error.code !== "auth/user-not-found") throw error;
  });
  return {success: true};
});

exports.createPersonnelRecord = onCall(async (request) => {
  const companyId = requiredText(request.data?.companyId, "Şirket");
  await requireCompanyManager(request, companyId);
  const record = request.data?.record;
  if (!record || typeof record !== "object") {
    throw new HttpsError("invalid-argument", "Personel bilgisi eksik.");
  }

  const reference = db
      .collection("companies")
      .doc(companyId)
      .collection("personnel")
      .doc();
  await reserveCompanyLimit({
    companyId,
    limitField: "maxPersonnel",
    usageField: "personnel",
    createReference: reference,
    createData: {
      ...record,
      id: reference.id,
      createdAt: FieldValue.serverTimestamp(),
      createdBy: request.auth.uid,
    },
  });
  return {id: reference.id};
});

exports.createStopRecord = onCall(async (request) => {
  const companyId = requiredText(request.data?.companyId, "Şirket");
  await requireCompanyManager(request, companyId);
  const record = request.data?.record;
  if (!record || typeof record !== "object") {
    throw new HttpsError("invalid-argument", "Durak bilgisi eksik.");
  }

  const reference = db
      .collection("companies")
      .doc(companyId)
      .collection("stops")
      .doc();
  await reserveCompanyLimit({
    companyId,
    limitField: "maxStops",
    usageField: "stops",
    createReference: reference,
    createData: {
      ...record,
      id: reference.id,
      createdAt: FieldValue.serverTimestamp(),
      createdBy: request.auth.uid,
    },
  });
  return {id: reference.id};
});
