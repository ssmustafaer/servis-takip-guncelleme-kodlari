# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\src\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\ss_mu\\Documents\\Codex\\2026-07-23\\referenced-chatgpt-conversation-this-is-untrusted\\work\\servis_takip_dev" PROJECT_DIR)

set(FLUTTER_VERSION "1.1.1+2" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 1 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 2 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\src\\flutter"
  "PROJECT_DIR=C:\\Users\\ss_mu\\Documents\\Codex\\2026-07-23\\referenced-chatgpt-conversation-this-is-untrusted\\work\\servis_takip_dev"
  "FLUTTER_ROOT=C:\\src\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\ss_mu\\Documents\\Codex\\2026-07-23\\referenced-chatgpt-conversation-this-is-untrusted\\work\\servis_takip_dev\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\ss_mu\\Documents\\Codex\\2026-07-23\\referenced-chatgpt-conversation-this-is-untrusted\\work\\servis_takip_dev"
  "FLUTTER_TARGET=C:\\Users\\ss_mu\\Documents\\Codex\\2026-07-23\\referenced-chatgpt-conversation-this-is-untrusted\\work\\servis_takip_dev\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9BUFBfRkxBVk9SPWNsaWVudA==,RkxVVFRFUl9WRVJTSU9OPTMuNDQuNg==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZWU4MGYwOGJiZg==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ODM2NzVlZDI3Ng==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMi4y"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\ss_mu\\Documents\\Codex\\2026-07-23\\referenced-chatgpt-conversation-this-is-untrusted\\work\\servis_takip_dev\\.dart_tool\\package_config.json"
  "FLAVOR=client"
)
