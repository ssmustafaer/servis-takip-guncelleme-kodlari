import 'package:flutter/material.dart';

import '../models/institution.dart';

class InstitutionTreeSelector extends StatelessWidget {
  const InstitutionTreeSelector({
    required this.institutions,
    required this.selectedIds,
    required this.onChanged,
    super.key,
  });

  final List<Institution> institutions;
  final Set<String> selectedIds;
  final ValueChanged<Set<String>> onChanged;

  List<({Institution institution, int depth})> get _items {
    final result = <({Institution institution, int depth})>[];

    void append(String? parentId, int depth) {
      final children = Institution.childrenOf(
        institutions,
        parentId,
      ).where((item) => item.active || selectedIds.contains(item.id));
      for (final child in children) {
        result.add((institution: child, depth: depth));
        append(child.id, depth + 1);
      }
    }

    append(null, 0);
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final items = _items;
    if (items.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: Text('Henüz kurum kaydı bulunmuyor.'),
      );
    }

    return Column(
      children: [
        for (final row in items)
          Builder(
            builder: (context) {
              final subtree = Institution.subtreeIds(
                institutions,
                row.institution.id,
              ).toSet();
              final selectedCount = subtree.where(selectedIds.contains).length;
              final bool? checked = selectedCount == 0
                  ? false
                  : selectedCount == subtree.length
                  ? true
                  : null;
              return Padding(
                padding: EdgeInsets.only(left: row.depth * 18.0),
                child: CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  tristate: true,
                  secondary: Icon(
                    row.depth == 0
                        ? Icons.domain_rounded
                        : Icons.account_tree_outlined,
                    size: 20,
                  ),
                  title: Text(row.institution.name),
                  value: checked,
                  onChanged: (value) {
                    final updated = selectedIds.toSet();
                    if (value == true) {
                      updated.addAll(subtree);
                    } else {
                      updated.removeAll(subtree);
                    }
                    onChanged(updated);
                  },
                ),
              );
            },
          ),
      ],
    );
  }
}
