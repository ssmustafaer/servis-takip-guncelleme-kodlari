class OneDayPassenger {
  const OneDayPassenger({
    required this.id,
    required this.personId,
    required this.institutionId,
    required this.date,
    required this.shift,
  });

  final String id;
  final String personId;
  final String institutionId;
  final String date;
  final String shift;

  Map<String, dynamic> toJson() => {
    'id': id,
    'personId': personId,
    'institutionId': institutionId,
    'date': date,
    'shift': shift,
  };

  factory OneDayPassenger.fromJson(Map<String, dynamic> json) {
    return OneDayPassenger(
      id: json['id'] as String,
      personId: json['personId'] as String,
      institutionId: json['institutionId'] as String? ?? '',
      date: json['date'] as String,
      shift: json['shift'] as String,
    );
  }
}
