import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';

import '../models/company.dart';
import '../services/admin_repository.dart';
import 'company_users_screen.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({
    required this.repository,
    this.openCreateOnStart = false,
    super.key,
  });

  final AdminRepository repository;
  final bool openCreateOnStart;

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  final _searchController = TextEditingController();
  String _query = '';
  String _statusFilter = 'all';

  AdminRepository get repository => widget.repository;

  @override
  void initState() {
    super.initState();
    if (widget.openCreateOnStart) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _openEditor(context);
      });
    }
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _openUsers(BuildContext context, Company company) async {
    try {
      await repository.ensureCompanyLoginCode(company);
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Şirket kodu hazırlanamadı: $error')),
      );
      return;
    }
    if (!context.mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            CompanyUsersScreen(company: company, repository: repository),
      ),
    );
  }

  Future<void> _openEditor(BuildContext context, {Company? company}) async {
    final result = await showDialog<_CompanyEditorResult>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _CompanyEditorDialog(company: company),
    );
    if (result == null || !context.mounted) return;

    try {
      if (company == null) {
        await repository.createCompany(
          name: result.name,
          planName: result.planName,
          packageId: result.packageId,
          limits: result.limits,
          expiresAt: result.expiresAt,
        );
      } else {
        await repository.updateCompany(
          companyId: company.id,
          planName: result.planName,
          packageId: result.packageId,
          limits: result.limits,
          active: result.active,
          expiresAt: result.expiresAt,
        );
      }
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            company == null
                ? '${result.name} oluşturuldu.'
                : '${result.name} güncellendi.',
          ),
        ),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('İşlem tamamlanamadı: $error')));
    }
  }

  Future<void> _archiveCompany(Company company) async {
    if (company.active) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Şirketi silmeden önce Düzenle bölümünden pasif yapın.',
          ),
        ),
      );
      return;
    }
    final controller = TextEditingController();
    final approved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Şirket silinsin mi?'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${company.name} şirketi Silinenler bölümüne taşınacak. Tüm kayıtları korunacak.',
            ),
            const SizedBox(height: 14),
            Text('Onaylamak için şirket adını yazın: ${company.name}'),
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: 'Şirket adı',
                border: OutlineInputBorder(),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(
              dialogContext,
              controller.text.trim().toLowerCase() ==
                  company.name.trim().toLowerCase(),
            ),
            child: const Text('SİLİNENLERE TAŞI'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (approved != true || !mounted) {
      if (approved == false && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Şirket adı eşleşmedi veya işlem iptal edildi.'),
          ),
        );
      }
      return;
    }
    await repository.archiveCompany(company);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Şirket Silinenler bölümüne taşındı.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('STYP - Servis Takip Yönetici Paneli'),
        actions: [
          IconButton(
            onPressed: repository.signOut,
            icon: const Icon(Icons.logout_rounded),
            tooltip: 'Çıkış Yap',
          ),
          const SizedBox(width: 8),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(context),
        icon: const Icon(Icons.add_business_rounded),
        label: const Text('Şirket Ekle'),
      ),
      body: StreamBuilder<List<Company>>(
        stream: repository.watchCompanies(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Şirketler yüklenemedi.\n${snapshot.error}',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final allCompanies = snapshot.data!;
          final companies = allCompanies
              .where((company) => !company.isDeleted)
              .toList();
          final statusCompanies = switch (_statusFilter) {
            'active' => companies.where((company) => company.active).toList(),
            'inactive' =>
              companies.where((company) => !company.active).toList(),
            _ => companies,
          };
          final normalizedQuery = _query.trim().toLowerCase();
          final filteredCompanies = normalizedQuery.isEmpty
              ? statusCompanies
              : statusCompanies
                    .where(
                      (company) =>
                          company.name.toLowerCase().contains(
                            normalizedQuery,
                          ) ||
                          company.loginCode.toLowerCase().contains(
                            normalizedQuery,
                          ),
                    )
                    .toList();
          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
                  child: TextField(
                    controller: _searchController,
                    onChanged: (value) => setState(() => _query = value),
                    decoration: InputDecoration(
                      hintText: 'Şirket adı veya şirket kodu ara',
                      prefixIcon: const Icon(Icons.search_rounded),
                      suffixIcon: _query.isEmpty
                          ? null
                          : IconButton(
                              onPressed: () {
                                _searchController.clear();
                                setState(() => _query = '');
                              },
                              icon: const Icon(Icons.clear_rounded),
                              tooltip: 'Aramayı temizle',
                            ),
                      border: const OutlineInputBorder(),
                    ),
                  ),
                ),
              ),
              SliverToBoxAdapter(
                child: _SummaryHeader(
                  companies: allCompanies,
                  selectedFilter: _statusFilter,
                  onFilter: (value) => setState(() => _statusFilter = value),
                  onDeleted: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) =>
                          _DeletedCompaniesScreen(repository: repository),
                    ),
                  ),
                ),
              ),
              if (companies.isEmpty)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(
                    child: Text(
                      'Henüz şirket yok.\nŞirket Ekle düğmesiyle başlayın.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 18, color: Color(0xFF52657B)),
                    ),
                  ),
                )
              else if (filteredCompanies.isEmpty)
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(
                    child: Text('Aramaya uygun şirket bulunamadı.'),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                  sliver: SliverList.separated(
                    itemCount: filteredCompanies.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 10),
                    itemBuilder: (context, index) {
                      final company = filteredCompanies[index];
                      return _CompactCompanyCard(
                        company: company,
                        onUsers: () => _openUsers(context, company),
                        onEdit: () => _openEditor(context, company: company),
                        onDelete: () => _archiveCompany(company),
                      );
                    },
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _CompactCompanyCard extends StatelessWidget {
  const _CompactCompanyCard({
    required this.company,
    required this.onUsers,
    required this.onEdit,
    required this.onDelete,
  });

  final Company company;
  final VoidCallback onUsers;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        title: Text(
          company.name.toUpperCase(),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Şirket Kodu: ${company.loginCode}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFF52657B),
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () async {
                    await Clipboard.setData(
                      ClipboardData(text: company.loginCode),
                    );
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Şirket kodu kopyalandı.')),
                    );
                  },
                  icon: const Icon(Icons.copy_rounded, size: 20),
                  tooltip: 'Şirket kodunu kopyala',
                  visualDensity: VisualDensity.compact,
                ),
              ],
            ),
            if (!company.active) ...[
              const SizedBox(height: 8),
              SizedBox(
                width: double.infinity,
                child: TextButton.icon(
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete_outline_rounded),
                  label: const Text('Silinenlere Taşı'),
                  style: TextButton.styleFrom(
                    foregroundColor: const Color(0xFF9B3F3F),
                  ),
                ),
              ),
            ],
            Text(
              'Paket Türü: ${company.packageId.isEmpty ? 'Özel Paket' : company.planName}',
              style: const TextStyle(
                color: Color(0xFF176B87),
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
        childrenPadding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        children: [
          _CompanyCard(company: company, onUsers: onUsers, onEdit: onEdit),
        ],
      ),
    );
  }
}

class _DeletedCompaniesScreen extends StatelessWidget {
  const _DeletedCompaniesScreen({required this.repository});

  final AdminRepository repository;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Silinenler')),
    body: StreamBuilder<List<Company>>(
      stream: repository.watchCompanies(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(
            child: Text('Silinen şirketler yüklenemedi: ${snapshot.error}'),
          );
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final deleted = snapshot.data!
            .where((company) => company.isDeleted)
            .toList();
        if (deleted.isEmpty) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: Text(
                'Silinen şirket bulunmuyor.',
                textAlign: TextAlign.center,
              ),
            ),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: deleted.length,
          separatorBuilder: (_, _) => const SizedBox(height: 6),
          itemBuilder: (context, index) {
            final company = deleted[index];
            return Card(
              child: ListTile(
                leading: const CircleAvatar(
                  child: Icon(Icons.business_rounded),
                ),
                title: Text(
                  company.name,
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                subtitle: Text(
                  'Şirket kodu: ${company.loginCode}\n'
                  'Silinme tarihi: ${company.deletedAt == null ? '-' : _CompanyCard._dateText(company.deletedAt!)}',
                ),
                isThreeLine: true,
                trailing: FilledButton.tonalIcon(
                  onPressed: () => _restore(context, company),
                  icon: const Icon(Icons.restore_rounded),
                  label: const Text('Geri Yükle'),
                ),
              ),
            );
          },
        );
      },
    ),
  );

  Future<void> _restore(BuildContext context, Company company) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Şirket geri yüklensin mi?'),
        content: Text(
          '${company.name} ve bağlı bütün kayıtları tekrar şirket listesine alınacak.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('GERİ YÜKLE'),
          ),
        ],
      ),
    );
    if (approved != true || !context.mounted) return;
    try {
      await repository.restoreCompany(company);
      if (!context.mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Şirket geri yüklendi.')));
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Şirket geri yüklenemedi: $error')),
      );
    }
  }
}

class _SummaryHeader extends StatelessWidget {
  const _SummaryHeader({
    required this.companies,
    required this.selectedFilter,
    required this.onFilter,
    required this.onDeleted,
  });

  final List<Company> companies;
  final String selectedFilter;
  final ValueChanged<String> onFilter;
  final VoidCallback onDeleted;

  @override
  Widget build(BuildContext context) {
    final current = companies.where((company) => !company.isDeleted).toList();
    final activeCount = current
        .where((company) => company.active && !company.isExpired)
        .length;
    final inactiveCount = current.where((company) => !company.active).length;
    final deletedCount = companies.where((company) => company.isDeleted).length;
    final userCount = current.fold<int>(
      0,
      (total, company) => total + company.usage.users,
    );
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF0B376A), Color(0xFF175A9E)],
          ),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Şirket Özeti',
              style: TextStyle(
                color: Colors.white,
                fontSize: 21,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: _SummaryBox(
                    label: 'Toplam Şirket',
                    value: '${current.length}',
                    selected: selectedFilter == 'all',
                    onTap: () => onFilter('all'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _SummaryBox(
                    label: 'Aktif Şirket',
                    value: '$activeCount',
                    selected: selectedFilter == 'active',
                    onTap: () => onFilter('active'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _SummaryBox(
                    label: 'Pasif Şirket',
                    value: '$inactiveCount',
                    selected: selectedFilter == 'inactive',
                    onTap: () => onFilter('inactive'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _SummaryBox(
                    label: 'Silinen Şirket',
                    value: '$deletedCount',
                    onTap: onDeleted,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _SummaryBox(label: 'Toplam Kullanıcı', value: '$userCount'),
          ],
        ),
      ),
    );
  }
}

class _SummaryBox extends StatelessWidget {
  const _SummaryBox({
    required this.label,
    required this.value,
    this.selected = false,
    this.onTap,
  });

  final String label;
  final String value;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected
          ? const Color(0xFFFFE1B7)
          : Colors.white.withValues(alpha: 0.14),
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 11),
          child: Column(
            children: [
              Text(
                value,
                style: TextStyle(
                  color: selected ? const Color(0xFF713800) : Colors.white,
                  fontSize: 23,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                label,
                textAlign: TextAlign.center,
                maxLines: 2,
                style: TextStyle(
                  color: selected ? const Color(0xFF713800) : Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CompanyCard extends StatelessWidget {
  const _CompanyCard({
    required this.company,
    required this.onUsers,
    required this.onEdit,
  });

  final Company company;
  final VoidCallback onUsers;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final available = company.active && !company.isExpired;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  backgroundColor: available
                      ? const Color(0xFFE8F5E9)
                      : const Color(0xFFFFEBEE),
                  child: Icon(
                    Icons.business_rounded,
                    color: available
                        ? const Color(0xFF0B6E4F)
                        : const Color(0xFFB3261E),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        company.name.toUpperCase(),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              'Şirket Kodu: ${company.loginCode}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Color(0xFF52657B),
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ),
                          IconButton(
                            visualDensity: VisualDensity.compact,
                            constraints: const BoxConstraints(
                              minWidth: 34,
                              minHeight: 34,
                            ),
                            padding: EdgeInsets.zero,
                            tooltip: 'Şirket kodunu kopyala',
                            onPressed: () async {
                              await Clipboard.setData(
                                ClipboardData(text: company.loginCode),
                              );
                              if (!context.mounted) return;
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text('Şirket kodu kopyalandı.'),
                                ),
                              );
                            },
                            icon: const Icon(Icons.copy_rounded, size: 19),
                          ),
                        ],
                      ),
                      Text(
                        'Paket Türü: ${company.packageId.isEmpty ? 'Özel Paket' : company.planName}',
                        style: const TextStyle(
                          color: Color(0xFF176B87),
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      available ? Icons.check_circle : Icons.block,
                      color: available
                          ? const Color(0xFF0B6E4F)
                          : const Color(0xFFB3261E),
                      size: 16,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      available ? 'Aktif' : 'Kapalı',
                      style: TextStyle(
                        color: available
                            ? const Color(0xFF0B6E4F)
                            : const Color(0xFFB3261E),
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const Divider(height: 28),
            _UsageLine(
              label: 'Kullanıcı',
              used: company.usage.users,
              limit: company.limits.maxUsers,
            ),
            _UsageLine(
              label: 'Kurum',
              used: company.usage.institutions,
              limit: company.limits.maxInstitutions,
            ),
            _UsageLine(
              label: 'Personel',
              used: company.usage.personnel,
              limit: company.limits.maxPersonnel,
            ),
            _UsageLine(
              label: 'Durak',
              used: company.usage.stops,
              limit: company.limits.maxStops,
            ),
            _UsageLine(
              label: 'Araç',
              used: company.usage.vehicles,
              limit: company.limits.maxVehicles,
            ),
            const SizedBox(height: 8),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: onUsers,
                    icon: const Icon(Icons.group_rounded),
                    label: const Text('Kullanıcılar'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: onEdit,
                    icon: const Icon(Icons.tune_rounded),
                    label: const Text('Düzenle'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  static String _dateText(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}.'
      '${date.month.toString().padLeft(2, '0')}.${date.year}';
}

class _UsageLine extends StatelessWidget {
  const _UsageLine({
    required this.label,
    required this.used,
    required this.limit,
  });

  final String label;
  final int used;
  final int limit;

  @override
  Widget build(BuildContext context) {
    final progress = limit <= 0
        ? 1.0
        : (used / limit).clamp(0.0, 1.0).toDouble();
    final full = used >= limit;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: Text(label)),
              Text(
                '$used / $limit',
                style: TextStyle(
                  color: full ? const Color(0xFFB3261E) : null,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          LinearProgressIndicator(
            value: progress,
            color: full ? const Color(0xFFB3261E) : null,
          ),
        ],
      ),
    );
  }
}

class _CompanyEditorResult {
  const _CompanyEditorResult({
    required this.name,
    required this.planName,
    required this.packageId,
    required this.limits,
    required this.active,
    this.expiresAt,
  });

  final String name;
  final String planName;
  final String packageId;
  final CompanyLimits limits;
  final bool active;
  final DateTime? expiresAt;
}

class _CompanyEditorDialog extends StatefulWidget {
  const _CompanyEditorDialog({this.company});

  final Company? company;

  @override
  State<_CompanyEditorDialog> createState() => _CompanyEditorDialogState();
}

class _CompanyEditorDialogState extends State<_CompanyEditorDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _planController;
  late final TextEditingController _usersController;
  late final TextEditingController _institutionsController;
  late final TextEditingController _personnelController;
  late final TextEditingController _stopsController;
  late final TextEditingController _vehiclesController;
  late bool _active;
  String _selectedPackageId = 'legacy';
  List<Map<String, dynamic>> _salesPackages = const [];
  bool _loadingPackages = true;
  DateTime? _expiresAt;

  @override
  void initState() {
    super.initState();
    final company = widget.company;
    _nameController = TextEditingController(text: company?.name ?? '');
    _planController = TextEditingController(
      text: company?.planName ?? 'Özel Paket',
    );
    _usersController = TextEditingController(
      text: '${company?.limits.maxUsers ?? 1}',
    );
    _institutionsController = TextEditingController(
      text: '${company?.limits.maxInstitutions ?? 10}',
    );
    _personnelController = TextEditingController(
      text: '${company?.limits.maxPersonnel ?? 30}',
    );
    _stopsController = TextEditingController(
      text: '${company?.limits.maxStops ?? 15}',
    );
    _vehiclesController = TextEditingController(
      text: '${company?.limits.maxVehicles ?? 1}',
    );
    _active = company?.active ?? true;
    _selectedPackageId = company == null
        ? 'free'
        : (company.packageId.isEmpty ? 'legacy' : company.packageId);
    _expiresAt = company?.expiresAt;
    _loadSalesPackages();
  }

  Future<void> _loadSalesPackages() async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('systemSettings')
          .doc('salesPackages')
          .get();
      final packages =
          (snapshot.data()?['packages'] as List<dynamic>? ?? const [])
              .whereType<Map>()
              .map((item) => Map<String, dynamic>.from(item))
              .where((item) => item['active'] != false)
              .toList()
            ..sort(
              (a, b) => ((a['sortOrder'] as num?)?.toInt() ?? 0).compareTo(
                (b['sortOrder'] as num?)?.toInt() ?? 0,
              ),
            );
      if (!mounted) return;
      setState(() {
        _salesPackages = packages;
        _loadingPackages = false;
      });
      if (widget.company == null && packages.isNotEmpty) {
        _applyPackage('free');
      }
    } catch (_) {
      if (mounted) setState(() => _loadingPackages = false);
    }
  }

  void _applyPackage(String packageId) {
    setState(() => _selectedPackageId = packageId);
    if (packageId == 'legacy') return;
    final package = _salesPackages.cast<Map<String, dynamic>?>().firstWhere(
      (item) => item?['id'] == packageId,
      orElse: () => null,
    );
    if (package == null) return;
    int value(String key) => (package[key] as num?)?.toInt() ?? 0;
    _planController.text = package['name']?.toString() ?? 'Özel Paket';
    _usersController.text = '${value('driverLimit')}';
    _institutionsController.text = '${value('institutionLimit')}';
    _personnelController.text = '${value('personnelLimit')}';
    _vehiclesController.text = '${value('vehicleLimit')}';
    _stopsController.text = '${value('personnelLimit')}';
    if (packageId == 'free') {
      _expiresAt = null;
    } else {
      _expiresAt = DateTime.now().add(const Duration(days: 365));
    }
  }

  Map<String, dynamic>? get _selectedSalesPackage {
    if (_selectedPackageId == 'legacy') return null;
    return _salesPackages.cast<Map<String, dynamic>?>().firstWhere(
      (item) => item?['id'] == _selectedPackageId,
      orElse: () => null,
    );
  }

  String _featureLimit(Map<String, dynamic> package, String key) {
    final value = (package[key] as num?)?.toInt() ?? 0;
    return value == 0 ? 'Sınırsız' : '$value / ay';
  }

  @override
  void dispose() {
    _nameController.dispose();
    _planController.dispose();
    _usersController.dispose();
    _institutionsController.dispose();
    _personnelController.dispose();
    _stopsController.dispose();
    _vehiclesController.dispose();
    super.dispose();
  }

  Future<void> _chooseExpiry() async {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final savedDate = _expiresAt;
    final initialDate = savedDate != null && !savedDate.isBefore(today)
        ? savedDate
        : today.add(const Duration(days: 365));

    final selected = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: today,
      lastDate: today.add(const Duration(days: 3650)),
      helpText: 'PAKET BİTİŞ TARİHİ',
    );
    if (selected != null) setState(() => _expiresAt = selected);
  }

  int? _positiveInt(String value) {
    final number = int.tryParse(value);
    return number != null && number > 0 ? number : null;
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.pop(
      context,
      _CompanyEditorResult(
        name: _nameController.text.trim(),
        planName: _planController.text.trim(),
        packageId: _selectedPackageId == 'legacy' ? '' : _selectedPackageId,
        limits: CompanyLimits(
          maxUsers: int.parse(_usersController.text),
          maxInstitutions: int.parse(_institutionsController.text),
          maxPersonnel: int.parse(_personnelController.text),
          maxStops: int.parse(_stopsController.text),
          maxVehicles: int.parse(_vehiclesController.text),
        ),
        active: _active,
        expiresAt: _expiresAt,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.company == null ? 'Şirket Ekle' : 'Şirketi Düzenle'),
      content: SizedBox(
        width: 520,
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  enabled: widget.company == null,
                  decoration: const InputDecoration(
                    labelText: 'Şirket Adı',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Şirket adını girin.'
                      : null,
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: _selectedPackageId,
                  decoration: const InputDecoration(
                    labelText: 'Satış Paketi',
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    if (widget.company != null)
                      const DropdownMenuItem(
                        value: 'legacy',
                        child: Text('Mevcut Özel Paket'),
                      ),
                    for (final package in _salesPackages)
                      DropdownMenuItem(
                        value: package['id']?.toString(),
                        child: Text(package['name']?.toString() ?? ''),
                      ),
                  ],
                  onChanged: _loadingPackages
                      ? null
                      : (value) {
                          if (value != null) _applyPackage(value);
                        },
                ),
                const SizedBox(height: 12),
                if (_selectedPackageId == 'legacy')
                  const Card(
                    color: Color(0xFFF5F7FA),
                    child: ListTile(
                      leading: Icon(Icons.verified_user_rounded),
                      title: Text('Özel Paket Özellikleri'),
                      subtitle: Text(
                        'Mevcut haklar korunur. Harita ve WhatsApp sınırsızdır.',
                      ),
                    ),
                  )
                else if (_selectedSalesPackage case final package?)
                  Card(
                    color: const Color(0xFFF0F7FF),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        children: [
                          _packageFeatureRow(
                            'Harita',
                            _featureLimit(package, 'monthlyMapLimit'),
                          ),
                          _packageFeatureRow(
                            'WhatsApp',
                            _featureLimit(package, 'monthlyWhatsAppLimit'),
                          ),
                          _packageFeatureRow(
                            'Rapor geçmişi',
                            ((package['reportHistoryDays'] as num?)?.toInt() ??
                                        0) ==
                                    0
                                ? 'Sınırsız'
                                : '${(package['reportHistoryDays'] as num).toInt()} gün',
                          ),
                          _packageFeatureRow(
                            'Tüm raporlar',
                            package['allReports'] == true ? 'Var' : 'Yok',
                          ),
                          _packageFeatureRow(
                            'Reklam',
                            package['adsEnabled'] == false ? 'Yok' : 'Var',
                          ),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _planController,
                  decoration: const InputDecoration(
                    labelText: 'Paket Adı',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Paket adını girin.'
                      : null,
                ),
                const SizedBox(height: 12),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 2.7,
                  children: [
                    _limitField(_usersController, 'Kullanıcı Sınırı'),
                    _limitField(_institutionsController, 'Kurum Sınırı'),
                    _limitField(_personnelController, 'Personel Sınırı'),
                    _limitField(_stopsController, 'Durak Sınırı'),
                    _limitField(_vehiclesController, 'Araç Sınırı'),
                  ],
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Şirket aktif'),
                  value: _active,
                  onChanged: (value) => setState(() => _active = value),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.event_rounded),
                  title: const Text('Paket bitiş tarihi'),
                  subtitle: Text(
                    _expiresAt == null
                        ? 'Süresiz'
                        : _CompanyCard._dateText(_expiresAt!),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (_expiresAt != null)
                        IconButton(
                          onPressed: () => setState(() => _expiresAt = null),
                          icon: const Icon(Icons.clear),
                          tooltip: 'Süresiz yap',
                        ),
                      IconButton(
                        onPressed: _chooseExpiry,
                        icon: const Icon(Icons.edit_calendar_rounded),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton.icon(
          onPressed: _loadingPackages ? null : _save,
          icon: const Icon(Icons.save_rounded),
          label: const Text('Kaydet'),
        ),
      ],
    );
  }

  Widget _limitField(TextEditingController controller, String label) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      validator: (value) => value == null || _positiveInt(value) == null
          ? '1 veya daha büyük olmalı.'
          : null,
    );
  }

  Widget _packageFeatureRow(String label, String value) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        Expanded(child: Text(label)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w800)),
      ],
    ),
  );
}
