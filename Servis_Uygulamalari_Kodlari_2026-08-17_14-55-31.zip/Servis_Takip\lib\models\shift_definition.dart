class ShiftTimeSlot {
  const ShiftTimeSlot({
    required this.id,
    required this.startMinutes,
    required this.endMinutes,
    this.workdayOffset = 0,
  });

  final String id;
  final int startMinutes;
  final int endMinutes;

  /// 0: başladığı günün, 1: ertesi günün çalışma kaydıdır.
  final int workdayOffset;

  String get label => '${_hourLabel(startMinutes)} / ${_hourLabel(endMinutes)}';

  bool get endsNextDay => endMinutes <= startMinutes;

  static String _hourLabel(int minutes) {
    if (minutes == 0) return '24';
    final hour = minutes ~/ 60;
    final minute = minutes % 60;
    if (minute == 0) return hour.toString().padLeft(2, '0');
    return '${hour.toString().padLeft(2, '0')}.${minute.toString().padLeft(2, '0')}';
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'startMinutes': startMinutes,
    'endMinutes': endMinutes,
    'workdayOffset': workdayOffset,
  };

  factory ShiftTimeSlot.fromJson(Map<String, dynamic> json) {
    final start = (json['startMinutes'] as num?)?.toInt() ?? 0;
    final end = (json['endMinutes'] as num?)?.toInt() ?? 0;
    return ShiftTimeSlot(
      id: json['id']?.toString() ?? '',
      startMinutes: start,
      endMinutes: end,
      workdayOffset:
          (json['workdayOffset'] as num?)?.toInt() ??
          (end != 0 && end < start ? 1 : 0),
    );
  }
}

class ShiftDefinition {
  static const backward = 'backward';
  static const forward = 'forward';
  static const fixed = 'fixed';

  const ShiftDefinition({
    required this.id,
    required this.name,
    required this.order,
    required this.slots,
    required this.changeDirection,
    this.changeDescription = '',
  });

  final String id;
  final String name;
  final int order;
  final List<ShiftTimeSlot> slots;
  final String changeDirection;
  final String changeDescription;

  ShiftDefinition copyWith({
    String? name,
    int? order,
    List<ShiftTimeSlot>? slots,
    String? changeDirection,
    String? changeDescription,
  }) {
    return ShiftDefinition(
      id: id,
      name: name ?? this.name,
      order: order ?? this.order,
      slots: slots ?? this.slots,
      changeDirection: changeDirection ?? this.changeDirection,
      changeDescription: changeDescription ?? this.changeDescription,
    );
  }

  String get directionLabel {
    switch (changeDirection) {
      case forward:
        return 'İzin sonrası bir sonraki vardiyaya geçer';
      case fixed:
        return 'Vardiya değişmez';
      default:
        return 'İzin sonrası bir önceki vardiyaya geçer';
    }
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'order': order,
    'slots': slots.map((slot) => slot.toJson()).toList(),
    'changeDirection': changeDirection,
    'changeDescription': changeDescription,
    'schemaVersion': 1,
  };

  factory ShiftDefinition.fromJson(Map<String, dynamic> json) {
    final rawSlots = json['slots'] as List<dynamic>? ?? const [];
    return ShiftDefinition(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      order: (json['order'] as num?)?.toInt() ?? 0,
      slots: rawSlots
          .whereType<Map>()
          .map(
            (slot) => ShiftTimeSlot.fromJson(Map<String, dynamic>.from(slot)),
          )
          .toList(),
      changeDirection:
          json['changeDirection']?.toString() ?? ShiftDefinition.backward,
      changeDescription: json['changeDescription']?.toString() ?? '',
    );
  }
}
