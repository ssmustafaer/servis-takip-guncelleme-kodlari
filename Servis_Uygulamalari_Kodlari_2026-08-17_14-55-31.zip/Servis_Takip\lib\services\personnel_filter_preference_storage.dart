import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'company_cloud_storage.dart';

class PersonnelFilterPreference {
  const PersonnelFilterPreference({
    this.institutionId = '',
    this.workStyleId = '',
    this.regionId = '',
    this.groupId = '',
  });

  final String institutionId;
  final String workStyleId;
  final String regionId;
  final String groupId;
}

class PersonnelFilterPreferenceStorage {
  PersonnelFilterPreferenceStorage._();

  static const _storage = FlutterSecureStorage();
  static const _institutionKey = 'personnel_filter_institution';
  static const _workStyleKey = 'personnel_filter_work_style';
  static const _regionKey = 'personnel_filter_region';
  static const _groupKey = 'personnel_filter_group';

  static Future<PersonnelFilterPreference> read() async {
    return PersonnelFilterPreference(
      institutionId:
          await _storage.read(
            key: await CompanyCloudStorage.cacheKey(_institutionKey),
          ) ??
          '',
      workStyleId:
          await _storage.read(
            key: await CompanyCloudStorage.cacheKey(_workStyleKey),
          ) ??
          '',
      regionId:
          await _storage.read(
            key: await CompanyCloudStorage.cacheKey(_regionKey),
          ) ??
          '',
      groupId:
          await _storage.read(
            key: await CompanyCloudStorage.cacheKey(_groupKey),
          ) ??
          '',
    );
  }

  static Future<void> save(PersonnelFilterPreference preference) async {
    await Future.wait([
      _storage.write(
        key: await CompanyCloudStorage.cacheKey(_institutionKey),
        value: preference.institutionId,
      ),
      _storage.write(
        key: await CompanyCloudStorage.cacheKey(_workStyleKey),
        value: preference.workStyleId,
      ),
      _storage.write(
        key: await CompanyCloudStorage.cacheKey(_regionKey),
        value: preference.regionId,
      ),
      _storage.write(
        key: await CompanyCloudStorage.cacheKey(_groupKey),
        value: preference.groupId,
      ),
    ]);
  }
}
