import '../models/institution.dart';
import 'company_cloud_storage.dart';

class InstitutionStorage {
  InstitutionStorage._();

  static Future<List<Institution>> readAll() async {
    final data = await CompanyCloudStorage.readCollection('institutions');
    final institutions = data.map(Institution.fromJson).toList();
    await CompanyCloudStorage.syncUsageCount(
      usageField: 'institutions',
      count: _rootCount(institutions),
    );
    return institutions;
  }

  static Future<void> saveAll(List<Institution> institutions) {
    return CompanyCloudStorage.replaceCollection(
      collectionName: 'institutions',
      items: institutions.map((item) => item.toJson()).toList(),
      limitField: 'maxInstitutions',
      usageField: 'institutions',
      usageCount: _rootCount(institutions),
    );
  }

  static int _rootCount(List<Institution> institutions) =>
      institutions.where((institution) => institution.isRoot).length;
}
