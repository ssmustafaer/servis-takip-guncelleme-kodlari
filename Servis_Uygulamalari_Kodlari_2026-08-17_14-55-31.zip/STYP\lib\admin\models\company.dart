import 'package:cloud_firestore/cloud_firestore.dart';

class CompanyLimits {
  const CompanyLimits({
    required this.maxUsers,
    required this.maxInstitutions,
    required this.maxPersonnel,
    required this.maxStops,
    required this.maxVehicles,
  });

  final int maxUsers;
  final int maxInstitutions;
  final int maxPersonnel;
  final int maxStops;
  final int maxVehicles;

  Map<String, dynamic> toJson() => {
    'maxUsers': maxUsers,
    'maxInstitutions': maxInstitutions,
    'maxPersonnel': maxPersonnel,
    'maxStops': maxStops,
    'maxVehicles': maxVehicles,
  };

  factory CompanyLimits.fromJson(Map<String, dynamic>? json) {
    return CompanyLimits(
      maxUsers: (json?['maxUsers'] as num?)?.toInt() ?? 1,
      maxInstitutions: (json?['maxInstitutions'] as num?)?.toInt() ?? 10,
      maxPersonnel: (json?['maxPersonnel'] as num?)?.toInt() ?? 30,
      maxStops: (json?['maxStops'] as num?)?.toInt() ?? 15,
      maxVehicles: (json?['maxVehicles'] as num?)?.toInt() ?? 1,
    );
  }
}

class CompanyUsage {
  const CompanyUsage({
    required this.users,
    required this.institutions,
    required this.personnel,
    required this.stops,
    required this.vehicles,
  });

  final int users;
  final int institutions;
  final int personnel;
  final int stops;
  final int vehicles;

  factory CompanyUsage.fromJson(Map<String, dynamic>? json) {
    return CompanyUsage(
      users: (json?['users'] as num?)?.toInt() ?? 0,
      institutions: (json?['institutions'] as num?)?.toInt() ?? 0,
      personnel: (json?['personnel'] as num?)?.toInt() ?? 0,
      stops: (json?['stops'] as num?)?.toInt() ?? 0,
      vehicles: (json?['vehicles'] as num?)?.toInt() ?? 0,
    );
  }
}

class Company {
  const Company({
    required this.id,
    required this.name,
    required this.active,
    required this.planName,
    required this.packageId,
    required this.loginCode,
    required this.limits,
    required this.usage,
    this.expiresAt,
    this.deletedAt,
  });

  final String id;
  final String name;
  final bool active;
  final String planName;
  final String packageId;
  final String loginCode;
  final CompanyLimits limits;
  final CompanyUsage usage;
  final DateTime? expiresAt;
  final DateTime? deletedAt;

  bool get isDeleted => deletedAt != null;

  bool get isExpired =>
      expiresAt != null && expiresAt!.isBefore(DateTime.now());

  factory Company.fromDocument(
    DocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data() ?? const <String, dynamic>{};
    final expiresAt = data['expiresAt'];
    final deletedAt = data['deletedAt'];
    return Company(
      id: document.id,
      name: data['name'] as String? ?? 'İsimsiz Şirket',
      active: data['active'] as bool? ?? false,
      planName: data['planName'] as String? ?? 'Özel Paket',
      packageId: data['packageId'] as String? ?? '',
      loginCode:
          data['loginCode'] as String? ??
          document.id
              .substring(0, document.id.length.clamp(0, 6))
              .toUpperCase(),
      limits: CompanyLimits.fromJson(data['limits'] as Map<String, dynamic>?),
      usage: CompanyUsage.fromJson(data['usage'] as Map<String, dynamic>?),
      expiresAt: expiresAt is Timestamp ? expiresAt.toDate() : null,
      deletedAt: deletedAt is Timestamp ? deletedAt.toDate() : null,
    );
  }
}
