import 'package:cloud_firestore/cloud_firestore.dart';

class PackageLimitException implements Exception {
  const PackageLimitException(this.message);
  final String message;

  @override
  String toString() => message;
}

class PackageAccessService {
  PackageAccessService._();

  static final _firestore = FirebaseFirestore.instance;

  static Future<Map<String, dynamic>> entitlements(String companyId) async {
    final companySnapshot = await _firestore
        .collection('companies')
        .doc(companyId)
        .get();
    final company = companySnapshot.data() ?? const <String, dynamic>{};
    final packageId = company['packageId']?.toString().trim() ?? '';
    if (packageId.isEmpty) {
      return const {
        'id': 'legacy',
        'name': 'Özel Paket',
        'allReports': true,
        'reportHistoryDays': 0,
        'adsEnabled': true,
      };
    }
    final packagesSnapshot = await _firestore
        .collection('systemSettings')
        .doc('salesPackages')
        .get();
    final packages =
        (packagesSnapshot.data()?['packages'] as List<dynamic>? ?? const [])
            .whereType<Map>();
    for (final item in packages) {
      final package = Map<String, dynamic>.from(item);
      if (package['id']?.toString() == packageId) return package;
    }
    return const {
      'id': 'free',
      'name': 'Ücretsiz',
      'allReports': false,
      'reportHistoryDays': 7,
      'adsEnabled': true,
    };
  }

  static Future<bool> adsEnabled(String companyId) async {
    final package = await entitlements(companyId);
    return package['adsEnabled'] as bool? ?? true;
  }

  static Future<void> consumeMap({
    required String companyId,
    required String serviceKey,
  }) {
    return _consume(
      companyId: companyId,
      feature: 'map',
      limitField: 'monthlyMapLimit',
      usageKey: serviceKey,
      limitMessage:
          'Bu ayki ücretsiz harita hakkınız doldu. Sınırsız kullanım için paketinizi yükseltebilirsiniz.',
    );
  }

  static Future<void> consumeWhatsApp({required String companyId}) {
    return _consume(
      companyId: companyId,
      feature: 'whatsapp',
      limitField: 'monthlyWhatsAppLimit',
      limitMessage:
          'Bu ayki ücretsiz WhatsApp gönderim hakkınız doldu. Sınırsız kullanım için paketinizi yükseltebilirsiniz.',
    );
  }

  static Future<void> _consume({
    required String companyId,
    required String feature,
    required String limitField,
    required String limitMessage,
    String? usageKey,
  }) async {
    final companyReference = _firestore.collection('companies').doc(companyId);
    final packagesReference = _firestore
        .collection('systemSettings')
        .doc('salesPackages');
    await _firestore.runTransaction((transaction) async {
      final companySnapshot = await transaction.get(companyReference);
      final company = companySnapshot.data();
      if (company == null) return;

      final packageId = company['packageId']?.toString().trim() ?? '';
      if (packageId.isEmpty) return; // Eski Özel Paket: sınırsız.

      final packagesSnapshot = await transaction.get(packagesReference);
      final packages =
          (packagesSnapshot.data()?['packages'] as List<dynamic>? ?? const [])
              .whereType<Map>();
      Map<String, dynamic>? selected;
      for (final item in packages) {
        final package = Map<String, dynamic>.from(item);
        if (package['id']?.toString() == packageId) {
          selected = package;
          break;
        }
      }
      if (selected == null) return;
      final limit = (selected[limitField] as num?)?.toInt() ?? 0;
      if (limit <= 0) return;

      final now = DateTime.now();
      final month = '${now.year}-${now.month.toString().padLeft(2, '0')}';
      final oldUsage = Map<String, dynamic>.from(
        company['packageUsage'] as Map? ?? const {},
      );
      final sameMonth = oldUsage['month'] == month;
      final countField = '${feature}Count';
      final keysField = '${feature}Keys';
      final currentCount = sameMonth
          ? (oldUsage[countField] as num?)?.toInt() ?? 0
          : 0;
      final keys = sameMonth
          ? (oldUsage[keysField] as List<dynamic>? ?? const [])
                .map((item) => item.toString())
                .toList()
          : <String>[];
      if (usageKey != null && keys.contains(usageKey)) return;
      if (currentCount >= limit) throw PackageLimitException(limitMessage);
      if (usageKey != null) keys.add(usageKey);

      if (!sameMonth) {
        transaction.update(companyReference, {
          'packageUsage': {
            'month': month,
            'mapCount': feature == 'map' ? 1 : 0,
            'mapKeys': feature == 'map' ? keys : <String>[],
            'whatsappCount': feature == 'whatsapp' ? 1 : 0,
            'whatsappKeys': <String>[],
          },
          'updatedAt': FieldValue.serverTimestamp(),
        });
      } else {
        transaction.update(companyReference, {
          'packageUsage.$countField': currentCount + 1,
          'packageUsage.$keysField': keys,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      }
    });
  }
}
