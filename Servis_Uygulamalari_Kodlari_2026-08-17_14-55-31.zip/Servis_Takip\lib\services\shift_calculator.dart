import '../models/personnel.dart';

class ShiftStatus {
  const ShiftStatus({
    required this.isLeave,
    required this.workingDay,
    this.shift,
  });

  final bool isLeave;
  final int workingDay;
  final String? shift;
}

class ShiftCalculator {
  ShiftCalculator._();

  static const defaultShifts = Personnel.threeShiftStandard;
  static const idleShift = '-- / --';

  static String normalizeShift(String shift) {
    final compact = shift
        .trim()
        .replaceAll(':00', '')
        .replaceAll('-', '/')
        .replaceAll(RegExp(r'\s+'), '');
    switch (compact) {
      case '00/08':
      case '24/08':
        return '24 / 08';
      case '08/16':
        return '08 / 16';
      case '16/24':
        return '16 / 24';
      case '23/07':
        return '23 / 07';
      case '07/15':
        return '07 / 15';
      case '15/23':
        return '15 / 23';
      default:
        return shift.trim();
    }
  }

  static ShiftStatus forDate(Personnel person, DateTime date) {
    if (person.workType == Personnel.guestWorkType) {
      return const ShiftStatus(isLeave: false, workingDay: 0, shift: idleShift);
    }
    final startingShift = normalizeShift(person.shift);
    if (startingShift == idleShift) {
      return const ShiftStatus(isLeave: false, workingDay: 0, shift: idleShift);
    }

    final reference = DateTime.parse(person.referenceDate);
    final referenceDay = DateTime(
      reference.year,
      reference.month,
      reference.day,
    );
    final targetDay = DateTime(date.year, date.month, date.day);
    final rotation = _rotationFor(person, startingShift);

    if (person.leaveMode == Personnel.cycleLeaveMode &&
        person.workType != Personnel.fixedWorkType) {
      final workDays = person.workDaysCount.clamp(1, 7);
      final leaveDays = person.leaveDaysCount.clamp(1, 7);
      final cycleLength = workDays + leaveDays;
      final difference = targetDay.difference(referenceDay).inDays;
      final totalIndex = (person.cycleDay.clamp(1, 6) - 1) + difference;
      final cyclePosition = _positiveModulo(totalIndex, cycleLength);
      if (cyclePosition >= workDays) {
        return const ShiftStatus(isLeave: true, workingDay: 0);
      }
      if (!rotation.contains(startingShift)) {
        return ShiftStatus(
          isLeave: false,
          workingDay: cyclePosition + 1,
          shift: startingShift,
        );
      }
      final completedCycles = _floorDivide(totalIndex, cycleLength);
      return ShiftStatus(
        isLeave: false,
        workingDay: cyclePosition + 1,
        shift: _rotate(
          rotation,
          startingShift,
          completedCycles,
          person.shiftDirection,
        ),
      );
    }

    if (person.leaveWeekdays.contains(targetDay.weekday)) {
      return const ShiftStatus(isLeave: true, workingDay: 0);
    }

    final workingDay = _workingDayAfterLastLeave(person, targetDay);
    if (person.workType == Personnel.fixedWorkType ||
        !rotation.contains(startingShift)) {
      return ShiftStatus(
        isLeave: false,
        workingDay: workingDay,
        shift: startingShift,
      );
    }

    final completedLeaves = _leaveDaysBetween(
      person.leaveWeekdays,
      referenceDay,
      targetDay,
    );
    return ShiftStatus(
      isLeave: false,
      workingDay: workingDay,
      shift: _rotate(
        rotation,
        startingShift,
        completedLeaves,
        person.shiftDirection,
      ),
    );
  }

  static List<String> _rotationFor(Personnel person, String startingShift) {
    final custom = person.customShiftSequence
        .map(normalizeShift)
        .where((shift) => shift.isNotEmpty)
        .toList();
    if (custom.contains(startingShift)) return custom;
    final configured = Personnel.shiftsForPattern(person.shiftPattern);
    if (configured.contains(startingShift)) return configured;
    return Personnel.shiftsForPattern(Personnel.inferPattern(startingShift));
  }

  static String _rotate(
    List<String> shifts,
    String startingShift,
    int completedPeriods,
    String direction,
  ) {
    final sign = direction == Personnel.shiftForward ? 1 : -1;
    final start = shifts.indexOf(startingShift);
    return shifts[_positiveModulo(
      start + completedPeriods * sign,
      shifts.length,
    )];
  }

  static int _positiveModulo(int value, int divisor) =>
      ((value % divisor) + divisor) % divisor;

  static int _leaveDaysBetween(
    List<int> leaveWeekdays,
    DateTime reference,
    DateTime target,
  ) {
    if (leaveWeekdays.isEmpty || reference == target) return 0;
    var count = 0;
    if (target.isAfter(reference)) {
      for (
        var day = reference;
        day.isBefore(target);
        day = day.add(const Duration(days: 1))
      ) {
        if (leaveWeekdays.contains(day.weekday)) count++;
      }
      return count;
    }
    for (
      var day = target;
      day.isBefore(reference);
      day = day.add(const Duration(days: 1))
    ) {
      if (leaveWeekdays.contains(day.weekday)) count--;
    }
    return count;
  }

  static int _workingDayAfterLastLeave(Personnel person, DateTime target) {
    if (person.leaveWeekdays.isEmpty) return person.cycleDay;
    var workingDay = 1;
    var cursor = target.subtract(const Duration(days: 1));
    while (workingDay < 7 && !person.leaveWeekdays.contains(cursor.weekday)) {
      workingDay++;
      cursor = cursor.subtract(const Duration(days: 1));
    }
    return workingDay;
  }

  static int _floorDivide(int value, int divisor) {
    var quotient = value ~/ divisor;
    if (value < 0 && value % divisor != 0) quotient--;
    return quotient;
  }
}
