import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../company/models/company_session.dart';
import '../services/app_update_service.dart';
import 'backup_driver_invitation_screen.dart';
import 'company_employees_screen.dart';
import 'deleted_records_screen.dart';
import 'emergency_contacts_screen.dart';
import 'institutions_screen.dart';
import 'personnel_screen.dart';
import 'my_package_screen.dart';
import 'reports_screen.dart';
import 'shifts_screen.dart';
import 'shift_times_screen.dart';
import 'stops_screen.dart';
import 'vehicles_screen.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({this.session, super.key});

  final CompanySession? session;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _updating = false;
  late final Future<PackageInfo> _packageInfo;

  @override
  void initState() {
    super.initState();
    _packageInfo = PackageInfo.fromPlatform();
  }

  bool _allowed(String permission) =>
      widget.session == null || widget.session!.permission(permission);

  Future<void> _openWhatsAppSupport() async {
    try {
      final package = await _packageInfo;
      final session = widget.session;
      final message = StringBuffer()
        ..writeln(
          'Merhaba, Servis Takip uygulaması için destek almak istiyorum.',
        )
        ..writeln()
        ..writeln('Şirket: ${session?.companyName ?? '-'}')
        ..writeln('Kullanıcı: ${session?.displayName ?? '-'}')
        ..writeln('Sürüm: ${package.version} (Yapı ${package.buildNumber})')
        ..writeln()
        ..write('Sorunum: ');
      final uri = Uri.https('wa.me', '/905365051744', {
        'text': message.toString(),
      });
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened) throw StateError('WhatsApp açılamadı.');
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'WhatsApp desteği açılamadı. 0536 505 17 44 numarasından ulaşabilirsiniz.',
          ),
        ),
      );
    }
  }

  Future<void> _updateApplication() async {
    if (_updating) return;
    setState(() => _updating = true);
    try {
      final result = await AppUpdateService.updateIfAvailable();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result == 'up_to_date'
                ? 'Uygulama güncel. Yeni sürüm bulunamadı.'
                : 'Yeni sürüm bulundu. Güncelleme işlemi başlatıldı.',
          ),
        ),
      );
    } on PlatformException catch (error) {
      if (!mounted) return;
      final message = switch (error.code) {
        'API_DISABLED' => 'Firebase App Testers API henüz etkinleştirilmemiş.',
        'AUTHENTICATION_CANCELED' => 'Google hesabıyla giriş iptal edildi.',
        'AUTHENTICATION_FAILURE' =>
          'Bu Google hesabına güncelleme yetkisi verilmemiş.',
        'DOWNLOAD_FAILURE' => 'Güncelleme indirilemedi. Tekrar deneyin.',
        'INSTALLATION_CANCELED' => 'Güncelleme kurulumu iptal edildi.',
        'INSTALLATION_FAILURE' =>
          'Güncelleme kurulamadı. APK imzasını kontrol edin.',
        'NETWORK_FAILURE' => 'İnternet bağlantısı bulunamadı.',
        'NOT_IMPLEMENTED' => 'Bu uygulama sürümünde güncelleme desteklenmiyor.',
        'UPDATE_NOT_AVAILABLE' => 'Uygulama zaten güncel.',
        _ => error.message ?? 'Güncelleme başlatılamadı.',
      };
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Güncelleme kontrol edilemedi: $error')),
      );
    } finally {
      if (mounted) setState(() => _updating = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ayarlar')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Kayıt Yönetimi',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          if (_allowed('canManageInstitutions'))
            Card(
              child: ListTile(
                leading: const Icon(Icons.domain_rounded),
                title: const Text('Kurumlar'),
                subtitle: const Text('Fabrika, okul veya diğer kurumlar'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const InstitutionsScreen(),
                  ),
                ),
              ),
            ),
          if (_allowed('canManageStops'))
            Card(
              child: ListTile(
                leading: const Icon(Icons.location_on_rounded),
                title: const Text('Duraklar'),
                subtitle: const Text('Durakları ve güzergâh sırasını düzenle'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: (_) => const StopsScreen()),
                ),
              ),
            ),
          if (_allowed('canManagePersonnel'))
            Card(
              child: ListTile(
                leading: const Icon(Icons.people_alt_rounded),
                title: const Text('Personel'),
                subtitle: const Text('Personel ekle, düzenle veya sil'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const PersonnelScreen(),
                  ),
                ),
              ),
            ),
          if (_allowed('canManageShifts'))
            Card(
              child: ListTile(
                leading: const Icon(Icons.access_time_rounded),
                title: const Text('Vardiya Saatleri'),
                subtitle: const Text('Giriş ve çıkış saatlerini düzenle'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const ShiftTimesScreen(),
                  ),
                ),
              ),
            ),
          if (_allowed('canManageShifts'))
            Card(
              child: ListTile(
                leading: const Icon(Icons.swap_horiz_rounded),
                title: const Text('Vardiyalar'),
                subtitle: const Text('Çalışılan vardiyaları düzenle'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: (_) => const ShiftsScreen()),
                ),
              ),
            ),
          if (_allowed('canViewReports'))
            Card(
              child: ListTile(
                leading: const Icon(Icons.assessment_rounded),
                title: const Text('Raporlar'),
                subtitle: const Text('Servis, yolcu ve kullanım raporları'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const ReportsScreen(),
                  ),
                ),
              ),
            ),
          const SizedBox(height: 24),
          const Text(
            'Şirket Yönetimi',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          if (widget.session != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.workspace_premium_rounded),
                title: const Text('Paketim'),
                subtitle: const Text('Mevcut paket, kullanım ve limitler'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => MyPackageScreen(session: widget.session!),
                  ),
                ),
              ),
            ),
          if (_allowed('canManageEmployees') && widget.session != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.badge_rounded),
                title: const Text('Şirket Çalışanları'),
                subtitle: const Text('Pozisyon ve erişim yetkileri'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) =>
                        CompanyEmployeesScreen(session: widget.session!),
                  ),
                ),
              ),
            ),
          if (_allowed('canManageEmployees') && widget.session != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.emergency_rounded),
                title: const Text('Acil Aranacak Kişiler'),
                subtitle: const Text(
                  'En fazla 3 kişiyi arama önceliğine göre sırala',
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) =>
                        EmergencyContactsScreen(session: widget.session!),
                  ),
                ),
              ),
            ),
          if (_allowed('canManageVehicles'))
            Card(
              child: ListTile(
                leading: const Icon(Icons.directions_bus_rounded),
                title: const Text('Araçlar'),
                subtitle: const Text('Plaka, model ve koltuk kapasitesi'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const VehiclesScreen(),
                  ),
                ),
              ),
            ),
          if (_allowed('canManagePersonnel') || _allowed('canManageStops'))
            Card(
              child: ListTile(
                leading: const Icon(Icons.restore_from_trash_rounded),
                title: const Text('Silinen Kayıtlar'),
                subtitle: const Text('Silinen personel ve durakları görüntüle'),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) => const DeletedRecordsScreen(),
                  ),
                ),
              ),
            ),
          if (_allowed('canManageEmployees') && widget.session != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.person_add_alt_1_rounded),
                title: const Text('Yedek Şoför Daveti'),
                subtitle: const Text(
                  'Süreli kullanım paketi ve ödeme bildirimi hazırla',
                ),
                trailing: const Icon(Icons.chevron_right_rounded),
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(
                    builder: (_) =>
                        BackupDriverInvitationScreen(session: widget.session!),
                  ),
                ),
              ),
            ),
          const SizedBox(height: 24),
          const Text(
            'Uygulama Güncelleme',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: _updating
                  ? const SizedBox.square(
                      dimension: 24,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.system_update_alt_rounded),
              title: const Text('Uygulamayı Güncelle'),
              subtitle: const Text(
                'Yeni sürümü kontrol eder, varsa indirip kurulumu başlatır',
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: _updating ? null : _updateApplication,
            ),
          ),
          FutureBuilder<PackageInfo>(
            future: _packageInfo,
            builder: (context, snapshot) {
              final package = snapshot.data;
              final version = package == null
                  ? 'Sürüm bilgisi yükleniyor'
                  : 'Sürüm ${package.version} (Yapı ${package.buildNumber})';
              return Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  version,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              );
            },
          ),
          const SizedBox(height: 24),
          const Text(
            'Destek ve İletişim',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: const Icon(Icons.chat_rounded, color: Color(0xFF128C7E)),
              title: const Text('WhatsApp ile Destek Al'),
              subtitle: const Text('0536 505 17 44'),
              trailing: const Icon(Icons.open_in_new_rounded),
              onTap: _openWhatsAppSupport,
            ),
          ),
        ],
      ),
    );
  }
}
