class Institution {
  const Institution({
    required this.id,
    required this.name,
    required this.type,
    this.parentId,
    this.active = true,
    this.latitude,
    this.longitude,
  });

  static const types = ['Fabrika', 'Okul', 'Diğer'];

  final String id;
  final String name;
  final String type;
  final String? parentId;
  final bool active;
  final double? latitude;
  final double? longitude;

  bool get isRoot => parentId == null || parentId!.isEmpty;
  bool get hasLocation => latitude != null && longitude != null;

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'type': type,
    'parentId': parentId,
    'active': active,
    'latitude': latitude,
    'longitude': longitude,
  };

  factory Institution.fromJson(Map<String, dynamic> json) => Institution(
    id: json['id'] as String,
    name: json['name'] as String,
    type: json['type'] as String? ?? 'Diğer',
    parentId: (json['parentId'] as String?)?.trim().isEmpty == true
        ? null
        : json['parentId'] as String?,
    active: json['active'] as bool? ?? true,
    latitude: (json['latitude'] as num?)?.toDouble(),
    longitude: (json['longitude'] as num?)?.toDouble(),
  );

  Institution copyWith({
    String? name,
    String? type,
    String? parentId,
    bool clearParent = false,
    bool? active,
    double? latitude,
    double? longitude,
    bool clearLocation = false,
  }) {
    return Institution(
      id: id,
      name: name ?? this.name,
      type: type ?? this.type,
      parentId: clearParent ? null : parentId ?? this.parentId,
      active: active ?? this.active,
      latitude: clearLocation ? null : latitude ?? this.latitude,
      longitude: clearLocation ? null : longitude ?? this.longitude,
    );
  }

  static List<Institution> childrenOf(
    List<Institution> institutions,
    String? parentId,
  ) {
    final items = institutions
        .where(
          (item) => parentId == null ? item.isRoot : item.parentId == parentId,
        )
        .toList();
    items.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return items;
  }

  static Set<String> subtreeIds(List<Institution> institutions, String rootId) {
    final result = <String>{rootId};
    void addChildren(String parentId) {
      for (final child in childrenOf(institutions, parentId)) {
        if (result.add(child.id)) addChildren(child.id);
      }
    }

    addChildren(rootId);
    return result;
  }

  static String pathLabel(
    List<Institution> institutions,
    Institution institution,
  ) {
    final byId = {for (final item in institutions) item.id: item};
    final names = <String>[institution.name];
    var parentId = institution.parentId;
    final visited = <String>{institution.id};
    while (parentId != null && parentId.isNotEmpty && visited.add(parentId)) {
      final parent = byId[parentId];
      if (parent == null) break;
      names.insert(0, parent.name);
      parentId = parent.parentId;
    }
    return names.join(' › ');
  }
}
