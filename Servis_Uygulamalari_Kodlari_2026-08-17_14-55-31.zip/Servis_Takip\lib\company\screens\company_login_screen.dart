import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../services/company_auth_repository.dart';

class CompanyLoginScreen extends StatefulWidget {
  const CompanyLoginScreen({required this.repository, super.key});

  final CompanyAuthRepository repository;

  @override
  State<CompanyLoginScreen> createState() => _CompanyLoginScreenState();
}

class _CompanyLoginScreenState extends State<CompanyLoginScreen> {
  static const _secureStorage = FlutterSecureStorage();
  static const _adminEmailKey = 'emergency_admin_email';
  static const _adminPasswordKey = 'emergency_admin_password';
  final _formKey = GlobalKey<FormState>();
  final _companyCodeController = TextEditingController();
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();
  var _busy = false;
  var _hidePassword = true;
  var _emergencyConfigured = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadEmergencyConfiguration();
  }

  Future<void> _loadEmergencyConfiguration() async {
    final password = await _secureStorage.read(key: _adminPasswordKey);
    if (mounted) {
      setState(() => _emergencyConfigured = password?.isNotEmpty == true);
    }
  }

  @override
  void dispose() {
    _companyCodeController.dispose();
    _nameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _signIn() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.repository.signIn(
        companyCode: _companyCodeController.text,
        displayName: _nameController.text,
        password: _passwordController.text,
      );
    } on FirebaseAuthException catch (error) {
      setState(() {
        _error = switch (error.code) {
          'invalid-credential' => 'Ad soyad veya şifre hatalı.',
          'too-many-requests' =>
            'Çok fazla deneme yapıldı. Biraz sonra tekrar deneyin.',
          _ => error.message ?? 'Giriş yapılamadı.',
        };
      });
    } catch (error) {
      setState(() => _error = error.toString().replaceFirst('Bad state: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _emergencyAdminSignIn() async {
    var email = await _secureStorage.read(key: _adminEmailKey) ?? '';
    var password = await _secureStorage.read(key: _adminPasswordKey) ?? '';
    if (email.isEmpty || password.isEmpty) {
      final result = await _askAdminCredentials();
      if (result == null) return;
      email = result.$1;
      password = result.$2;
    }
    if (!mounted) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.repository.signInSystemAdmin(
        email: email,
        password: password,
      );
      await _secureStorage.write(key: _adminEmailKey, value: email);
      await _secureStorage.write(key: _adminPasswordKey, value: password);
      if (mounted) setState(() => _emergencyConfigured = true);
    } catch (error) {
      await _secureStorage.delete(key: _adminPasswordKey);
      if (mounted) {
        setState(() {
          _emergencyConfigured = false;
          _error = error.toString().replaceFirst('Bad state: ', '');
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<(String, String)?> _askAdminCredentials() async {
    final emailController = TextEditingController();
    final passwordController = TextEditingController();
    final result = await showDialog<(String, String)>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Acil Yönetici Girişi'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'İlk kullanımda sistem yöneticisi bilgilerinizi girin. Bilgiler yalnızca bu telefonun güvenli alanında saklanır.',
            ),
            const SizedBox(height: 14),
            TextField(
              controller: emailController,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'Yönetici e-postası',
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Yönetici şifresi'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () {
              if (emailController.text.trim().isEmpty ||
                  passwordController.text.isEmpty)
                return;
              Navigator.pop(dialogContext, (
                emailController.text.trim(),
                passwordController.text,
              ));
            },
            child: const Text('DEVAM ET'),
          ),
        ],
      ),
    );
    emailController.dispose();
    passwordController.dispose();
    return result;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        GestureDetector(
                          onLongPress: _busy ? null : _emergencyAdminSignIn,
                          child: const Icon(
                            Icons.directions_bus_rounded,
                            size: 64,
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          'Servis Takip',
                          style: Theme.of(context).textTheme.headlineMedium
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 24),
                        TextFormField(
                          controller: _companyCodeController,
                          textCapitalization: TextCapitalization.characters,
                          decoration: const InputDecoration(
                            labelText: 'Şirket kodu',
                            prefixIcon: Icon(Icons.business_rounded),
                          ),
                          validator: (value) =>
                              value == null || value.trim().isEmpty
                              ? 'Şirket kodunu girin.'
                              : null,
                        ),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: _nameController,
                          textCapitalization: TextCapitalization.words,
                          decoration: const InputDecoration(
                            labelText: 'Ad soyad',
                            prefixIcon: Icon(Icons.person_rounded),
                          ),
                          validator: (value) =>
                              value == null || value.trim().isEmpty
                              ? 'Adınızı ve soyadınızı girin.'
                              : null,
                        ),
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: _passwordController,
                          obscureText: _hidePassword,
                          onFieldSubmitted: (_) => _busy ? null : _signIn(),
                          decoration: InputDecoration(
                            labelText: 'Şifre',
                            prefixIcon: const Icon(Icons.lock_rounded),
                            suffixIcon: IconButton(
                              onPressed: () => setState(
                                () => _hidePassword = !_hidePassword,
                              ),
                              icon: Icon(
                                _hidePassword
                                    ? Icons.visibility
                                    : Icons.visibility_off,
                              ),
                            ),
                          ),
                          validator: (value) => (value?.length ?? 0) < 6
                              ? 'Şifre en az 6 karakter olmalıdır.'
                              : null,
                        ),
                        if (_error != null) ...[
                          const SizedBox(height: 12),
                          Text(
                            _error!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.red),
                          ),
                        ],
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          child: FilledButton(
                            onPressed: _busy ? null : _signIn,
                            child: _busy
                                ? const SizedBox(
                                    width: 22,
                                    height: 22,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Text('GİRİŞ YAP'),
                          ),
                        ),
                        if (_emergencyConfigured) ...[
                          const SizedBox(height: 10),
                          SizedBox(
                            width: double.infinity,
                            child: OutlinedButton.icon(
                              onPressed: _busy ? null : _emergencyAdminSignIn,
                              icon: const Icon(
                                Icons.admin_panel_settings_rounded,
                              ),
                              label: const Text('ACİL YÖNETİCİ GİRİŞİ'),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
