import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'company_cloud_storage.dart';

class AuthorizedContact {
  const AuthorizedContact({
    required this.name,
    required this.phone,
    this.employeeId = '',
  });

  final String name;
  final String phone;
  final String employeeId;

  Map<String, String> toMap() => {
    'name': name,
    'phone': phone,
    'employeeId': employeeId,
  };

  factory AuthorizedContact.fromMap(Map<String, dynamic> map) =>
      AuthorizedContact(
        name: map['name']?.toString() ?? '',
        phone: map['phone']?.toString() ?? '',
        employeeId: map['employeeId']?.toString() ?? '',
      );
}

class AuthorizedContactStorage {
  AuthorizedContactStorage._();

  static const _nameKey = 'authorized_contact_name';
  static const _phoneKey = 'authorized_contact_phone';
  static const _listKey = 'authorized_contacts';
  static const _storage = FlutterSecureStorage();

  static Future<AuthorizedContact?> read() async {
    final contacts = await readAll();
    return contacts.firstOrNull;
  }

  static Future<List<AuthorizedContact>> readAll() async {
    final cloudList = await CompanyCloudStorage.readDocument(
      collectionName: 'settings',
      documentId: 'authorizedContacts',
    );
    if (cloudList != null) {
      final contacts = (cloudList['contacts'] as List<dynamic>? ?? const [])
          .whereType<Map>()
          .map(
            (item) =>
                AuthorizedContact.fromMap(Map<String, dynamic>.from(item)),
          )
          .where((item) => item.phone.isNotEmpty)
          .take(3)
          .toList();
      await _writeListCache(contacts);
      if (contacts.isNotEmpty) return contacts;
    }

    final cloud = await CompanyCloudStorage.readDocument(
      collectionName: 'settings',
      documentId: 'authorizedContact',
    );
    if (cloud != null) {
      final contact = AuthorizedContact(
        name: cloud['name'] as String? ?? '',
        phone: cloud['phone'] as String? ?? '',
      );
      await _writeCache(contact);
      if (contact.phone.isNotEmpty) {
        await saveAll([contact]);
        return [contact];
      }
    }

    final cachedList = await _storage.read(
      key: await CompanyCloudStorage.cacheKey(_listKey),
    );
    if (cachedList != null && cachedList.isNotEmpty) {
      try {
        return (jsonDecode(cachedList) as List<dynamic>)
            .whereType<Map>()
            .map(
              (item) =>
                  AuthorizedContact.fromMap(Map<String, dynamic>.from(item)),
            )
            .where((item) => item.phone.isNotEmpty)
            .take(3)
            .toList();
      } catch (_) {
        // Eski veya bozuk yerel kayıt varsa tek kişilik eski kayıt denenir.
      }
    }
    final name = await _storage.read(
      key: await CompanyCloudStorage.cacheKey(_nameKey),
    );
    final phone = await _storage.read(
      key: await CompanyCloudStorage.cacheKey(_phoneKey),
    );
    if (name == null || phone == null || phone.isEmpty) return const [];
    return [AuthorizedContact(name: name, phone: phone)];
  }

  static Future<void> save(AuthorizedContact contact) async {
    await saveAll([contact]);
  }

  static Future<void> saveAll(List<AuthorizedContact> contacts) async {
    final limited = contacts.take(3).toList();
    await CompanyCloudStorage.writeDocument(
      collectionName: 'settings',
      documentId: 'authorizedContacts',
      data: {'contacts': limited.map((item) => item.toMap()).toList()},
    );
    await _writeListCache(limited);
    if (limited.isNotEmpty) await _writeCache(limited.first);
  }

  static Future<void> _writeListCache(List<AuthorizedContact> contacts) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_listKey),
      value: jsonEncode(contacts.map((item) => item.toMap()).toList()),
    );
  }

  static Future<void> _writeCache(AuthorizedContact contact) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_nameKey),
      value: contact.name,
    );
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_phoneKey),
      value: contact.phone,
    );
  }
}
