import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class PaymentApprovalRequestService {
  PaymentApprovalRequestService({
    FirebaseFirestore? firestore,
    FirebaseAuth? auth,
  }) : _firestore = firestore ?? FirebaseFirestore.instance,
       _auth = auth ?? FirebaseAuth.instance;

  final FirebaseFirestore _firestore;
  final FirebaseAuth _auth;

  Future<String> create({
    required String companyId,
    required String companyName,
    required String requestedByName,
    required String driverId,
    required String driverName,
    required String driverPhone,
    required String campaignId,
    required String campaignTitle,
    required int campaignDays,
    required num amount,
    required String paymentCode,
    required String loginName,
    required String temporaryPassword,
  }) async {
    final user = _auth.currentUser;
    if (user == null) {
      throw StateError('Onay talebi oluşturmak için giriş yapılmalıdır.');
    }

    final company = await _firestore
        .collection('companies')
        .doc(companyId)
        .get();
    final companyCode = company.data()?['loginCode']?.toString() ?? '';
    if (companyCode.isEmpty) {
      throw StateError('Şirket giriş kodu bulunamadı.');
    }

    final reference = _firestore.collection('paymentApprovalRequests').doc();
    await reference.set({
      'companyId': companyId,
      'companyName': companyName,
      'requestedByUid': user.uid,
      'requestedByName': requestedByName,
      'driverId': driverId,
      'driverName': driverName,
      'driverPhone': driverPhone,
      'campaignId': campaignId,
      'campaignTitle': campaignTitle,
      'campaignDays': campaignDays,
      'amount': amount,
      'paymentCode': paymentCode,
      'companyCode': companyCode,
      'loginName': loginName,
      'temporaryPassword': temporaryPassword,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
      'updatedAt': FieldValue.serverTimestamp(),
    });
    return reference.id;
  }
}
