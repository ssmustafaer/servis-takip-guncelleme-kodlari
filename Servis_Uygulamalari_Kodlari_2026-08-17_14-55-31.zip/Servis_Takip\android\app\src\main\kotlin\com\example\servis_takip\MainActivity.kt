package com.example.servis_takip

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.FileProvider
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private val updateChannelName = "servis_takip/app_update"
    private val overlayChannelName = "com.servis_takip/stop_overlay"
    private lateinit var overlayChannel: MethodChannel
    private var overlayView: View? = null
    private var downloadId: Long? = null
    private var receiverRegistered = false
    private val density by lazy { resources.displayMetrics.density }

    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) != downloadId) return
            val apk = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "servis_takip_update.apk")
            if (!apk.exists()) return
            val uri = FileProvider.getUriForFile(context, "$packageName.fileprovider", apk)
            startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                },
            )
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, updateChannelName)
            .setMethodCallHandler { call, result ->
                if (call.method != "downloadAndInstall") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                val url = call.argument<String>("url")
                if (url.isNullOrBlank()) {
                    result.error("INVALID_URL", "APK bağlantısı bulunamadı.", null)
                    return@setMethodCallHandler
                }
                try {
                    startUpdateDownload(url)
                    result.success("update_started")
                } catch (error: Exception) {
                    result.error("DOWNLOAD_FAILURE", error.localizedMessage, null)
                }
            }

        overlayChannel = MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            overlayChannelName,
        )
        overlayChannel.setMethodCallHandler { call, result ->
            when (call.method) {
                "canDrawOverlays" -> result.success(canDrawOverlays())
                "requestOverlayPermission" -> {
                    requestOverlayPermission()
                    result.success(null)
                }
                "showStopOverlay" -> {
                    if (!canDrawOverlays()) {
                        result.error("permission_denied", "Overlay izni verilmedi", null)
                        return@setMethodCallHandler
                    }
                    val stopName = call.argument<String>("stopName").orEmpty()
                    @Suppress("UNCHECKED_CAST")
                    val passengers = call.argument<List<Map<String, Any?>>>("passengers").orEmpty()
                    showStopOverlay(stopName, passengers)
                    result.success(null)
                }
                "hideStopOverlay" -> {
                    hideStopOverlay()
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun startUpdateDownload(url: String) {
        val directory = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)!!
        val apk = File(directory, "servis_takip_update.apk")
        if (apk.exists()) apk.delete()
        if (!receiverRegistered) {
            val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(downloadReceiver, filter, RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(downloadReceiver, filter)
            }
            receiverRegistered = true
        }
        val request = DownloadManager.Request(Uri.parse(url))
            .setTitle("Servis Takip güncelleniyor")
            .setDescription("Yeni sürüm indiriliyor")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(
                this,
                Environment.DIRECTORY_DOWNLOADS,
                "servis_takip_update.apk",
            )
        downloadId = (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
    }

    private fun canDrawOverlays(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName"),
                ),
            )
        }
    }

    private fun showStopOverlay(stopName: String, passengers: List<Map<String, Any?>>) {
        hideStopOverlay()
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            setBackgroundColor(Color.WHITE)
            elevation = dp(12).toFloat()
        }
        val passengerIds = passengers.mapNotNull { passenger ->
            passenger["id"]?.toString()?.takeIf { it.isNotBlank() }
        }
        val absentPassengerIds = mutableSetOf<String>()
        fun completeStop() {
            hideStopOverlay()
            overlayChannel.invokeMethod(
                "overlayStopCompleted",
                mapOf(
                    "passengerIds" to passengerIds,
                    "absentPassengerIds" to absentPassengerIds.toList(),
                ),
            )
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "DURAĞA YAKLAŞTINIZ\n$stopName"
            textSize = 20f
            setTextColor(Color.rgb(20, 45, 70))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Button(this).apply {
            text = "KAPAT"
            textSize = 15f
            minHeight = dp(52)
            minWidth = dp(92)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { completeStop() }
        })
        root.addView(header)
        root.addView(TextView(this).apply {
            text = "Yalnızca durakta olmayan yolcuları YOK olarak işaretleyin. Pencereyi kapattığınızda diğer yolcular binmiş sayılır."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(8), 0, dp(10))
        })

        val statusView = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            visibility = View.GONE
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        root.addView(statusView)

        val handler = Handler(Looper.getMainLooper())
        var statusMessageSequence = 0

        fun showTemporaryStatus(message: String, color: Int) {
            statusMessageSequence += 1
            val sequence = statusMessageSequence
            statusView.text = message
            statusView.setTextColor(color)
            statusView.visibility = View.VISIBLE
            handler.postDelayed({
                if (sequence == statusMessageSequence && overlayView === root) {
                    statusView.visibility = View.GONE
                }
            }, 2_000)
        }

        val passengerList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        passengers.forEach { passenger ->
            val personId = passenger["id"]?.toString().orEmpty()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, dp(9))
            }
            val nameView = TextView(this).apply {
                text = passenger["name"]?.toString().orEmpty()
                textSize = 18f
                setTextColor(Color.BLACK)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(dp(4), 0, dp(12), 0)
            }
            row.addView(
                nameView,
                LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f),
            )
            val absent = actionButton("YOK", Color.rgb(190, 35, 35))
            fun submitAbsent() {
                absent.isEnabled = false
                absentPassengerIds.add(personId)
                overlayChannel.invokeMethod(
                    "overlayAttendance",
                    mapOf("personId" to personId, "status" to "Durakta Yok"),
                    object : MethodChannel.Result {
                        override fun success(result: Any?) {
                            if (overlayView !== root) return
                            if (result != true) {
                                absent.isEnabled = true
                                absentPassengerIds.remove(personId)
                                showTemporaryStatus(
                                    "Kayıt yapılamadı. Tekrar deneyin.",
                                    Color.rgb(190, 35, 35),
                                )
                                return
                            }
                            absent.text = "✓ YOK"
                            nameView.setTextColor(Color.DKGRAY)
                            showTemporaryStatus(
                                "Yok olarak işaretlendi.",
                                Color.rgb(190, 35, 35),
                            )
                        }

                        override fun error(
                            errorCode: String,
                            errorMessage: String?,
                            errorDetails: Any?,
                        ) {
                            if (overlayView !== root) return
                            absent.isEnabled = true
                            absentPassengerIds.remove(personId)
                            showTemporaryStatus(
                                "Kayıt yapılamadı. Tekrar deneyin.",
                                Color.rgb(190, 35, 35),
                            )
                        }

                        override fun notImplemented() {
                            error("not_implemented", null, null)
                        }
                    },
                )
            }
            absent.setOnClickListener { submitAbsent() }
            row.addView(
                absent,
                LinearLayout.LayoutParams(dp(120), dp(56)),
            )
            passengerList.addView(row)
        }
        root.addView(
            ScrollView(this).apply { addView(passengerList) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f),
        )

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            dp(430),
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(30)
        }
        overlayView = root
        windowManager.addView(root, params)
    }

    private fun actionButton(label: String, color: Int) = Button(this).apply {
        text = label
        textSize = 17f
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        minHeight = dp(60)
        minWidth = dp(140)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        isAllCaps = false
    }

    private fun hideStopOverlay() {
        val view = overlayView ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(view)
        } catch (_: IllegalArgumentException) {
            // Pencere zaten kaldırılmış olabilir.
        }
        overlayView = null
    }

    private fun dp(value: Int): Int = (value * density).toInt()

    override fun onDestroy() {
        hideStopOverlay()
        if (receiverRegistered) unregisterReceiver(downloadReceiver)
        super.onDestroy()
    }
}
