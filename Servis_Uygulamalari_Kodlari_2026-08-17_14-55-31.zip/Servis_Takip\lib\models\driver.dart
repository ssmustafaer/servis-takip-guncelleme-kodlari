class Driver {
  const Driver({
    required this.id,
    required this.name,
    this.canManageSettings = false,
  });

  final String id;
  final String name;
  final bool canManageSettings;

  Driver copyWith({bool? canManageSettings}) => Driver(
    id: id,
    name: name,
    canManageSettings: canManageSettings ?? this.canManageSettings,
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'canManageSettings': canManageSettings,
  };

  factory Driver.fromJson(Map<String, dynamic> json) => Driver(
    id: json['id'] as String,
    name: json['name'] as String,
    canManageSettings: json['canManageSettings'] as bool? ?? false,
  );
}
