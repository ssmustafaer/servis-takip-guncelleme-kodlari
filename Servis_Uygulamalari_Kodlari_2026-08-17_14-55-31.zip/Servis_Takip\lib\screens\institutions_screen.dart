import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import '../models/institution.dart';
import '../models/personnel.dart';
import '../models/shift_definition.dart';
import '../services/institution_storage.dart';
import '../services/personnel_storage.dart';
import '../services/shift_definition_storage.dart';
import 'map_picker_screen.dart';

class InstitutionsScreen extends StatefulWidget {
  const InstitutionsScreen({super.key});

  @override
  State<InstitutionsScreen> createState() => _InstitutionsScreenState();
}

class _InstitutionsScreenState extends State<InstitutionsScreen> {
  var _loading = true;
  List<Institution> _institutions = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final items = await InstitutionStorage.readAll();
    if (!mounted) return;
    setState(() {
      _institutions = items;
      _loading = false;
    });
  }

  String _normalizedName(String value) => value.trim().toLowerCase();

  ShiftDefinition? _findShiftDefinition(
    List<ShiftDefinition> definitions, {
    required int slotCount,
    required bool fixed,
  }) {
    final candidates = definitions.where((definition) {
      final isFixed = definition.changeDirection == ShiftDefinition.fixed;
      return definition.slots.length == slotCount && isFixed == fixed;
    }).toList();
    if (candidates.isEmpty) return null;

    bool preferred(ShiftDefinition definition) {
      final name = _normalizedName(definition.name);
      if (fixed) {
        return name.contains('sabit') ||
            definition.slots.any((slot) => slot.label == '08 / 16');
      }
      return slotCount == 3
          ? name.contains('3') || name.contains('üç')
          : name.contains('2') || name.contains('iki');
    }

    return candidates.where(preferred).firstOrNull ?? candidates.first;
  }

  ShiftDefinition? _findDefinitionNamed(
    List<ShiftDefinition> definitions,
    String name,
  ) {
    final expected = _normalizedName(name);
    return definitions
        .where(
          (definition) => _normalizedName(definition.name).contains(expected),
        )
        .firstOrNull;
  }

  Future<void> _migrateBucaToAnatolia() async {
    final anatolia = _institutions
        .where(
          (item) => item.isRoot && _normalizedName(item.name) == 'anatolia',
        )
        .firstOrNull;
    final bucaRecords = _institutions
        .where(
          (item) =>
              item.id != anatolia?.id && _normalizedName(item.name) == 'buca',
        )
        .toList();

    if (anatolia == null || bucaRecords.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('ANATOLIA ana kaydı veya BUCA kaydı bulunamadı.'),
        ),
      );
      return;
    }

    final definitions = await ShiftDefinitionStorage.readAll();
    final threeShift = _findShiftDefinition(
      definitions,
      slotCount: 3,
      fixed: false,
    );
    final twoShift = _findShiftDefinition(
      definitions,
      slotCount: 2,
      fixed: false,
    );
    final fixedShift = _findShiftDefinition(
      definitions,
      slotCount: 1,
      fixed: true,
    );
    final reliefShift = _findDefinitionNamed(definitions, 'dinlendirici');

    final missing = <String>[
      if (threeShift == null) '3’lü Vardiya',
      if (twoShift == null) '2’li Vardiya',
      if (fixedShift == null) 'Sabit vardiya',
      if (reliefShift == null) 'Dinlendirici',
    ];
    if (missing.isNotEmpty) {
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Yeni vardiya kaydı eksik'),
          content: Text(
            '${missing.join(', ')} kaydı bulunamadı. Önce Vardiyalar '
            'ekranında bu kayıtları oluşturun. Hiçbir veri değiştirilmedi.',
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('TAMAM'),
            ),
          ],
        ),
      );
      return;
    }

    final bucaSubtreeIds = <String>{};
    final obsoleteAncestorIds = <String>{};
    final institutionByOriginalId = {
      for (final item in _institutions) item.id: item,
    };
    for (final buca in bucaRecords) {
      bucaSubtreeIds.addAll(Institution.subtreeIds(_institutions, buca.id));
      var parentId = buca.parentId;
      while (parentId != null &&
          parentId.isNotEmpty &&
          parentId != anatolia.id) {
        if (!obsoleteAncestorIds.add(parentId)) break;
        parentId = institutionByOriginalId[parentId]?.parentId;
      }
    }
    final personnel = await PersonnelStorage.readAll();
    final affected = personnel
        .where((person) => bucaSubtreeIds.contains(person.institutionId))
        .toList();
    final reliefCount = affected
        .where((person) => person.workType == Personnel.reliefWorkType)
        .length;
    final guestCount = affected
        .where((person) => person.workType == Personnel.guestWorkType)
        .length;
    final fixedCount = affected.where((person) {
      return person.workType == Personnel.fixedWorkType ||
          person.shift.trim() == '08 / 16 Sabit';
    }).length;
    final twoCount = affected.where((person) {
      return person.workType != Personnel.fixedWorkType &&
          person.shiftSystem == Personnel.twoShiftSystem;
    }).length;
    final threeCount = affected.length - fixedCount - twoCount - guestCount;
    final guestSummary = guestCount > 0
        ? '• Misafir (yalnızca kurum bağı taşınır): $guestCount\n\n'
        : '';

    if (!mounted) return;
    final previewApproved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('BUCA → ANATOLIA taşıma ön izlemesi'),
        content: Text(
          '${bucaRecords.length} BUCA kaydı doğrudan ANATOLIA’ya bağlanacak.\n\n'
          'Silinecek eski üst kayıt: ${obsoleteAncestorIds.length}\n'
          'Etkilenen personel: ${affected.length}\n'
          '• 3’lü vardiya: $threeCount\n'
          '• 2’li vardiya: $twoCount\n'
          '• Sabit: $fixedCount\n'
          '• Dinlendirici: $reliefCount\n\n'
          '$guestSummary'
          'Personel, izin, dinlendirici takvimi ve eski vardiya alanları '
          'korunacaktır. Bu işlem buluttaki kayıtları günceller.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('KONTROL ETTİM'),
          ),
        ],
      ),
    );
    if (previewApproved != true || !mounted) return;

    final finalApproved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Son onay'),
        content: const Text(
          'Taşıma şimdi uygulanacak. Eski kayıtlar silinmeyecek. Devam edilsin mi?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('HAYIR'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('EVET, TAŞI'),
          ),
        ],
      ),
    );
    if (finalApproved != true) return;

    try {
      final bucaIds = bucaRecords.map((item) => item.id).toSet();
      final updatedInstitutions = [
        for (final item in _institutions)
          if (obsoleteAncestorIds.contains(item.id))
            ...<Institution>[]
          else if (bucaIds.contains(item.id))
            item.copyWith(parentId: anatolia.id)
          else
            item,
      ];
      final institutionById = {
        for (final item in updatedInstitutions) item.id: item,
      };

      ShiftDefinition definitionFor(Personnel person) {
        if (person.workType == Personnel.reliefWorkType) return reliefShift!;
        if (person.workType == Personnel.fixedWorkType ||
            person.shift.trim() == '08 / 16 Sabit') {
          return fixedShift!;
        }
        if (person.shiftSystem == Personnel.twoShiftSystem) return twoShift!;
        return threeShift!;
      }

      final updatedPersonnel = [
        for (final person in personnel)
          if (!bucaSubtreeIds.contains(person.institutionId))
            person
          else
            (() {
              final institution = institutionById[person.institutionId];
              final newPath = institution == null
                  ? person.institutionName
                  : Institution.pathLabel(updatedInstitutions, institution);
              if (person.workType == Personnel.guestWorkType) {
                return person.copyWith(institutionName: newPath);
              }
              final definition = definitionFor(person);
              final sequence = definition.slots
                  .map((slot) => slot.label)
                  .toList();
              final currentShift = sequence.contains(person.shift)
                  ? person.shift
                  : sequence.first;
              return person.copyWith(
                institutionName: newPath,
                shift: currentShift,
                shiftDefinitionId: definition.id,
                customShiftSequence: sequence,
                shiftDirection:
                    definition.changeDirection == ShiftDefinition.forward
                    ? Personnel.shiftForward
                    : Personnel.shiftBackward,
              );
            })(),
      ];

      await InstitutionStorage.saveAll(updatedInstitutions);
      await PersonnelStorage.saveAll(updatedPersonnel);
      if (!mounted) return;
      setState(() => _institutions = updatedInstitutions);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${bucaRecords.length} BUCA kaydı ve ${affected.length} personel güncellendi.',
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Taşıma tamamlanamadı: $error')));
    }
  }

  Future<void> _openEditor({
    Institution? institution,
    Institution? parent,
  }) async {
    final result = await showDialog<Institution>(
      context: context,
      builder: (_) =>
          _InstitutionDialog(institution: institution, parent: parent),
    );
    if (result == null) return;
    final updated = [
      for (final item in _institutions)
        if (item.id != result.id) item,
      result,
    ];
    try {
      await InstitutionStorage.saveAll(updated);
      if (mounted) setState(() => _institutions = updated);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Kayıt kaydedilemedi: $error')));
    }
  }

  Future<void> _delete(Institution institution) async {
    final hasChildren = _institutions.any(
      (item) => item.parentId == institution.id,
    );
    if (hasChildren) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Önce bu kaydın alt kayıtlarını silin.')),
      );
      return;
    }
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Kayıt silinsin mi?'),
        content: Text('${institution.name} kaydı silinecek.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
            child: const Text('SİL'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    final updated = _institutions
        .where((item) => item.id != institution.id)
        .toList();
    await InstitutionStorage.saveAll(updated);
    if (mounted) setState(() => _institutions = updated);
  }

  Future<void> _movePersonnelTo(Institution target) async {
    final sources = _institutions
        .where((item) => item.id != target.id)
        .toList();
    if (sources.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kaynak olarak seçilebilecek kurum yok.')),
      );
      return;
    }

    final source = await showDialog<Institution>(
      context: context,
      builder: (context) {
        Institution? selected;
        return StatefulBuilder(
          builder: (context, setDialogState) => AlertDialog(
            title: const Text('Personelleri Buraya Taşı'),
            content: SizedBox(
              width: 430,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Hedef: ${Institution.pathLabel(_institutions, target)}',
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<Institution>(
                    initialValue: selected,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Kaynak kurum',
                      border: OutlineInputBorder(),
                    ),
                    items: sources
                        .map(
                          (item) => DropdownMenuItem(
                            value: item,
                            child: Text(
                              Institution.pathLabel(_institutions, item),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )
                        .toList(),
                    onChanged: (value) =>
                        setDialogState(() => selected = value),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('VAZGEÇ'),
              ),
              FilledButton(
                onPressed: selected == null
                    ? null
                    : () => Navigator.pop(context, selected),
                child: const Text('DEVAM ET'),
              ),
            ],
          ),
        );
      },
    );
    if (source == null || !mounted) return;

    final personnel = await PersonnelStorage.readAll();
    final matching = personnel
        .where((person) => person.institutionId == source.id)
        .toList();
    if (!mounted) return;
    if (matching.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${source.name} kaydında personel bulunamadı.')),
      );
      return;
    }

    final targetLabel = Institution.pathLabel(_institutions, target);
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Toplu taşıma onayı'),
        content: Text(
          '${matching.length} personel\n\n'
          '${Institution.pathLabel(_institutions, source)}\n'
          'kaydından\n\n$targetLabel\n'
          'kaydına taşınacak.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('PERSONELLERİ TAŞI'),
          ),
        ],
      ),
    );
    if (approved != true) return;

    try {
      for (final person in matching) {
        await PersonnelStorage.saveOne(
          person.copyWith(
            institutionId: target.id,
            institutionName: targetLabel,
          ),
        );
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${matching.length} personel başarıyla taşındı.'),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Personeller taşınamadı: $error')));
    }
  }

  List<({Institution item, int depth})> get _treeItems {
    final result = <({Institution item, int depth})>[];
    final visited = <String>{};

    void addBranch(Institution item, int depth) {
      if (!visited.add(item.id)) return;
      result.add((item: item, depth: depth));
      for (final child in Institution.childrenOf(_institutions, item.id)) {
        addBranch(child, depth + 1);
      }
    }

    for (final root in Institution.childrenOf(_institutions, null)) {
      addBranch(root, 0);
    }
    // Üst kaydı daha önce silinmiş eski verileri de görünür tutar.
    for (final item in _institutions) {
      if (!visited.contains(item.id)) addBranch(item, 0);
    }
    return result;
  }

  @override
  Widget build(BuildContext context) {
    final treeItems = _treeItems;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kurumlar'),
        actions: [
          IconButton(
            onPressed: _migrateBucaToAnatolia,
            tooltip: 'BUCA kayıtlarını ANATOLIA’ya taşı',
            icon: const Icon(Icons.drive_file_move_outline),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(),
        icon: const Icon(Icons.add_business_rounded),
        label: const Text('Kurum Ekle'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : treeItems.isEmpty
          ? const Center(child: Text('Henüz kurum kaydı yok.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
              itemCount: treeItems.length,
              itemBuilder: (context, index) {
                final entry = treeItems[index];
                final institution = entry.item;
                final childCount = _institutions
                    .where((item) => item.parentId == institution.id)
                    .length;
                return Padding(
                  padding: EdgeInsets.only(left: entry.depth * 20.0),
                  child: Card(
                    color: institution.active ? null : Colors.grey.shade200,
                    child: ListTile(
                      leading: Icon(
                        entry.depth == 0
                            ? institution.type == 'Okul'
                                  ? Icons.school_rounded
                                  : Icons.factory_rounded
                            : Icons.account_tree_rounded,
                      ),
                      title: Text(
                        institution.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      subtitle: Text(
                        entry.depth == 0
                            ? '${institution.type}${childCount == 0 ? '' : ' • $childCount bölge'}'
                                  '\n${institution.hasLocation ? 'Konum kayıtlı' : 'Konum eklenmedi'}'
                            : entry.depth == 1
                            ? 'Bölge${childCount == 0 ? '' : ' • $childCount takım'}'
                            : entry.depth == 2
                            ? 'Takım'
                            : 'Alt kayıt',
                      ),
                      onTap: () => _openEditor(institution: institution),
                      trailing: Wrap(
                        spacing: 0,
                        children: [
                          IconButton(
                            onPressed: () => _openEditor(parent: institution),
                            icon: const Icon(Icons.add_rounded),
                            tooltip: institution.isRoot
                                ? 'Bölge ekle'
                                : 'Takım ekle',
                          ),
                          PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'edit') {
                                _openEditor(institution: institution);
                              } else if (value == 'movePersonnel') {
                                _movePersonnelTo(institution);
                              } else if (value == 'delete') {
                                _delete(institution);
                              }
                            },
                            itemBuilder: (_) => const [
                              PopupMenuItem(
                                value: 'edit',
                                child: Text('Düzenle'),
                              ),
                              PopupMenuItem(
                                value: 'movePersonnel',
                                child: Text('Personelleri buraya taşı'),
                              ),
                              PopupMenuItem(
                                value: 'delete',
                                child: Text('Sil'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class _InstitutionDialog extends StatefulWidget {
  const _InstitutionDialog({this.institution, this.parent});

  final Institution? institution;
  final Institution? parent;

  @override
  State<_InstitutionDialog> createState() => _InstitutionDialogState();
}

class _InstitutionDialogState extends State<_InstitutionDialog> {
  static const _defaultMapLocation = LatLng(38.461926, 27.189566);

  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late String _type;
  late bool _active;
  LatLng? _location;
  bool _gettingLocation = false;

  bool get _isSubRecord =>
      widget.parent != null || widget.institution?.isRoot == false;

  String get _newRecordKind {
    final parent = widget.parent;
    if (parent == null) return 'Kurum';
    final name = parent.name.toLowerCase();
    if (parent.isRoot ||
        name.contains('vardiya') ||
        name.contains('memur') ||
        name.contains('güvenlik')) {
      return 'Bölge';
    }
    return 'Takım';
  }

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.institution?.name);
    _type =
        widget.institution?.type ??
        widget.parent?.type ??
        Institution.types.first;
    _active = widget.institution?.active ?? true;
    final institution = widget.institution;
    if (institution?.hasLocation == true) {
      _location = LatLng(institution!.latitude!, institution.longitude!);
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.pop(
      context,
      Institution(
        id:
            widget.institution?.id ??
            DateTime.now().microsecondsSinceEpoch.toString(),
        name: _nameController.text.trim(),
        type: _type,
        parentId: widget.institution?.parentId ?? widget.parent?.id,
        active: _active,
        latitude: _isSubRecord ? null : _location?.latitude,
        longitude: _isSubRecord ? null : _location?.longitude,
      ),
    );
  }

  Future<void> _chooseOnMap() async {
    final selected = await Navigator.of(context).push<LatLng>(
      MaterialPageRoute(
        builder: (_) => MapPickerScreen(
          initialLocation: _location ?? _defaultMapLocation,
          selectedLocation: _location,
          title: 'Haritadan Kurum Konumu Seç',
        ),
      ),
    );
    if (selected != null && mounted) setState(() => _location = selected);
  }

  Future<void> _useCurrentLocation() async {
    if (_gettingLocation) return;
    if (!await Geolocator.isLocationServiceEnabled()) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Telefonun konum hizmetini açın.')),
      );
      return;
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Konum izni verilmedi.')),
      );
      return;
    }

    setState(() => _gettingLocation = true);
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      if (!mounted) return;
      setState(
        () => _location = LatLng(position.latitude, position.longitude),
      );
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mevcut konum alınamadı.')),
      );
    } finally {
      if (mounted) setState(() => _gettingLocation = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final parentName = widget.parent?.name;
    return AlertDialog(
      title: Text(
        widget.institution != null
            ? 'Kaydı Düzenle'
            : _isSubRecord
            ? '$_newRecordKind Ekle'
            : 'Kurum Ekle',
      ),
      content: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (parentName != null) ...[
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.account_tree_rounded),
                  title: const Text('Üst kayıt'),
                  subtitle: Text(parentName),
                ),
                const SizedBox(height: 4),
              ],
              TextFormField(
                controller: _nameController,
                autofocus: true,
                textCapitalization: TextCapitalization.words,
                decoration: InputDecoration(
                  labelText: _isSubRecord
                      ? '$_newRecordKind adı'
                      : 'Kurum adı',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Kayıt adını girin.'
                    : null,
              ),
              if (!_isSubRecord) ...[
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  initialValue: _type,
                  decoration: const InputDecoration(
                    labelText: 'Kurum türü',
                    border: OutlineInputBorder(),
                  ),
                  items: Institution.types
                      .map(
                        (type) =>
                            DropdownMenuItem(value: type, child: Text(type)),
                      )
                      .toList(),
                  onChanged: (value) => setState(() => _type = value ?? _type),
                ),
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Kurum Konumu',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _gettingLocation ? null : _useCurrentLocation,
                    icon: _gettingLocation
                        ? const SizedBox.square(
                            dimension: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.my_location_rounded),
                    label: Text(
                      _gettingLocation
                          ? 'KONUM ALINIYOR...'
                          : 'MEVCUT GPS KONUMU',
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _gettingLocation ? null : _chooseOnMap,
                    icon: const Icon(Icons.map_rounded),
                    label: const Text('HARİTADAN SEÇ'),
                  ),
                ),
                const SizedBox(height: 8),
                if (_location == null)
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text('Kurum konumu henüz eklenmedi.'),
                  )
                else
                  Row(
                    children: [
                      const Icon(
                        Icons.location_on_rounded,
                        color: Colors.green,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          '${_location!.latitude.toStringAsFixed(5)}, '
                          '${_location!.longitude.toStringAsFixed(5)}',
                        ),
                      ),
                      IconButton(
                        onPressed: () => setState(() => _location = null),
                        tooltip: 'Konumu sil',
                        icon: const Icon(Icons.delete_outline_rounded),
                      ),
                    ],
                  ),
              ],
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Aktif'),
                value: _active,
                onChanged: (value) => setState(() => _active = value),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('VAZGEÇ'),
        ),
        FilledButton(onPressed: _save, child: const Text('KAYDET')),
      ],
    );
  }
}
