class Stop {
  const Stop({
    required this.id,
    required this.name,
    required this.order,
    required this.latitude,
    required this.longitude,
    required this.note,
    this.institutionId = '',
    this.institutionName = '',
  });

  final String id;
  final String name;
  final int order;
  final double latitude;
  final double longitude;
  final String note;
  final String institutionId;
  final String institutionName;

  bool get hasLocation =>
      latitude >= -90 &&
      latitude <= 90 &&
      longitude >= -180 &&
      longitude <= 180 &&
      !(latitude == 0 && longitude == 0);

  Stop copyWith({int? order, String? institutionId, String? institutionName}) =>
      Stop(
        id: id,
        name: name,
        order: order ?? this.order,
        latitude: latitude,
        longitude: longitude,
        note: note,
        institutionId: institutionId ?? this.institutionId,
        institutionName: institutionName ?? this.institutionName,
      );

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'order': order,
    'latitude': latitude,
    'longitude': longitude,
    'note': note,
    'institutionId': institutionId,
    'institutionName': institutionName,
  };

  factory Stop.fromJson(Map<String, dynamic> json) => Stop(
    id: json['id'] as String,
    name: json['name'] as String,
    order: json['order'] as int,
    latitude: (json['latitude'] as num).toDouble(),
    longitude: (json['longitude'] as num).toDouble(),
    note: json['note'] as String? ?? '',
    institutionId: json['institutionId'] as String? ?? '',
    institutionName: json['institutionName'] as String? ?? '',
  );
}
