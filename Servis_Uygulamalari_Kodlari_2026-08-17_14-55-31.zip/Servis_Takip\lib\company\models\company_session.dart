class CompanySession {
  const CompanySession({
    required this.userId,
    required this.companyId,
    required this.companyName,
    required this.displayName,
    required this.role,
    required this.permissions,
    required this.allowedInstitutionIds,
    required this.allInstitutions,
    required this.allowedVehicleIds,
    required this.allVehicles,
    this.emergencyMode = false,
  });

  final String userId;
  final String companyId;
  final String companyName;
  final String displayName;
  final String role;
  final Map<String, bool> permissions;
  final List<String> allowedInstitutionIds;
  final bool allInstitutions;
  final List<String> allowedVehicleIds;
  final bool allVehicles;
  final bool emergencyMode;

  Map<String, dynamic> toJson() => {
    'userId': userId,
    'companyId': companyId,
    'companyName': companyName,
    'displayName': displayName,
    'role': role,
    'permissions': permissions,
    'allowedInstitutionIds': allowedInstitutionIds,
    'allInstitutions': allInstitutions,
    'allowedVehicleIds': allowedVehicleIds,
    'allVehicles': allVehicles,
    'emergencyMode': emergencyMode,
  };

  factory CompanySession.fromJson(Map<String, dynamic> json) {
    return CompanySession(
      userId: json['userId'] as String? ?? '',
      companyId: json['companyId'] as String? ?? '',
      companyName: json['companyName'] as String? ?? 'Şirket',
      displayName: json['displayName'] as String? ?? 'Kullanıcı',
      role: json['role'] as String? ?? 'driver',
      permissions: (json['permissions'] as Map<String, dynamic>? ?? const {})
          .map((key, value) => MapEntry(key, value == true)),
      allowedInstitutionIds:
          (json['allowedInstitutionIds'] as List<dynamic>? ?? const [])
              .map((value) => value.toString())
              .toList(),
      allInstitutions: json['allInstitutions'] as bool? ?? true,
      allowedVehicleIds:
          (json['allowedVehicleIds'] as List<dynamic>? ?? const [])
              .map((value) => value.toString())
              .toList(),
      allVehicles: json['allVehicles'] as bool? ?? true,
      emergencyMode: json['emergencyMode'] as bool? ?? false,
    );
  }

  bool get isOwner =>
      role == 'system_admin' || role == 'company_admin' || role == 'owner';

  bool permission(String key) => isOwner || permissions[key] == true;

  bool get canManageSettings => permission('canViewSettings');
}
