import 'package:flutter/material.dart';

import '../widgets/turkish_flag_placeholder.dart';
import 'pin_entry_screen.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF082A52);

    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Positioned(
              top: 4,
              right: 20,
              child: Text(
                'Designed by\nMustafa ER',
                textAlign: TextAlign.right,
                style: TextStyle(
                  color: Color(0xFF52657B),
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
              child: Column(
                children: [
              const Spacer(flex: 2),
              const TurkishFlagPlaceholder(),
              const SizedBox(height: 32),
              const Icon(Icons.directions_bus_rounded, size: 76, color: navy),
              const SizedBox(height: 18),
              Text(
                'Servis Takip v1.1',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  color: navy,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Doğru kişi, doğru durak, doğru zaman.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  color: const Color(0xFF40546C),
                ),
              ),
              const Spacer(flex: 3),
              SizedBox(
                width: double.infinity,
                height: 56,
                child: FilledButton.icon(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const PinEntryScreen(),
                      ),
                    );
                  },
                  icon: const Icon(Icons.lock_outline_rounded),
                  label: const Text('GİRİŞ YAP'),
                  style: FilledButton.styleFrom(
                    backgroundColor: navy,
                    textStyle: const TextStyle(
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.6,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              const Text(
                'Personel ve vardiya yönetim sistemi',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF718196)),
              ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
