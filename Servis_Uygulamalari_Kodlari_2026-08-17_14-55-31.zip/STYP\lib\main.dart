import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:url_launcher/url_launcher.dart';

import 'admin/screens/admin_dashboard_screen.dart';
import 'admin/screens/phone_permissions_screen.dart';
import 'admin/services/admin_repository.dart';
import 'screens/sales_packages_screen.dart';

const _imagePickerChannel = MethodChannel('com.servistakip.stty/image_picker');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: 'AIzaSyC8A2tkpS8N2a-UW_SeqxKJlq2MPjgtEes',
      appId: '1:974943205540:android:2d3ba2d556f3f686e5ce31',
      messagingSenderId: '974943205540',
      projectId: 'servis-takip-bulut',
      storageBucket: 'servis-takip-bulut.firebasestorage.app',
    ),
  );
  runApp(const SttyApp());
}

const _storage = FlutterSecureStorage();
const _ibanStorageKey = 'stty_payment_accounts';
const _authorityStorageKey = 'stty_collection_authorities';
const _campaignStorageKey = 'stty_campaigns';

Future<void> syncSelectedSettingsToFirebase() async {
  final ibanRaw = await _storage.read(key: _ibanStorageKey);
  final authorityRaw = await _storage.read(key: _authorityStorageKey);
  final campaignRaw = await _storage.read(key: _campaignStorageKey);

  final updates = <String, Object?>{};

  // Yeni bir telefonda yerel kayıtlar henüz oluşmamış olabilir. Bu durumda
  // Firebase'deki mevcut ortak ayarları boş listelerle ezme.
  if (campaignRaw != null) {
    final campaigns = (jsonDecode(campaignRaw) as List<dynamic>)
        .map(
          (item) => Campaign.fromJson(Map<String, dynamic>.from(item as Map)),
        )
        .toList();
    final activeCampaigns = campaigns
        .where((item) => item.days > 0 && item.price > 0)
        .toList();
    updates['campaigns'] = [
      for (var index = 0; index < activeCampaigns.length; index++)
        {
          'id': activeCampaigns[index].id,
          'title': activeCampaigns[index].title,
          'days': activeCampaigns[index].days,
          'price': activeCampaigns[index].price,
          'userLimit': activeCampaigns[index].userLimit,
          'description': activeCampaigns[index].description,
          'imageBase64': activeCampaigns[index].imageBase64,
          'active': true,
          'sortOrder': index,
          'groupTitle': activeCampaigns[index].groupTitle,
        },
    ];
  }

  if (ibanRaw != null) {
    final ibans = (jsonDecode(ibanRaw) as List<dynamic>)
        .map(
          (item) => IbanRecord.fromJson(Map<String, dynamic>.from(item as Map)),
        )
        .toList();
    final selectedIbans = ibans.where((item) => item.checked).toList();
    if (selectedIbans.isEmpty && ibans.isNotEmpty) {
      selectedIbans.add(ibans.first);
    }
    final selectedIban = selectedIbans.firstOrNull;
    updates['ibans'] = [
      for (final iban in ibans)
        {
          'id': iban.id,
          'title': iban.title,
          'recipientName': iban.recipient,
          'iban': iban.iban,
          'whatsApp': iban.whatsApp,
          'checked': selectedIbans.any((item) => item.id == iban.id),
        },
    ];
    updates['selectedIbans'] = [
      for (final iban in selectedIbans)
        {
          'id': iban.id,
          'title': iban.title,
          'recipientName': iban.recipient,
          'iban': iban.iban,
        },
    ];
    updates['selectedIban'] = selectedIban == null
        ? <String, Object?>{}
        : {
            'id': selectedIban.id,
            'title': selectedIban.title,
            'recipientName': selectedIban.recipient,
            'iban': selectedIban.iban,
          };
  }

  if (authorityRaw != null) {
    final authorities = (jsonDecode(authorityRaw) as List<dynamic>)
        .map(
          (item) => CollectionAuthority.fromJson(
            Map<String, dynamic>.from(item as Map),
          ),
        )
        .toList();
    final selectedAuthorities = authorities
        .where((item) => item.checked)
        .toList();
    if (selectedAuthorities.isEmpty && authorities.isNotEmpty) {
      selectedAuthorities.add(authorities.first);
    }
    final selectedAuthority = selectedAuthorities.firstOrNull;
    updates['collectionAuthorities'] = [
      for (final authority in authorities)
        {
          'id': authority.id,
          'name': authority.fullName,
          'phone': authority.phone,
          'checked': selectedAuthorities.any((item) => item.id == authority.id),
        },
    ];
    updates['collectionContacts'] = [
      for (final authority in selectedAuthorities)
        {
          'id': authority.id,
          'name': authority.fullName,
          'phone': authority.phone,
        },
    ];
    updates['collectionContact'] = selectedAuthority == null
        ? <String, Object?>{}
        : {
            'id': selectedAuthority.id,
            'name': selectedAuthority.fullName,
            'phone': selectedAuthority.phone,
          };
  }

  if (updates.isEmpty) return;
  updates['updatedBy'] = FirebaseAuth.instance.currentUser?.uid;
  updates['updatedAt'] = FieldValue.serverTimestamp();
  await FirebaseFirestore.instance
      .collection('systemSettings')
      .doc('temporaryDriverInvitation')
      .set(updates, SetOptions(merge: true));
}

class SttyApp extends StatelessWidget {
  const SttyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'STYP - Servis Takip Yönetici Paneli',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B87)),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
      ),
      home: const SttyAuthGate(),
    );
  }
}

class SttyAuthGate extends StatelessWidget {
  const SttyAuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        return snapshot.data == null
            ? const SttyLoginScreen()
            : const MainMenuScreen();
      },
    );
  }
}

class SttyLoginScreen extends StatefulWidget {
  const SttyLoginScreen({super.key});

  @override
  State<SttyLoginScreen> createState() => _SttyLoginScreenState();
}

class _SttyLoginScreenState extends State<SttyLoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _loading = false;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    if (_email.text.trim().isEmpty || _password.text.isEmpty || _loading) {
      return;
    }
    setState(() => _loading = true);
    try {
      final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email.text.trim(),
        password: _password.text,
      );
      final profile = await FirebaseFirestore.instance
          .collection('users')
          .doc(credential.user!.uid)
          .get();
      if (profile.data()?['role'] != 'system_admin') {
        await FirebaseAuth.instance.signOut();
        throw StateError('Bu hesap sistem yöneticisi değil.');
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Giriş yapılamadı: $error')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('STYP Yönetici Girişi')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          TextField(
            controller: _email,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(labelText: 'Yönetici E-postası'),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _password,
            obscureText: true,
            decoration: const InputDecoration(labelText: 'Şifre'),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _loading ? null : _login,
            child: _loading
                ? const SizedBox.square(
                    dimension: 22,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Text('GİRİŞ YAP'),
          ),
        ],
      ),
    );
  }
}

class MainMenuScreen extends StatefulWidget {
  const MainMenuScreen({super.key});

  @override
  State<MainMenuScreen> createState() => _MainMenuScreenState();
}

class _MainMenuScreenState extends State<MainMenuScreen> {
  bool _syncing = false;

  Future<void> _sync({bool showResult = true}) async {
    if (_syncing) return;
    setState(() => _syncing = true);
    try {
      await syncSelectedSettingsToFirebase();
      if (!mounted || !showResult) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Seçimler Firebase ile eşitlendi.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Firebase eşitlemesi yapılamadı: $error')),
      );
    } finally {
      if (mounted) setState(() => _syncing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('STYP', style: TextStyle(fontWeight: FontWeight.w900)),
            Text(
              'Servis Takip Yönetici Paneli',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: _syncing ? null : _sync,
            tooltip: 'Firebase ile eşitle',
            icon: _syncing
                ? const SizedBox.square(
                    dimension: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.cloud_sync_rounded),
          ),
          IconButton(
            onPressed: FirebaseAuth.instance.signOut,
            tooltip: 'Çıkış yap',
            icon: const Icon(Icons.logout_rounded),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _ManagementSummary(),
          const SizedBox(height: 18),
          const Text(
            'Hızlı İşlemler',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => AdminDashboardScreen(
                        repository: AdminRepository(),
                        openCreateOnStart: true,
                      ),
                    ),
                  ),
                  icon: const Icon(Icons.add_business_rounded),
                  label: const Text('YENİ ŞİRKET'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton.tonalIcon(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute<void>(
                      builder: (_) => const PendingApprovalsScreen(),
                    ),
                  ),
                  icon: const Icon(Icons.pending_actions_rounded),
                  label: const Text('BEKLEYENLER'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 22),
          const Text(
            'Yönetim Bölümleri',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 8),
          _sectionCard(
            icon: Icons.business_center_rounded,
            color: const Color(0xFFDCEBFF),
            title: 'Şirket Yönetimi',
            subtitle: 'Şirketler, kullanıcılar, paket ve süre işlemleri',
            screen: _companyManagementScreen(),
          ),
          _sectionCard(
            icon: Icons.sell_rounded,
            color: const Color(0xFFDDF5E8),
            title: 'Satış ve Paketler',
            subtitle: 'Paketler, kampanyalar, ödemeler ve IBAN',
            screen: _salesManagementScreen(),
          ),
          _sectionCard(
            icon: Icons.admin_panel_settings_rounded,
            color: const Color(0xFFFFE8B0),
            title: 'Yetkilendirmeler',
            subtitle: 'Telefon, tahsilat ve yönetici yetkileri',
            screen: const AuthorizationsScreen(),
          ),
          _sectionCard(
            icon: Icons.settings_suggest_rounded,
            color: const Color(0xFFE8E3F8),
            title: 'Sistem Yönetimi',
            subtitle: 'Uygulama bağlantısı ve Firebase eşitleme',
            screen: _systemManagementScreen(),
          ),
        ],
      ),
    );
  }

  Widget _sectionCard({
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    required Widget screen,
  }) => Card(
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
      leading: CircleAvatar(backgroundColor: color, child: Icon(icon)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w900)),
      subtitle: Text(subtitle),
      trailing: const Icon(Icons.chevron_right_rounded),
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => screen),
      ),
    ),
  );

  Widget _companyManagementScreen() => _MenuSectionScreen(
    title: 'Şirket Yönetimi',
    destinations: [
      _MenuDestination(
        icon: Icons.business_rounded,
        title: 'Şirketler ve Kullanıcılar',
        subtitle: 'Şirket ekle, paket ata, süre ve kullanıcıları yönet',
        builder: (_) => AdminDashboardScreen(repository: AdminRepository()),
      ),
    ],
  );

  Widget _salesManagementScreen() => const _MenuSectionScreen(
    title: 'Satış ve Paketler',
    destinations: [
      _MenuDestination(
        icon: Icons.fact_check_rounded,
        title: 'Ödeme ve Onay İşlemleri',
        subtitle: 'Bekleyen ve tamamlanan talepler',
        builder: _pendingBuilder,
      ),
      _MenuDestination(
        icon: Icons.workspace_premium_rounded,
        title: 'Satış Paketleri',
        subtitle: 'Ücretsiz, Standart ve Profesyonel paketler',
        builder: _packagesBuilder,
      ),
      _MenuDestination(
        icon: Icons.campaign_rounded,
        title: 'Kampanyalar',
        subtitle: 'Kampanyaları ekle ve düzenle',
        builder: _campaignBuilder,
      ),
      _MenuDestination(
        icon: Icons.account_balance_rounded,
        title: 'IBAN Girişi',
        subtitle: 'Ödeme hesaplarını yönet',
        builder: _ibanBuilder,
      ),
    ],
  );

  Widget _systemManagementScreen() => _MenuSectionScreen(
    title: 'Sistem Yönetimi',
    destinations: [
      const _MenuDestination(
        icon: Icons.link_rounded,
        title: 'Uygulama Bağlantısı',
        subtitle: 'İndirme ve güncelleme bağlantısını yönet',
        builder: _distributionBuilder,
      ),
      _MenuDestination(
        icon: Icons.cloud_sync_rounded,
        title: 'Firebase ile Eşitle',
        subtitle: 'Seçili ortak ayarları buluta gönder',
        onTap: () => _sync(),
      ),
    ],
  );
}

Widget _pendingBuilder(BuildContext context) => const PendingApprovalsScreen();
Widget _packagesBuilder(BuildContext context) => const SalesPackagesScreen();
Widget _campaignBuilder(BuildContext context) => const CampaignScreen();
Widget _ibanBuilder(BuildContext context) => const IbanScreen();
Widget _distributionBuilder(BuildContext context) =>
    const AppDistributionSettingsScreen();

class _ManagementSummary extends StatelessWidget {
  const _ManagementSummary();

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('companies').snapshots(),
      builder: (context, companiesSnapshot) {
        final companies = companiesSnapshot.data?.docs ?? const [];
        final active = companies
            .where((doc) => doc.data()['active'] == true)
            .length;
        final limit = DateTime.now().add(const Duration(days: 30));
        final expiring = companies.where((doc) {
          if (doc.data()['deletedAt'] != null) return false;
          final expiresAt = doc.data()['expiresAt'];
          if (expiresAt is! Timestamp) return false;
          final date = expiresAt.toDate();
          return date.isAfter(DateTime.now()) && date.isBefore(limit);
        }).length;
        return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance
              .collection('paymentApprovalRequests')
              .where('status', isEqualTo: 'pending')
              .snapshots(),
          builder: (context, approvalsSnapshot) {
            final pending = approvalsSnapshot.data?.docs.length ?? 0;
            return Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF0B376A), Color(0xFF175A9E)],
                ),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Yönetim Özeti',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 21,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: _MetricCard(
                          value: '$active',
                          label: 'Aktif Şirket',
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _MetricCard(
                          value: '$pending',
                          label: 'Bekleyen Onay',
                          alert: pending > 0,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: _MetricCard(
                          value: '$expiring',
                          label: 'Süresi Yaklaşan',
                          alert: expiring > 0,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.value,
    required this.label,
    this.alert = false,
  });

  final String value;
  final String label;
  final bool alert;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 11),
    decoration: BoxDecoration(
      color: alert
          ? const Color(0xFFFFE1B7)
          : Colors.white.withValues(alpha: 0.14),
      borderRadius: BorderRadius.circular(12),
    ),
    child: Column(
      children: [
        Text(
          value,
          style: TextStyle(
            color: alert ? const Color(0xFF8B3E00) : Colors.white,
            fontSize: 23,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          label,
          textAlign: TextAlign.center,
          maxLines: 2,
          style: TextStyle(
            color: alert ? const Color(0xFF693000) : Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    ),
  );
}

class _MenuDestination {
  const _MenuDestination({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.builder,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final WidgetBuilder? builder;
  final VoidCallback? onTap;
}

class _MenuSectionScreen extends StatelessWidget {
  const _MenuSectionScreen({required this.title, required this.destinations});

  final String title;
  final List<_MenuDestination> destinations;

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: destinations.length,
      separatorBuilder: (_, _) => const SizedBox(height: 5),
      itemBuilder: (context, index) {
        final item = destinations[index];
        return Card(
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 7,
            ),
            leading: CircleAvatar(child: Icon(item.icon)),
            title: Text(
              item.title,
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
            subtitle: Text(item.subtitle),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap:
                item.onTap ??
                () => Navigator.push(
                  context,
                  MaterialPageRoute<void>(builder: item.builder!),
                ),
          ),
        );
      },
    ),
  );
}

class AuthorizationsScreen extends StatelessWidget {
  const AuthorizationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Yetkilendirmeler')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.phone_android_rounded),
              ),
              title: const Text(
                'Telefon Yetkilendirmeleri',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: const Text(
                'Kullanıcıya özel tek telefon muafiyetlerini yönet',
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (_) =>
                      PhonePermissionsScreen(repository: AdminRepository()),
                ),
              ),
            ),
          ),
          Card(
            child: ListTile(
              leading: const CircleAvatar(
                child: Icon(Icons.verified_user_rounded),
              ),
              title: const Text(
                'Tahsilat Kontrol Yetkileri',
                style: TextStyle(fontWeight: FontWeight.w800),
              ),
              subtitle: const Text(
                'Tahsilat bildirimlerini kontrol edecek kişileri yönet',
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (_) => const CollectionAuthorityScreen(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class PaymentApprovalRequest {
  const PaymentApprovalRequest({
    required this.id,
    required this.companyId,
    required this.companyName,
    required this.requestedByName,
    required this.driverId,
    required this.driverName,
    required this.driverPhone,
    required this.campaignTitle,
    required this.campaignDays,
    required this.amount,
    required this.paymentCode,
    required this.companyCode,
    required this.loginName,
    required this.temporaryPassword,
    required this.createdAt,
    required this.status,
    required this.accessStartsAt,
    required this.accessEndsAt,
    required this.approvedAt,
    required this.accessEnabled,
  });

  final String id;
  final String companyId;
  final String companyName;
  final String requestedByName;
  final String driverId;
  final String driverName;
  final String driverPhone;
  final String campaignTitle;
  final int campaignDays;
  final num amount;
  final String paymentCode;
  final String companyCode;
  final String loginName;
  final String temporaryPassword;
  final DateTime? createdAt;
  final String status;
  final DateTime? accessStartsAt;
  final DateTime? accessEndsAt;
  final DateTime? approvedAt;
  final bool accessEnabled;

  bool get hasApproval =>
      status == 'approved' ||
      status == 'expired' ||
      approvedAt != null ||
      accessStartsAt != null ||
      accessEndsAt != null;
  bool get isPending => status == 'pending' && !hasApproval;
  bool get isExpired =>
      status == 'expired' ||
      (hasApproval &&
          accessEndsAt != null &&
          !accessEndsAt!.isAfter(DateTime.now()));
  bool get isActive => hasApproval && !isExpired;

  factory PaymentApprovalRequest.fromDocument(
    DocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data() ?? const <String, dynamic>{};
    return PaymentApprovalRequest(
      id: document.id,
      companyId: data['companyId']?.toString() ?? '',
      companyName: data['companyName']?.toString() ?? '',
      requestedByName: data['requestedByName']?.toString() ?? '',
      driverId: data['driverId']?.toString() ?? '',
      driverName: data['driverName']?.toString() ?? '',
      driverPhone: data['driverPhone']?.toString() ?? '',
      campaignTitle: data['campaignTitle']?.toString() ?? '',
      campaignDays: (data['campaignDays'] as num?)?.toInt() ?? 0,
      amount: data['amount'] as num? ?? 0,
      paymentCode: data['paymentCode']?.toString() ?? '',
      companyCode: data['companyCode']?.toString() ?? '',
      loginName: data['loginName']?.toString() ?? '',
      temporaryPassword: data['temporaryPassword']?.toString() ?? '',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate(),
      status: data['status']?.toString() ?? 'pending',
      accessStartsAt: (data['accessStartsAt'] as Timestamp?)?.toDate(),
      accessEndsAt: (data['accessEndsAt'] as Timestamp?)?.toDate(),
      approvedAt: (data['approvedAt'] as Timestamp?)?.toDate(),
      accessEnabled: data['accessActive'] as bool? ?? true,
    );
  }
}

enum _ApprovalCategory { pending, approved, expired }

class PendingApprovalsScreen extends StatelessWidget {
  const PendingApprovalsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Onay İşlemleri')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _approvalMenuCard(
            context,
            title: 'Onay Bekleyenler',
            subtitle: 'Henüz karar verilmemiş ödeme bildirimleri',
            icon: Icons.pending_actions_rounded,
            category: _ApprovalCategory.pending,
          ),
          _approvalMenuCard(
            context,
            title: 'Onaylananlar',
            subtitle: 'Kullanım süresi devam eden onaylı kayıtlar',
            icon: Icons.check_circle_rounded,
            category: _ApprovalCategory.approved,
          ),
          _approvalMenuCard(
            context,
            title: 'Onayı Bitenler',
            subtitle: 'Kullanım süresi sona eren kayıtlar',
            icon: Icons.timer_off_rounded,
            category: _ApprovalCategory.expired,
          ),
        ],
      ),
    );
  }

  Widget _approvalMenuCard(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required _ApprovalCategory category,
  }) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute<void>(
            builder: (_) =>
                _ApprovalListScreen(category: category, title: title),
          ),
        ),
      ),
    );
  }
}

class _ApprovalListScreen extends StatefulWidget {
  const _ApprovalListScreen({required this.category, required this.title});

  final _ApprovalCategory category;
  final String title;

  @override
  State<_ApprovalListScreen> createState() => _ApprovalListScreenState();
}

class _ApprovalListScreenState extends State<_ApprovalListScreen> {
  String? _processingId;
  final Set<String> _expiringIds = <String>{};
  final Set<String> _reconcilingIds = <String>{};
  final _searchController = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _normalizePhone(String value) {
    var digits = value.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.startsWith('0')) digits = '90${digits.substring(1)}';
    if (!digits.startsWith('90') && digits.length == 10) digits = '90$digits';
    return digits;
  }

  String _price(num value) => value == value.toInt()
      ? '${value.toInt()} TL'
      : '${value.toStringAsFixed(2)} TL';

  String _date(DateTime? value) {
    if (value == null) return 'Tarih bekleniyor';
    String two(int number) => number.toString().padLeft(2, '0');
    return '${two(value.day)}.${two(value.month)}.${value.year} '
        '${two(value.hour)}:${two(value.minute)}';
  }

  Future<String?> _installationUrl() async {
    final reference = FirebaseFirestore.instance
        .collection('systemSettings')
        .doc('appDistribution');
    final snapshot = await reference.get();
    final current = snapshot.data()?['installUrl']?.toString().trim() ?? '';
    return current.isEmpty ? null : current;
  }

  Future<void> _approve(PaymentApprovalRequest request) async {
    if (_processingId != null) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Ödeme onaylansın mı?'),
        content: Text(
          '${request.companyName}\n${request.driverName}\n'
          '${request.campaignTitle} — ${request.campaignDays} gün — ${_price(request.amount)}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('ONAYLA'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _processingId = request.id);
    try {
      final installUrl = await _installationUrl();
      if (installUrl == null) {
        throw StateError('Geçerli uygulama bağlantısı girilmedi.');
      }
      final now = DateTime.now();
      final expiresAt = now.add(Duration(days: request.campaignDays));
      final database = FirebaseFirestore.instance;
      final batch = database.batch();
      final approvalRef = database
          .collection('paymentApprovalRequests')
          .doc(request.id);
      final accessRef = database
          .collection('companies')
          .doc(request.companyId)
          .collection('temporaryAccess')
          .doc(request.driverId);
      batch.update(approvalRef, {
        'status': 'approved',
        'accessActive': true,
        'approvedAt': FieldValue.serverTimestamp(),
        'approvedBy': FirebaseAuth.instance.currentUser?.uid,
        'accessStartsAt': Timestamp.fromDate(now),
        'accessEndsAt': Timestamp.fromDate(expiresAt),
        'deviceBindingRequired': true,
        'maxDevices': 1,
        'deviceLimitMessage':
            'Bu kullanım yalnızca 1 telefonda kullanılabilir.',
        'installUrl': installUrl,
        'temporaryPassword': FieldValue.delete(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      batch.set(accessRef, {
        'active': true,
        'approvalRequestId': request.id,
        'driverId': request.driverId,
        'driverName': request.driverName,
        'campaignTitle': request.campaignTitle,
        'startsAt': Timestamp.fromDate(now),
        'endsAt': Timestamp.fromDate(expiresAt),
        'deviceBindingRequired': true,
        'maxDevices': 1,
        'deviceId': null,
        'deviceName': null,
        'deviceLimitMessage':
            'Bu kullanım yalnızca 1 telefonda kullanılabilir.',
        'approvedBy': FirebaseAuth.instance.currentUser?.uid,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      await batch.commit();

      final phone = _normalizePhone(request.driverPhone);
      final message =
          '''Merhaba ${request.driverName},

Servis Takip geçici kullanım davetiniz onaylandı.
Şirket: ${request.companyName}
Paket: ${request.campaignTitle}
Geçerlilik: ${request.campaignDays} gün
Başlama Tarihi: ${_date(now)}
Bitiş Tarihi: ${_date(expiresAt)}

Şirket Kodu: ${request.companyCode}
Kullanıcı İsmi: ${request.loginName}
Şifre: ${request.temporaryPassword}

Uygulamayı indirmek için:
$installUrl

Bu kullanım yalnızca ilk giriş yapılan telefonda çalışır.
Başka bir telefona kurulup kullanılamaz.

Ödeme kodu: ${request.paymentCode}''';
      final uri = Uri.parse(
        'https://wa.me/$phone?text=${Uri.encodeComponent(message)}',
      );
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        throw StateError('WhatsApp açılamadı. Onay kaydı tamamlandı.');
      }
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('İşlem tamamlanamadı: $error')));
    } finally {
      if (mounted) setState(() => _processingId = null);
    }
  }

  int _remainingDays(DateTime? endsAt) {
    if (endsAt == null) return 0;
    final difference = endsAt.difference(DateTime.now());
    if (difference.isNegative) return 0;
    return (difference.inMinutes / Duration.minutesPerDay).ceil();
  }

  Future<void> _extendAccess(PaymentApprovalRequest request) async {
    if (_processingId != null) return;
    final controller = TextEditingController(text: '7');
    final days = await showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Süre Uzatma'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'Eklenecek Gün Sayısı',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () {
              final value = int.tryParse(controller.text.trim());
              if (value == null || value <= 0) return;
              Navigator.pop(dialogContext, value);
            },
            child: const Text('UZAT'),
          ),
        ],
      ),
    );
    Future<void>.delayed(const Duration(milliseconds: 600), controller.dispose);
    if (days == null || !mounted) return;
    setState(() => _processingId = request.id);
    try {
      final now = DateTime.now();
      final currentEnd = request.accessEndsAt;
      final base = currentEnd != null && currentEnd.isAfter(now)
          ? currentEnd
          : now;
      final newEnd = base.add(Duration(days: days));
      final database = FirebaseFirestore.instance;
      final batch = database.batch();
      final approvalRef = database
          .collection('paymentApprovalRequests')
          .doc(request.id);
      final accessRef = database
          .collection('companies')
          .doc(request.companyId)
          .collection('temporaryAccess')
          .doc(request.driverId);
      batch.update(approvalRef, {
        'status': 'approved',
        'accessActive': true,
        'accessStartsAt': Timestamp.fromDate(request.accessStartsAt ?? now),
        'accessEndsAt': Timestamp.fromDate(newEnd),
        'extendedByDays': FieldValue.increment(days),
        'lastExtendedAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
      batch.set(accessRef, {
        'active': true,
        'startsAt': Timestamp.fromDate(request.accessStartsAt ?? now),
        'endsAt': Timestamp.fromDate(newEnd),
        'deviceBindingRequired': true,
        'maxDevices': 1,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      await batch.commit();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Kullanım süresi $days gün uzatıldı.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Süre uzatılamadı: $error')));
    } finally {
      if (mounted) setState(() => _processingId = null);
    }
  }

  Future<void> _reject(PaymentApprovalRequest request) async {
    if (_processingId != null) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Ödeme reddedilsin mi?'),
        content: Text(
          '${request.companyName} — ${request.driverName}\n\n'
          'Bu işlemden emin misiniz?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('EVET, REDDET'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _processingId = request.id);
    try {
      await FirebaseFirestore.instance
          .collection('paymentApprovalRequests')
          .doc(request.id)
          .update({
            'status': 'rejected',
            'rejectedAt': FieldValue.serverTimestamp(),
            'rejectedBy': FirebaseAuth.instance.currentUser?.uid,
            'updatedAt': FieldValue.serverTimestamp(),
          });
    } finally {
      if (mounted) setState(() => _processingId = null);
    }
  }

  Future<void> _toggleAccess(PaymentApprovalRequest request) async {
    if (_processingId != null) return;
    final enable = !request.accessEnabled;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(
          enable
              ? 'Kullanıcı aktifleştirilsin mi?'
              : 'Kullanıcı pasife alınsın mı?',
        ),
        content: Text(
          enable
              ? '${request.driverName} uygulamayı tekrar kullanabilecek.'
              : '${request.driverName} uygulamayı kullanamayacak.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: Text(enable ? 'AKTİFLEŞTİR' : 'PASİFE AL'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() => _processingId = request.id);
    try {
      final database = FirebaseFirestore.instance;
      final batch = database.batch();
      batch.update(
        database.collection('paymentApprovalRequests').doc(request.id),
        {'accessActive': enable, 'updatedAt': FieldValue.serverTimestamp()},
      );
      batch.set(
        database
            .collection('companies')
            .doc(request.companyId)
            .collection('temporaryAccess')
            .doc(request.driverId),
        {'active': enable, 'updatedAt': FieldValue.serverTimestamp()},
        SetOptions(merge: true),
      );
      await batch.commit();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            enable
                ? '${request.driverName} aktifleştirildi.'
                : '${request.driverName} pasife alındı.',
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Kullanım durumu değiştirilemedi: $error')),
      );
    } finally {
      if (mounted) setState(() => _processingId = null);
    }
  }

  Future<void> _markExpiredAccess(PaymentApprovalRequest request) async {
    if (!_expiringIds.add(request.id)) return;
    try {
      final database = FirebaseFirestore.instance;
      final batch = database.batch();
      batch.update(
        database.collection('paymentApprovalRequests').doc(request.id),
        {
          'status': 'expired',
          'accessActive': false,
          'expiredAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        },
      );
      batch.set(
        database
            .collection('companies')
            .doc(request.companyId)
            .collection('temporaryAccess')
            .doc(request.driverId),
        {
          'active': false,
          'expiredAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        },
        SetOptions(merge: true),
      );
      await batch.commit();
    } finally {
      _expiringIds.remove(request.id);
    }
  }

  Future<void> _reconcileLegacyApproval(PaymentApprovalRequest request) async {
    if (!_reconcilingIds.add(request.id)) return;
    try {
      final database = FirebaseFirestore.instance;
      final accessSnapshot = await database
          .collection('companies')
          .doc(request.companyId)
          .collection('temporaryAccess')
          .doc(request.driverId)
          .get();
      if (!accessSnapshot.exists) return;
      final data = accessSnapshot.data() ?? const <String, dynamic>{};
      final startsAt = data['startsAt'] as Timestamp?;
      final endsAt = data['endsAt'] as Timestamp?;
      if (startsAt == null && endsAt == null) return;
      await database
          .collection('paymentApprovalRequests')
          .doc(request.id)
          .update({
            'status': 'approved',
            if (startsAt != null) 'accessStartsAt': startsAt,
            if (endsAt != null) 'accessEndsAt': endsAt,
            'approvedAt': startsAt ?? FieldValue.serverTimestamp(),
            'updatedAt': FieldValue.serverTimestamp(),
          });
    } finally {
      _reconcilingIds.remove(request.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance
        .collection('paymentApprovalRequests')
        .snapshots();
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: stream,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Kayıtlar açılamadı:\n${snapshot.error}'),
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final requests =
              snapshot.data!.docs
                  .map(PaymentApprovalRequest.fromDocument)
                  .toList()
                ..sort(
                  (a, b) => (b.createdAt ?? DateTime(2000)).compareTo(
                    a.createdAt ?? DateTime(2000),
                  ),
                );
          final pending = requests.where((item) => item.isPending).toList();
          final active = requests.where((item) => item.isActive).toList();
          final expired = requests.where((item) => item.isExpired).toList();
          for (final item in pending) {
            WidgetsBinding.instance.addPostFrameCallback(
              (_) => _reconcileLegacyApproval(item),
            );
          }
          for (final item in expired.where(
            (request) => request.status == 'approved',
          )) {
            WidgetsBinding.instance.addPostFrameCallback(
              (_) => _markExpiredAccess(item),
            );
          }
          final categoryRecords = switch (widget.category) {
            _ApprovalCategory.pending => pending,
            _ApprovalCategory.approved => active,
            _ApprovalCategory.expired => expired,
          };
          final normalizedQuery = _query.trim().toLowerCase();
          final selected = normalizedQuery.isEmpty
              ? categoryRecords
              : categoryRecords
                    .where(
                      (item) =>
                          item.companyName.toLowerCase().contains(
                            normalizedQuery,
                          ) ||
                          item.driverName.toLowerCase().contains(
                            normalizedQuery,
                          ) ||
                          item.paymentCode.toLowerCase().contains(
                            normalizedQuery,
                          ) ||
                          item.campaignTitle.toLowerCase().contains(
                            normalizedQuery,
                          ),
                    )
                    .toList();
          final emptyText = switch (widget.category) {
            _ApprovalCategory.pending =>
              'Şu anda onay bekleyen ödeme bulunmuyor.',
            _ApprovalCategory.approved => 'Onaylanan kullanım bulunmuyor.',
            _ApprovalCategory.expired => 'Onayı biten kullanım bulunmuyor.',
          };
          return ListView(
            padding: const EdgeInsets.all(12),
            children: [
              TextField(
                controller: _searchController,
                onChanged: (value) => setState(() => _query = value),
                decoration: InputDecoration(
                  hintText: 'Firma, şoför, ödeme kodu veya paket ara',
                  prefixIcon: const Icon(Icons.search_rounded),
                  suffixIcon: _query.isEmpty
                      ? null
                      : IconButton(
                          onPressed: () {
                            _searchController.clear();
                            setState(() => _query = '');
                          },
                          icon: const Icon(Icons.clear_rounded),
                        ),
                  border: const OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              if (selected.isEmpty)
                _emptyCard(
                  normalizedQuery.isEmpty
                      ? emptyText
                      : 'Aramaya uygun kayıt bulunamadı.',
                )
              else
                ...selected.map((item) => _requestCard(item)),
              const SizedBox(height: 30),
            ],
          );
        },
      ),
    );
  }

  Widget _emptyCard(String text) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Text(text, style: const TextStyle(color: Color(0xFF52657B))),
    ),
  );

  Widget _requestCard(PaymentApprovalRequest item) {
    final busy = _processingId == item.id;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        title: Row(
          children: [
            Expanded(
              child: Text(
                item.companyName,
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                color: item.isPending
                    ? const Color(0xFFF59E0B)
                    : item.isExpired || !item.accessEnabled
                    ? const Color(0xFFB3261E)
                    : const Color(0xFF16A34A),
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 6),
            Text(
              item.isPending
                  ? 'Onay Bekliyor'
                  : item.isExpired
                  ? 'Onayı Bitti'
                  : item.accessEnabled
                  ? 'Kullanım Aktif'
                  : 'Kullanım Pasif',
              style: TextStyle(
                color: item.isPending
                    ? const Color(0xFFB45309)
                    : item.isExpired || !item.accessEnabled
                    ? const Color(0xFFB3261E)
                    : const Color(0xFF15803D),
                fontWeight: FontWeight.w800,
                fontSize: 12,
              ),
            ),
          ],
        ),
        subtitle: Text('Şoför: ${item.driverName}'),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        children: [
          const Divider(),
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Paketi seçen: ${item.requestedByName}'),
                Text('Paket: ${item.campaignTitle} — ${item.campaignDays} gün'),
                Text('Tutar: ${_price(item.amount)}'),
                Text('Ödeme kodu: ${item.paymentCode}'),
                Text('Bildirim: ${_date(item.createdAt)}'),
                if (!item.isPending) ...[
                  Text('Başlama: ${_date(item.accessStartsAt)}'),
                  Text('Bitiş: ${_date(item.accessEndsAt)}'),
                  Text('Kalan Gün: ${_remainingDays(item.accessEndsAt)}'),
                ],
                const SizedBox(height: 12),
                if (item.isPending)
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton(
                          onPressed: busy ? null : () => _reject(item),
                          child: const Text('REDDET'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: busy ? null : () => _approve(item),
                          icon: busy
                              ? const SizedBox.square(
                                  dimension: 18,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                  ),
                                )
                              : const Icon(Icons.check_circle_rounded),
                          label: const Text('ONAYLA'),
                        ),
                      ),
                    ],
                  )
                else
                  Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: null,
                              icon: const Icon(Icons.verified_rounded),
                              label: const Text('ONAYLANDI'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: OutlinedButton.icon(
                              onPressed: busy
                                  ? null
                                  : () => _extendAccess(item),
                              icon: const Icon(Icons.more_time_rounded),
                              label: const Text('SÜRE UZAT'),
                            ),
                          ),
                        ],
                      ),
                      if (!item.isExpired) ...[
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: busy ? null : () => _toggleAccess(item),
                            icon: Icon(
                              item.accessEnabled
                                  ? Icons.person_off_rounded
                                  : Icons.person_rounded,
                            ),
                            label: Text(
                              item.accessEnabled
                                  ? 'KULLANICIYI PASİFE AL'
                                  : 'KULLANICIYI AKTİFLEŞTİR',
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AppDistributionSettingsScreen extends StatefulWidget {
  const AppDistributionSettingsScreen({super.key});

  @override
  State<AppDistributionSettingsScreen> createState() =>
      _AppDistributionSettingsScreenState();
}

class _AppDistributionSettingsScreenState
    extends State<AppDistributionSettingsScreen> {
  final _controller = TextEditingController();
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final snapshot = await FirebaseFirestore.instance
        .collection('systemSettings')
        .doc('appDistribution')
        .get();
    _controller.text = snapshot.data()?['installUrl']?.toString() ?? '';
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _save() async {
    final value = _controller.text.trim();
    if (!value.startsWith('https://') || _saving) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Geçerli bir https bağlantısı girin.')),
      );
      return;
    }
    setState(() => _saving = true);
    try {
      await FirebaseFirestore.instance
          .collection('systemSettings')
          .doc('appDistribution')
          .set({
            'installUrl': value,
            'updatedBy': FirebaseAuth.instance.currentUser?.uid,
            'updatedAt': FieldValue.serverTimestamp(),
          }, SetOptions(merge: true));
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Uygulama bağlantısı kaydedildi.')),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Uygulama Bağlantısı')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(18),
              children: [
                const Text(
                  'Firebase App Distribution içindeki Davet Bağlantısını '
                  'veya daha sonra Google Play bağlantısını buraya kaydedin. '
                  'Onay sırasında bu bağlantı otomatik gönderilir.',
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: _controller,
                  keyboardType: TextInputType.url,
                  decoration: const InputDecoration(
                    labelText: 'Uygulama indirme bağlantısı',
                    hintText: 'https://...',
                    prefixIcon: Icon(Icons.link_rounded),
                  ),
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  icon: const Icon(Icons.save_rounded),
                  label: const Text('BAĞLANTIYI KAYDET'),
                ),
              ],
            ),
    );
  }
}

class IbanRecord {
  const IbanRecord({
    required this.id,
    required this.title,
    required this.recipient,
    required this.iban,
    required this.whatsApp,
    this.checked = false,
  });

  final String id;
  final String title;
  final String recipient;
  final String iban;
  final String whatsApp;
  final bool checked;

  IbanRecord copyWith({bool? checked}) => IbanRecord(
    id: id,
    title: title,
    recipient: recipient,
    iban: iban,
    whatsApp: whatsApp,
    checked: checked ?? this.checked,
  );

  Map<String, Object> toJson() => {
    'id': id,
    'title': title,
    'recipient': recipient,
    'iban': iban,
    'whatsApp': whatsApp,
    'checked': checked,
  };

  factory IbanRecord.fromJson(Map<String, dynamic> json) => IbanRecord(
    id: json['id'] as String? ?? '',
    title: json['title'] as String? ?? '',
    recipient: json['recipient'] as String? ?? '',
    iban: json['iban'] as String? ?? '',
    whatsApp: json['whatsApp'] as String? ?? '',
    checked: json['checked'] as bool? ?? json['active'] as bool? ?? false,
  );
}

class IbanScreen extends StatefulWidget {
  const IbanScreen({super.key});

  @override
  State<IbanScreen> createState() => _IbanScreenState();
}

class _IbanScreenState extends State<IbanScreen> {
  static const _key = _ibanStorageKey;
  List<IbanRecord> _records = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    var records = <IbanRecord>[];
    var loadedFromFirebase = false;
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('systemSettings')
          .doc('temporaryDriverInvitation')
          .get();
      final data = snapshot.data();
      final cloudIbans = data?['ibans'] as List?;
      final legacySelectedIbans = data?['selectedIbans'] as List?;
      if (data != null &&
          (data.containsKey('ibans') ||
              (legacySelectedIbans?.isNotEmpty ?? false))) {
        loadedFromFirebase = true;
        final source = cloudIbans ?? legacySelectedIbans;
        records = (source ?? const [])
            .whereType<Map>()
            .map((item) {
              final value = Map<String, dynamic>.from(item);
              return IbanRecord(
                id: value['id']?.toString() ?? '',
                title: value['title']?.toString() ?? '',
                recipient:
                    value['recipientName']?.toString() ??
                    value['recipient']?.toString() ??
                    '',
                iban: value['iban']?.toString() ?? '',
                whatsApp: value['whatsApp']?.toString() ?? '',
                checked: value['checked'] as bool? ?? true,
              );
            })
            .where((item) => item.id.isNotEmpty && item.iban.isNotEmpty)
            .toList();
      }
    } catch (_) {
      // Çevrimdışıyken son yerel kopya kullanılabilir.
    }
    if (!loadedFromFirebase) {
      final raw = await _storage.read(key: _key);
      records = raw == null
          ? <IbanRecord>[]
          : (jsonDecode(raw) as List<dynamic>)
                .map(
                  (item) => IbanRecord.fromJson(
                    Map<String, dynamic>.from(item as Map),
                  ),
                )
                .toList();
    } else {
      await _storage.write(
        key: _key,
        value: jsonEncode(records.map((item) => item.toJson()).toList()),
      );
    }
    if (!mounted) return;
    setState(() {
      _records = records;
      _loading = false;
    });
  }

  Future<void> _save(List<IbanRecord> records) async {
    await _storage.write(
      key: _key,
      value: jsonEncode(records.map((item) => item.toJson()).toList()),
    );
    await syncSelectedSettingsToFirebase();
  }

  Future<void> _edit([IbanRecord? existing]) async {
    final title = TextEditingController(text: existing?.title ?? '');
    final recipient = TextEditingController(text: existing?.recipient ?? '');
    final iban = TextEditingController(text: existing?.iban ?? '');
    final whatsApp = TextEditingController(text: existing?.whatsApp ?? '');
    final result = await showDialog<IbanRecord>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(existing == null ? 'IBAN Ekle' : 'IBAN Kaydını Düzelt'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: title,
                decoration: const InputDecoration(labelText: 'Başlık'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: recipient,
                decoration: const InputDecoration(
                  labelText: 'Alıcı Adı / Unvanı',
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: iban,
                textCapitalization: TextCapitalization.characters,
                decoration: const InputDecoration(labelText: 'IBAN'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: whatsApp,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'WhatsApp Numarası',
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () {
              if (title.text.trim().isEmpty ||
                  recipient.text.trim().isEmpty ||
                  iban.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Başlık, alıcı ve IBAN zorunludur.'),
                  ),
                );
                return;
              }
              Navigator.pop(
                dialogContext,
                IbanRecord(
                  id:
                      existing?.id ??
                      DateTime.now().microsecondsSinceEpoch.toString(),
                  title: title.text.trim(),
                  recipient: recipient.text.trim(),
                  iban: iban.text.trim().toUpperCase(),
                  whatsApp: whatsApp.text.trim(),
                  checked: existing?.checked ?? true,
                ),
              );
            },
            child: const Text('KAYDET'),
          ),
        ],
      ),
    );
    Future<void>.delayed(const Duration(milliseconds: 600), () {
      title.dispose();
      recipient.dispose();
      iban.dispose();
      whatsApp.dispose();
    });
    if (result == null || !mounted) return;
    final records = [..._records];
    final index = records.indexWhere((item) => item.id == result.id);
    if (index < 0) {
      records.add(result);
    } else {
      records[index] = result;
    }
    await _save(records);
    if (mounted) setState(() => _records = records);
  }

  Future<void> _delete(IbanRecord record) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('IBAN kaydı silinsin mi?'),
        content: Text('${record.title} silinecek.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('SİL'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    final records = _records.where((item) => item.id != record.id).toList();
    await _save(records);
    if (mounted) setState(() => _records = records);
  }

  Future<void> _toggle(IbanRecord record, bool value) async {
    final records = _records
        .map(
          (item) => item.id == record.id ? item.copyWith(checked: value) : item,
        )
        .toList();
    await _save(records);
    if (mounted) setState(() => _records = records);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('IBAN Girişi')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(),
        icon: const Icon(Icons.add),
        label: const Text('EKLE'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _records.isEmpty
          ? const Center(child: Text('Kayıtlı IBAN yok.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
              itemCount: _records.length,
              itemBuilder: (context, index) {
                final record = _records[index];
                return Card(
                  child: CheckboxListTile(
                    value: record.checked,
                    onChanged: (value) => _toggle(record, value ?? false),
                    title: Text(
                      record.title,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${record.recipient}\n${record.iban}${record.whatsApp.isEmpty ? '' : '\nWhatsApp: ${record.whatsApp}'}',
                    ),
                    secondary: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          tooltip: 'IBAN kopyala',
                          onPressed: () async {
                            await Clipboard.setData(
                              ClipboardData(text: record.iban),
                            );
                            if (!context.mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('IBAN kopyalandı.')),
                            );
                          },
                          icon: const Icon(Icons.copy_rounded),
                        ),
                        PopupMenuButton<String>(
                          onSelected: (value) =>
                              value == 'edit' ? _edit(record) : _delete(record),
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'edit', child: Text('Düzelt')),
                            PopupMenuItem(value: 'delete', child: Text('Sil')),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class CollectionAuthority {
  const CollectionAuthority({
    required this.id,
    required this.fullName,
    required this.phone,
    this.checked = false,
  });

  final String id;
  final String fullName;
  final String phone;
  final bool checked;

  CollectionAuthority copyWith({bool? checked}) => CollectionAuthority(
    id: id,
    fullName: fullName,
    phone: phone,
    checked: checked ?? this.checked,
  );

  Map<String, Object> toJson() => {
    'id': id,
    'fullName': fullName,
    'phone': phone,
    'checked': checked,
  };

  factory CollectionAuthority.fromJson(Map<String, dynamic> json) =>
      CollectionAuthority(
        id: json['id'] as String? ?? '',
        fullName: json['fullName'] as String? ?? '',
        phone: json['phone'] as String? ?? '',
        checked: json['checked'] as bool? ?? false,
      );
}

class CollectionAuthorityScreen extends StatefulWidget {
  const CollectionAuthorityScreen({super.key});

  @override
  State<CollectionAuthorityScreen> createState() =>
      _CollectionAuthorityScreenState();
}

class _CollectionAuthorityScreenState extends State<CollectionAuthorityScreen> {
  static const _key = _authorityStorageKey;
  List<CollectionAuthority> _authorities = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    var authorities = <CollectionAuthority>[];
    var loadedFromFirebase = false;
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('systemSettings')
          .doc('temporaryDriverInvitation')
          .get();
      final data = snapshot.data();
      final cloudAuthorities = data?['collectionAuthorities'] as List?;
      final legacySelectedAuthorities = data?['collectionContacts'] as List?;
      if (data != null &&
          (data.containsKey('collectionAuthorities') ||
              (legacySelectedAuthorities?.isNotEmpty ?? false))) {
        loadedFromFirebase = true;
        final source = cloudAuthorities ?? legacySelectedAuthorities;
        authorities = (source ?? const [])
            .whereType<Map>()
            .map((item) {
              final value = Map<String, dynamic>.from(item);
              return CollectionAuthority(
                id: value['id']?.toString() ?? '',
                fullName:
                    value['name']?.toString() ??
                    value['fullName']?.toString() ??
                    '',
                phone: value['phone']?.toString() ?? '',
                checked: value['checked'] as bool? ?? true,
              );
            })
            .where((item) => item.id.isNotEmpty && item.phone.isNotEmpty)
            .toList();
      }
    } catch (_) {
      // Çevrimdışıyken son yerel kopya kullanılabilir.
    }
    if (!loadedFromFirebase) {
      final raw = await _storage.read(key: _key);
      authorities = raw == null
          ? <CollectionAuthority>[]
          : (jsonDecode(raw) as List<dynamic>)
                .map(
                  (item) => CollectionAuthority.fromJson(
                    Map<String, dynamic>.from(item as Map),
                  ),
                )
                .toList();
    } else {
      await _storage.write(
        key: _key,
        value: jsonEncode(authorities.map((item) => item.toJson()).toList()),
      );
    }
    if (!mounted) return;
    setState(() {
      _authorities = authorities;
      _loading = false;
    });
  }

  Future<void> _save(List<CollectionAuthority> authorities) async {
    await _storage.write(
      key: _key,
      value: jsonEncode(authorities.map((item) => item.toJson()).toList()),
    );
    await syncSelectedSettingsToFirebase();
  }

  Future<void> _edit([CollectionAuthority? existing]) async {
    final fullName = TextEditingController(text: existing?.fullName ?? '');
    final phone = TextEditingController(text: existing?.phone ?? '');
    final result = await showDialog<CollectionAuthority>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(existing == null ? 'Yetkili Ekle' : 'Yetkiliyi Değiştir'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: fullName,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(labelText: 'İsim Soyisim'),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Telefon Numarası'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () {
              if (fullName.text.trim().isEmpty || phone.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('İsim soyisim ve telefon zorunludur.'),
                  ),
                );
                return;
              }
              Navigator.pop(
                dialogContext,
                CollectionAuthority(
                  id:
                      existing?.id ??
                      DateTime.now().microsecondsSinceEpoch.toString(),
                  fullName: fullName.text.trim(),
                  phone: phone.text.trim(),
                  checked: existing?.checked ?? true,
                ),
              );
            },
            child: const Text('KAYDET'),
          ),
        ],
      ),
    );
    Future<void>.delayed(const Duration(milliseconds: 600), () {
      fullName.dispose();
      phone.dispose();
    });
    if (result == null || !mounted) return;
    final authorities = [..._authorities];
    final index = authorities.indexWhere((item) => item.id == result.id);
    if (index < 0) {
      authorities.add(result);
    } else {
      authorities[index] = result;
    }
    await _save(authorities);
    if (mounted) setState(() => _authorities = authorities);
  }

  Future<void> _delete(CollectionAuthority authority) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Yetkili silinsin mi?'),
        content: Text('${authority.fullName} silinecek.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('SİL'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    final authorities = _authorities
        .where((item) => item.id != authority.id)
        .toList();
    await _save(authorities);
    if (mounted) setState(() => _authorities = authorities);
  }

  Future<void> _toggle(CollectionAuthority authority, bool value) async {
    final authorities = _authorities
        .map(
          (item) =>
              item.id == authority.id ? item.copyWith(checked: value) : item,
        )
        .toList();
    await _save(authorities);
    if (mounted) setState(() => _authorities = authorities);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tahsilat Kontrol Yetkilileri')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(),
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('EKLE'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _authorities.isEmpty
          ? const Center(child: Text('Kayıtlı tahsilat kontrol yetkilisi yok.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
              itemCount: _authorities.length,
              itemBuilder: (context, index) {
                final authority = _authorities[index];
                return Card(
                  child: CheckboxListTile(
                    value: authority.checked,
                    onChanged: (value) => _toggle(authority, value ?? false),
                    title: Text(
                      authority.fullName,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(authority.phone),
                    secondary: PopupMenuButton<String>(
                      onSelected: (value) => value == 'edit'
                          ? _edit(authority)
                          : _delete(authority),
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('Değiştir')),
                        PopupMenuItem(value: 'delete', child: Text('Sil')),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class CampaignItem {
  const CampaignItem({required this.text, this.checked = false});
  final String text;
  final bool checked;
  CampaignItem copyWith({bool? checked}) =>
      CampaignItem(text: text, checked: checked ?? this.checked);
  Map<String, Object> toJson() => {'text': text, 'checked': checked};
  factory CampaignItem.fromJson(Map<String, dynamic> json) => CampaignItem(
    text: json['text'] as String? ?? '',
    checked: json['checked'] as bool? ?? false,
  );
}

class Campaign {
  static const defaultGroupTitle = 'Yedek Şoför Paketi';

  const Campaign({
    required this.id,
    required this.title,
    required this.days,
    required this.price,
    this.userLimit = '',
    this.groupTitle = defaultGroupTitle,
    this.description = '',
    this.imageBase64 = '',
    this.checked = false,
  });
  final String id;
  final String title;
  final int days;
  final num price;
  final String userLimit;
  final String groupTitle;
  final String description;
  final String imageBase64;
  final bool checked;
  Campaign copyWith({
    String? title,
    int? days,
    num? price,
    String? userLimit,
    String? groupTitle,
    String? description,
    String? imageBase64,
    bool? checked,
  }) => Campaign(
    id: id,
    title: title ?? this.title,
    days: days ?? this.days,
    price: price ?? this.price,
    userLimit: userLimit ?? this.userLimit,
    groupTitle: groupTitle ?? this.groupTitle,
    description: description ?? this.description,
    imageBase64: imageBase64 ?? this.imageBase64,
    checked: checked ?? this.checked,
  );
  Map<String, Object> toJson() => {
    'id': id,
    'title': title,
    'days': days,
    'price': price,
    'userLimit': userLimit,
    'groupTitle': groupTitle,
    'description': description,
    'imageBase64': imageBase64,
    'checked': checked,
  };
  factory Campaign.fromJson(Map<String, dynamic> json) {
    final title = json['title'] as String? ?? '';
    final legacyItems = (json['items'] as List<dynamic>? ?? const [])
        .map((item) => Map<String, dynamic>.from(item as Map))
        .toList();
    final searchable = [
      title,
      ...legacyItems.map((item) => item['text']?.toString() ?? ''),
    ].join(' ');
    final numbers = RegExp(
      r'\d+(?:[.,]\d+)?',
    ).allMatches(searchable).map((match) => match.group(0)!).toList();
    final parsedDays = numbers.isEmpty
        ? 0
        : int.tryParse(numbers.first.replaceAll(',', '.').split('.').first) ??
              0;
    final parsedPrice = numbers.length < 2
        ? 0
        : num.tryParse(numbers.last.replaceAll(',', '.')) ?? 0;
    return Campaign(
      id: json['id'] as String? ?? '',
      title: title,
      days: (json['days'] as num?)?.toInt() ?? parsedDays,
      price: json['price'] as num? ?? parsedPrice,
      userLimit: json['userLimit']?.toString() ?? '',
      groupTitle: json['groupTitle'] as String? ?? Campaign.defaultGroupTitle,
      description: json['description'] as String? ?? '',
      imageBase64: json['imageBase64'] as String? ?? '',
      checked: json['checked'] as bool? ?? false,
    );
  }
}

class PackageGroup {
  const PackageGroup({
    required this.id,
    required this.title,
    this.checked = false,
  });
  final String id;
  final String title;
  final bool checked;
  PackageGroup copyWith({String? title, bool? checked}) => PackageGroup(
    id: id,
    title: title ?? this.title,
    checked: checked ?? this.checked,
  );
  Map<String, Object> toJson() => {
    'id': id,
    'title': title,
    'checked': checked,
  };
  factory PackageGroup.fromJson(Map<String, dynamic> json) => PackageGroup(
    id: json['id'] as String? ?? '',
    title: json['title'] as String? ?? '',
    checked: json['checked'] as bool? ?? false,
  );
}

class CampaignScreen extends StatefulWidget {
  const CampaignScreen({super.key});
  @override
  State<CampaignScreen> createState() => _CampaignScreenState();
}

class _CampaignScreenState extends State<CampaignScreen> {
  static const _groupsKey = 'stty_campaign_groups';
  List<PackageGroup> _groups = const [];
  List<Campaign> _campaigns = const [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final results = await Future.wait([
      _storage.read(key: _groupsKey),
      _storage.read(key: _campaignStorageKey),
    ]);
    var campaigns = results[1] == null
        ? <Campaign>[]
        : (jsonDecode(results[1]!) as List<dynamic>)
              .map(
                (item) =>
                    Campaign.fromJson(Map<String, dynamic>.from(item as Map)),
              )
              .toList();
    if (campaigns.isEmpty) {
      try {
        final snapshot = await FirebaseFirestore.instance
            .collection('systemSettings')
            .doc('temporaryDriverInvitation')
            .get();
        final remoteItems = snapshot.data()?['campaigns'] as List<dynamic>?;
        if (remoteItems != null) {
          campaigns = remoteItems
              .whereType<Map>()
              .map((item) => Campaign.fromJson(Map<String, dynamic>.from(item)))
              .where((item) => item.id.isNotEmpty)
              .toList();
          if (campaigns.isNotEmpty) {
            await _storage.write(
              key: _campaignStorageKey,
              value: jsonEncode(
                campaigns.map((item) => item.toJson()).toList(),
              ),
            );
          }
        }
      } catch (_) {
        // Ortak ayarlar okunamazsa yerel paketlerle devam edilir.
      }
    }
    if (campaigns.isEmpty) {
      campaigns = const [
        Campaign(
          id: 'backup-driver-3-days',
          title: '3 Günlük Kullanım',
          days: 3,
          price: 200,
          userLimit: '1',
          checked: true,
        ),
        Campaign(
          id: 'backup-driver-7-days',
          title: '7 Günlük Kullanım',
          days: 7,
          price: 400,
          userLimit: '1',
          checked: true,
        ),
        Campaign(
          id: 'backup-driver-30-days',
          title: '30 Günlük Kullanım',
          days: 30,
          price: 1000,
          userLimit: '1',
          checked: true,
        ),
      ];
      await _storage.write(
        key: _campaignStorageKey,
        value: jsonEncode(campaigns.map((item) => item.toJson()).toList()),
      );
      try {
        await syncSelectedSettingsToFirebase();
      } catch (_) {
        // Firebase bağlantısı gelince sonraki düzenlemede yeniden eşitlenir.
      }
    }
    var groups = results[0] == null
        ? <PackageGroup>[]
        : (jsonDecode(results[0]!) as List<dynamic>)
              .map(
                (item) => PackageGroup.fromJson(
                  Map<String, dynamic>.from(item as Map),
                ),
              )
              .toList();
    if (groups.isEmpty) {
      final titles = campaigns
          .map((item) => item.groupTitle.trim())
          .where((title) => title.isNotEmpty)
          .toSet();
      if (titles.isEmpty) titles.add(Campaign.defaultGroupTitle);
      groups = [
        for (final title in titles)
          PackageGroup(id: 'package-${title.hashCode.abs()}', title: title),
      ];
      await _saveGroups(groups);
    }
    if (!mounted) return;
    setState(() {
      _groups = groups;
      _campaigns = campaigns;
      _loading = false;
    });
  }

  Future<void> _saveGroups(List<PackageGroup> groups) => _storage.write(
    key: _groupsKey,
    value: jsonEncode(groups.map((item) => item.toJson()).toList()),
  );

  Future<void> _addGroup() async {
    final controller = TextEditingController();
    final title = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Paket Ekle'),
        content: TextField(
          controller: controller,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Paket Başlığı'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () {
              if (controller.text.trim().isEmpty) return;
              Navigator.pop(dialogContext, controller.text.trim());
            },
            child: const Text('EKLE'),
          ),
        ],
      ),
    );
    Future<void>.delayed(const Duration(milliseconds: 600), controller.dispose);
    if (title == null || !mounted) return;
    final groups = [
      ..._groups,
      PackageGroup(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        title: title,
      ),
    ];
    await _saveGroups(groups);
    if (mounted) setState(() => _groups = groups);
  }

  Future<void> _toggleGroup(PackageGroup group, bool checked) async {
    final groups = _groups
        .map(
          (item) =>
              item.id == group.id ? item.copyWith(checked: checked) : item,
        )
        .toList();
    await _saveGroups(groups);
    if (mounted) setState(() => _groups = groups);
  }

  Future<void> _editGroup(PackageGroup group) async {
    final controller = TextEditingController(text: group.title);
    final title = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Paket Başlığını Düzelt'),
        content: TextField(
          controller: controller,
          autofocus: true,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(labelText: 'Paket Başlığı'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () {
              if (controller.text.trim().isEmpty) return;
              Navigator.pop(dialogContext, controller.text.trim());
            },
            child: const Text('KAYDET'),
          ),
        ],
      ),
    );
    Future<void>.delayed(const Duration(milliseconds: 600), controller.dispose);
    if (title == null || title == group.title || !mounted) return;

    final groups = _groups
        .map((item) => item.id == group.id ? item.copyWith(title: title) : item)
        .toList();
    final campaigns = _campaigns
        .map(
          (item) => item.groupTitle == group.title
              ? item.copyWith(groupTitle: title)
              : item,
        )
        .toList();
    await _saveGroups(groups);
    await _storage.write(
      key: _campaignStorageKey,
      value: jsonEncode(campaigns.map((item) => item.toJson()).toList()),
    );
    await syncSelectedSettingsToFirebase();
    if (mounted) {
      setState(() {
        _groups = groups;
        _campaigns = campaigns;
      });
    }
  }

  Future<void> _deleteGroup(PackageGroup group) async {
    final childCount = _childCount(group.title);
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Paket başlığı silinsin mi?'),
        content: Text(
          childCount == 0
              ? '${group.title} silinecek.'
              : '${group.title} ve içindeki $childCount paket silinecek.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('SİL'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    final groups = _groups.where((item) => item.id != group.id).toList();
    final campaigns = _campaigns
        .where((item) => item.groupTitle != group.title)
        .toList();
    await _saveGroups(groups);
    await _storage.write(
      key: _campaignStorageKey,
      value: jsonEncode(campaigns.map((item) => item.toJson()).toList()),
    );
    await syncSelectedSettingsToFirebase();
    if (mounted) {
      setState(() {
        _groups = groups;
        _campaigns = campaigns;
      });
    }
  }

  int _childCount(String title) =>
      _campaigns.where((item) => item.groupTitle == title).length;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kampanyalar')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addGroup,
        icon: const Icon(Icons.add),
        label: const Text('PAKET EKLE'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
              itemCount: _groups.length,
              itemBuilder: (context, index) {
                final group = _groups[index];
                return Card(
                  child: ListTile(
                    leading: Checkbox(
                      value: group.checked,
                      onChanged: (value) => _toggleGroup(group, value ?? false),
                    ),
                    title: Text(
                      group.title,
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text('${_childCount(group.title)} alt paket'),
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) => value == 'edit'
                          ? _editGroup(group)
                          : _deleteGroup(group),
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('Düzelt')),
                        PopupMenuItem(value: 'delete', child: Text('Sil')),
                      ],
                    ),
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute<void>(
                          builder: (_) =>
                              SubPackageScreen(groupTitle: group.title),
                        ),
                      );
                      await _load();
                    },
                  ),
                );
              },
            ),
    );
  }
}

class SubPackageScreen extends StatefulWidget {
  const SubPackageScreen({required this.groupTitle, super.key});
  final String groupTitle;
  @override
  State<SubPackageScreen> createState() => _SubPackageScreenState();
}

class _SubPackageScreenState extends State<SubPackageScreen> {
  List<Campaign> _allCampaigns = const [];
  bool _loading = true;

  List<Campaign> get _campaigns => _allCampaigns
      .where((item) => item.groupTitle == widget.groupTitle)
      .toList();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await _storage.read(key: _campaignStorageKey);
    final campaigns = raw == null
        ? <Campaign>[]
        : (jsonDecode(raw) as List<dynamic>)
              .map(
                (item) =>
                    Campaign.fromJson(Map<String, dynamic>.from(item as Map)),
              )
              .toList();
    if (!mounted) return;
    setState(() {
      _allCampaigns = campaigns;
      _loading = false;
    });
  }

  Future<void> _save(List<Campaign> campaigns) async {
    await _storage.write(
      key: _campaignStorageKey,
      value: jsonEncode(campaigns.map((item) => item.toJson()).toList()),
    );
    await syncSelectedSettingsToFirebase();
  }

  Future<void> _edit([Campaign? existing]) async {
    final title = TextEditingController(text: existing?.title ?? '');
    final days = TextEditingController(
      text: existing == null ? '' : '${existing.days}',
    );
    final price = TextEditingController(
      text: existing == null ? '' : '${existing.price}',
    );
    final userLimit = TextEditingController(text: existing?.userLimit ?? '');
    final description = TextEditingController(
      text: existing?.description ?? '',
    );
    var imageBase64 = existing?.imageBase64 ?? '';
    final result = await showDialog<Campaign>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(existing == null ? 'Paket Ekle' : 'Paketi Düzelt'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: title,
                  decoration: const InputDecoration(labelText: 'Paket Adı'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: days,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Paket Süresi (Gün)',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: userLimit,
                  decoration: const InputDecoration(
                    labelText: 'Kullanıcı Sınırı',
                    hintText: 'Örnek: 1-5 veya Sınırsız',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: price,
                  keyboardType: const TextInputType.numberWithOptions(
                    decimal: true,
                  ),
                  decoration: const InputDecoration(
                    labelText: 'Paket Fiyatı (TL)',
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: description,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'Açıklama'),
                ),
                const SizedBox(height: 12),
                if (imageBase64.isNotEmpty)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.memory(
                      base64Decode(imageBase64),
                      height: 130,
                      fit: BoxFit.cover,
                    ),
                  ),
                Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () async {
                        final selected = await _imagePickerChannel
                            .invokeMethod<String>('pickImage');
                        if (selected == null || selected.isEmpty) return;
                        setDialogState(() => imageBase64 = selected);
                      },
                      icon: const Icon(Icons.add_photo_alternate_rounded),
                      label: Text(
                        imageBase64.isEmpty
                            ? 'GÖRSEL EKLE'
                            : 'GÖRSELİ DEĞİŞTİR',
                      ),
                    ),
                    if (imageBase64.isNotEmpty)
                      OutlinedButton.icon(
                        onPressed: () => setDialogState(() => imageBase64 = ''),
                        icon: const Icon(Icons.delete_outline_rounded),
                        label: const Text('SİL'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Theme.of(context).colorScheme.error,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('VAZGEÇ'),
            ),
            FilledButton(
              onPressed: () {
                final dayValue = int.tryParse(days.text.trim()) ?? 0;
                final priceValue =
                    num.tryParse(price.text.trim().replaceAll(',', '.')) ?? 0;
                if (title.text.trim().isEmpty ||
                    dayValue <= 0 ||
                    priceValue <= 0) {
                  ScaffoldMessenger.of(this.context).showSnackBar(
                    const SnackBar(
                      content: Text(
                        'Paket adı, paket süresi ve paket fiyatı zorunludur.',
                      ),
                    ),
                  );
                  return;
                }
                Navigator.pop(
                  dialogContext,
                  Campaign(
                    id:
                        existing?.id ??
                        DateTime.now().microsecondsSinceEpoch.toString(),
                    title: title.text.trim(),
                    days: dayValue,
                    price: priceValue,
                    userLimit: userLimit.text.trim(),
                    groupTitle: widget.groupTitle,
                    description: description.text.trim(),
                    imageBase64: imageBase64,
                    checked: existing?.checked ?? false,
                  ),
                );
              },
              child: const Text('KAYDET'),
            ),
          ],
        ),
      ),
    );
    Future<void>.delayed(const Duration(milliseconds: 600), () {
      title.dispose();
      days.dispose();
      price.dispose();
      userLimit.dispose();
      description.dispose();
    });
    if (result == null || !mounted) return;
    final campaigns = [..._allCampaigns];
    final index = campaigns.indexWhere((item) => item.id == result.id);
    if (index < 0) {
      campaigns.add(result);
    } else {
      campaigns[index] = result;
    }
    await _save(campaigns);
    if (mounted) setState(() => _allCampaigns = campaigns);
  }

  Future<void> _toggle(Campaign campaign, bool checked) async {
    final campaigns = _allCampaigns
        .map(
          (item) =>
              item.id == campaign.id ? item.copyWith(checked: checked) : item,
        )
        .toList();
    await _save(campaigns);
    if (mounted) setState(() => _allCampaigns = campaigns);
  }

  Future<void> _delete(Campaign campaign) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Paket silinsin mi?'),
        content: Text('${campaign.title} silinecek.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('SİL'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    final campaigns = _allCampaigns
        .where((item) => item.id != campaign.id)
        .toList();
    await _save(campaigns);
    if (mounted) setState(() => _allCampaigns = campaigns);
  }

  @override
  Widget build(BuildContext context) {
    final campaigns = _campaigns;
    return Scaffold(
      appBar: AppBar(title: Text(widget.groupTitle)),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _edit(),
        icon: const Icon(Icons.add),
        label: const Text('PAKET EKLE'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : campaigns.isEmpty
          ? const Center(child: Text('Bu başlıkta henüz paket yok.'))
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
              itemCount: campaigns.length,
              itemBuilder: (context, index) {
                final campaign = campaigns[index];
                return Card(
                  child: CheckboxListTile(
                    value: campaign.checked,
                    onChanged: (value) => _toggle(campaign, value ?? false),
                    title: Row(
                      children: [
                        if (campaign.imageBase64.isNotEmpty) ...[
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.memory(
                              base64Decode(campaign.imageBase64),
                              width: 48,
                              height: 48,
                              fit: BoxFit.cover,
                            ),
                          ),
                          const SizedBox(width: 10),
                        ],
                        Expanded(
                          child: Text(
                            campaign.title,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                      ],
                    ),
                    subtitle: Text(
                      'Süre: ${campaign.days} gün'
                      '${campaign.userLimit.isEmpty ? '' : ' • Kullanıcı: ${campaign.userLimit}'}'
                      ' • Fiyat: ${campaign.price} TL'
                      '${campaign.description.isEmpty ? '' : '\n${campaign.description}'}',
                    ),
                    secondary: PopupMenuButton<String>(
                      onSelected: (value) =>
                          value == 'edit' ? _edit(campaign) : _delete(campaign),
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'edit', child: Text('Düzelt')),
                        PopupMenuItem(value: 'delete', child: Text('Sil')),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
