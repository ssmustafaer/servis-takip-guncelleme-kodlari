import 'package:flutter/material.dart';

import '../company/models/company_session.dart';
import 'company_employees_screen.dart';
import 'institutions_screen.dart';
import 'personnel_screen.dart';
import 'shifts_screen.dart';
import 'stops_screen.dart';
import 'vehicles_screen.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({this.session, super.key});

  final CompanySession? session;

  static const _steps = <({IconData icon, String title, String text})>[
    (
      icon: Icons.login_rounded,
      title: '1. Uygulamaya giriş',
      text:
          'Şirket kodunuzu, kullanıcı adınızı ve şifrenizi girin. Şoför hesabıyla giriş yapıldığında yalnızca yetkili olunan kurum ve araçlar görünür.',
    ),
    (
      icon: Icons.directions_bus_rounded,
      title: '2. Servisi hazırlama',
      text:
          'Ana sayfadan Toplama veya Dağıtım seçin. Şoför, araç, kurum, alt kayıt ve kayıt grubunu seçin.',
    ),
    (
      icon: Icons.view_list_rounded,
      title: '3. Listeleme şeklini seçme',
      text:
          'Personel İsmine Göre yalnız yolcuları; Durak Sırasına Göre yolcusu olan durakları; Tüm Duraklara Uğra ise yolcu olmasa bile bütün durakları gösterir.',
    ),
    (
      icon: Icons.play_circle_rounded,
      title: '4. Servisi başlatma',
      text:
          'Vardiyayı seçip BAŞLA düğmesine basın. Servis başlamadan Bindi ve Yok işlemleri kullanılamaz.',
    ),
    (
      icon: Icons.how_to_reg_rounded,
      title: '5. Yolcu durumunu işaretleme',
      text:
          'Durakta yalnızca bulunmayan yolcular için Yok düğmesini kullanın. Durak penceresini kapattığınızda işaretlenmeyen yolcular otomatik olarak Bindi kaydedilir ve sıradaki durağın navigasyonu açılır.',
    ),
    (
      icon: Icons.stop_circle_rounded,
      title: '6. Servisi bitirme',
      text:
          'Güzergâh tamamlandığında BİTİR düğmesine basın ve onaylayın. Başlama-bitiş saatleri ile yolcu durumları raporlara kaydedilir.',
    ),
    (
      icon: Icons.person_add_alt_1_rounded,
      title: '7. Geçici yolcu ve izin',
      text:
          'Yolcu Ekle yalnız seçilen tarih ve vardiyaya geçici yolcu ekler. İzinler bölümünden personel izni ve erken dönüş bilgisi yönetilir.',
    ),
    (
      icon: Icons.system_update_rounded,
      title: '8. Uygulamayı güncelleme',
      text:
          'Ayarlar > Uygulamayı Güncelle seçeneğini kullanın. Android yükleme ekranı açıldığında Güncelle düğmesine basın; uygulamayı silmeyin.',
    ),
  ];

  bool _allowed(String permission) =>
      session == null || session!.permission(permission);

  void _open(
    BuildContext context, {
    required String permission,
    required WidgetBuilder builder,
  }) {
    if (!_allowed(permission)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bu bölümü açma yetkiniz bulunmuyor.')),
      );
      return;
    }
    Navigator.of(context).push(MaterialPageRoute<void>(builder: builder));
  }

  Widget _setupTile({
    required BuildContext context,
    required int number,
    required IconData icon,
    required String title,
    String? text,
    required VoidCallback onTap,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        contentPadding: const EdgeInsets.fromLTRB(14, 10, 8, 10),
        leading: CircleAvatar(
          backgroundColor: const Color(0xFFE3EEFF),
          foregroundColor: const Color(0xFF082A52),
          child: Text(
            '$number',
            style: const TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
        ),
        subtitle: text == null
            ? null
            : Padding(
                padding: const EdgeInsets.only(top: 5),
                child: Text(text, style: const TextStyle(height: 1.35)),
              ),
        trailing: IconButton(
          tooltip: '$title bölümünü aç',
          onPressed: onTap,
          icon: const Icon(Icons.arrow_forward_rounded),
        ),
        onTap: onTap,
      ),
    );
  }

  Widget _usageCard(({IconData icon, String title, String text}) step) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              backgroundColor: const Color(0xFFE3EEFF),
              foregroundColor: const Color(0xFF082A52),
              child: Icon(step.icon),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    step.title,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    step.text,
                    style: const TextStyle(
                      color: Color(0xFF52657B),
                      height: 1.35,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Yardım')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            clipBehavior: Clip.antiAlias,
            child: ExpansionTile(
              leading: const Icon(Icons.account_tree_rounded),
              title: const Text(
                'İlk Kurulum Şeması',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              childrenPadding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
              children: [
                _setupTile(
                  context: context,
                  number: 1,
                  icon: Icons.domain_rounded,
                  title: 'Kurumunuzu kaydedin',
                  text: '├─ Vardiya\n├─ Memur\n├─ Güvenlik\n└─ ...',
                  onTap: () => _open(
                    context,
                    permission: 'canManageInstitutions',
                    builder: (_) => const InstitutionsScreen(),
                  ),
                ),
                _setupTile(
                  context: context,
                  number: 2,
                  icon: Icons.swap_horiz_rounded,
                  title: 'Vardiyaları oluşturun',
                  text: '├─ 24 / 08  -  08 / 16  -  16 / 24\n└─ ...',
                  onTap: () => _open(
                    context,
                    permission: 'canManageShifts',
                    builder: (_) => const ShiftsScreen(),
                  ),
                ),
                _setupTile(
                  context: context,
                  number: 3,
                  icon: Icons.location_on_rounded,
                  title: 'Durakları oluşturun',
                  text:
                      '├─ Atatürk Bulvarı\n├─ Cumhuriyet Parkı\n├─ Belediye\n└─ ...',
                  onTap: () => _open(
                    context,
                    permission: 'canManageStops',
                    builder: (_) => const StopsScreen(),
                  ),
                ),
                _setupTile(
                  context: context,
                  number: 4,
                  icon: Icons.people_alt_rounded,
                  title: 'Personel girişlerini yapın',
                  text:
                      '├─ Adı ve soyadı\n├─ Kurumu ve çalışma grubu\n├─ Vardiyası\n├─ Durağı\n├─ Telefon ve WhatsApp\n└─ Lütfen bilgileri eksiksiz doldurun',
                  onTap: () => _open(
                    context,
                    permission: 'canManagePersonnel',
                    builder: (_) => const PersonnelScreen(),
                  ),
                ),
                _setupTile(
                  context: context,
                  number: 5,
                  icon: Icons.badge_rounded,
                  title: 'Şirket çalışanlarını girin',
                  text:
                      '├─ Şirket sahibi\n├─ İdari personel\n├─ Şoför\n└─ Şoför yetkilerini dikkatle ayarlayın',
                  onTap: () {
                    if (session == null) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Şirket çalışanları bu girişte açılamıyor.',
                          ),
                        ),
                      );
                      return;
                    }
                    _open(
                      context,
                      permission: 'canManageEmployees',
                      builder: (_) => CompanyEmployeesScreen(session: session!),
                    );
                  },
                ),
                _setupTile(
                  context: context,
                  number: 6,
                  icon: Icons.directions_bus_rounded,
                  title: 'Araçlarınızı girin',
                  text:
                      '├─ Plaka\n├─ Marka ve model\n├─ Koltuk kapasitesi\n└─ ...',
                  onTap: () => _open(
                    context,
                    permission: 'canManageVehicles',
                    builder: (_) => const VehiclesScreen(),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Card(
            clipBehavior: Clip.antiAlias,
            child: ExpansionTile(
              leading: const Icon(Icons.menu_book_rounded),
              title: const Text(
                'Günlük Kullanım',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              childrenPadding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
              children: _steps.map(_usageCard).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
