import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'screens/admin_dashboard_screen.dart';
import 'screens/admin_login_screen.dart';
import 'services/admin_repository.dart';

class ServisTakipAdminApp extends StatelessWidget {
  ServisTakipAdminApp({super.key});

  final AdminRepository _repository = AdminRepository();

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF082A52);
    return MaterialApp(
      title: 'Servis Takip Yönetici Paneli',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: navy),
        scaffoldBackgroundColor: const Color(0xFFF4F7FB),
        appBarTheme: const AppBarTheme(
          backgroundColor: navy,
          foregroundColor: Colors.white,
        ),
      ),
      home: StreamBuilder<User?>(
        stream: _repository.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          if (snapshot.data == null) {
            return AdminLoginScreen(repository: _repository);
          }
          return _AdminAuthorizationGate(repository: _repository);
        },
      ),
    );
  }
}

class _AdminAuthorizationGate extends StatelessWidget {
  const _AdminAuthorizationGate({required this.repository});

  final AdminRepository repository;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: repository.isSystemAdmin(),
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snapshot.data == true) {
          return AdminDashboardScreen(repository: repository);
        }
        return Scaffold(
          appBar: AppBar(title: const Text('Yetkisiz Giriş')),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    Icons.admin_panel_settings_outlined,
                    size: 72,
                    color: Color(0xFFB3261E),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Bu hesabın sistem yöneticisi yetkisi yok.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: repository.signOut,
                    child: const Text('Çıkış Yap'),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
