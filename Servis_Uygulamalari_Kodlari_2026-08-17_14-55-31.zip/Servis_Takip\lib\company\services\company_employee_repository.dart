import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

import '../models/company_employee.dart';

class CompanyEmployeeRepository {
  CompanyEmployeeRepository({
    FirebaseFirestore? firestore,
    FirebaseFunctions? functions,
  }) : _firestore = firestore ?? FirebaseFirestore.instance,
       _functions = functions ?? FirebaseFunctions.instance;

  final FirebaseFirestore _firestore;
  final FirebaseFunctions _functions;

  Stream<List<CompanyEmployee>> watchEmployees(String companyId) {
    return _firestore
        .collection('users')
        .where('companyId', isEqualTo: companyId)
        .snapshots()
        .map((snapshot) {
          final employees = snapshot.docs
              .map(CompanyEmployee.fromDocument)
              .toList();
          employees.sort((a, b) {
            if (a.active != b.active) return a.active ? -1 : 1;
            return a.displayName.toLowerCase().compareTo(
              b.displayName.toLowerCase(),
            );
          });
          return employees;
        });
  }

  Future<void> setEmployeeActive({
    required String employeeId,
    required bool active,
  }) {
    return _firestore.collection('users').doc(employeeId).update({
      'active': active,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> deleteEmployee({
    required String companyId,
    required String employeeId,
  }) async {
    await _functions.httpsCallable('deleteCompanyEmployee').call({
      'companyId': companyId,
      'targetUserId': employeeId,
    });
  }

  Future<void> updateEmployee(CompanyEmployee employee) {
    return _firestore.collection('users').doc(employee.id).update({
      'displayName': employee.displayName.trim(),
      'role': employee.role,
      'phone': employee.phone,
      'address': employee.address.trim(),
      'district': employee.district.trim(),
      'city': employee.city.trim(),
      'latitude': employee.latitude,
      'longitude': employee.longitude,
      'active': employee.active,
      'permissions': employee.permissions,
      'allowedInstitutionIds': employee.allowedInstitutionIds,
      'allInstitutions': employee.allInstitutions,
      'allowedVehicleIds': employee.allowedVehicleIds,
      'allVehicles': employee.allVehicles,
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> resetPassword({
    required String employeeId,
    required String newPassword,
  }) async {
    await _functions.httpsCallable('resetCompanyUserPassword').call({
      'targetUserId': employeeId,
      'newPassword': newPassword,
    });
  }

  Future<void> verifyPassword({
    required String employeeId,
    required String password,
  }) async {
    final profile = await _firestore.collection('users').doc(employeeId).get();
    final email = profile.data()?['email']?.toString() ?? '';
    if (email.isEmpty) {
      throw StateError('Şoför hesabının giriş bilgisi bulunamadı.');
    }
    final appName = 'verify_${DateTime.now().microsecondsSinceEpoch}';
    final secondaryApp = await Firebase.initializeApp(
      name: appName,
      options: Firebase.app().options,
    );
    final secondaryAuth = FirebaseAuth.instanceFor(app: secondaryApp);
    try {
      await secondaryAuth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } finally {
      await secondaryAuth.signOut();
      await secondaryApp.delete();
    }
  }

  Future<void> createEmployee({
    required String companyId,
    required String displayName,
    required String phone,
    required String password,
    required String role,
    required List<String> allowedInstitutionIds,
    required bool allInstitutions,
    required List<String> allowedVehicleIds,
    required bool allVehicles,
    required String address,
    required String district,
    required String city,
    required double? latitude,
    required double? longitude,
  }) async {
    final normalizedName = _normalizeLoginName(displayName);
    final internalEmail = '$normalizedName.$companyId@servistakip.local';
    final appName = 'employee_${DateTime.now().microsecondsSinceEpoch}';
    final secondaryApp = await Firebase.initializeApp(
      name: appName,
      options: Firebase.app().options,
    );
    final secondaryAuth = FirebaseAuth.instanceFor(app: secondaryApp);
    User? createdUser;
    try {
      final credential = await secondaryAuth.createUserWithEmailAndPassword(
        email: internalEmail,
        password: password,
      );
      createdUser = credential.user;
      if (createdUser == null) {
        throw StateError('Çalışan hesabı oluşturulamadı.');
      }
      await createdUser.updateDisplayName(displayName.trim());

      final companyReference = _firestore
          .collection('companies')
          .doc(companyId);
      final userReference = _firestore.collection('users').doc(createdUser.uid);
      await _firestore.runTransaction((transaction) async {
        final companySnapshot = await transaction.get(companyReference);
        final company = companySnapshot.data();
        if (company == null || company['active'] != true) {
          throw StateError('Şirket hesabı aktif değil.');
        }
        final limits = company['limits'] as Map<String, dynamic>? ?? const {};
        final usage = company['usage'] as Map<String, dynamic>? ?? const {};
        final maxUsers = (limits['maxUsers'] as num?)?.toInt() ?? 0;
        final usedUsers = (usage['users'] as num?)?.toInt() ?? 0;
        if (maxUsers > 0 && usedUsers >= maxUsers) {
          throw StateError('Kullanıcı sınırı doldu ($usedUsers/$maxUsers).');
        }
        transaction.set(userReference, {
          'companyId': companyId,
          'displayName': displayName.trim(),
          'phone': phone.trim(),
          'address': address.trim(),
          'district': district.trim(),
          'city': city.trim(),
          'latitude': latitude,
          'longitude': longitude,
          'email': internalEmail,
          'loginName': normalizedName,
          'role': role,
          'active': true,
          'permissions': _defaultPermissions(role),
          'allInstitutions': role == CompanyEmployee.ownerRole
              ? true
              : allInstitutions,
          'allowedInstitutionIds': role == CompanyEmployee.ownerRole
              ? <String>[]
              : allowedInstitutionIds,
          'allVehicles': role == CompanyEmployee.ownerRole ? true : allVehicles,
          'allowedVehicleIds': role == CompanyEmployee.ownerRole
              ? <String>[]
              : allowedVehicleIds,
          'createdAt': FieldValue.serverTimestamp(),
          'updatedAt': FieldValue.serverTimestamp(),
        });
        transaction.update(companyReference, {
          'usage.users': usedUsers + 1,
          'updatedAt': FieldValue.serverTimestamp(),
        });
      });
    } catch (_) {
      if (createdUser != null) {
        await createdUser.delete().catchError((_) {});
      }
      rethrow;
    } finally {
      await secondaryAuth.signOut();
      await secondaryApp.delete();
    }
  }

  Map<String, bool> _defaultPermissions(String role) {
    final owner = role == CompanyEmployee.ownerRole || role == 'company_admin';
    return {
      'canViewSettings': owner,
      'canManageInstitutions': owner,
      'canManageVehicles': owner,
      'canManageEmployees': owner,
      'canManagePersonnel': owner,
      'canManageStops': owner,
      'canManageShifts': owner,
      'canViewReports': owner,
    };
  }

  String _normalizeLoginName(String value) {
    var normalized = value.trim().toLowerCase();
    const replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((source, target) {
      normalized = normalized.replaceAll(source, target);
    });
    normalized = normalized
        .replaceAll(RegExp(r'[^a-z0-9]+'), '.')
        .replaceAll(RegExp(r'^\.+|\.+$'), '');
    return normalized.isEmpty ? 'kullanici' : normalized;
  }
}
