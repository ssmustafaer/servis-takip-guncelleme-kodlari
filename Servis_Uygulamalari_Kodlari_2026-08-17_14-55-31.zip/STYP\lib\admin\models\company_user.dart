import 'package:cloud_firestore/cloud_firestore.dart';

class CompanyUser {
  const CompanyUser({
    required this.id,
    required this.companyId,
    required this.displayName,
    required this.email,
    required this.role,
    required this.active,
    required this.deviceId,
    required this.deviceName,
  });

  final String id;
  final String companyId;
  final String displayName;
  final String email;
  final String role;
  final bool active;
  final String deviceId;
  final String deviceName;

  bool get hasRegisteredDevice => deviceId.isNotEmpty;

  bool get isCompanyAdmin => role == 'company_admin';
  String get positionName => switch (role) {
    'company_admin' || 'owner' => 'Sahibi',
    'administrative' => 'İdari Personel',
    _ => 'Şoför',
  };

  factory CompanyUser.fromDocument(
    DocumentSnapshot<Map<String, dynamic>> document,
  ) {
    final data = document.data() ?? const <String, dynamic>{};
    return CompanyUser(
      id: document.id,
      companyId: data['companyId'] as String? ?? '',
      displayName: data['displayName'] as String? ?? 'İsimsiz Kullanıcı',
      email: data['email'] as String? ?? '',
      role: data['role'] as String? ?? 'driver',
      active: data['active'] as bool? ?? false,
      deviceId: data['deviceId'] as String? ?? '',
      deviceName: data['deviceName'] as String? ?? '',
    );
  }
}
