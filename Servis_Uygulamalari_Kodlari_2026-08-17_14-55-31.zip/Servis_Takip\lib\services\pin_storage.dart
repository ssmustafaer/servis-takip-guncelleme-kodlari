import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class PinStorage {
  PinStorage._();

  static const _pinKey = 'app_pin';
  static const _storage = FlutterSecureStorage();

  static Future<bool> hasPin() async {
    return (await _storage.read(key: _pinKey)) != null;
  }

  static Future<void> savePin(String pin) async {
    await _storage.write(key: _pinKey, value: pin);
  }

  static Future<bool> verifyPin(String pin) async {
    return (await _storage.read(key: _pinKey)) == pin;
  }
}
