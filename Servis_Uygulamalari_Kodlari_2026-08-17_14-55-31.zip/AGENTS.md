# Servis Uygulamaları Çalışma Kuralları

Bu klasör, Servis Takip uygulaması ile STYP yönetim uygulamasının ortak çalışma alanıdır.

## Doğru proje yolları

- Servis Takip: `C:\Users\Mustafa ER\Documents\Codex\2026-08-12\referenced-chatgpt-conversation-this-is-an-2\Servis_Takip`
- STYP: `C:\Users\Mustafa ER\Documents\Codex\2026-08-12\referenced-chatgpt-conversation-this-is-an-2\STYP`
- Ortak çalıştırma menüsü: `C:\Users\Mustafa ER\Documents\Codex\2026-08-12\referenced-chatgpt-conversation-this-is-an-2\SERVIS_UYGULAMALARI_MENU.bat`

## Kesin kısıtlar

- `C:\Servis_Takip` yanlış ve eski yoldur. Hiçbir işlemde kullanılmamalıdır.
- Kullanıcı açıkça istemedikçe APK veya AAB oluşturulmamalıdır.
- Kullanıcı açıkça istemedikçe Firebase, GitHub veya başka bir dış servise yayın yapılmamalıdır.
- Servis Takip ile STYP ayrı uygulamalardır. Değişiklik yapılmadan önce hedef uygulama doğrulanmalıdır.
- Kullanıcının mevcut ve kaydedilmemiş değişiklikleri korunmalıdır; ilgisiz dosyalar geri alınmamalı veya silinmemelidir.

## Çalıştırma

Servis Takip:

```bat
cd /d "C:\Users\Mustafa ER\Documents\Codex\2026-08-12\referenced-chatgpt-conversation-this-is-an-2\Servis_Takip"
flutter run --flavor client -t lib\main.dart
```

STYP:

```bat
cd /d "C:\Users\Mustafa ER\Documents\Codex\2026-08-12\referenced-chatgpt-conversation-this-is-an-2\STYP"
flutter run
```

Masaüstündeki `SERVIS_UYGULAMALARI_MENU - Kısayol` kullanılabilir. Menüde `1` Servis Takip'i, `2` STYP'yi çalıştırır. `3` APK üretir ve `4` yayın yapar; bu seçenekler yalnızca kullanıcı açıkça istediğinde kullanılmalıdır.

## Değişiklik öncesi ve sonrası kontrol

1. Hedef uygulamanın doğru klasörde olduğu doğrulanmalıdır.
2. Mevcut Git durumu incelenmeli ve kullanıcı değişiklikleri korunmalıdır.
3. İstenen değişiklik dar kapsamda uygulanmalıdır.
4. Uygun statik analiz, test veya APK üretmeyen Gradle/Kotlin görevi çalıştırılmalıdır.
5. Sonuçta değiştirilen dosyalar, yapılan doğrulamalar ve kalan uyarılar açıkça belirtilmelidir.

## Android yapılandırması

- Gradle 9 kullanılırken `java.util.Properties`, Kotlin DSL/Gradle ad çakışmasını önlemek için alias ile içe aktarılmalıdır: `import java.util.Properties as JavaProperties`.
- Java ve Kotlin hedefi 17'dir.
- Client flavor çalıştırma hedefi `lib\main.dart` dosyasıdır.

