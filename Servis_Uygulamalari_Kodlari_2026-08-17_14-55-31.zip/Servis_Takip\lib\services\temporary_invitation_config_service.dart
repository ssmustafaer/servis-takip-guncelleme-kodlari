import 'package:cloud_firestore/cloud_firestore.dart';

import 'invitation_payment_settings_storage.dart';

class TemporaryAccessCampaign {
  const TemporaryAccessCampaign({
    required this.id,
    required this.title,
    required this.days,
    required this.price,
    this.groupTitle = 'Yedek Şoför Paketi',
    this.description = '',
    this.imageBase64 = '',
    this.active = true,
    this.sortOrder = 0,
  });

  final String id;
  final String title;
  final int days;
  final num price;
  final String groupTitle;
  final String description;
  final String imageBase64;
  final bool active;
  final int sortOrder;

  factory TemporaryAccessCampaign.fromMap(Map<String, dynamic> map) {
    return TemporaryAccessCampaign(
      id: map['id']?.toString() ?? '',
      title: map['title']?.toString() ?? '',
      days: (map['days'] as num?)?.toInt() ?? 0,
      price: map['price'] as num? ?? 0,
      groupTitle: (map['groupTitle']?.toString().trim().isNotEmpty ?? false)
          ? map['groupTitle'].toString().trim()
          : 'Yedek Şoför Paketi',
      description: map['description']?.toString().trim() ?? '',
      imageBase64: map['imageBase64']?.toString().trim() ?? '',
      active: map['active'] as bool? ?? true,
      sortOrder: (map['sortOrder'] as num?)?.toInt() ?? 0,
    );
  }
}

class InvitationIban {
  const InvitationIban({
    required this.id,
    required this.title,
    required this.recipientName,
    required this.iban,
  });

  final String id;
  final String title;
  final String recipientName;
  final String iban;

  factory InvitationIban.fromMap(Map<String, dynamic> map) => InvitationIban(
    id: map['id']?.toString() ?? '',
    title: map['title']?.toString() ?? '',
    recipientName: map['recipientName']?.toString() ?? '',
    iban: map['iban']?.toString() ?? '',
  );
}

class InvitationCollectionContact {
  const InvitationCollectionContact({
    required this.id,
    required this.name,
    required this.phone,
  });

  final String id;
  final String name;
  final String phone;

  factory InvitationCollectionContact.fromMap(Map<String, dynamic> map) =>
      InvitationCollectionContact(
        id: map['id']?.toString() ?? '',
        name: map['name']?.toString() ?? '',
        phone: map['phone']?.toString() ?? '',
      );
}

class TemporaryInvitationConfig {
  const TemporaryInvitationConfig({
    required this.campaigns,
    required this.ibans,
    required this.collectionContacts,
    required this.remoteConfigured,
  });

  final List<TemporaryAccessCampaign> campaigns;
  final List<InvitationIban> ibans;
  final List<InvitationCollectionContact> collectionContacts;
  final bool remoteConfigured;

  bool get hasPaymentDetails =>
      ibans.isNotEmpty && collectionContacts.isNotEmpty;
}

class TemporaryInvitationConfigService {
  TemporaryInvitationConfigService({FirebaseFirestore? firestore})
    : _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _firestore;

  Future<TemporaryInvitationConfig> read() async {
    try {
      final snapshot = await _firestore
          .collection('systemSettings')
          .doc('temporaryDriverInvitation')
          .get();
      final data = snapshot.data();
      if (data != null) {
        final campaigns =
            (data['campaigns'] as List<dynamic>? ?? const [])
                .whereType<Map>()
                .map(
                  (item) => TemporaryAccessCampaign.fromMap(
                    Map<String, dynamic>.from(item),
                  ),
                )
                .where(
                  (item) =>
                      item.active &&
                      item.id.isNotEmpty &&
                      item.days > 0 &&
                      item.price > 0,
                )
                .toList()
              ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
        final iban = Map<String, dynamic>.from(
          data['selectedIban'] as Map? ?? const {},
        );
        final contact = Map<String, dynamic>.from(
          data['collectionContact'] as Map? ?? const {},
        );
        final ibans = (data['selectedIbans'] as List<dynamic>? ?? const [])
            .whereType<Map>()
            .map(
              (item) => InvitationIban.fromMap(Map<String, dynamic>.from(item)),
            )
            .where((item) => item.iban.isNotEmpty)
            .toList();
        if (ibans.isEmpty && (iban['iban']?.toString() ?? '').isNotEmpty) {
          ibans.add(InvitationIban.fromMap(iban));
        }
        final contacts =
            (data['collectionContacts'] as List<dynamic>? ?? const [])
                .whereType<Map>()
                .map(
                  (item) => InvitationCollectionContact.fromMap(
                    Map<String, dynamic>.from(item),
                  ),
                )
                .where((item) => item.phone.isNotEmpty)
                .toList();
        if (contacts.isEmpty &&
            (contact['phone']?.toString() ?? '').isNotEmpty) {
          contacts.add(InvitationCollectionContact.fromMap(contact));
        }
        // Ödeme bilgileri Firebase'de bulunduysa kampanya listesi boş olsa da
        // bunları kullan. Önceki sürüm kampanya yokken IBAN ve yetkiliyi de
        // atıp tamamen yerel ayarlara dönüyordu.
        if (campaigns.isNotEmpty || ibans.isNotEmpty || contacts.isNotEmpty) {
          return TemporaryInvitationConfig(
            campaigns: campaigns.isEmpty ? _defaultCampaigns() : campaigns,
            ibans: ibans,
            collectionContacts: contacts,
            remoteConfigured: ibans.isNotEmpty && contacts.isNotEmpty,
          );
        }
      }
    } catch (_) {
      // STTY ayarı henüz yayınlanmadıysa önceki yerel ayarlar kullanılabilir.
    }
    return _localFallback();
  }

  Future<TemporaryInvitationConfig> _localFallback() async {
    final accounts = await InvitationPaymentSettingsStorage.readAll();
    final selected = accounts.where((item) => item.active).firstOrNull;
    return TemporaryInvitationConfig(
      campaigns: _defaultCampaigns(),
      ibans: selected == null
          ? const []
          : [
              InvitationIban(
                id: selected.id,
                title: selected.title,
                recipientName: selected.recipientName,
                iban: selected.iban,
              ),
            ],
      collectionContacts: selected == null
          ? const []
          : [
              InvitationCollectionContact(
                id: selected.id,
                name: selected.title,
                phone: selected.notificationPhone,
              ),
            ],
      remoteConfigured: false,
    );
  }

  List<TemporaryAccessCampaign> _defaultCampaigns() => const [
    TemporaryAccessCampaign(
      id: 'fallback-3-days',
      title: '3 Günlük Kullanım',
      days: 3,
      price: 200,
      sortOrder: 1,
    ),
    TemporaryAccessCampaign(
      id: 'fallback-7-days',
      title: '7 Günlük Kullanım',
      days: 7,
      price: 400,
      sortOrder: 2,
    ),
    TemporaryAccessCampaign(
      id: 'fallback-30-days',
      title: '30 Günlük Kullanım',
      days: 30,
      price: 1000,
      sortOrder: 3,
    ),
  ];
}
