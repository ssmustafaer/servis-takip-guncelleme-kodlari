class Personnel {
  static const rotatingWorkType = 'Vardiya';
  static const fixedWorkType = 'Sabit';
  static const reliefWorkType = 'Dinlendirici';
  static const guestWorkType = 'Misafir';

  static const weeklyLeaveMode = 'İzin Günü ile';
  static const cycleLeaveMode = 'Çalışma Günü ile';
  static const shiftBackward = '8 Saat Geri';
  static const shiftForward = '8 Saat İleri';

  static const threeShiftSystem = '3 Vardiya';
  static const twoShiftSystem = '2 Vardiya';
  static const threeShiftStandardPattern = 'three_standard';
  static const threeShiftEarlyPattern = 'three_early';
  static const twoShiftStandardPattern = 'two_standard';
  static const twoShiftEarlyPattern = 'two_early';

  static const threeShiftStandard = ['24 / 08', '08 / 16', '16 / 24'];
  static const threeShiftEarly = ['23 / 07', '07 / 15', '15 / 23'];
  static const twoShiftStandard = ['08 / 16', '16 / 24'];
  static const twoShiftEarly = ['07 / 15', '15 / 23'];

  const Personnel({
    required this.id,
    required this.fullName,
    required this.phone,
    required this.whatsApp,
    required this.stopName,
    required this.stopOrder,
    required this.shift,
    required this.workType,
    required this.leaveWeekdays,
    this.leaveMode = weeklyLeaveMode,
    this.workDaysCount = 6,
    this.leaveDaysCount = 1,
    this.shiftDirection = shiftBackward,
    this.shiftSystem = threeShiftSystem,
    this.shiftPattern = threeShiftStandardPattern,
    this.shiftDefinitionId = '',
    this.customShiftSequence = const [],
    this.reliefWeeklyShifts = const {},
    this.reliefMonthlyShifts = const {},
    this.fixedServiceWeekdays = const [],
    this.fixedServiceShifts = const [],
    this.serviceEntryTimes = const [],
    this.serviceExitTimes = const [],
    this.serviceEntryTimesByWeekday = const {},
    this.serviceExitTimesByWeekday = const {},
    this.customServiceParticipationEnabled = false,
    required this.institutionId,
    required this.institutionName,
    required this.referenceDate,
    required this.cycleDay,
    this.stopLatitude,
    this.stopLongitude,
    required this.note,
  });

  final String id;
  final String fullName;
  final String phone;
  final String whatsApp;
  final String stopName;
  final int stopOrder;
  final String shift;
  final String workType;
  final List<int> leaveWeekdays;
  final String leaveMode;
  final int workDaysCount;
  final int leaveDaysCount;
  final String shiftDirection;
  final String shiftSystem;
  final String shiftPattern;

  /// Yeni Vardiyalar ekranında oluşturulan sistemin kimliği.
  /// Boşsa eski shiftSystem/shiftPattern alanları kullanılmaya devam eder.
  final String shiftDefinitionId;
  final List<String> customShiftSequence;
  final Map<int, List<String>> reliefWeeklyShifts;
  final Map<String, List<String>> reliefMonthlyShifts;
  final List<int> fixedServiceWeekdays;
  final List<String> fixedServiceShifts;
  final List<String> serviceEntryTimes;
  final List<String> serviceExitTimes;
  final Map<int, List<String>> serviceEntryTimesByWeekday;
  final Map<int, List<String>> serviceExitTimesByWeekday;
  final bool customServiceParticipationEnabled;
  final String institutionId;
  final String institutionName;
  final String referenceDate;
  final int cycleDay;
  final double? stopLatitude;
  final double? stopLongitude;
  final String note;

  static List<String> shiftsForPattern(String pattern) {
    switch (pattern) {
      case threeShiftEarlyPattern:
        return threeShiftEarly;
      case twoShiftStandardPattern:
        return twoShiftStandard;
      case twoShiftEarlyPattern:
        return twoShiftEarly;
      default:
        return threeShiftStandard;
    }
  }

  static String patternLabel(String pattern) =>
      shiftsForPattern(pattern).join(' - ');

  static String inferPattern(String shift) {
    if (threeShiftEarly.contains(shift)) return threeShiftEarlyPattern;
    if (twoShiftEarly.contains(shift)) return twoShiftEarlyPattern;
    return threeShiftStandardPattern;
  }

  List<String> reliefShiftsForDate(DateTime date) {
    final key =
        '${date.year.toString().padLeft(4, '0')}-'
        '${date.month.toString().padLeft(2, '0')}-'
        '${date.day.toString().padLeft(2, '0')}';
    if (reliefMonthlyShifts.isNotEmpty) {
      return reliefMonthlyShifts[key] ?? const <String>[];
    }
    return reliefWeeklyShifts[date.weekday] ?? const <String>[];
  }

  bool serviceParticipationIncludes(
    DateTime date,
    String selectedShift, {
    bool isDistribution = false,
  }) {
    if (!customServiceParticipationEnabled) return true;
    final selectedDays = fixedServiceWeekdays;
    if (selectedDays.isEmpty) return false;
    if (selectedDays.isNotEmpty && !selectedDays.contains(date.weekday)) {
      return false;
    }
    final parts = ShiftCalculatorCompat.parts(selectedShift);
    if (parts == null) return true;
    final entries =
        serviceEntryTimesByWeekday[date.weekday] ?? serviceEntryTimes;
    final exits = serviceExitTimesByWeekday[date.weekday] ?? serviceExitTimes;
    if (isDistribution) {
      if (serviceExitTimesByWeekday.containsKey(date.weekday) &&
          exits.isEmpty) {
        return false;
      }
      if (exits.isNotEmpty && !exits.contains(parts.$2)) return false;
    } else {
      if (serviceEntryTimesByWeekday.containsKey(date.weekday) &&
          entries.isEmpty) {
        return false;
      }
      if (entries.isNotEmpty && !entries.contains(parts.$1)) return false;
    }
    // Bir önceki sürümde kaydedilen birleşik saat seçimlerini korur.
    if (!serviceEntryTimesByWeekday.containsKey(date.weekday) &&
        !serviceExitTimesByWeekday.containsKey(date.weekday) &&
        serviceEntryTimes.isEmpty &&
        serviceExitTimes.isEmpty &&
        fixedServiceShifts.isNotEmpty &&
        !fixedServiceShifts
            .map(ShiftCalculatorCompat.normalize)
            .contains(ShiftCalculatorCompat.normalize(selectedShift))) {
      return false;
    }
    return true;
  }

  Personnel copyWith({
    int? stopOrder,
    String? shift,
    String? workType,
    List<int>? leaveWeekdays,
    String? leaveMode,
    int? workDaysCount,
    int? leaveDaysCount,
    String? shiftDirection,
    String? shiftSystem,
    String? shiftPattern,
    String? shiftDefinitionId,
    List<String>? customShiftSequence,
    Map<int, List<String>>? reliefWeeklyShifts,
    Map<String, List<String>>? reliefMonthlyShifts,
    List<int>? fixedServiceWeekdays,
    List<String>? fixedServiceShifts,
    List<String>? serviceEntryTimes,
    List<String>? serviceExitTimes,
    Map<int, List<String>>? serviceEntryTimesByWeekday,
    Map<int, List<String>>? serviceExitTimesByWeekday,
    bool? customServiceParticipationEnabled,
    String? institutionId,
    String? institutionName,
    String? referenceDate,
    int? cycleDay,
  }) {
    return Personnel(
      id: id,
      fullName: fullName,
      phone: phone,
      whatsApp: whatsApp,
      stopName: stopName,
      stopOrder: stopOrder ?? this.stopOrder,
      shift: shift ?? this.shift,
      workType: workType ?? this.workType,
      leaveWeekdays: leaveWeekdays ?? this.leaveWeekdays,
      leaveMode: leaveMode ?? this.leaveMode,
      workDaysCount: workDaysCount ?? this.workDaysCount,
      leaveDaysCount: leaveDaysCount ?? this.leaveDaysCount,
      shiftDirection: shiftDirection ?? this.shiftDirection,
      shiftSystem: shiftSystem ?? this.shiftSystem,
      shiftPattern: shiftPattern ?? this.shiftPattern,
      shiftDefinitionId: shiftDefinitionId ?? this.shiftDefinitionId,
      customShiftSequence: customShiftSequence ?? this.customShiftSequence,
      reliefWeeklyShifts: reliefWeeklyShifts ?? this.reliefWeeklyShifts,
      reliefMonthlyShifts: reliefMonthlyShifts ?? this.reliefMonthlyShifts,
      fixedServiceWeekdays: fixedServiceWeekdays ?? this.fixedServiceWeekdays,
      fixedServiceShifts: fixedServiceShifts ?? this.fixedServiceShifts,
      serviceEntryTimes: serviceEntryTimes ?? this.serviceEntryTimes,
      serviceExitTimes: serviceExitTimes ?? this.serviceExitTimes,
      serviceEntryTimesByWeekday:
          serviceEntryTimesByWeekday ?? this.serviceEntryTimesByWeekday,
      serviceExitTimesByWeekday:
          serviceExitTimesByWeekday ?? this.serviceExitTimesByWeekday,
      customServiceParticipationEnabled:
          customServiceParticipationEnabled ??
          this.customServiceParticipationEnabled,
      institutionId: institutionId ?? this.institutionId,
      institutionName: institutionName ?? this.institutionName,
      referenceDate: referenceDate ?? this.referenceDate,
      cycleDay: cycleDay ?? this.cycleDay,
      stopLatitude: stopLatitude,
      stopLongitude: stopLongitude,
      note: note,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'fullName': fullName,
    'phone': phone,
    'whatsApp': whatsApp,
    'stopName': stopName,
    'stopOrder': stopOrder,
    'shift': shift,
    'workType': workType,
    'leaveWeekdays': leaveWeekdays,
    'leaveMode': leaveMode,
    'workDaysCount': workDaysCount,
    'leaveDaysCount': leaveDaysCount,
    'shiftDirection': shiftDirection,
    'shiftDefinitionId': shiftDefinitionId,
    'customShiftSequence': customShiftSequence,
    'reliefWeeklyShifts': {
      for (final entry in reliefWeeklyShifts.entries)
        entry.key.toString(): entry.value,
    },
    'reliefMonthlyShifts': {
      for (final entry in reliefMonthlyShifts.entries) entry.key: entry.value,
    },
    'fixedServiceWeekdays': fixedServiceWeekdays,
    'fixedServiceShifts': fixedServiceShifts,
    'serviceEntryTimes': serviceEntryTimes,
    'serviceExitTimes': serviceExitTimes,
    'serviceEntryTimesByWeekday': {
      for (final entry in serviceEntryTimesByWeekday.entries)
        entry.key.toString(): entry.value,
    },
    'serviceExitTimesByWeekday': {
      for (final entry in serviceExitTimesByWeekday.entries)
        entry.key.toString(): entry.value,
    },
    'customServiceParticipationEnabled': customServiceParticipationEnabled,
    'institutionId': institutionId,
    'institutionName': institutionName,
    'referenceDate': referenceDate,
    'cycleDay': cycleDay,
    'stopLatitude': stopLatitude,
    'stopLongitude': stopLongitude,
    'note': note,
  };

  factory Personnel.fromJson(Map<String, dynamic> json) {
    final rawShift = json['shift'] as String? ?? '08 / 16';
    final hasFixedSuffix = rawShift.endsWith(' Sabit');
    final savedShift = hasFixedSuffix
        ? rawShift.substring(0, rawShift.length - ' Sabit'.length)
        : rawShift;
    final savedWorkType =
        json['workType'] as String? ??
        (savedShift == '-- / --' ? fixedWorkType : rotatingWorkType);
    final leaveDays = (json['leaveWeekdays'] as List<dynamic>?)
        ?.map((day) => (day as num).toInt())
        .toList();
    final oldWorkingDays = (json['workingWeekdays'] as List<dynamic>?)
        ?.map((day) => (day as num).toInt())
        .toSet();
    final migratedLeaveDays =
        leaveDays ??
        (savedWorkType == reliefWorkType && oldWorkingDays != null
            ? [
                for (var day = 1; day <= 7; day++)
                  if (!oldWorkingDays.contains(day)) day,
              ]
            : const <int>[]);
    final pattern = json['shiftPattern'] as String? ?? inferPattern(savedShift);
    final system =
        json['shiftSystem'] as String? ??
        (pattern == twoShiftStandardPattern || pattern == twoShiftEarlyPattern
            ? twoShiftSystem
            : threeShiftSystem);
    final rawReliefSchedule =
        json['reliefWeeklyShifts'] as Map<String, dynamic>? ??
        const <String, dynamic>{};
    final reliefSchedule = <int, List<String>>{
      for (final entry in rawReliefSchedule.entries)
        if (int.tryParse(entry.key) != null)
          int.parse(entry.key): (entry.value as List<dynamic>)
              .map((value) => value.toString())
              .toList(),
    };
    final rawMonthlyReliefSchedule =
        json['reliefMonthlyShifts'] as Map<String, dynamic>? ??
        const <String, dynamic>{};
    final monthlyReliefSchedule = <String, List<String>>{
      for (final entry in rawMonthlyReliefSchedule.entries)
        entry.key: (entry.value as List<dynamic>)
            .map((value) => value.toString())
            .toList(),
    };
    // Eski Dinlendirici kayıtlarını kaybetmemek için daha önce seçilmiş
    // vardiyayı izinli olmayan günlere taşır.
    if (reliefSchedule.isEmpty && savedWorkType == reliefWorkType) {
      for (var weekday = 1; weekday <= 7; weekday++) {
        if (!migratedLeaveDays.contains(weekday)) {
          reliefSchedule[weekday] = [savedShift];
        }
      }
    }

    return Personnel(
      id: json['id'] as String? ?? '',
      fullName: json['fullName'] as String? ?? '',
      phone: json['phone'] as String? ?? '',
      whatsApp: json['whatsApp'] as String? ?? '',
      stopName: json['stopName'] as String? ?? '',
      stopOrder: (json['stopOrder'] as num?)?.toInt() ?? 0,
      shift: savedShift,
      workType: hasFixedSuffix ? fixedWorkType : savedWorkType,
      leaveWeekdays: migratedLeaveDays,
      leaveMode: _normalizeLeaveMode(json['leaveMode'] as String?),
      workDaysCount: (json['workDaysCount'] as num?)?.toInt() ?? 6,
      leaveDaysCount: (json['leaveDaysCount'] as num?)?.toInt() ?? 1,
      shiftDirection: _normalizeDirection(json['shiftDirection'] as String?),
      shiftSystem: system,
      shiftPattern: pattern,
      shiftDefinitionId: json['shiftDefinitionId'] as String? ?? '',
      customShiftSequence:
          (json['customShiftSequence'] as List<dynamic>?)
              ?.map((value) => value.toString())
              .toList() ??
          const [],
      reliefWeeklyShifts: reliefSchedule,
      reliefMonthlyShifts: monthlyReliefSchedule,
      fixedServiceWeekdays:
          (json['fixedServiceWeekdays'] as List<dynamic>?)
              ?.map((value) => (value as num).toInt())
              .toList() ??
          const [],
      fixedServiceShifts:
          (json['fixedServiceShifts'] as List<dynamic>?)
              ?.map((value) => value.toString())
              .toList() ??
          const [],
      serviceEntryTimes:
          (json['serviceEntryTimes'] as List<dynamic>?)
              ?.map((value) => value.toString())
              .toList() ??
          const [],
      serviceExitTimes:
          (json['serviceExitTimes'] as List<dynamic>?)
              ?.map((value) => value.toString())
              .toList() ??
          const [],
      serviceEntryTimesByWeekday: _weekdayTimesFromJson(
        json['serviceEntryTimesByWeekday'],
      ),
      serviceExitTimesByWeekday: _weekdayTimesFromJson(
        json['serviceExitTimesByWeekday'],
      ),
      customServiceParticipationEnabled:
          json['customServiceParticipationEnabled'] as bool? ?? false,
      institutionId: json['institutionId'] as String? ?? '',
      institutionName: json['institutionName'] as String? ?? '',
      referenceDate:
          json['referenceDate'] as String? ??
          DateTime.now().toIso8601String().substring(0, 10),
      cycleDay: (json['cycleDay'] as num?)?.toInt() ?? 1,
      stopLatitude: (json['stopLatitude'] as num?)?.toDouble(),
      stopLongitude: (json['stopLongitude'] as num?)?.toDouble(),
      note: json['note'] as String? ?? '',
    );
  }

  static String _normalizeLeaveMode(String? value) {
    if (value == null) return weeklyLeaveMode;
    if (value.contains('alışma') ||
        value.contains('Döng') ||
        value.contains('DÃ¶n') ||
        value.contains('DÃ¶ng')) {
      return cycleLeaveMode;
    }
    return weeklyLeaveMode;
  }

  static String _normalizeDirection(String? value) {
    if (value != null &&
        (value.contains('İleri') || value.contains('Ä°leri'))) {
      return shiftForward;
    }
    return shiftBackward;
  }

  static Map<int, List<String>> _weekdayTimesFromJson(dynamic value) {
    if (value is! Map) return const {};
    return {
      for (final entry in value.entries)
        if (int.tryParse(entry.key.toString()) != null && entry.value is List)
          int.parse(entry.key.toString()): (entry.value as List)
              .map((item) => item.toString())
              .toList(),
    };
  }
}

// Model katmanında servis bağımlılığı oluşturmadan saat yazımlarını eşitler.
class ShiftCalculatorCompat {
  static String normalize(String shift) => shift
      .trim()
      .replaceAll(':00', '')
      .replaceAll('-', '/')
      .replaceAll(RegExp(r'\s+'), '');

  static (String, String)? parts(String shift) {
    final values = shift.split('/').map((value) => value.trim()).toList();
    if (values.length != 2) return null;
    return (values.first, values.last);
  }
}
