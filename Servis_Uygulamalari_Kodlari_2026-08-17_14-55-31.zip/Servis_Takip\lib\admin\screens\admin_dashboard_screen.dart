import 'package:flutter/material.dart';

import '../models/company.dart';
import '../services/admin_repository.dart';
import 'company_users_screen.dart';
import 'phone_permissions_screen.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({required this.repository, super.key});

  final AdminRepository repository;

  Future<void> _openUsers(BuildContext context, Company company) async {
    try {
      await repository.ensureCompanyLoginCode(company);
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Şirket kodu hazırlanamadı: $error')),
      );
      return;
    }
    if (!context.mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) =>
            CompanyUsersScreen(company: company, repository: repository),
      ),
    );
  }

  Future<void> _openEditor(BuildContext context, {Company? company}) async {
    final result = await showDialog<_CompanyEditorResult>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _CompanyEditorDialog(company: company),
    );
    if (result == null || !context.mounted) return;

    try {
      if (company == null) {
        await repository.createCompany(
          name: result.name,
          planName: result.planName,
          limits: result.limits,
          expiresAt: result.expiresAt,
        );
      } else {
        await repository.updateCompany(
          companyId: company.id,
          planName: result.planName,
          limits: result.limits,
          active: result.active,
          expiresAt: result.expiresAt,
        );
      }
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            company == null
                ? '${result.name} oluşturuldu.'
                : '${result.name} güncellendi.',
          ),
        ),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('İşlem tamamlanamadı: $error')));
    }
  }

  void _openPhonePermissions(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => PhonePermissionsScreen(repository: repository),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Servis Takip Yönetici Paneli'),
        actions: [
          IconButton(
            onPressed: repository.signOut,
            icon: const Icon(Icons.logout_rounded),
            tooltip: 'Çıkış Yap',
          ),
          const SizedBox(width: 8),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _openEditor(context),
        icon: const Icon(Icons.add_business_rounded),
        label: const Text('Şirket Ekle'),
      ),
      body: StreamBuilder<List<Company>>(
        stream: repository.watchCompanies(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Şirketler yüklenemedi.\n${snapshot.error}',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final companies = snapshot.data!;
          return LayoutBuilder(
            builder: (context, constraints) {
              final columns = constraints.maxWidth >= 1100
                  ? 3
                  : constraints.maxWidth >= 700
                  ? 2
                  : 1;
              return CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 18, 20, 4),
                      child: Card(
                        child: ListTile(
                          leading: const CircleAvatar(
                            child: Icon(Icons.admin_panel_settings_rounded),
                          ),
                          title: const Text(
                            'Yetkilendirmeler',
                            style: TextStyle(fontWeight: FontWeight.w800),
                          ),
                          subtitle: const Text('Telefon Yetkileri'),
                          trailing: const Icon(Icons.chevron_right_rounded),
                          onTap: () => _openPhonePermissions(context),
                        ),
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: _SummaryHeader(companies: companies),
                  ),
                  if (companies.isEmpty)
                    const SliverFillRemaining(
                      hasScrollBody: false,
                      child: Center(
                        child: Text(
                          'Henüz şirket yok.\nŞirket Ekle düğmesiyle başlayın.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 18,
                            color: Color(0xFF52657B),
                          ),
                        ),
                      ),
                    )
                  else
                    SliverPadding(
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                      sliver: SliverGrid(
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: columns,
                          mainAxisSpacing: 14,
                          crossAxisSpacing: 14,
                          mainAxisExtent: columns == 1 ? 440 : 420,
                        ),
                        delegate: SliverChildBuilderDelegate((context, index) {
                          final company = companies[index];
                          return _CompanyCard(
                            company: company,
                            onUsers: () => _openUsers(context, company),
                            onEdit: () =>
                                _openEditor(context, company: company),
                          );
                        }, childCount: companies.length),
                      ),
                    ),
                ],
              );
            },
          );
        },
      ),
    );
  }
}

class _SummaryHeader extends StatelessWidget {
  const _SummaryHeader({required this.companies});

  final List<Company> companies;

  @override
  Widget build(BuildContext context) {
    final activeCount = companies
        .where((company) => company.active && !company.isExpired)
        .length;
    final userCount = companies.fold<int>(
      0,
      (total, company) => total + company.usage.users,
    );
    return LayoutBuilder(
      builder: (context, constraints) {
        const spacing = 12.0;
        final availableWidth = constraints.maxWidth - 40;
        final boxWidth = availableWidth < 600
            ? availableWidth
            : (availableWidth - (spacing * 2)) / 3;
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Wrap(
            spacing: spacing,
            runSpacing: spacing,
            children: [
              _SummaryBox(
                width: boxWidth,
                icon: Icons.business_rounded,
                label: 'Toplam Şirket',
                value: '${companies.length}',
              ),
              _SummaryBox(
                width: boxWidth,
                icon: Icons.verified_rounded,
                label: 'Aktif Şirket',
                value: '$activeCount',
              ),
              _SummaryBox(
                width: boxWidth,
                icon: Icons.people_alt_rounded,
                label: 'Toplam Kullanıcı',
                value: '$userCount',
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SummaryBox extends StatelessWidget {
  const _SummaryBox({
    required this.width,
    required this.icon,
    required this.label,
    required this.value,
  });

  final double width;
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(child: Icon(icon)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      value,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CompanyCard extends StatelessWidget {
  const _CompanyCard({
    required this.company,
    required this.onUsers,
    required this.onEdit,
  });

  final Company company;
  final VoidCallback onUsers;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final available = company.active && !company.isExpired;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: available
                      ? const Color(0xFFE8F5E9)
                      : const Color(0xFFFFEBEE),
                  child: Icon(
                    Icons.business_rounded,
                    color: available
                        ? const Color(0xFF0B6E4F)
                        : const Color(0xFFB3261E),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        company.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(company.planName),
                      Text(
                        'Giriş kodu: ${company.loginCode}',
                        style: const TextStyle(
                          color: Color(0xFF52657B),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
                Chip(
                  label: Text(available ? 'Aktif' : 'Kapalı'),
                  avatar: Icon(
                    available ? Icons.check_circle : Icons.block,
                    size: 18,
                  ),
                ),
              ],
            ),
            const Divider(height: 28),
            _UsageLine(
              label: 'Kullanıcı',
              used: company.usage.users,
              limit: company.limits.maxUsers,
            ),
            _UsageLine(
              label: 'Kurum',
              used: company.usage.institutions,
              limit: company.limits.maxInstitutions,
            ),
            _UsageLine(
              label: 'Personel',
              used: company.usage.personnel,
              limit: company.limits.maxPersonnel,
            ),
            _UsageLine(
              label: 'Durak',
              used: company.usage.stops,
              limit: company.limits.maxStops,
            ),
            _UsageLine(
              label: 'Araç',
              used: company.usage.vehicles,
              limit: company.limits.maxVehicles,
            ),
            const Spacer(),
            Text(
              company.expiresAt == null
                  ? 'Bitiş tarihi: Süresiz'
                  : 'Bitiş tarihi: ${_dateText(company.expiresAt!)}',
              style: TextStyle(
                color: company.isExpired
                    ? const Color(0xFFB3261E)
                    : const Color(0xFF52657B),
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: onUsers,
                    icon: const Icon(Icons.group_rounded),
                    label: const Text('Kullanıcılar'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.outlined(
                  onPressed: onEdit,
                  icon: const Icon(Icons.tune_rounded),
                  tooltip: 'Paket ve sınırları düzenle',
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  static String _dateText(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}.'
      '${date.month.toString().padLeft(2, '0')}.${date.year}';
}

class _UsageLine extends StatelessWidget {
  const _UsageLine({
    required this.label,
    required this.used,
    required this.limit,
  });

  final String label;
  final int used;
  final int limit;

  @override
  Widget build(BuildContext context) {
    final progress = limit <= 0
        ? 1.0
        : (used / limit).clamp(0.0, 1.0).toDouble();
    final full = used >= limit;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: Text(label)),
              Text(
                '$used / $limit',
                style: TextStyle(
                  color: full ? const Color(0xFFB3261E) : null,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          LinearProgressIndicator(
            value: progress,
            color: full ? const Color(0xFFB3261E) : null,
          ),
        ],
      ),
    );
  }
}

class _CompanyEditorResult {
  const _CompanyEditorResult({
    required this.name,
    required this.planName,
    required this.limits,
    required this.active,
    this.expiresAt,
  });

  final String name;
  final String planName;
  final CompanyLimits limits;
  final bool active;
  final DateTime? expiresAt;
}

class _CompanyEditorDialog extends StatefulWidget {
  const _CompanyEditorDialog({this.company});

  final Company? company;

  @override
  State<_CompanyEditorDialog> createState() => _CompanyEditorDialogState();
}

class _CompanyEditorDialogState extends State<_CompanyEditorDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _planController;
  late final TextEditingController _usersController;
  late final TextEditingController _institutionsController;
  late final TextEditingController _personnelController;
  late final TextEditingController _stopsController;
  late final TextEditingController _vehiclesController;
  late bool _active;
  DateTime? _expiresAt;

  @override
  void initState() {
    super.initState();
    final company = widget.company;
    _nameController = TextEditingController(text: company?.name ?? '');
    _planController = TextEditingController(
      text: company?.planName ?? 'Özel Paket',
    );
    _usersController = TextEditingController(
      text: '${company?.limits.maxUsers ?? 1}',
    );
    _institutionsController = TextEditingController(
      text: '${company?.limits.maxInstitutions ?? 10}',
    );
    _personnelController = TextEditingController(
      text: '${company?.limits.maxPersonnel ?? 30}',
    );
    _stopsController = TextEditingController(
      text: '${company?.limits.maxStops ?? 15}',
    );
    _vehiclesController = TextEditingController(
      text: '${company?.limits.maxVehicles ?? 1}',
    );
    _active = company?.active ?? true;
    _expiresAt = company?.expiresAt;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _planController.dispose();
    _usersController.dispose();
    _institutionsController.dispose();
    _personnelController.dispose();
    _stopsController.dispose();
    _vehiclesController.dispose();
    super.dispose();
  }

  Future<void> _chooseExpiry() async {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final savedDate = _expiresAt;
    final initialDate = savedDate != null && !savedDate.isBefore(today)
        ? savedDate
        : today.add(const Duration(days: 365));

    final selected = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: today,
      lastDate: today.add(const Duration(days: 3650)),
      helpText: 'PAKET BİTİŞ TARİHİ',
    );
    if (selected != null) setState(() => _expiresAt = selected);
  }

  int? _positiveInt(String value) {
    final number = int.tryParse(value);
    return number != null && number > 0 ? number : null;
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.pop(
      context,
      _CompanyEditorResult(
        name: _nameController.text.trim(),
        planName: _planController.text.trim(),
        limits: CompanyLimits(
          maxUsers: int.parse(_usersController.text),
          maxInstitutions: int.parse(_institutionsController.text),
          maxPersonnel: int.parse(_personnelController.text),
          maxStops: int.parse(_stopsController.text),
          maxVehicles: int.parse(_vehiclesController.text),
        ),
        active: _active,
        expiresAt: _expiresAt,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.company == null ? 'Şirket Ekle' : 'Şirketi Düzenle'),
      content: SizedBox(
        width: 520,
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  enabled: widget.company == null,
                  decoration: const InputDecoration(
                    labelText: 'Şirket Adı',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Şirket adını girin.'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _planController,
                  decoration: const InputDecoration(
                    labelText: 'Paket Adı',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Paket adını girin.'
                      : null,
                ),
                const SizedBox(height: 12),
                GridView.count(
                  crossAxisCount: 2,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  childAspectRatio: 2.7,
                  children: [
                    _limitField(_usersController, 'Kullanıcı Sınırı'),
                    _limitField(_institutionsController, 'Kurum Sınırı'),
                    _limitField(_personnelController, 'Personel Sınırı'),
                    _limitField(_stopsController, 'Durak Sınırı'),
                    _limitField(_vehiclesController, 'Araç Sınırı'),
                  ],
                ),
                const SizedBox(height: 8),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Şirket aktif'),
                  value: _active,
                  onChanged: (value) => setState(() => _active = value),
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.event_rounded),
                  title: const Text('Paket bitiş tarihi'),
                  subtitle: Text(
                    _expiresAt == null
                        ? 'Süresiz'
                        : _CompanyCard._dateText(_expiresAt!),
                  ),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (_expiresAt != null)
                        IconButton(
                          onPressed: () => setState(() => _expiresAt = null),
                          icon: const Icon(Icons.clear),
                          tooltip: 'Süresiz yap',
                        ),
                      IconButton(
                        onPressed: _chooseExpiry,
                        icon: const Icon(Icons.edit_calendar_rounded),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton.icon(
          onPressed: _save,
          icon: const Icon(Icons.save_rounded),
          label: const Text('Kaydet'),
        ),
      ],
    );
  }

  Widget _limitField(TextEditingController controller, String label) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
      ),
      validator: (value) => value == null || _positiveInt(value) == null
          ? '1 veya daha büyük olmalı.'
          : null,
    );
  }
}
