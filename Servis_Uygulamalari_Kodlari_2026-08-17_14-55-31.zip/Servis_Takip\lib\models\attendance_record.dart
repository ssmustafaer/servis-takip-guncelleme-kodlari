class AttendanceRecord {
  const AttendanceRecord({
    required this.personId,
    required this.date,
    required this.shift,
    required this.status,
    required this.recordedAt,
    required this.latitude,
    required this.longitude,
    this.serviceId,
    this.markedByDriver = true,
  });

  final String personId;
  final String date;
  final String shift;
  final String status;
  final String recordedAt;
  final double latitude;
  final double longitude;
  final String? serviceId;
  final bool markedByDriver;

  Map<String, dynamic> toJson() => {
    'personId': personId,
    'date': date,
    'shift': shift,
    'status': status,
    'recordedAt': recordedAt,
    'latitude': latitude,
    'longitude': longitude,
    'serviceId': serviceId,
    'markedByDriver': markedByDriver,
  };

  factory AttendanceRecord.fromJson(Map<String, dynamic> json) =>
      AttendanceRecord(
        personId: json['personId'] as String,
        date: json['date'] as String,
        shift: json['shift'] as String,
        status: json['status'] as String,
        recordedAt: json['recordedAt'] as String,
        latitude: (json['latitude'] as num).toDouble(),
        longitude: (json['longitude'] as num).toDouble(),
        serviceId: json['serviceId'] as String?,
        markedByDriver: json['markedByDriver'] as bool? ?? true,
      );
}
