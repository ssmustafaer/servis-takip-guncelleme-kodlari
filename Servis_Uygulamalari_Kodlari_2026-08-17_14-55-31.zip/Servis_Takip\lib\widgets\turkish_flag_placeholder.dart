import 'package:flutter/material.dart';

/// Geçici bayrak alanı. Uygulamanın nihai logosu hazır olduğunda görsel asset
/// ile değiştirilecek.
class TurkishFlagPlaceholder extends StatelessWidget {
  const TurkishFlagPlaceholder({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 116,
      height: 76,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: const Color(0xFFE30A17),
        borderRadius: BorderRadius.circular(8),
        boxShadow: const [
          BoxShadow(color: Color(0x24000000), blurRadius: 10, offset: Offset(0, 4)),
        ],
      ),
      child: const Text(
        '🇹🇷',
        style: TextStyle(fontSize: 46),
        semanticsLabel: 'Türk bayrağı yer tutucusu',
      ),
    );
  }
}
