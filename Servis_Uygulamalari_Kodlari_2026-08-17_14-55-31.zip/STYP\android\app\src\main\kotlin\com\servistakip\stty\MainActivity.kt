package com.servistakip.stty

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

class MainActivity : FlutterActivity() {
    private val channelName = "com.servistakip.stty/image_picker"
    private val imageRequestCode = 7001
    private var pendingResult: MethodChannel.Result? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                if (call.method != "pickImage") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                if (pendingResult != null) {
                    result.error("picker_busy", "Resim seçme penceresi zaten açık.", null)
                    return@setMethodCallHandler
                }
                pendingResult = result
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                startActivityForResult(intent, imageRequestCode)
            }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != imageRequestCode) return
        val result = pendingResult
        pendingResult = null
        if (resultCode != Activity.RESULT_OK || data?.data == null) {
            result?.success(null)
            return
        }
        try {
            val sourceBitmap = contentResolver.openInputStream(data.data!!)?.use { input ->
                BitmapFactory.decodeStream(input)
            }
            if (sourceBitmap == null) {
                result?.error("image_read", "Seçilen resim okunamadı.", null)
                return
            }
            val maxDimension = 1000
            val largestSide = maxOf(sourceBitmap.width, sourceBitmap.height)
            val selectedBitmap = if (largestSide > maxDimension) {
                val ratio = maxDimension.toDouble() / largestSide.toDouble()
                Bitmap.createScaledBitmap(
                    sourceBitmap,
                    (sourceBitmap.width * ratio).toInt(),
                    (sourceBitmap.height * ratio).toInt(),
                    true,
                )
            } else {
                sourceBitmap
            }
            val output = ByteArrayOutputStream()
            selectedBitmap.compress(Bitmap.CompressFormat.JPEG, 75, output)
            val bytes = output.toByteArray()
            if (selectedBitmap !== sourceBitmap) selectedBitmap.recycle()
            sourceBitmap.recycle()
            result?.success(Base64.encodeToString(bytes, Base64.NO_WRAP))
        } catch (error: Exception) {
            result?.error("image_read", "Resim okunamadı: ${error.message}", null)
        }
    }
}
