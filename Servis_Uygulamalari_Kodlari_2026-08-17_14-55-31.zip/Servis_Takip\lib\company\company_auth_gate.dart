import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../screens/home_screen.dart';
import 'models/company_session.dart';
import 'screens/company_login_screen.dart';
import 'services/company_auth_repository.dart';
import '../services/company_cloud_storage.dart';

class CompanyAuthGate extends StatefulWidget {
  const CompanyAuthGate({super.key});

  @override
  State<CompanyAuthGate> createState() => _CompanyAuthGateState();
}

class _CompanyAuthGateState extends State<CompanyAuthGate> {
  final _repository = CompanyAuthRepository();
  String? _checkedUserId;
  Future<bool>? _adminCheck;
  Future<CompanySession>? _companySession;

  void _prepareUser(User user) {
    if (_checkedUserId == user.uid) return;
    _checkedUserId = user.uid;
    _adminCheck = _repository.isSystemAdmin(user);
    _companySession = null;
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: _repository.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        final user = snapshot.data;
        if (user == null) {
          CompanyCloudStorage.setEmergencyCompany(null);
          _checkedUserId = null;
          _adminCheck = null;
          _companySession = null;
          return CompanyLoginScreen(repository: _repository);
        }
        _prepareUser(user);
        return FutureBuilder<bool>(
          future: _adminCheck,
          builder: (context, adminSnapshot) {
            if (!adminSnapshot.hasData) {
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            }
            if (adminSnapshot.data == true) {
              return _EmergencyCompanySelector(
                repository: _repository,
                user: user,
              );
            }
            _companySession ??= _repository.loadSession(user);
            return FutureBuilder<CompanySession>(
              future: _companySession,
              builder: (context, sessionSnapshot) {
                if (sessionSnapshot.connectionState ==
                    ConnectionState.waiting) {
                  return const Scaffold(
                    body: Center(child: CircularProgressIndicator()),
                  );
                }
                if (sessionSnapshot.hasError) {
                  return Scaffold(
                    body: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.error_outline_rounded, size: 56),
                            const SizedBox(height: 12),
                            Text(
                              _friendlyError(sessionSnapshot.error),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 16),
                            FilledButton.icon(
                              onPressed: () {
                                setState(() {
                                  _companySession = _repository.loadSession(
                                    user,
                                  );
                                });
                              },
                              icon: const Icon(Icons.refresh_rounded),
                              label: const Text('TEKRAR DENE'),
                            ),
                            const SizedBox(height: 8),
                            FilledButton(
                              onPressed: _repository.signOut,
                              child: const Text('ÇIKIŞ YAP'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                }
                return HomeScreen(session: sessionSnapshot.data!);
              },
            );
          },
        );
      },
    );
  }

  String _friendlyError(Object? error) {
    if (error is FirebaseException && error.code == 'resource-exhausted') {
      return 'Bulut kullanım kotası geçici olarak doldu. '
          'Son kayıtlı bilgilerle açılamadı. Lütfen daha sonra tekrar deneyin.';
    }
    return error.toString().replaceFirst('Bad state: ', '');
  }
}

class _EmergencyCompanySelector extends StatefulWidget {
  const _EmergencyCompanySelector({
    required this.repository,
    required this.user,
  });

  final CompanyAuthRepository repository;
  final User user;

  @override
  State<_EmergencyCompanySelector> createState() =>
      _EmergencyCompanySelectorState();
}

class _EmergencyCompanySelectorState extends State<_EmergencyCompanySelector> {
  final _searchController = TextEditingController();
  CompanySession? _session;
  String _query = '';
  String? _error;
  bool _loading = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _openCompany(String companyId) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final session = await widget.repository.loadEmergencySession(
        user: widget.user,
        companyId: companyId,
      );
      if (mounted) setState(() => _session = session);
    } catch (error) {
      if (mounted) {
        setState(
          () => _error = error.toString().replaceFirst('Bad state: ', ''),
        );
      }
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_session != null) {
      return HomeScreen(
        session: _session!,
        onExitEmergency: () {
          CompanyCloudStorage.setEmergencyCompany(null);
          setState(() => _session = null);
        },
      );
    }
    return Scaffold(
      appBar: AppBar(
        title: const Text('Acil Yönetici Erişimi'),
        actions: [
          IconButton(
            onPressed: widget.repository.signOut,
            icon: const Icon(Icons.logout_rounded),
            tooltip: 'Çıkış yap',
          ),
        ],
      ),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: widget.repository.watchEmergencyCompanies(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Şirketler alınamadı: ${snapshot.error}'),
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final query = _query.trim().toLowerCase();
          final companies = snapshot.data!.docs.where((document) {
            final data = document.data();
            if (data['deletedAt'] != null) return false;
            final name = (data['name'] as String? ?? '').toLowerCase();
            final code = (data['loginCode'] as String? ?? '').toLowerCase();
            return query.isEmpty ||
                name.contains(query) ||
                code.contains(query);
          }).toList();
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Card(
                color: Color(0xFFFFF1D6),
                child: Padding(
                  padding: EdgeInsets.all(14),
                  child: Text(
                    'Bu giriş sistem yöneticisine özeldir. Seçilen şirkete yapılan acil giriş kayıt altına alınır.',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _searchController,
                autofocus: true,
                onChanged: (value) => setState(() => _query = value),
                decoration: const InputDecoration(
                  labelText: 'Şirket adı veya kodu ara',
                  prefixIcon: Icon(Icons.search_rounded),
                  border: OutlineInputBorder(),
                ),
              ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(
                    _error!,
                    style: const TextStyle(color: Colors.red),
                  ),
                ),
              const SizedBox(height: 10),
              if (_loading) const LinearProgressIndicator(),
              for (final company in companies)
                Card(
                  child: ListTile(
                    leading: const CircleAvatar(
                      child: Icon(Icons.business_rounded),
                    ),
                    title: Text(
                      company.data()['name'] as String? ?? 'Şirket',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    subtitle: Text(
                      'Şirket kodu: ${company.data()['loginCode'] ?? '-'}',
                    ),
                    trailing: const Icon(Icons.login_rounded),
                    enabled: !_loading,
                    onTap: () => _openCompany(company.id),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}
