import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart' as google;
import 'package:latlong2/latlong.dart';

class MapPickerScreen extends StatefulWidget {
  const MapPickerScreen({
    required this.initialLocation,
    this.selectedLocation,
    this.title = 'Haritadan Konum Seç',
    super.key,
  });

  final LatLng initialLocation;
  final LatLng? selectedLocation;
  final String title;

  @override
  State<MapPickerScreen> createState() => _MapPickerScreenState();
}

class _MapPickerScreenState extends State<MapPickerScreen> {
  google.GoogleMapController? _controller;
  late google.LatLng _selectedLocation;
  google.MapType _mapType = google.MapType.normal;
  bool _gettingLocation = false;

  @override
  void initState() {
    super.initState();
    final initial = widget.selectedLocation ?? widget.initialLocation;
    _selectedLocation = google.LatLng(initial.latitude, initial.longitude);
  }

  Future<void> _goToCurrentLocation() async {
    if (_gettingLocation) return;
    if (!await Geolocator.isLocationServiceEnabled()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Telefonun konum hizmetini açın.')),
        );
      }
      return;
    }
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Konum izni verilmedi.')));
      }
      return;
    }
    setState(() => _gettingLocation = true);
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      final point = google.LatLng(position.latitude, position.longitude);
      _selectedLocation = point;
      await _controller?.animateCamera(
        google.CameraUpdate.newLatLngZoom(point, 17),
      );
      if (mounted) setState(() {});
    } finally {
      if (mounted) setState(() => _gettingLocation = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          IconButton(
            tooltip: _mapType == google.MapType.normal
                ? 'Uydu görünümü'
                : 'Harita görünümü',
            onPressed: () => setState(() {
              _mapType = _mapType == google.MapType.normal
                  ? google.MapType.hybrid
                  : google.MapType.normal;
            }),
            icon: const Icon(Icons.layers_rounded),
          ),
        ],
      ),
      body: Stack(
        children: [
          google.GoogleMap(
            initialCameraPosition: google.CameraPosition(
              target: _selectedLocation,
              zoom: 15,
            ),
            mapType: _mapType,
            myLocationButtonEnabled: false,
            myLocationEnabled: false,
            zoomControlsEnabled: false,
            onMapCreated: (controller) => _controller = controller,
            onCameraMove: (position) => _selectedLocation = position.target,
            onCameraIdle: () => setState(() {}),
          ),
          const IgnorePointer(
            child: Center(
              child: Padding(
                padding: EdgeInsets.only(bottom: 42),
                child: Icon(
                  Icons.location_on_rounded,
                  size: 54,
                  color: Colors.red,
                  shadows: [Shadow(color: Colors.white, blurRadius: 5)],
                ),
              ),
            ),
          ),
          Positioned(
            right: 16,
            bottom: 92,
            child: FloatingActionButton.extended(
              heroTag: 'current-location',
              onPressed: _gettingLocation ? null : _goToCurrentLocation,
              icon: _gettingLocation
                  ? const SizedBox.square(
                      dimension: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.my_location_rounded),
              label: const Text('KONUMUM'),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: SafeArea(
              top: false,
              child: Container(
                color: Theme.of(context).scaffoldBackgroundColor,
                padding: const EdgeInsets.all(16),
                child: SizedBox(
                  width: double.infinity,
                  height: 56,
                  child: FilledButton.icon(
                    onPressed: () => Navigator.pop(
                      context,
                      LatLng(
                        _selectedLocation.latitude,
                        _selectedLocation.longitude,
                      ),
                    ),
                    icon: const Icon(Icons.check_rounded),
                    label: const Text('BU KONUMU KAYDET'),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
