import 'package:flutter/material.dart';

import '../models/stop.dart';
import '../models/institution.dart';
import '../services/institution_storage.dart';
import '../services/personnel_storage.dart';
import '../services/stop_storage.dart';
import '../services/deleted_records_storage.dart';
import 'stop_form_screen.dart';

class StopsScreen extends StatefulWidget {
  const StopsScreen({super.key});

  @override
  State<StopsScreen> createState() => _StopsScreenState();
}

class _StopsScreenState extends State<StopsScreen> {
  bool _loading = true;
  List<Stop> _stops = [];
  List<Institution> _institutions = [];
  String? _filterRootId;
  String? _filterChildId;
  String? _filterGrandchildId;

  @override
  void initState() {
    super.initState();
    _loadStops();
  }

  Future<void> _loadStops() async {
    final result = await Future.wait([
      StopStorage.readAll(),
      InstitutionStorage.readAll(),
    ]);
    if (!mounted) return;
    final loadedStops = result[0] as List<Stop>;
    _institutions = result[1] as List<Institution>;
    final normalizedStops = _normalizeGroupOrders(loadedStops);
    setState(() {
      _stops = normalizedStops;
      _loading = false;
    });
    final orderChanged = loadedStops.length == normalizedStops.length &&
        loadedStops.any((stop) {
          final normalized = normalizedStops.firstWhere(
            (item) => item.id == stop.id,
          );
          return normalized.order != stop.order;
        });
    if (orderChanged) {
      await StopStorage.saveAll(normalizedStops);
      await _syncPersonnelStopOrders(normalizedStops);
    }
  }

  List<Institution> _children(String? parentId) => Institution.childrenOf(
    _institutions,
    parentId,
  ).where((item) => item.active).toList();

  void _restoreFilter(String? institutionId) {
    Institution? selected;
    for (final item in _institutions) {
      if (item.id == institutionId) {
        selected = item;
        break;
      }
    }
    if (selected == null) return;
    final byId = {for (final item in _institutions) item.id: item};
    final path = <Institution>[selected];
    var parentId = selected.parentId;
    while (parentId != null && parentId.isNotEmpty) {
      final parent = byId[parentId];
      if (parent == null) break;
      path.insert(0, parent);
      parentId = parent.parentId;
    }
    _filterRootId = path.isNotEmpty ? path[0].id : null;
    _filterChildId = path.length > 1 ? path[1].id : null;
    _filterGrandchildId = path.length > 2 ? path[2].id : null;
  }

  String? get _filterInstitutionId =>
      _filterGrandchildId ?? _filterChildId ?? _filterRootId;

  List<Stop> get _visibleStops {
    final selectedId = _filterInstitutionId;
    if (selectedId == null) return const [];
    final ids = Institution.subtreeIds(_institutions, selectedId);
    return _stops.where((stop) => ids.contains(stop.institutionId)).toList()
      ..sort(_compareStops);
  }

  int _compareStops(Stop a, Stop b) {
    final group = _orderGroupId(a).compareTo(_orderGroupId(b));
    if (group != 0) return group;
    final order = a.order.compareTo(b.order);
    return order != 0 ? order : a.id.compareTo(b.id);
  }

  String _orderGroupId(Stop stop) {
    final byId = {for (final item in _institutions) item.id: item};
    final selected = byId[stop.institutionId];
    if (selected == null) return stop.institutionId;
    final path = <Institution>[selected];
    var parentId = selected.parentId;
    final visited = <String>{selected.id};
    while (parentId != null && parentId.isNotEmpty && visited.add(parentId)) {
      final parent = byId[parentId];
      if (parent == null) break;
      path.insert(0, parent);
      parentId = parent.parentId;
    }
    return path.length > 1 ? path[1].id : path.first.id;
  }

  List<Stop> _normalizeGroupOrders(List<Stop> stops) {
    final groups = <String, List<Stop>>{};
    for (final stop in stops) {
      groups.putIfAbsent(_orderGroupId(stop), () => []).add(stop);
    }
    final normalized = <Stop>[];
    for (final group in groups.values) {
      group.sort((a, b) => a.order.compareTo(b.order));
      for (var index = 0; index < group.length; index++) {
        normalized.add(group[index].copyWith(order: index + 1));
      }
    }
    normalized.sort(_compareStops);
    return normalized;
  }

  Future<void> _syncPersonnelStopOrders(List<Stop> stops) async {
    final stopByGroupAndName = {
      for (final stop in stops)
        '${stop.institutionId}\u0000${stop.name.trim().toLowerCase()}': stop,
    };
    final personnel = await PersonnelStorage.readAll();
    for (final person in personnel) {
      final stop =
          stopByGroupAndName['${person.institutionId}\u0000${person.stopName.trim().toLowerCase()}'];
      if (stop != null && person.stopOrder != stop.order) {
        await PersonnelStorage.saveOne(person.copyWith(stopOrder: stop.order));
      }
    }
  }

  Future<void> _moveStop(Stop stop, int direction) async {
    final orderGroupId = _orderGroupId(stop);
    final group = _stops
        .where((item) => _orderGroupId(item) == orderGroupId)
        .toList()
      ..sort((a, b) {
        final orderComparison = a.order.compareTo(b.order);
        return orderComparison != 0 ? orderComparison : a.id.compareTo(b.id);
      });
    final currentIndex = group.indexWhere((item) => item.id == stop.id);
    final targetIndex = currentIndex + direction;
    if (currentIndex < 0 || targetIndex < 0 || targetIndex >= group.length) {
      return;
    }

    final moved = group.removeAt(currentIndex);
    group.insert(targetIndex, moved);
    final orderById = <String, int>{
      for (var index = 0; index < group.length; index++)
        group[index].id: index + 1,
    };
    final updated = _stops.map((item) {
      final order = orderById[item.id];
      return order == null ? item : item.copyWith(order: order);
    }).toList()..sort(_compareStops);
    await StopStorage.saveAll(updated);
    await _syncPersonnelStopOrders(updated);
    if (mounted) setState(() => _stops = updated);
  }

  Future<void> _assignUnassignedStops() async {
    final unassigned = _stops
        .where((stop) => stop.institutionId.isEmpty)
        .toList();
    if (unassigned.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Kurum bilgisi eksik durak bulunmuyor.')),
      );
      return;
    }
    final institution = await showDialog<Institution>(
      context: context,
      builder: (_) => _StopInstitutionDialog(institutions: _institutions),
    );
    if (institution == null || !mounted) return;
    final label = Institution.pathLabel(_institutions, institution);
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Mevcut durakları bağla'),
        content: Text(
          '${unassigned.length} mevcut durak\n\n$label\n\nkaydına bağlanacak.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('DURAKLARI BAĞLA'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    final updated = _stops
        .map(
          (stop) => stop.institutionId.isEmpty
              ? stop.copyWith(
                  institutionId: institution.id,
                  institutionName: label,
                )
              : stop,
        )
        .toList();
    await StopStorage.saveAll(updated);
    if (!mounted) return;
    setState(() {
      _stops = updated;
      _restoreFilter(institution.id);
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${unassigned.length} durak $label kaydına bağlandı.'),
      ),
    );
  }

  Future<void> _addStop() async {
    final stop = await Navigator.of(context).push<Stop>(
      MaterialPageRoute(
        builder: (_) =>
            StopFormScreen(initialInstitutionId: _filterInstitutionId),
      ),
    );
    if (stop == null) return;

    final withInsertedStop =
        _stops
            .map(
              (item) =>
                  _orderGroupId(item) == _orderGroupId(stop) &&
                      item.order >= stop.order
                  ? item.copyWith(order: item.order + 1)
                  : item,
            )
            .toList()
          ..add(stop);
    final updated = _normalizeGroupOrders(withInsertedStop);
    await StopStorage.saveAll(updated);
    await _syncPersonnelStopOrders(updated);
    if (!mounted) return;
    setState(() {
      _stops = updated;
      _restoreFilter(stop.institutionId);
    });
  }

  Future<void> _editStop(Stop stop) async {
    final edited = await Navigator.of(
      context,
    ).push<Stop>(MaterialPageRoute(builder: (_) => StopFormScreen(stop: stop)));
    if (edited == null) return;

    final withoutStop = _stops.where((item) => item.id != stop.id).toList();
    final withEditedStop =
        withoutStop
            .map(
              (item) =>
                  _orderGroupId(item) == _orderGroupId(edited) &&
                      item.order >= edited.order
                  ? item.copyWith(order: item.order + 1)
                  : item,
            )
            .toList()
          ..add(edited);
    final updated = _normalizeGroupOrders(withEditedStop);
    await StopStorage.saveAll(updated);
    await _syncPersonnelStopOrders(updated);
    if (mounted) setState(() => _stops = updated);
  }

  Future<void> _deleteStop(Stop stop) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Durağı Sil'),
        content: Text(
          '${stop.name} durağını silmek istediğinize emin misiniz?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            icon: const Icon(Icons.delete_forever_rounded),
            label: const Text('SİL'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    await DeletedRecordsStorage.archiveStop(stop);
    final updated = _normalizeGroupOrders(
      _stops.where((item) => item.id != stop.id).toList(),
    );
    await StopStorage.saveAll(updated);
    await _syncPersonnelStopOrders(updated);
    if (!mounted) return;
    setState(() => _stops = updated);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${stop.name} durağı silindi.')),
    );
  }

  Widget _filterBar() {
    final roots = _children(null);
    final children = _filterRootId == null
        ? <Institution>[]
        : _children(_filterRootId);
    final grandchildren = _filterChildId == null
        ? <Institution>[]
        : _children(_filterChildId);
    InputDecoration decoration(String label) => InputDecoration(
      labelText: label,
      border: const OutlineInputBorder(),
      contentPadding: const EdgeInsets.symmetric(horizontal: 7, vertical: 12),
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 10, 8, 4),
      child: Row(
        children: [
          Expanded(
            child: DropdownButtonFormField<String>(
              key: ValueKey('stops-root-$_filterRootId'),
              initialValue: _filterRootId,
              isExpanded: true,
              decoration: decoration('Kurum'),
              items: roots
                  .map(
                    (item) => DropdownMenuItem(
                      value: item.id,
                      child: Text(item.name, overflow: TextOverflow.ellipsis),
                    ),
                  )
                  .toList(),
              onChanged: (value) => setState(() {
                _filterRootId = value;
                _filterChildId = null;
                _filterGrandchildId = null;
              }),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: DropdownButtonFormField<String>(
              key: ValueKey('stops-child-$_filterRootId-$_filterChildId'),
              initialValue: _filterChildId,
              isExpanded: true,
              decoration: decoration('Alt Kayıt'),
              items: children
                  .map(
                    (item) => DropdownMenuItem(
                      value: item.id,
                      child: Text(item.name, overflow: TextOverflow.ellipsis),
                    ),
                  )
                  .toList(),
              onChanged: children.isEmpty
                  ? null
                  : (value) => setState(() {
                      _filterChildId = value;
                      _filterGrandchildId = null;
                    }),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: DropdownButtonFormField<String>(
              key: ValueKey('stops-grand-$_filterChildId-$_filterGrandchildId'),
              initialValue: _filterGrandchildId,
              isExpanded: true,
              decoration: decoration('Kayıt Grubu'),
              items: grandchildren
                  .map(
                    (item) => DropdownMenuItem(
                      value: item.id,
                      child: Text(item.name, overflow: TextOverflow.ellipsis),
                    ),
                  )
                  .toList(),
              onChanged: grandchildren.isEmpty
                  ? null
                  : (value) => setState(() => _filterGrandchildId = value),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stopList(List<Stop> stops) {
    if (stops.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(32),
          child: Text(
            'Seçilen kayıt grubunda durak bulunmuyor.',
            textAlign: TextAlign.center,
          ),
        ),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
      itemCount: stops.length,
      separatorBuilder: (_, _) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final stop = stops[index];
        final orderGroupId = _orderGroupId(stop);
        final group = _stops
            .where((item) => _orderGroupId(item) == orderGroupId)
            .toList()
          ..sort((a, b) => a.order.compareTo(b.order));
        final groupIndex = group.indexWhere((item) => item.id == stop.id);
        return Card(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 48,
                      child: CircleAvatar(child: Text('${stop.order}')),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            stop.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            stop.institutionName.isEmpty
                                ? 'Kurum bilgisi eksik'
                                : stop.institutionName,
                          ),
                          if (stop.hasLocation)
                            Text(
                              '${stop.latitude.toStringAsFixed(5)}, ${stop.longitude.toStringAsFixed(5)}',
                            )
                          else
                            const Text(
                              'Konum bilgisi yok, durak güzergahta görünmez',
                              style: TextStyle(
                                color: Colors.red,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 48,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(8),
                        onTap: () => _deleteStop(stop),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 2),
                          child: Column(
                            children: [
                              Icon(
                                Icons.remove_circle_rounded,
                                size: 20,
                                color: Color(0xFF8F3D38),
                              ),
                              Text(
                                'Sil',
                                style: TextStyle(
                                  color: Color(0xFF8F3D38),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const Spacer(),
                    _compactStopAction(
                      icon: Icons.edit_note_rounded,
                      tooltip: 'Düzenle',
                      onPressed: () => _editStop(stop),
                    ),
                    _compactStopAction(
                      icon: Icons.keyboard_arrow_up_rounded,
                      tooltip: 'Yukarı taşı',
                      onPressed: groupIndex > 0
                          ? () => _moveStop(stop, -1)
                          : null,
                    ),
                    _compactStopAction(
                      icon: Icons.keyboard_arrow_down_rounded,
                      tooltip: 'Aşağı taşı',
                      onPressed: groupIndex >= 0 && groupIndex < group.length - 1
                          ? () => _moveStop(stop, 1)
                          : null,
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _compactStopAction({
    required IconData icon,
    required String tooltip,
    required VoidCallback? onPressed,
  }) {
    return IconButton(
      onPressed: onPressed,
      icon: Icon(icon, size: 25),
      tooltip: tooltip,
      padding: EdgeInsets.zero,
      constraints: const BoxConstraints.tightFor(width: 38, height: 30),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Duraklar'),
        actions: [
          IconButton(
            onPressed: _loading ? null : _assignUnassignedStops,
            icon: const Icon(Icons.drive_file_move_rounded),
            tooltip: 'Mevcut durakları kuruma bağla',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addStop,
        icon: const Icon(Icons.add_location_alt_rounded),
        label: const Text('Durak Ekle'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                _filterBar(),
                Expanded(child: _stopList(_visibleStops)),
              ],
            ),
    );
  }

  // Eski görünüm geçiş süresince kaynakta tutuluyor; yeni ekran yukarıdadır.
  // ignore: unused_element
  Widget _legacyBuild(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Duraklar'),
        actions: [
          IconButton(
            onPressed: _loading ? null : _assignUnassignedStops,
            icon: const Icon(Icons.drive_file_move_rounded),
            tooltip: 'Mevcut durakları kuruma bağla',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addStop,
        icon: const Icon(Icons.add_location_alt_rounded),
        label: const Text('Durak Ekle'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _stops.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Henüz durak yok. Sağ alttaki Durak Ekle düğmesiyle haritadan ilk durağını seç.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              itemCount: _stops.length,
              separatorBuilder: (_, _) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final stop = _stops[index];
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(child: Text('${stop.order}')),
                    title: Text(
                      stop.name,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          stop.institutionName.isEmpty
                              ? 'Kurum bilgisi eksik'
                              : stop.institutionName,
                        ),
                        if (stop.hasLocation)
                          Text(
                            '${stop.latitude.toStringAsFixed(5)}, ${stop.longitude.toStringAsFixed(5)}',
                          )
                        else
                          const Text(
                            'Konum bilgisi yok, durak güzergahta görünmez',
                            style: TextStyle(
                              color: Colors.red,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                      ],
                    ),
                    trailing: IconButton(
                      onPressed: () => _editStop(stop),
                      icon: const Icon(Icons.edit_rounded),
                      tooltip: 'Düzenle',
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class _StopInstitutionDialog extends StatefulWidget {
  const _StopInstitutionDialog({required this.institutions});

  final List<Institution> institutions;

  @override
  State<_StopInstitutionDialog> createState() => _StopInstitutionDialogState();
}

class _StopInstitutionDialogState extends State<_StopInstitutionDialog> {
  String? _rootId;
  String? _childId;
  String? _grandchildId;

  List<Institution> _children(String? parentId) => Institution.childrenOf(
    widget.institutions,
    parentId,
  ).where((item) => item.active).toList();

  Institution? get _selection {
    final id = _grandchildId ?? _childId ?? _rootId;
    if (id == null) return null;
    final item = widget.institutions.firstWhere((item) => item.id == id);
    return _children(item.id).isEmpty ? item : null;
  }

  @override
  Widget build(BuildContext context) {
    final roots = _children(null);
    final children = _rootId == null ? <Institution>[] : _children(_rootId);
    final grandchildren = _childId == null
        ? <Institution>[]
        : _children(_childId);
    return AlertDialog(
      title: const Text('Durakların kayıt grubunu seçin'),
      content: SizedBox(
        width: 430,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            DropdownButtonFormField<String>(
              key: ValueKey('assign-root-$_rootId'),
              initialValue: _rootId,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Kurum Seçimi',
                border: OutlineInputBorder(),
              ),
              items: roots
                  .map(
                    (item) => DropdownMenuItem(
                      value: item.id,
                      child: Text(item.name),
                    ),
                  )
                  .toList(),
              onChanged: (value) => setState(() {
                _rootId = value;
                _childId = null;
                _grandchildId = null;
              }),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              key: ValueKey('assign-child-$_rootId-$_childId'),
              initialValue: _childId,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Bölge Seçimi',
                border: OutlineInputBorder(),
              ),
              items: children
                  .map(
                    (item) => DropdownMenuItem(
                      value: item.id,
                      child: Text(item.name),
                    ),
                  )
                  .toList(),
              onChanged: children.isEmpty
                  ? null
                  : (value) => setState(() {
                      _childId = value;
                      _grandchildId = null;
                    }),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              key: ValueKey('assign-grandchild-$_childId-$_grandchildId'),
              initialValue: _grandchildId,
              isExpanded: true,
              decoration: const InputDecoration(
                labelText: 'Takım Seçimi (İsteğe Bağlı)',
                border: OutlineInputBorder(),
              ),
              items: grandchildren
                  .map(
                    (item) => DropdownMenuItem(
                      value: item.id,
                      child: Text(item.name),
                    ),
                  )
                  .toList(),
              onChanged: grandchildren.isEmpty
                  ? null
                  : (value) => setState(() => _grandchildId = value),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('VAZGEÇ'),
        ),
        FilledButton(
          onPressed: _selection == null
              ? null
              : () => Navigator.pop(context, _selection),
          child: const Text('SEÇ'),
        ),
      ],
    );
  }
}
