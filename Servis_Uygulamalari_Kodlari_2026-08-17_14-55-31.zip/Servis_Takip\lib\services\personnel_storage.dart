import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/personnel.dart';
import 'company_cloud_storage.dart';

class PersonnelStorage {
  PersonnelStorage._();

  static const _personnelKey = 'personnel_list';
  static const _storage = FlutterSecureStorage();

  static Future<List<Personnel>> readAll() async {
    final cloudData = await CompanyCloudStorage.readCollection('personnel');
    if (cloudData.isNotEmpty) {
      final personnel = cloudData
          .where((item) => item['deletedAt'] == null)
          .map(Personnel.fromJson)
          .toList()
        ..sort((a, b) => a.stopOrder.compareTo(b.stopOrder));
      await _writeCache(personnel);
      await CompanyCloudStorage.markCloudInitialized('personnel');
      return personnel;
    }
    if (await CompanyCloudStorage.isCloudInitialized('personnel')) return [];

    final savedValue =
        await _storage.read(
          key: await CompanyCloudStorage.cacheKey(_personnelKey),
        ) ??
        await _storage.read(key: _personnelKey);
    if (savedValue == null || savedValue.isEmpty) {
      await CompanyCloudStorage.markCloudInitialized('personnel');
      return [];
    }
    final personnel =
        (jsonDecode(savedValue) as List<dynamic>)
            .map((item) => Personnel.fromJson(item as Map<String, dynamic>))
            .toList()
          ..sort((a, b) => a.stopOrder.compareTo(b.stopOrder));
    if (await CompanyCloudStorage.canClaimLegacyData()) {
      await CompanyCloudStorage.replaceCollection(
        collectionName: 'personnel',
        items: personnel.map((person) => person.toJson()).toList(),
        limitField: 'maxPersonnel',
        usageField: 'personnel',
      );
    }
    await CompanyCloudStorage.markCloudInitialized('personnel');
    return personnel;
  }

  static Future<void> saveAll(List<Personnel> personnel) async {
    await CompanyCloudStorage.replaceCollection(
      collectionName: 'personnel',
      items: personnel.map((person) => person.toJson()).toList(),
      limitField: 'maxPersonnel',
      usageField: 'personnel',
    );
    await _writeCache(personnel);
    await CompanyCloudStorage.markCloudInitialized('personnel');
  }

  static Future<void> saveOne(Personnel person) async {
    await CompanyCloudStorage.writeDocument(
      collectionName: 'personnel',
      documentId: person.id,
      data: person.toJson(),
    );
  }

  static Stream<List<Personnel>> watchAll() {
    return CompanyCloudStorage.watchCollection('personnel').map((data) {
      return data
          .where((item) => item['deletedAt'] == null)
          .map(Personnel.fromJson)
          .toList()
        ..sort((a, b) => a.stopOrder.compareTo(b.stopOrder));
    });
  }

  static Future<void> _writeCache(List<Personnel> personnel) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_personnelKey),
      value: jsonEncode(personnel.map((person) => person.toJson()).toList()),
    );
  }
}
