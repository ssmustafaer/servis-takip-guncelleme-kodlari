import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import 'company_cloud_storage.dart';

class StopPreferenceStorage {
  StopPreferenceStorage._();

  static const _storage = FlutterSecureStorage();

  static Future<String?> readInstitutionId() async {
    return _storage.read(
      key: await CompanyCloudStorage.cacheKey('stop_preference_institution'),
    );
  }

  static Future<void> saveInstitutionId(String institutionId) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey('stop_preference_institution'),
      value: institutionId,
    );
  }
}
