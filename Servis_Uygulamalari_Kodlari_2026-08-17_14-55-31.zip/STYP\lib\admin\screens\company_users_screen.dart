import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../models/company.dart';
import '../models/company_user.dart';
import '../services/admin_repository.dart';

class CompanyUsersScreen extends StatelessWidget {
  const CompanyUsersScreen({
    required this.company,
    required this.repository,
    super.key,
  });

  final Company company;
  final AdminRepository repository;

  Future<void> _editUser(BuildContext context, CompanyUser user) async {
    final result = await showDialog<_UserAccess>(
      context: context,
      builder: (_) => _UserAccessDialog(user: user),
    );
    if (result == null || !context.mounted) return;
    try {
      await repository.updateCompanyUser(
        user: user,
        role: result.role,
        active: result.active,
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${user.displayName} güncellendi.')),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Kullanıcı güncellenemedi: $error')),
      );
    }
  }

  Future<void> _addUser(BuildContext context) async {
    final result = await showDialog<_NewUser>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const _NewUserDialog(),
    );
    if (result == null || !context.mounted) return;

    try {
      await repository.createCompanyUser(
        company: company,
        displayName: result.displayName,
        password: result.password,
        role: result.role,
        active: result.active,
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('${result.displayName} kullanıcısı oluşturuldu.'),
        ),
      );
    } on FirebaseAuthException catch (error) {
      if (!context.mounted) return;
      final message = switch (error.code) {
        'email-already-in-use' =>
          'Bu şirkette aynı isimle bir kullanıcı zaten var.',
        'invalid-email' => 'Kullanıcı adı oluşturulamadı.',
        'weak-password' => 'Şifre en az 6 karakter olmalıdır.',
        _ => error.message ?? 'Kullanıcı oluşturulamadı.',
      };
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('$error')));
    }
  }

  Future<void> _resetDevice(BuildContext context, CompanyUser user) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Telefon kaydını sıfırla'),
        content: Text(
          '${user.displayName} yeni bir telefondan giriş yapabilecek. '
          'Mevcut telefon bağlantısı kaldırılsın mı?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Sıfırla'),
          ),
        ],
      ),
    );
    if (approved != true || !context.mounted) return;
    try {
      await repository.resetCompanyUserDevice(user);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Telefon kaydı sıfırlandı.')),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Telefon kaydı sıfırlanamadı: $error')),
      );
    }
  }

  Future<void> _toggleActive(BuildContext context, CompanyUser user) async {
    try {
      await repository.updateCompanyUser(
        user: user,
        role: user.role,
        active: !user.active,
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            user.active
                ? '${user.displayName} pasife alındı.'
                : '${user.displayName} aktifleştirildi.',
          ),
        ),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Durum değiştirilemedi: $error')));
    }
  }

  Future<void> _deleteUser(BuildContext context, CompanyUser user) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Kullanıcı silinsin mi?'),
        content: Text(
          '${user.displayName} kullanıcı kaydı silinecek ve uygulamaya erişemeyecek.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Sil'),
          ),
        ],
      ),
    );
    if (approved != true || !context.mounted) return;
    try {
      await repository.deleteCompanyUser(user: user);
      if (!context.mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('${user.displayName} silindi.')));
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Kullanıcı silinemedi: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('${company.name} Kullanıcıları')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: company.usage.users >= company.limits.maxUsers
            ? null
            : () => _addUser(context),
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('Kullanıcı Ekle'),
      ),
      body: StreamBuilder<List<CompanyUser>>(
        stream: repository.watchCompanyUsers(company.id),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text('Kullanıcılar yüklenemedi:\n${snapshot.error}'),
            );
          }
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final users = snapshot.data!;
          if (users.isEmpty) {
            return Center(
              child: Text(
                'Henüz kullanıcı yok.\n'
                'Paket sınırı: ${company.limits.maxUsers}',
                textAlign: TextAlign.center,
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
            itemCount: users.length + 1,
            separatorBuilder: (_, _) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              if (index == 0) {
                final registered = users
                    .where((user) => user.hasRegisteredDevice)
                    .length;
                return Card(
                  color: const Color(0xFFEAF2FF),
                  child: ListTile(
                    leading: const Icon(Icons.phone_android_rounded),
                    title: Text('$registered kayıtlı telefon'),
                    subtitle: Text(
                      '${users.length} kullanıcı hesabından $registered tanesi bir telefona bağlandı.',
                    ),
                  ),
                );
              }
              final user = users[index - 1];
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    child: Icon(
                      user.isCompanyAdmin
                          ? Icons.admin_panel_settings_rounded
                          : Icons.drive_eta_rounded,
                    ),
                  ),
                  title: Text(user.displayName),
                  subtitle: Text(
                    '${user.positionName} • ${user.active ? 'Aktif' : 'Pasif'}\n'
                    '${user.hasRegisteredDevice ? user.deviceName : 'Telefon kaydı yok'}',
                  ),
                  isThreeLine: true,
                  trailing: PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'edit') _editUser(context, user);
                      if (value == 'toggle_active') {
                        _toggleActive(context, user);
                      }
                      if (value == 'delete') _deleteUser(context, user);
                      if (value == 'reset_device') {
                        _resetDevice(context, user);
                      }
                    },
                    itemBuilder: (_) => [
                      const PopupMenuItem(
                        value: 'edit',
                        child: Text('Kullanıcıyı düzenle'),
                      ),
                      PopupMenuItem(
                        value: 'toggle_active',
                        child: Text(user.active ? 'Pasife al' : 'Aktifleştir'),
                      ),
                      if (user.hasRegisteredDevice)
                        const PopupMenuItem(
                          value: 'reset_device',
                          child: Text('Telefon kaydını sıfırla'),
                        ),
                      const PopupMenuDivider(),
                      const PopupMenuItem(
                        value: 'delete',
                        child: Text('Kullanıcıyı sil'),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class _UserAccess {
  const _UserAccess({required this.role, required this.active});

  final String role;
  final bool active;
}

class _UserAccessDialog extends StatefulWidget {
  const _UserAccessDialog({required this.user});

  final CompanyUser user;

  @override
  State<_UserAccessDialog> createState() => _UserAccessDialogState();
}

class _UserAccessDialogState extends State<_UserAccessDialog> {
  late String _role;
  late bool _active;

  @override
  void initState() {
    super.initState();
    _role = widget.user.isCompanyAdmin ? 'company_admin' : widget.user.role;
    _active = widget.user.active;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.user.displayName),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Kullanıcı aktif'),
            subtitle: const Text('Kapalıysa uygulamaya erişemez.'),
            value: _active,
            onChanged: (value) => setState(() => _active = value),
          ),
          DropdownButtonFormField<String>(
            initialValue: _role,
            decoration: const InputDecoration(labelText: 'Pozisyonu'),
            items: const [
              DropdownMenuItem(value: 'company_admin', child: Text('Sahibi')),
              DropdownMenuItem(
                value: 'administrative',
                child: Text('İdari Personel'),
              ),
              DropdownMenuItem(value: 'driver', child: Text('Şoför')),
            ],
            onChanged: (value) {
              if (value != null) setState(() => _role = value);
            },
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton(
          onPressed: () =>
              Navigator.pop(context, _UserAccess(role: _role, active: _active)),
          child: const Text('Kaydet'),
        ),
      ],
    );
  }
}

class _NewUser {
  const _NewUser({
    required this.displayName,
    required this.password,
    required this.role,
    required this.active,
  });

  final String displayName;
  final String password;
  final String role;
  final bool active;
}

class _NewUserDialog extends StatefulWidget {
  const _NewUserDialog();

  @override
  State<_NewUserDialog> createState() => _NewUserDialogState();
}

class _NewUserDialogState extends State<_NewUserDialog> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _passwordController = TextEditingController();
  var _role = 'driver';
  var _active = true;
  var _hidePassword = true;

  @override
  void dispose() {
    _nameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.pop(
      context,
      _NewUser(
        displayName: _nameController.text.trim(),
        password: _passwordController.text,
        role: _role,
        active: _active,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Kullanıcı Ekle'),
      content: SizedBox(
        width: 420,
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _nameController,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(
                    labelText: 'Adı soyadı',
                    prefixIcon: Icon(Icons.person_rounded),
                  ),
                  validator: (value) => value == null || value.trim().isEmpty
                      ? 'Adı soyadı girin.'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _passwordController,
                  obscureText: _hidePassword,
                  decoration: InputDecoration(
                    labelText: 'Geçici şifre',
                    prefixIcon: const Icon(Icons.lock_rounded),
                    suffixIcon: IconButton(
                      onPressed: () =>
                          setState(() => _hidePassword = !_hidePassword),
                      icon: Icon(
                        _hidePassword ? Icons.visibility : Icons.visibility_off,
                      ),
                    ),
                  ),
                  validator: (value) => (value?.length ?? 0) < 6
                      ? 'Şifre en az 6 karakter olmalıdır.'
                      : null,
                ),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  initialValue: _role,
                  decoration: const InputDecoration(
                    labelText: 'Pozisyonu',
                    prefixIcon: Icon(Icons.badge_rounded),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'company_admin',
                      child: Text('Sahibi'),
                    ),
                    DropdownMenuItem(
                      value: 'administrative',
                      child: Text('İdari Personel'),
                    ),
                    DropdownMenuItem(value: 'driver', child: Text('Şoför')),
                  ],
                  onChanged: (value) {
                    if (value != null) setState(() => _role = value);
                  },
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('Kullanıcı aktif'),
                  subtitle: const Text(
                    'Pasif kullanıcı uygulamaya giriş yapamaz.',
                  ),
                  value: _active,
                  onChanged: (value) => setState(() => _active = value),
                ),
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton(onPressed: _save, child: const Text('Kullanıcı Oluştur')),
      ],
    );
  }
}
