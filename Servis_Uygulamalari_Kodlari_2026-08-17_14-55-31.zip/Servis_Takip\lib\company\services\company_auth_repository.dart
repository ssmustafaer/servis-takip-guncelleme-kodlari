import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/company_session.dart';
import 'device_identity_service.dart';
import '../../services/company_cloud_storage.dart';

class CompanyAuthRepository {
  CompanyAuthRepository({FirebaseAuth? auth, FirebaseFirestore? firestore})
    : _auth = auth ?? FirebaseAuth.instance,
      _firestore = firestore ?? FirebaseFirestore.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _firestore;
  static const _localStorage = FlutterSecureStorage();

  Stream<User?> authStateChanges() => _auth.authStateChanges();

  Future<bool> isSystemAdmin(User user) async {
    final token = await user.getIdTokenResult();
    if (token.claims?['role'] == 'system_admin') return true;
    try {
      final profile = await _firestore.collection('users').doc(user.uid).get();
      return profile.data()?['role'] == 'system_admin';
    } on FirebaseException catch (error) {
      if (_isTemporaryCloudError(error)) return false;
      rethrow;
    }
  }

  Future<void> signInSystemAdmin({
    required String email,
    required String password,
  }) async {
    final credential = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = credential.user;
    if (user == null || !await isSystemAdmin(user)) {
      await _auth.signOut();
      throw StateError('Bu hesap sistem yöneticisi değil.');
    }
  }

  Stream<QuerySnapshot<Map<String, dynamic>>> watchEmergencyCompanies() =>
      _firestore.collection('companies').orderBy('name').snapshots();

  Future<CompanySession> loadEmergencySession({
    required User user,
    required String companyId,
  }) async {
    await _bindCurrentDevice();
    if (!await isSystemAdmin(user)) {
      throw StateError('Acil yönetici erişimi yetkiniz yok.');
    }
    final profile = await _firestore.collection('users').doc(user.uid).get();
    final company = await _firestore
        .collection('companies')
        .doc(companyId)
        .get();
    final data = company.data();
    if (data == null || data['deletedAt'] != null) {
      throw StateError('Şirket bulunamadı veya silinmiş.');
    }
    await _firestore.collection('emergencyAccessLogs').add({
      'adminUid': user.uid,
      'adminName':
          profile.data()?['displayName'] ?? user.email ?? 'Sistem Yöneticisi',
      'companyId': companyId,
      'companyName': data['name'] ?? 'Şirket',
      'startedAt': FieldValue.serverTimestamp(),
      'mode': 'emergency_admin',
    });
    CompanyCloudStorage.setEmergencyCompany(companyId);
    return CompanySession(
      userId: user.uid,
      companyId: companyId,
      companyName: data['name'] as String? ?? 'Şirket',
      displayName: profile.data()?['displayName'] as String? ?? 'Mustafa ER',
      role: 'system_admin',
      permissions: const {},
      allowedInstitutionIds: const [],
      allInstitutions: true,
      allowedVehicleIds: const [],
      allVehicles: true,
      emergencyMode: true,
    );
  }

  Future<CompanySession> loadSession(User user) async {
    try {
      final session = await _loadCloudSession(user);
      await _localStorage.write(
        key: _sessionKey(user.uid),
        value: jsonEncode(session.toJson()),
      );
      return session;
    } on FirebaseException catch (error) {
      if (!_isTemporaryCloudError(error)) rethrow;
      final cached =
          await _readCachedSession(user.uid) ??
          await _readFirestoreCachedSession(user);
      if (cached != null) return cached;
      throw StateError(
        'Firebase kullanım kotası dolmuş veya bağlantı geçici olarak kullanılamıyor. '
        'Daha önce bu telefonda açılmış bir oturum bulunamadı. Lütfen daha sonra tekrar deneyin.',
      );
    }
  }

  Future<CompanySession> _loadCloudSession(User user) async {
    await _bindCurrentDevice();
    final profile = await _firestore.collection('users').doc(user.uid).get();
    final profileData = profile.data();
    if (profileData == null || profileData['active'] != true) {
      throw StateError('Kullanıcı hesabı aktif değil.');
    }
    final companyId = profileData['companyId'] as String? ?? '';
    if (companyId.isEmpty) {
      throw StateError('Kullanıcı bir şirkete bağlı değil.');
    }
    var company = await _firestore.collection('companies').doc(companyId).get();
    var companyData = company.data();
    if (companyData == null || companyData['active'] != true) {
      throw StateError('Şirket hesabı aktif değil.');
    }
    final expiresAt = companyData['expiresAt'];
    if (expiresAt is Timestamp && expiresAt.toDate().isBefore(DateTime.now())) {
      await _downgradeExpiredPackage(company.reference);
      company = await _firestore.collection('companies').doc(companyId).get();
      companyData = company.data();
      if (companyData == null || companyData['active'] != true) {
        throw StateError('Şirket paketi güncellenemedi.');
      }
    }
    return CompanySession(
      userId: user.uid,
      companyId: companyId,
      companyName: companyData['name'] as String? ?? 'Şirket',
      displayName: profileData['displayName'] as String? ?? 'Kullanıcı',
      role: profileData['role'] as String? ?? 'driver',
      permissions:
          (profileData['permissions'] as Map<String, dynamic>? ?? const {}).map(
            (key, value) => MapEntry(key, value == true),
          ),
      allowedInstitutionIds:
          (profileData['allowedInstitutionIds'] as List<dynamic>? ?? const [])
              .map((value) => value.toString())
              .toList(),
      allInstitutions: profileData['allInstitutions'] as bool? ?? true,
      allowedVehicleIds:
          (profileData['allowedVehicleIds'] as List<dynamic>? ?? const [])
              .map((value) => value.toString())
              .toList(),
      allVehicles: profileData['allVehicles'] as bool? ?? true,
    );
  }

  Future<CompanySession?> _readCachedSession(String userId) async {
    final encoded = await _localStorage.read(key: _sessionKey(userId));
    if (encoded == null || encoded.isEmpty) return null;
    try {
      final session = CompanySession.fromJson(
        Map<String, dynamic>.from(jsonDecode(encoded) as Map),
      );
      if (session.userId != userId || session.companyId.isEmpty) return null;
      return session;
    } catch (_) {
      return null;
    }
  }

  Future<CompanySession?> _readFirestoreCachedSession(User user) async {
    try {
      const cache = GetOptions(source: Source.cache);
      final profile = await _firestore
          .collection('users')
          .doc(user.uid)
          .get(cache);
      final profileData = profile.data();
      if (profileData == null || profileData['active'] != true) return null;
      final companyId = profileData['companyId'] as String? ?? '';
      if (companyId.isEmpty) return null;
      final company = await _firestore
          .collection('companies')
          .doc(companyId)
          .get(cache);
      final companyData = company.data();
      if (companyData == null || companyData['active'] != true) return null;
      final session = CompanySession(
        userId: user.uid,
        companyId: companyId,
        companyName: companyData['name'] as String? ?? 'Şirket',
        displayName: profileData['displayName'] as String? ?? 'Kullanıcı',
        role: profileData['role'] as String? ?? 'driver',
        permissions:
            (profileData['permissions'] as Map<String, dynamic>? ?? const {})
                .map((key, value) => MapEntry(key, value == true)),
        allowedInstitutionIds:
            (profileData['allowedInstitutionIds'] as List<dynamic>? ?? const [])
                .map((value) => value.toString())
                .toList(),
        allInstitutions: profileData['allInstitutions'] as bool? ?? true,
        allowedVehicleIds:
            (profileData['allowedVehicleIds'] as List<dynamic>? ?? const [])
                .map((value) => value.toString())
                .toList(),
        allVehicles: profileData['allVehicles'] as bool? ?? true,
      );
      await _localStorage.write(
        key: _sessionKey(user.uid),
        value: jsonEncode(session.toJson()),
      );
      return session;
    } catch (_) {
      return null;
    }
  }

  String _sessionKey(String userId) => 'company_session_$userId';

  static bool _isTemporaryCloudError(FirebaseException error) {
    return const {
      'resource-exhausted',
      'unavailable',
      'deadline-exceeded',
    }.contains(error.code);
  }

  Future<void> _downgradeExpiredPackage(
    DocumentReference<Map<String, dynamic>> companyReference,
  ) async {
    final settings = await _firestore
        .collection('systemSettings')
        .doc('salesPackages')
        .get();
    final packages = settings.data()?['packages'] as List<dynamic>? ?? const [];
    final free = packages.whereType<Map>().firstWhere(
      (item) => item['id'] == 'free',
      orElse: () => const {},
    );
    int value(String key, int fallback) =>
        (free[key] as num?)?.toInt() ?? fallback;
    await companyReference.update({
      'packageId': 'free',
      'planName': 'Ücretsiz',
      'expiresAt': null,
      'limits': {
        'maxUsers': value('driverLimit', 1),
        'maxInstitutions': value('institutionLimit', 2),
        'maxPersonnel': value('personnelLimit', 50),
        'maxStops': value('personnelLimit', 50),
        'maxVehicles': value('vehicleLimit', 1),
      },
      'packageUsage': {
        'month': '',
        'mapCount': 0,
        'whatsappCount': 0,
        'mapServiceKeys': <String>[],
      },
      'updatedAt': FieldValue.serverTimestamp(),
    });
  }

  Future<void> signIn({
    required String companyCode,
    required String displayName,
    required String password,
  }) async {
    final code = companyCode.trim().toUpperCase();
    final codeDocument = await _firestore
        .collection('companyLoginCodes')
        .doc(code)
        .get();
    final codeData = codeDocument.data();
    if (codeData == null || codeData['active'] != true) {
      throw StateError('Şirket kodu geçersiz veya şirket aktif değil.');
    }
    final companyId = codeData['companyId'] as String? ?? '';
    if (companyId.isEmpty) {
      throw StateError('Şirket bağlantısı bulunamadı.');
    }
    final email = _internalEmail(
      companyId: companyId,
      displayName: displayName,
    );
    await _auth.signInWithEmailAndPassword(email: email, password: password);
  }

  Future<void> signOut() {
    CompanyCloudStorage.setEmergencyCompany(null);
    return _auth.signOut();
  }

  Future<void> _bindCurrentDevice() async {
    final device = await DeviceIdentityService.read();
    final user = _auth.currentUser;
    if (user == null) throw StateError('Kullanıcı oturumu bulunamadı.');
    final reference = _firestore.collection('users').doc(user.uid);
    await _firestore.runTransaction((transaction) async {
      final snapshot = await transaction.get(reference);
      final data = snapshot.data();
      final isAdmin = data?['role'] == 'system_admin';
      if (data == null || (data['active'] != true && !isAdmin)) {
        throw StateError('Kullanıcı hesabı aktif değil.');
      }
      final registeredDeviceId = data['deviceId'] as String? ?? '';
      final exemption = registeredDeviceId.isEmpty
          ? null
          : await transaction.get(
              _firestore
                  .collection('deviceExemptions')
                  .doc('${user.uid}_$registeredDeviceId'),
            );
      final isExempt = exemption?.data()?['active'] == true;
      if (!isExempt &&
          registeredDeviceId.isNotEmpty &&
          registeredDeviceId != device.id) {
        throw StateError(
          'Bu kullanıcı hesabı başka bir telefona kayıtlı. '
          'Şirket veya sistem yöneticinizden telefon kaydını sıfırlamasını isteyin.',
        );
      }
      transaction.update(reference, {
        if (registeredDeviceId.isEmpty) 'deviceId': device.id,
        if (registeredDeviceId.isEmpty) 'deviceName': device.name,
        if (registeredDeviceId.isEmpty)
          'deviceBoundAt': FieldValue.serverTimestamp(),
        'deviceLastSeenAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    });
  }

  String _internalEmail({
    required String companyId,
    required String displayName,
  }) {
    return '${_normalizeLoginName(displayName)}.$companyId@servistakip.local';
  }

  String _normalizeLoginName(String value) {
    var normalized = value.trim().toLowerCase();
    const replacements = <String, String>{
      'ç': 'c',
      'ğ': 'g',
      'ı': 'i',
      'ö': 'o',
      'ş': 's',
      'ü': 'u',
    };
    replacements.forEach((source, target) {
      normalized = normalized.replaceAll(source, target);
    });
    normalized = normalized
        .replaceAll(RegExp(r'[^a-z0-9]+'), '.')
        .replaceAll(RegExp(r'^\.+|\.+$'), '');
    return normalized.isEmpty ? 'kullanici' : normalized;
  }
}
