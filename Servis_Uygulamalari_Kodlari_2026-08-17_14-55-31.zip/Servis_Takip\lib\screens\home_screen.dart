import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../company/models/company_session.dart';
import '../widgets/dashboard_menu_card.dart';
import '../widgets/one_day_passenger_dialog.dart';
import 'service_setup_screen.dart';
import 'settings_screen.dart';
import 'personnel_leaves_screen.dart';
import 'help_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({this.session, this.onExitEmergency, super.key});

  final CompanySession? session;
  final VoidCallback? onExitEmergency;

  Widget _quickButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      height: 44,
      child: FilledButton.icon(
        onPressed: onPressed,
        icon: Icon(icon, size: 18),
        label: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
        ),
        style: FilledButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 6),
        ),
      ),
    );
  }

  Future<void> _changePassword(BuildContext context) async {
    final result = await showDialog<_PasswordChange>(
      context: context,
      builder: (_) => const _ChangePasswordDialog(),
    );
    if (result == null || !context.mounted) return;
    final user = FirebaseAuth.instance.currentUser;
    if (user == null || user.email == null) return;
    try {
      await user.reauthenticateWithCredential(
        EmailAuthProvider.credential(
          email: user.email!,
          password: result.currentPassword,
        ),
      );
      await user.updatePassword(result.newPassword);
      if (!context.mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Şifreniz değiştirildi.')));
    } on FirebaseAuthException catch (error) {
      if (!context.mounted) return;
      final message = switch (error.code) {
        'wrong-password' || 'invalid-credential' => 'Mevcut şifreniz hatalı.',
        'weak-password' => 'Yeni şifre yeterince güçlü değil.',
        _ => error.message ?? 'Şifre değiştirilemedi.',
      };
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(message)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final dateText =
        '${now.day.toString().padLeft(2, '0')}.${now.month.toString().padLeft(2, '0')}.${now.year}';

    return Scaffold(
      appBar: AppBar(
        title: Text(
          session?.emergencyMode == true
              ? 'ACİL • ${session!.companyName}'
              : 'Servis Takip v1.1',
        ),
        centerTitle: false,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    session?.displayName.trim().isNotEmpty == true
                        ? session!.displayName.trim()
                        : 'Kullanıcı',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const Text(
                    'Designed by Mustafa ER',
                    style: TextStyle(fontSize: 9),
                  ),
                ],
              ),
            ),
          ),
          PopupMenuButton<String>(
            tooltip: 'Hesap işlemleri',
            onSelected: (value) {
              if (value == 'password') _changePassword(context);
              if (value == 'company') onExitEmergency?.call();
              if (value == 'logout') FirebaseAuth.instance.signOut();
            },
            itemBuilder: (_) => [
              if (session?.emergencyMode == true)
                const PopupMenuItem(
                  value: 'company',
                  child: ListTile(
                    leading: Icon(Icons.swap_horiz_rounded),
                    title: Text('Şirket Değiştir'),
                  ),
                ),
              const PopupMenuItem(
                value: 'password',
                child: ListTile(
                  leading: Icon(Icons.password_rounded),
                  title: Text('Şifremi Değiştir'),
                ),
              ),
              const PopupMenuItem(
                value: 'logout',
                child: ListTile(
                  leading: Icon(Icons.logout_rounded),
                  title: Text('Çıkış Yap'),
                ),
              ),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            if (session?.emergencyMode == true) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFE8B0),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'Acil Yönetici Erişimi • ${session!.companyName}\nBu erişim kayıt altına alınmaktadır.',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
              const SizedBox(height: 12),
            ],
            Text(
              'Hayırlı yolculuklar',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: const Color(0xFF082A52),
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: _quickButton(
                    label: 'Yolcu Ekle',
                    icon: Icons.person_add_alt_1_rounded,
                    color: const Color(0xFF527A6B),
                    onPressed: () async {
                      final added = await OneDayPassengerDialog.show(context);
                      if (added == true && context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Geçici yolcu listesi güncellendi.'),
                          ),
                        );
                      }
                    },
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _quickButton(
                    label: 'İzinler',
                    icon: Icons.beach_access_rounded,
                    color: const Color(0xFFA46161),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => PersonnelLeavesScreen(
                            canManage:
                                session?.permission('canManagePersonnel') ??
                                true,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 7),
                Expanded(
                  child: _quickButton(
                    label: 'Yardım',
                    icon: Icons.help_outline_rounded,
                    color: const Color(0xFF5B7896),
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) => HelpScreen(session: session),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Bugün: $dateText',
              style: const TextStyle(color: Color(0xFF52657B)),
            ),
            const SizedBox(height: 24),
            DashboardMenuCard(
              icon: Icons.directions_bus_rounded,
              title: 'Servisi Başlat / Toplama',
              subtitle: 'İşe gidecek personeli duraklardan topla.',
              color: const Color(0xFF0B6E4F),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => ServiceSetupScreen(
                      isDistribution: false,
                      allInstitutions: session?.allInstitutions ?? true,
                      allowedInstitutionIds:
                          session?.allowedInstitutionIds ?? const [],
                      allVehicles: session?.allVehicles ?? true,
                      allowedVehicleIds: session?.allowedVehicleIds ?? const [],
                      preferredDriverId: session?.role == 'driver'
                          ? session?.userId
                          : null,
                      preferredDriverName: session?.role == 'driver'
                          ? session?.displayName
                          : null,
                      canEditPersonnel:
                          session?.permission('canManagePersonnel') ?? true,
                    ),
                  ),
                );
              },
            ),
            DashboardMenuCard(
              icon: Icons.home_work_rounded,
              title: 'Servisi Başlat / Dağıtım',
              subtitle: 'Geçici olarak kullanıma kapalı.',
              color: const Color(0xFF8A4B08),
              onTap: null,
            ),
            if (session == null || session!.canManageSettings)
              DashboardMenuCard(
                icon: Icons.settings_rounded,
                title: 'Ayarlar',
                subtitle: 'Kayıt ve uygulama ayarları.',
                color: const Color(0xFF455A64),
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => SettingsScreen(session: session),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _PasswordChange {
  const _PasswordChange({
    required this.currentPassword,
    required this.newPassword,
  });

  final String currentPassword;
  final String newPassword;
}

class _ChangePasswordDialog extends StatefulWidget {
  const _ChangePasswordDialog();

  @override
  State<_ChangePasswordDialog> createState() => _ChangePasswordDialogState();
}

class _ChangePasswordDialogState extends State<_ChangePasswordDialog> {
  final _formKey = GlobalKey<FormState>();
  final _currentController = TextEditingController();
  final _newController = TextEditingController();
  final _repeatController = TextEditingController();
  var _hidePasswords = true;

  @override
  void dispose() {
    _currentController.dispose();
    _newController.dispose();
    _repeatController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Şifremi Değiştir'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: _currentController,
                obscureText: _hidePasswords,
                decoration: const InputDecoration(
                  labelText: 'Mevcut şifre',
                  border: OutlineInputBorder(),
                ),
                validator: (value) =>
                    (value?.isEmpty ?? true) ? 'Mevcut şifrenizi girin.' : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _newController,
                obscureText: _hidePasswords,
                decoration: const InputDecoration(
                  labelText: 'Yeni şifre',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => (value?.length ?? 0) < 6
                    ? 'Yeni şifre en az 6 karakter olmalıdır.'
                    : null,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _repeatController,
                obscureText: _hidePasswords,
                decoration: const InputDecoration(
                  labelText: 'Yeni şifre tekrar',
                  border: OutlineInputBorder(),
                ),
                validator: (value) => value != _newController.text
                    ? 'Yeni şifreler aynı değil.'
                    : null,
              ),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Şifreleri göster'),
                value: !_hidePasswords,
                onChanged: (value) =>
                    setState(() => _hidePasswords = value != true),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton(
          onPressed: () {
            if (!_formKey.currentState!.validate()) return;
            Navigator.pop(
              context,
              _PasswordChange(
                currentPassword: _currentController.text,
                newPassword: _newController.text,
              ),
            );
          },
          child: const Text('Şifreyi Değiştir'),
        ),
      ],
    );
  }
}
