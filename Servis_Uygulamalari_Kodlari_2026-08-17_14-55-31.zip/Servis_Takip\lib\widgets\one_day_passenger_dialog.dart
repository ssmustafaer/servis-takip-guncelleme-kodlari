import 'package:flutter/material.dart';

import '../models/one_day_passenger.dart';
import '../models/personnel.dart';
import '../models/work_shift.dart';
import '../models/shift_definition.dart';
import '../models/institution.dart';
import '../services/one_day_passenger_storage.dart';
import '../services/personnel_storage.dart';
import '../services/shift_calculator.dart';
import '../services/shift_storage.dart';
import '../services/shift_definition_storage.dart';
import '../services/institution_storage.dart';

class OneDayPassengerDialog extends StatefulWidget {
  const OneDayPassengerDialog({
    this.initialDate,
    this.initialShift,
    this.institutionId,
    super.key,
  });

  final DateTime? initialDate;
  final String? initialShift;
  final String? institutionId;

  static Future<bool?> show(
    BuildContext context, {
    DateTime? initialDate,
    String? initialShift,
    String? institutionId,
  }) {
    return Navigator.of(context).push<bool>(
      MaterialPageRoute<bool>(
        builder: (_) => OneDayPassengerDialog(
          initialDate: initialDate,
          initialShift: initialShift,
          institutionId: institutionId,
        ),
      ),
    );
  }

  @override
  State<OneDayPassengerDialog> createState() => _OneDayPassengerDialogState();
}

class _OneDayPassengerDialogState extends State<OneDayPassengerDialog> {
  bool _loading = true;
  bool _saving = false;
  bool _changed = false;
  List<Personnel> _personnel = [];
  List<OneDayPassenger> _assignments = [];
  List<String> _shifts = [];
  String? _personId;
  String? _shift;
  late DateTime _date;
  String _searchText = '';

  @override
  void initState() {
    super.initState();
    _date = widget.initialDate ?? DateTime.now();
    _load();
  }

  Future<void> _load() async {
    try {
      final result = await Future.wait([
        PersonnelStorage.readAll(),
        ShiftStorage.readAll(),
        OneDayPassengerStorage.readAll(),
        ShiftDefinitionStorage.readAll(),
        InstitutionStorage.readAll(),
      ]);
      final institutions = result[4] as List<Institution>;
      final allowedInstitutionIds = widget.institutionId == null
          ? const <String>{}
          : Institution.subtreeIds(institutions, widget.institutionId!);
      final personnel =
          (result[0] as List<Personnel>)
              .where(
                (person) =>
                    widget.institutionId == null ||
                    allowedInstitutionIds.contains(person.institutionId),
              )
              .toList()
            ..sort((a, b) => a.fullName.compareTo(b.fullName));
      final shifts = (result[1] as List<WorkShift>)
          .map((item) => item.name)
          .where((name) => name != ShiftCalculator.idleShift)
          .toList();
      for (final shift in {
        ...Personnel.threeShiftStandard,
        ...Personnel.threeShiftEarly,
        ...Personnel.twoShiftStandard,
        ...Personnel.twoShiftEarly,
      }) {
        if (!shifts.contains(shift)) shifts.add(shift);
      }
      for (final definition in result[3] as List<ShiftDefinition>) {
        for (final slot in definition.slots) {
          if (!shifts.contains(slot.label)) shifts.add(slot.label);
        }
      }
      if (!mounted) return;
      setState(() {
        _personnel = personnel;
        _assignments = result[2] as List<OneDayPassenger>;
        _shifts = shifts;
        _personId = personnel.isEmpty ? null : personnel.first.id;
        _shift = widget.initialShift ?? (shifts.isEmpty ? null : shifts.first);
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
    }
  }

  String get _dateIso {
    final year = _date.year.toString().padLeft(4, '0');
    final month = _date.month.toString().padLeft(2, '0');
    final day = _date.day.toString().padLeft(2, '0');
    return '$year-$month-$day';
  }

  String get _dateText {
    final day = _date.day.toString().padLeft(2, '0');
    final month = _date.month.toString().padLeft(2, '0');
    return '$day.$month.${_date.year}';
  }

  List<OneDayPassenger> get _selectedDateAssignments {
    final visiblePersonIds = _personnel.map((person) => person.id).toSet();
    final assignments = _assignments
        .where(
          (assignment) =>
              assignment.date == _dateIso &&
              visiblePersonIds.contains(assignment.personId),
        )
        .toList();
    assignments.sort((first, second) {
      final firstName = _personName(first.personId);
      final secondName = _personName(second.personId);
      return firstName.compareTo(secondName);
    });
    return assignments;
  }

  String _personName(String personId) {
    for (final person in _personnel) {
      if (person.id == personId) return person.fullName;
    }
    return 'Kayıtlı personel';
  }

  Future<void> _selectDate() async {
    final selected = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 730)),
    );
    if (selected != null && mounted) setState(() => _date = selected);
  }

  Future<void> _save() async {
    final personId = _personId;
    final shift = _shift;
    if (personId == null || shift == null) return;
    final person = _personnel.firstWhere((item) => item.id == personId);
    setState(() => _saving = true);
    try {
      await OneDayPassengerStorage.save(
        OneDayPassenger(
          id: '${_dateIso}_${personId}_${shift.replaceAll('/', '_').replaceAll(' ', '')}',
          personId: personId,
          institutionId: person.institutionId,
          date: _dateIso,
          shift: shift,
        ),
      );
      if (mounted) Navigator.pop(context, true);
    } catch (error) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Yolcu eklenemedi: $error')));
    }
  }

  Future<void> _deleteAssignment(OneDayPassenger assignment) async {
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Yolcuyu listeden çıkar'),
        content: Text(
          '${_personName(assignment.personId)} adlı yolcu '
          '${assignment.shift} vardiyasından çıkarılsın mı?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFB3261E),
            ),
            icon: const Icon(Icons.person_remove_rounded),
            label: const Text('LİSTEDEN ÇIKAR'),
          ),
        ],
      ),
    );
    if (approved != true || !mounted) return;

    setState(() => _saving = true);
    try {
      await OneDayPassengerStorage.delete(assignment.id);
      if (!mounted) return;
      setState(() {
        _assignments.removeWhere((item) => item.id == assignment.id);
        _saving = false;
        _changed = true;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Yolcu vardiya listesinden çıkarıldı.')),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Yolcu çıkarılamadı: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final noRecords = _personnel.isEmpty || _shifts.isEmpty;
    final selectedDateAssignments = _selectedDateAssignments;
    final filteredPersonnel = _personnel
        .where(
          (person) => person.fullName.toLowerCase().contains(
            _searchText.trim().toLowerCase(),
          ),
        )
        .toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Yolcu Ekle')),
      body: SafeArea(
        child: _loading
            ? const Padding(
                padding: EdgeInsets.all(24),
                child: Center(child: CircularProgressIndicator()),
              )
            : noRecords
            ? const Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  'İşlem için en az bir personel ve bir vardiya kaydı gerekir.',
                ),
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Sadece bu vardiya için yolcu eklenir ve raporlarda görünür.',
                        style: TextStyle(
                          color: Color(0xFF52657B),
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    TextField(
                      decoration: const InputDecoration(
                        labelText: 'Personel Ara',
                        prefixIcon: Icon(Icons.search_rounded),
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (value) => setState(() => _searchText = value),
                    ),
                    const SizedBox(height: 8),
                    Container(
                      constraints: const BoxConstraints(maxHeight: 190),
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFFD0D8E2)),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: filteredPersonnel.length,
                        itemBuilder: (context, index) {
                          final person = filteredPersonnel[index];
                          return RadioListTile<String>(
                            dense: true,
                            value: person.id,
                            groupValue: _personId,
                            title: Text(
                              person.fullName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              person.stopName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            onChanged: _saving
                                ? null
                                : (value) => setState(() => _personId = value),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 14),
                    Visibility(
                      visible: false,
                      child: DropdownButtonFormField<String>(
                        initialValue: _personId,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'Personel',
                          border: OutlineInputBorder(),
                        ),
                        items: _personnel
                            .map(
                              (person) => DropdownMenuItem(
                                value: person.id,
                                child: Text(
                                  person.fullName,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            )
                            .toList(),
                        onChanged: _saving
                            ? null
                            : (value) => setState(() => _personId = value),
                      ),
                    ),
                    const SizedBox(height: 14),
                    InkWell(
                      onTap: _saving || widget.initialDate != null
                          ? null
                          : _selectDate,
                      borderRadius: BorderRadius.circular(4),
                      child: InputDecorator(
                        decoration: const InputDecoration(
                          labelText: 'Tarih',
                          border: OutlineInputBorder(),
                          suffixIcon: Icon(Icons.calendar_month_rounded),
                        ),
                        child: Text(_dateText),
                      ),
                    ),
                    const SizedBox(height: 14),
                    DropdownButtonFormField<String>(
                      initialValue: _shift,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Vardiya',
                        border: OutlineInputBorder(),
                      ),
                      items: _shifts
                          .map(
                            (shift) => DropdownMenuItem(
                              value: shift,
                              child: Text(shift),
                            ),
                          )
                          .toList(),
                      onChanged: _saving || widget.initialShift != null
                          ? null
                          : (value) => setState(() => _shift = value),
                    ),
                    const SizedBox(height: 18),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        '$_dateText tarihine eklenen yolcular',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w800,
                          color: const Color(0xFF082A52),
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    if (selectedDateAssignments.isEmpty)
                      const Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Bu tarih için geçici yolcu eklenmemiş.',
                          style: TextStyle(color: Color(0xFF66788A)),
                        ),
                      )
                    else
                      ...selectedDateAssignments.map(
                        (assignment) => Card(
                          margin: const EdgeInsets.only(bottom: 7),
                          child: ListTile(
                            dense: true,
                            leading: const CircleAvatar(
                              child: Icon(Icons.person_rounded, size: 19),
                            ),
                            title: Text(
                              _personName(assignment.personId),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text(
                                  assignment.shift,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: Color(0xFF0B6E4F),
                                  ),
                                ),
                                IconButton(
                                  tooltip: 'Listeden çıkar',
                                  onPressed: _saving
                                      ? null
                                      : () => _deleteAssignment(assignment),
                                  color: const Color(0xFFB3261E),
                                  icon: const Icon(Icons.person_remove_rounded),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _saving
                      ? null
                      : () => Navigator.pop(context, _changed),
                  child: Text(_changed ? 'KAPAT' : 'VAZGEÇ'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: FilledButton.icon(
                  onPressed: _loading || _saving || noRecords ? null : _save,
                  icon: _saving
                      ? const SizedBox.square(
                          dimension: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.person_add_alt_1_rounded),
                  label: const Text('YOLCUYU EKLE'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
