import 'package:flutter/material.dart';

import '../company/models/company_employee.dart';
import '../company/models/company_session.dart';
import '../company/services/company_employee_repository.dart';
import '../services/authorized_contact_storage.dart';

class EmergencyContactsScreen extends StatefulWidget {
  const EmergencyContactsScreen({required this.session, super.key});

  final CompanySession session;

  @override
  State<EmergencyContactsScreen> createState() =>
      _EmergencyContactsScreenState();
}

class _EmergencyContactsScreenState extends State<EmergencyContactsScreen> {
  final _repository = CompanyEmployeeRepository();
  List<AuthorizedContact> _contacts = const [];
  bool _loading = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final contacts = await AuthorizedContactStorage.readAll();
    if (!mounted) return;
    setState(() {
      _contacts = contacts;
      _loading = false;
    });
  }

  Future<void> _save(List<AuthorizedContact> contacts) async {
    setState(() {
      _contacts = contacts;
      _saving = true;
    });
    try {
      await AuthorizedContactStorage.saveAll(contacts);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _add(List<CompanyEmployee> employees) async {
    if (_contacts.length >= 3) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('En fazla 3 acil kişi eklenebilir.')),
      );
      return;
    }
    final available = employees
        .where(
          (employee) =>
              employee.active &&
              !_contacts.any((item) => item.employeeId == employee.id),
        )
        .toList();
    if (available.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Acil listeye eklenebilecek aktif çalışan bulunamadı.'),
        ),
      );
      return;
    }

    String? selectedId = available.first.id;
    final phoneController = TextEditingController(text: available.first.phone);
    String? phoneError;
    final selected = await showDialog<AuthorizedContact>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) {
          final selectedEmployee = available.firstWhere(
            (item) => item.id == selectedId,
          );
          return AlertDialog(
            title: const Text('Acil Kişisi Ekle'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButtonFormField<String>(
                  initialValue: selectedId,
                  decoration: const InputDecoration(
                    labelText: 'Şirket çalışanı',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.person_rounded),
                  ),
                  items: available
                      .map(
                        (employee) => DropdownMenuItem(
                          value: employee.id,
                          child: Text(employee.displayName),
                        ),
                      )
                      .toList(),
                  onChanged: (value) {
                    if (value == null) return;
                    final employee = available.firstWhere(
                      (item) => item.id == value,
                    );
                    setDialogState(() {
                      selectedId = value;
                      phoneController.text = employee.phone;
                      phoneError = null;
                    });
                  },
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    labelText: 'Telefon numarası',
                    hintText: '05xx xxx xx xx',
                    border: const OutlineInputBorder(),
                    prefixIcon: const Icon(Icons.phone_rounded),
                    errorText: phoneError,
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: const Text('VAZGEÇ'),
              ),
              FilledButton(
                onPressed: () {
                  final phone = phoneController.text.trim();
                  final digits = phone.replaceAll(RegExp(r'[^0-9]'), '');
                  if (digits.length < 10) {
                    setDialogState(
                      () => phoneError = 'Geçerli telefon numarası girin.',
                    );
                    return;
                  }
                  Navigator.pop(
                    dialogContext,
                    AuthorizedContact(
                      employeeId: selectedEmployee.id,
                      name: selectedEmployee.displayName,
                      phone: phone,
                    ),
                  );
                },
                child: const Text('EKLE'),
              ),
            ],
          );
        },
      ),
    );
    phoneController.dispose();
    if (selected == null) return;
    await _save([..._contacts, selected]);
  }

  Future<void> _move(int index, int direction) async {
    final target = index + direction;
    if (target < 0 || target >= _contacts.length) return;
    final updated = [..._contacts];
    final contact = updated.removeAt(index);
    updated.insert(target, contact);
    await _save(updated);
  }

  Future<void> _remove(int index) async {
    final contact = _contacts[index];
    final approved = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Acil kişisi kaldırılsın mı?'),
        content: Text('${contact.name} acil arama listesinden çıkarılacak.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('KALDIR'),
          ),
        ],
      ),
    );
    if (approved != true) return;
    final updated = [..._contacts]..removeAt(index);
    await _save(updated);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Acil Aranacak Kişiler'),
        actions: [
          if (_saving)
            const Padding(
              padding: EdgeInsets.only(right: 16),
              child: Center(
                child: SizedBox.square(
                  dimension: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : StreamBuilder<List<CompanyEmployee>>(
              stream: _repository.watchEmployees(widget.session.companyId),
              builder: (context, snapshot) {
                final employees = snapshot.data ?? const <CompanyEmployee>[];
                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    FilledButton.icon(
                      onPressed: _saving || _contacts.length >= 3
                          ? null
                          : () => _add(employees),
                      icon: const Icon(Icons.person_add_alt_1_rounded),
                      label: const Text('ACİL KİŞİSİ EKLE'),
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      'En fazla 3 kişi eklenebilir. 1 numaralı kişi ilk aranacak kişidir.',
                      style: TextStyle(color: Color(0xFF52657B)),
                    ),
                    const SizedBox(height: 14),
                    if (_contacts.isEmpty)
                      const Card(
                        child: Padding(
                          padding: EdgeInsets.all(20),
                          child: Text(
                            'Henüz acil aranacak kişi eklenmedi.',
                            textAlign: TextAlign.center,
                          ),
                        ),
                      ),
                    for (var index = 0; index < _contacts.length; index++)
                      Card(
                        child: ListTile(
                          leading: CircleAvatar(child: Text('${index + 1}')),
                          title: Text(
                            _contacts[index].name,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          subtitle: Text(_contacts[index].phone),
                          trailing: Wrap(
                            spacing: 0,
                            children: [
                              IconButton(
                                tooltip: 'Yukarı taşı',
                                onPressed: index == 0 || _saving
                                    ? null
                                    : () => _move(index, -1),
                                icon: const Icon(Icons.arrow_upward_rounded),
                              ),
                              IconButton(
                                tooltip: 'Aşağı taşı',
                                onPressed:
                                    index == _contacts.length - 1 || _saving
                                    ? null
                                    : () => _move(index, 1),
                                icon: const Icon(Icons.arrow_downward_rounded),
                              ),
                              IconButton(
                                tooltip: 'Listeden çıkar',
                                onPressed: _saving
                                    ? null
                                    : () => _remove(index),
                                icon: const Icon(
                                  Icons.delete_outline_rounded,
                                  color: Colors.redAccent,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
    );
  }
}
