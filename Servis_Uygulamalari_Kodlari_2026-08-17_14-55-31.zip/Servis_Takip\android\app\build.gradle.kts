import java.util.Properties as JavaProperties
import java.io.File

plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

val localProperties = JavaProperties().apply {
    val propertiesFile = rootProject.file("local.properties")
    if (propertiesFile.exists()) {
        propertiesFile.inputStream().use { load(it) }
    }
}

val signingPropertiesFile = System.getenv("SERVIS_TAKIP_SIGNING_PROPERTIES")
    ?.takeIf { it.isNotBlank() }
    ?.let(::File)
    ?: File(
        System.getProperty("user.home"),
        "Documents/Codex/Servis_Takip_Signing/key.properties",
    )

val signingProperties = JavaProperties().apply {
    require(signingPropertiesFile.exists()) {
        "Servis Takip release signing properties not found: ${signingPropertiesFile.absolutePath}"
    }
    signingPropertiesFile.inputStream().use { load(it) }
}

android {
    namespace = "com.example.servis_takip"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    buildFeatures {
        resValues = true
    }

    flavorDimensions += "application"

    productFlavors {
        create("client") {
            dimension = "application"
            resValue("string", "app_name", "Servis Takip")
        }
        create("admin") {
            dimension = "application"
            applicationIdSuffix = ".admin"
            resValue("string", "app_name", "Servis Takip Yönetici Paneli")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.example.servis_takip"
        // You can update the following values to match your application needs.
        // For more information, see: https://flutter.dev/to/review-gradle-config.
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        manifestPlaceholders["MAPS_API_KEY"] =
            localProperties.getProperty("MAPS_API_KEY")
                ?: System.getenv("MAPS_API_KEY")
                ?: ""
    }


    signingConfigs {
        create("release") {
            keyAlias = signingProperties.getProperty("keyAlias")
            keyPassword = signingProperties.getProperty("keyPassword")
            storeFile = file(signingProperties.getProperty("storeFile"))
            storePassword = signingProperties.getProperty("storePassword")
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}
