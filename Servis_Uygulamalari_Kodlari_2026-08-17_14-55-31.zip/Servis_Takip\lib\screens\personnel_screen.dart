import 'package:flutter/material.dart';

import '../models/institution.dart';
import '../models/personnel.dart';
import '../services/institution_storage.dart';
import '../services/personnel_filter_preference_storage.dart';
import '../services/personnel_storage.dart';
import '../services/deleted_records_storage.dart';
import '../services/shift_calculator.dart';
import 'personnel_form_screen.dart';

class PersonnelScreen extends StatefulWidget {
  const PersonnelScreen({super.key});

  @override
  State<PersonnelScreen> createState() => _PersonnelScreenState();
}

class _PersonnelScreenState extends State<PersonnelScreen> {
  final _searchController = TextEditingController();
  bool _loading = true;
  List<Personnel> _personnel = [];
  List<Institution> _institutions = [];
  String _institutionFilterId = '';
  String _workStyleFilterId = '';
  String _regionFilterId = '';
  String _groupFilterId = '';
  String _searchQuery = '';

  List<Institution> get _rootInstitutions => Institution.childrenOf(
    _institutions.where((item) => item.active).toList(),
    null,
  );

  List<Institution> get _workStyles => _institutionFilterId.isEmpty
      ? const []
      : Institution.childrenOf(
          _institutions,
          _institutionFilterId,
        ).where((item) => item.active).toList();

  bool _isLegacyWorkStyle(Institution item) {
    final name = item.name.toLowerCase();
    return name.contains('vardiya') ||
        name.contains('memur') ||
        name.contains('güvenlik') ||
        name.contains('sabit') ||
        name.contains('dinlendirici');
  }

  List<Institution> get _regions {
    if (_institutionFilterId.isEmpty) return const [];
    final result = <Institution>[];
    for (final child in Institution.childrenOf(
      _institutions,
      _institutionFilterId,
    )) {
      if (_isLegacyWorkStyle(child)) {
        result.addAll(Institution.childrenOf(_institutions, child.id));
      } else {
        result.add(child);
      }
    }
    return result.where((item) => item.active).toList();
  }

  List<Institution> get _groups => _regionFilterId.isEmpty
      ? const []
      : Institution.childrenOf(
          _institutions,
          _regionFilterId,
        ).where((item) => item.active).toList();

  List<Personnel> get _filteredPersonnel {
    late final List<Personnel> institutionFiltered;
    if (_groupFilterId == _unassignedGroupFilter) {
      institutionFiltered = _personnel
          .where((person) => person.institutionId == _regionFilterId)
          .toList();
    } else {
      final selectedId = _groupFilterId.isNotEmpty
          ? _groupFilterId
          : _regionFilterId.isNotEmpty
          ? _regionFilterId
          : _workStyleFilterId.isNotEmpty
          ? _workStyleFilterId
          : _institutionFilterId;
      if (selectedId.isEmpty) {
        institutionFiltered = _personnel;
      } else {
        final allowedIds = Institution.subtreeIds(_institutions, selectedId);
        institutionFiltered = _personnel
            .where((person) => allowedIds.contains(person.institutionId))
            .toList();
      }
    }
    final query = _searchQuery.trim().toLowerCase();
    if (query.isEmpty) return institutionFiltered;
    return institutionFiltered
        .where((person) => person.fullName.toLowerCase().contains(query))
        .toList();
  }

  static const _unassignedGroupFilter = '__unassigned_group__';

  List<String> _missingInformation(Personnel person) {
    final missing = <String>[];
    if (person.fullName.trim().isEmpty) missing.add('Ad soyad');
    if (person.phone.trim().isEmpty) missing.add('Telefon');
    if (person.institutionId.trim().isEmpty ||
        person.institutionName.trim().isEmpty) {
      missing.add('Kurum');
    }
    if (person.stopName.trim().isEmpty || person.stopOrder < 1) {
      missing.add('Durak');
    }
    if (person.stopLatitude == null || person.stopLongitude == null) {
      missing.add('Durak konumu');
    }
    if (person.workType.trim().isEmpty) missing.add('Çalışma şekli');
    if (person.workType != Personnel.reliefWorkType &&
        person.workType != Personnel.guestWorkType &&
        person.shift.trim().isEmpty) {
      missing.add('Vardiya');
    }
    // Haftanın günüyle çalışan düzende en az bir izin günü gerekir.
    // "Çalışma Günü ile" düzeninde izin, gün sayısıyla hesaplandığı için
    // haftalık izin listesinin boş olması eksik bilgi değildir.
    if (person.workType != Personnel.reliefWorkType &&
        person.workType != Personnel.guestWorkType &&
        person.leaveMode == Personnel.weeklyLeaveMode &&
        person.leaveWeekdays.isEmpty) {
      missing.add('İzinli gün');
    }
    if (person.workType == Personnel.reliefWorkType &&
        !person.reliefWeeklyShifts.values.any((shifts) => shifts.isNotEmpty) &&
        !person.reliefMonthlyShifts.values.any((shifts) => shifts.isNotEmpty)) {
      missing.add('Çalışma günleri');
    }
    return missing;
  }

  @override
  void initState() {
    super.initState();
    _loadPersonnel();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadPersonnel() async {
    final result = await Future.wait([
      PersonnelStorage.readAll(),
      InstitutionStorage.readAll(),
      PersonnelFilterPreferenceStorage.read(),
    ]);
    final personnel = result[0] as List<Personnel>;
    final institutions = result[1] as List<Institution>;
    final preference = result[2] as PersonnelFilterPreference;
    final rootIds = Institution.childrenOf(
      institutions,
      null,
    ).map((item) => item.id).toSet();
    final institutionId = rootIds.contains(preference.institutionId)
        ? preference.institutionId
        : '';
    const workStyleId = '';
    final regionIds = <String>{};
    if (institutionId.isNotEmpty) {
      for (final child in Institution.childrenOf(institutions, institutionId)) {
        if (_isLegacyWorkStyle(child)) {
          regionIds.addAll(
            Institution.childrenOf(
              institutions,
              child.id,
            ).map((item) => item.id),
          );
        } else {
          regionIds.add(child.id);
        }
      }
    }
    final regionId = regionIds.contains(preference.regionId)
        ? preference.regionId
        : '';
    final groupIds = regionId.isEmpty
        ? const <String>{}
        : Institution.childrenOf(
            institutions,
            regionId,
          ).map((item) => item.id).toSet();
    final groupId = preference.groupId == _unassignedGroupFilter
        ? _unassignedGroupFilter
        : groupIds.contains(preference.groupId)
        ? preference.groupId
        : '';
    if (!mounted) return;
    setState(() {
      _personnel = personnel;
      _institutions = institutions;
      _institutionFilterId = institutionId;
      _workStyleFilterId = workStyleId;
      _regionFilterId = regionId;
      _groupFilterId = groupId;
      _loading = false;
    });
  }

  Future<void> _saveFilters() {
    return PersonnelFilterPreferenceStorage.save(
      PersonnelFilterPreference(
        institutionId: _institutionFilterId,
        workStyleId: _workStyleFilterId,
        regionId: _regionFilterId,
        groupId: _groupFilterId,
      ),
    );
  }

  void _selectInstitution(String? value) {
    setState(() {
      _institutionFilterId = value ?? '';
      _workStyleFilterId = '';
      _regionFilterId = '';
      _groupFilterId = '';
    });
    _saveFilters();
  }

  void _selectWorkStyle(String? value) {
    setState(() {
      _workStyleFilterId = value ?? '';
      _regionFilterId = '';
      _groupFilterId = '';
    });
    _saveFilters();
  }

  void _selectRegion(String? value) {
    setState(() {
      _regionFilterId = value ?? '';
      _groupFilterId = '';
    });
    _saveFilters();
  }

  void _selectGroup(String? value) {
    setState(() => _groupFilterId = value ?? '');
    _saveFilters();
  }

  Future<void> _addPersonnel() async {
    final person = await Navigator.of(context).push<Personnel>(
      MaterialPageRoute(builder: (_) => const PersonnelFormScreen()),
    );
    if (person == null) return;

    final updated = [..._personnel, person]
      ..sort((a, b) => a.stopOrder.compareTo(b.stopOrder));
    await PersonnelStorage.saveAll(updated);
    if (!mounted) return;
    setState(() => _personnel = updated);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '${person.fullName}, ${person.stopOrder}. sıraya eklendi.',
        ),
      ),
    );
  }

  Future<void> _deletePersonnel(Personnel person) async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Personeli sil'),
        content: Text('${person.fullName} kaydı silinsin mi?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
            child: const Text('Sil'),
          ),
        ],
      ),
    );
    if (shouldDelete != true) return;

    await DeletedRecordsStorage.archivePersonnel(person);
    final updated = _personnel.where((item) => item.id != person.id).toList();
    await PersonnelStorage.saveAll(updated);
    if (!mounted) return;
    setState(() => _personnel = updated);
  }

  Future<void> _editPersonnel(Personnel person) async {
    final edited = await Navigator.of(context).push<Personnel>(
      MaterialPageRoute(builder: (_) => PersonnelFormScreen(personnel: person)),
    );
    if (edited == null) return;

    final updated = _personnel.where((item) => item.id != person.id).toList()
      ..add(edited)
      ..sort((a, b) => a.stopOrder.compareTo(b.stopOrder));

    await PersonnelStorage.saveAll(updated);
    if (!mounted) return;
    setState(() => _personnel = updated);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Personel bilgileri güncellendi.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filteredPersonnel = _filteredPersonnel;
    return Scaffold(
      appBar: AppBar(title: const Text('Personel')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addPersonnel,
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('Personel Ekle'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Card(
                  margin: const EdgeInsets.fromLTRB(12, 12, 12, 4),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      children: [
                        TextField(
                          controller: _searchController,
                          autofocus: false,
                          textInputAction: TextInputAction.search,
                          decoration: InputDecoration(
                            labelText: 'Personel Ara',
                            hintText: 'Ad veya soyad yazın',
                            prefixIcon: const Icon(Icons.search_rounded),
                            suffixIcon: _searchQuery.isEmpty
                                ? null
                                : IconButton(
                                    onPressed: () {
                                      _searchController.clear();
                                      setState(() => _searchQuery = '');
                                    },
                                    icon: const Icon(Icons.close_rounded),
                                    tooltip: 'Aramayı temizle',
                                  ),
                            border: const OutlineInputBorder(),
                            isDense: true,
                          ),
                          onChanged: (value) =>
                              setState(() => _searchQuery = value),
                        ),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          initialValue: _institutionFilterId,
                          isExpanded: true,
                          decoration: const InputDecoration(
                            labelText: 'Kurum Seçimi',
                            prefixIcon: Icon(Icons.domain_rounded),
                            border: OutlineInputBorder(),
                            isDense: true,
                          ),
                          items: [
                            const DropdownMenuItem(
                              value: '',
                              child: Text('Tüm Kurumlar'),
                            ),
                            ..._rootInstitutions.map(
                              (item) => DropdownMenuItem(
                                value: item.id,
                                child: Text(item.name),
                              ),
                            ),
                          ],
                          onChanged: _selectInstitution,
                        ),
                        if (_institutionFilterId.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          DropdownButtonFormField<String>(
                            key: ValueKey(
                              'personnel-region-$_workStyleFilterId-$_regionFilterId',
                            ),
                            initialValue: _regionFilterId,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'Bölge Seçimi',
                              prefixIcon: Icon(
                                Icons.subdirectory_arrow_right_rounded,
                              ),
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: [
                              const DropdownMenuItem(
                                value: '',
                                child: Text('Tüm Bölgeler'),
                              ),
                              ..._regions.map(
                                (item) => DropdownMenuItem(
                                  value: item.id,
                                  child: Text(item.name),
                                ),
                              ),
                            ],
                            onChanged: _selectRegion,
                          ),
                        ],
                        if (_regionFilterId.isNotEmpty) ...[
                          const SizedBox(height: 10),
                          DropdownButtonFormField<String>(
                            key: ValueKey(
                              'personnel-group-$_regionFilterId-$_groupFilterId',
                            ),
                            initialValue: _groupFilterId,
                            isExpanded: true,
                            decoration: const InputDecoration(
                              labelText: 'Takım Seçimi (isteğe bağlı)',
                              prefixIcon: Icon(Icons.groups_2_outlined),
                              border: OutlineInputBorder(),
                              isDense: true,
                            ),
                            items: [
                              const DropdownMenuItem(
                                value: '',
                                child: Text('Tüm Takımlar'),
                              ),
                              const DropdownMenuItem(
                                value: _unassignedGroupFilter,
                                child: Text('Takım Seçilmemişler'),
                              ),
                              ..._groups.map(
                                (item) => DropdownMenuItem(
                                  value: item.id,
                                  child: Text(item.name),
                                ),
                              ),
                            ],
                            onChanged: _selectGroup,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: _personnel.isEmpty
                      ? const _EmptyPersonnelState()
                      : filteredPersonnel.isEmpty
                      ? const Center(
                          child: Text(
                            'Seçilen filtrelere uygun personel bulunamadı.',
                            textAlign: TextAlign.center,
                          ),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                          itemCount: filteredPersonnel.length,
                          separatorBuilder: (_, _) =>
                              const SizedBox(height: 10),
                          itemBuilder: (context, index) {
                            final person = filteredPersonnel[index];
                            final missing = _missingInformation(person);
                            final hasMissingInformation = missing.isNotEmpty;
                            final status = ShiftCalculator.forDate(
                              person,
                              DateTime.now(),
                            );
                            final statusText =
                                person.workType == Personnel.guestWorkType
                                ? 'Vardiyasız'
                                : status.shift == ShiftCalculator.idleShift
                                ? 'Boşta'
                                : status.isLeave
                                ? 'Bugün izinli'
                                : person.workType == Personnel.reliefWorkType
                                ? '${status.shift}'
                                : '${status.shift} • ${status.workingDay}. çalışma günü';
                            return Card(
                              color: hasMissingInformation
                                  ? const Color(0xFFFFE8E6)
                                  : null,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                                side: hasMissingInformation
                                    ? const BorderSide(
                                        color: Color(0xFFB3261E),
                                        width: 1.4,
                                      )
                                    : BorderSide.none,
                              ),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: hasMissingInformation
                                      ? const Color(0xFFB3261E)
                                      : null,
                                  foregroundColor: hasMissingInformation
                                      ? Colors.white
                                      : null,
                                  child: Text('${index + 1}'),
                                ),
                                title: Text(
                                  person.fullName,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    color: hasMissingInformation
                                        ? const Color(0xFFB3261E)
                                        : null,
                                  ),
                                ),
                                subtitle: Text(
                                  hasMissingInformation
                                      ? '${person.stopName}\nEksik: ${missing.join(', ')}'
                                      : '${person.stopName}${person.stopLatitude == null ? '' : ' • Konum kayıtlı'}\n'
                                            '${person.workType} • $statusText',
                                  style: hasMissingInformation
                                      ? const TextStyle(
                                          color: Color(0xFF8C1D18),
                                        )
                                      : null,
                                ),
                                isThreeLine: true,
                                trailing: PopupMenuButton<String>(
                                  onSelected: (value) {
                                    if (value == 'edit') _editPersonnel(person);
                                    if (value == 'delete') {
                                      _deletePersonnel(person);
                                    }
                                  },
                                  itemBuilder: (context) => const [
                                    PopupMenuItem(
                                      value: 'edit',
                                      child: ListTile(
                                        leading: Icon(Icons.edit_outlined),
                                        title: Text('Düzenle'),
                                      ),
                                    ),
                                    PopupMenuItem(
                                      value: 'delete',
                                      child: ListTile(
                                        leading: Icon(
                                          Icons.delete_outline_rounded,
                                        ),
                                        title: Text('Sil'),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

class _EmptyPersonnelState extends StatelessWidget {
  const _EmptyPersonnelState();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Padding(
        padding: EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.people_outline_rounded,
              size: 72,
              color: Color(0xFF52657B),
            ),
            SizedBox(height: 16),
            Text(
              'Henüz personel yok.',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700),
            ),
            SizedBox(height: 8),
            Text(
              'Sağ alttaki Personel Ekle düğmesine basarak ilk kaydı oluşturun.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xFF52657B)),
            ),
          ],
        ),
      ),
    );
  }
}
