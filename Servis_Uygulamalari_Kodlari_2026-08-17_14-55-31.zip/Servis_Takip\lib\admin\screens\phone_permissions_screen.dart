import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../services/admin_repository.dart';

class PhonePermissionsScreen extends StatelessWidget {
  const PhonePermissionsScreen({required this.repository, super.key});

  final AdminRepository repository;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Telefon Yetkileri')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
        stream: repository.watchRegisteredDevices(),
        builder: (context, usersSnapshot) {
          if (usersSnapshot.hasError) {
            return Center(
              child: Text('Telefonlar yüklenemedi: ${usersSnapshot.error}'),
            );
          }
          if (!usersSnapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: repository.watchDeviceExemptions(),
            builder: (context, exemptionsSnapshot) {
              if (exemptionsSnapshot.hasError) {
                return Center(
                  child: Text(
                    'Telefon yetkileri yüklenemedi: ${exemptionsSnapshot.error}',
                  ),
                );
              }
              if (!exemptionsSnapshot.hasData) {
                return const Center(child: CircularProgressIndicator());
              }
              final exemptIds = exemptionsSnapshot.data!.docs
                  .where((doc) => doc.data()['active'] == true)
                  .map((doc) => doc.id)
                  .toSet();
              final devices = <String, _RegisteredDevice>{};
              for (final document in usersSnapshot.data!.docs) {
                final data = document.data();
                final deviceId = (data['deviceId'] as String? ?? '').trim();
                if (deviceId.isEmpty) continue;
                final displayName =
                    (data['displayName'] as String? ?? 'Kullanıcı').trim();
                final deviceName = (data['deviceName'] as String? ?? 'Telefon')
                    .trim();
                devices[document.id] = _RegisteredDevice(
                  userId: document.id,
                  id: deviceId,
                  name: deviceName,
                  userName: displayName,
                );
              }
              final list = devices.values.toList()
                ..sort((a, b) => a.userName.compareTo(b.userName));

              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  const Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Text(
                        'Muafiyet yalnızca seçilen kullanıcı ile kayıtlı '
                        'telefonu için geçerlidir. Aynı telefondaki diğer '
                        'kullanıcılar muaf olmaz.',
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (list.isEmpty)
                    const Padding(
                      padding: EdgeInsets.all(24),
                      child: Text(
                        'Henüz sisteme kaydolmuş telefon bulunamadı.',
                        textAlign: TextAlign.center,
                      ),
                    ),
                  for (final device in list)
                    Card(
                      child: SwitchListTile(
                        secondary: Icon(
                          exemptIds.contains(device.exemptionId)
                              ? Icons.phonelink_lock_rounded
                              : Icons.phone_android_rounded,
                        ),
                        title: Text(device.userName),
                        subtitle: Text(
                          '${device.name} • Kod: ${device.shortCode}',
                        ),
                        value: exemptIds.contains(device.exemptionId),
                        onChanged: (value) => _setExemption(
                          context,
                          device: device,
                          active: value,
                        ),
                      ),
                    ),
                ],
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _setExemption(
    BuildContext context, {
    required _RegisteredDevice device,
    required bool active,
  }) async {
    try {
      await repository.setDeviceExemption(
        userId: device.userId,
        deviceId: device.id,
        deviceName: device.name,
        active: active,
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            active ? 'Telefon muaf yapıldı.' : 'Telefon muafiyeti kaldırıldı.',
          ),
        ),
      );
    } catch (error) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('İşlem tamamlanamadı: $error')));
    }
  }
}

class _RegisteredDevice {
  const _RegisteredDevice({
    required this.userId,
    required this.id,
    required this.name,
    required this.userName,
  });

  final String userId;
  final String id;
  final String name;
  final String userName;

  String get exemptionId => '${userId}_$id';

  String get shortCode => id.length <= 6 ? id : id.substring(id.length - 6);
}
