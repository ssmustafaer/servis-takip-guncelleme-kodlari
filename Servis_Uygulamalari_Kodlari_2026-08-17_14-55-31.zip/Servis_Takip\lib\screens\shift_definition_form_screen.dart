import 'package:flutter/material.dart';

import '../models/shift_definition.dart';
import '../services/shift_time_storage.dart';

class ShiftDefinitionFormScreen extends StatefulWidget {
  const ShiftDefinitionFormScreen({super.key, this.definition});

  final ShiftDefinition? definition;

  @override
  State<ShiftDefinitionFormScreen> createState() =>
      _ShiftDefinitionFormScreenState();
}

class _ShiftDefinitionFormScreenState extends State<ShiftDefinitionFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _descriptionController;
  late String _direction;
  late List<ShiftTimeSlot> _slots;
  List<ShiftTimeSlot> _registeredSlots = [];

  @override
  void initState() {
    super.initState();
    final value = widget.definition;
    _nameController = TextEditingController(text: value?.name ?? '');
    _descriptionController = TextEditingController(
      text: value?.changeDescription ?? '',
    );
    _direction = value?.changeDirection ?? ShiftDefinition.backward;
    _slots = [...?value?.slots];
    _loadRegisteredSlots();
  }

  Future<void> _loadRegisteredSlots() async {
    final items = await ShiftTimeStorage.readAll();
    if (mounted) setState(() => _registeredSlots = items);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  String _clockLabel(int minutes) {
    final hour = minutes ~/ 60;
    final minute = minutes % 60;
    return '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
  }

  Future<void> _addOrEditSlot({int? index}) async {
    final existing = index == null ? null : _slots[index];
    if (_registeredSlots.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Önce Ayarlar > Vardiya Saatleri bölümünden saat ekleyin.',
          ),
        ),
      );
      return;
    }
    String? selectedId = existing == null
        ? null
        : _registeredSlots
              .where(
                (item) =>
                    item.startMinutes == existing.startMinutes &&
                    item.endMinutes == existing.endMinutes,
              )
              .firstOrNull
              ?.id;
    final result = await showDialog<ShiftTimeSlot>(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(index == null ? 'Kayıtlı Saat Seç' : 'Saati Değiştir'),
          content: DropdownButtonFormField<String>(
            initialValue: selectedId,
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'Vardiya Saati',
              border: OutlineInputBorder(),
            ),
            items: [
              for (final item in _registeredSlots)
                DropdownMenuItem(value: item.id, child: Text(item.label)),
            ],
            onChanged: (value) => setDialogState(() => selectedId = value),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Vazgeç'),
            ),
            FilledButton(
              onPressed: selectedId == null
                  ? null
                  : () => Navigator.pop(
                      context,
                      _registeredSlots.firstWhere(
                        (item) => item.id == selectedId,
                      ),
                    ),
              child: const Text('Kaydet'),
            ),
          ],
        ),
      ),
    );
    if (result == null || !mounted) return;
    if (_slots.any(
      (item) =>
          item.id != existing?.id &&
          item.startMinutes == result.startMinutes &&
          item.endMinutes == result.endMinutes,
    )) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bu saat sistemde zaten seçili.')),
      );
      return;
    }
    final slot = result;
    setState(() {
      if (index == null) {
        _slots.add(slot);
      } else {
        _slots[index] = slot;
      }
    });
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    if (_slots.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('En az bir çalışma saati ekleyin.')),
      );
      return;
    }
    final old = widget.definition;
    Navigator.pop(
      context,
      ShiftDefinition(
        id: old?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        name: _nameController.text.trim(),
        order: old?.order ?? 0,
        slots: _slots,
        changeDirection: _direction,
        changeDescription: _descriptionController.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.definition == null
              ? 'Vardiya Sistemi Ekle'
              : 'Vardiya Sistemini Düzenle',
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const _SectionTitle(
              number: '1',
              title: 'Vardiya Tanımı',
              subtitle: 'Örnek: 3’lü Vardiya, 2’li Vardiya, Sabit 08/16',
            ),
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Açıklama',
                border: OutlineInputBorder(),
              ),
              validator: (value) => value == null || value.trim().isEmpty
                  ? 'Vardiya açıklamasını yazın.'
                  : null,
            ),
            const SizedBox(height: 22),
            const _SectionTitle(
              number: '2',
              title: 'Çalışma Saatleri',
              subtitle:
                  'Giriş ve çıkış saatlerini yarım saatlik listeden seçin.',
            ),
            for (var index = 0; index < _slots.length; index++)
              Card(
                child: ListTile(
                  leading: CircleAvatar(child: Text('${index + 1}')),
                  title: Text(
                    _slots[index].label,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    '${_clockLabel(_slots[index].startMinutes)} - '
                    '${_clockLabel(_slots[index].endMinutes)}'
                    '${_slots[index].endsNextDay ? ' (ertesi gün biter)' : ''}',
                  ),
                  onTap: () => _addOrEditSlot(index: index),
                  trailing: IconButton(
                    tooltip: 'Saati kaldır',
                    onPressed: () => setState(() => _slots.removeAt(index)),
                    icon: const Icon(Icons.delete_outline, color: Colors.red),
                  ),
                ),
              ),
            OutlinedButton.icon(
              onPressed: _addOrEditSlot,
              icon: const Icon(Icons.add_alarm_rounded),
              label: const Text('KAYITLI SAAT SEÇ'),
            ),
            const SizedBox(height: 22),
            const _SectionTitle(
              number: '3',
              title: 'Vardiya Değişim Kuralı',
              subtitle:
                  'İzin sonrasında vardiyanın hangi yönde değişeceğini seçin.',
            ),
            DropdownButtonFormField<String>(
              initialValue: _direction,
              decoration: const InputDecoration(
                labelText: 'Değişim Yönü',
                border: OutlineInputBorder(),
              ),
              items: const [
                DropdownMenuItem(
                  value: ShiftDefinition.backward,
                  child: Text('Bir önceki vardiyaya geçer (geri)'),
                ),
                DropdownMenuItem(
                  value: ShiftDefinition.forward,
                  child: Text('Bir sonraki vardiyaya geçer (ileri)'),
                ),
                DropdownMenuItem(
                  value: ShiftDefinition.fixed,
                  child: Text('Vardiya değişmez (sabit)'),
                ),
              ],
              onChanged: (value) {
                if (value != null) setState(() => _direction = value);
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _descriptionController,
              maxLines: 2,
              decoration: const InputDecoration(
                labelText: 'Kural Açıklaması (isteğe bağlı)',
                hintText: 'Örnek: Her izin dönüşünde 8 saat geri gider',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              height: 52,
              child: FilledButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.save_rounded),
                label: const Text('VARDİYA SİSTEMİNİ KAYDET'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({
    required this.number,
    required this.title,
    required this.subtitle,
  });

  final String number;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 15,
            backgroundColor: const Color(0xFF0B315D),
            foregroundColor: Colors.white,
            child: Text(number),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text(
                  subtitle,
                  style: const TextStyle(color: Color(0xFF5E6B78)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
