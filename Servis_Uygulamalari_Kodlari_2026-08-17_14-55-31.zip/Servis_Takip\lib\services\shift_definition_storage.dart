import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/shift_definition.dart';
import 'company_cloud_storage.dart';

class ShiftDefinitionStorage {
  ShiftDefinitionStorage._();

  static const _key = 'shift_definitions_v1';
  static const _collection = 'shiftDefinitions';
  static const _storage = FlutterSecureStorage();

  static Future<List<ShiftDefinition>> readAll() async {
    final localValue = await _storage.read(
      key: await CompanyCloudStorage.cacheKey(_key),
    );
    if (localValue != null && localValue.isNotEmpty) {
      return _decode(localValue);
    }

    final cloudData = await CompanyCloudStorage.readCollection(_collection);
    if (cloudData.isNotEmpty) {
      final definitions = cloudData.map(ShiftDefinition.fromJson).toList()
        ..sort((a, b) => a.order.compareTo(b.order));
      await _writeCache(definitions);
      return definitions;
    }

    return const [];
  }

  static List<ShiftDefinition> _decode(String value) {
    final definitions =
        (jsonDecode(value) as List<dynamic>)
            .map(
              (item) => ShiftDefinition.fromJson(
                Map<String, dynamic>.from(item as Map),
              ),
            )
            .toList()
          ..sort((a, b) => a.order.compareTo(b.order));
    return definitions;
  }

  /// Yeni vardiya sistemleri şirket içindeki bütün cihazlarla paylaşılır.
  static Future<void> saveAll(List<ShiftDefinition> definitions) async {
    final ordered = [
      for (var index = 0; index < definitions.length; index++)
        definitions[index].copyWith(order: index + 1),
    ];
    await CompanyCloudStorage.replaceCollection(
      collectionName: _collection,
      items: ordered.map((item) => item.toJson()).toList(),
    );
    await _writeCache(ordered);
  }

  /// Kullanıcı onayından sonra çağrılarak yerel taslakları buluta gönderir.
  static Future<void> publishToCloud(List<ShiftDefinition> definitions) async {
    await CompanyCloudStorage.replaceCollection(
      collectionName: _collection,
      items: definitions.map((item) => item.toJson()).toList(),
    );
  }

  static Future<void> _writeCache(List<ShiftDefinition> definitions) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_key),
      value: jsonEncode(definitions.map((item) => item.toJson()).toList()),
    );
  }
}
