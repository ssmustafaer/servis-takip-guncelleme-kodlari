import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:package_info_plus/package_info_plus.dart';

class AppUpdateService {
  AppUpdateService._();

  static const _channel = MethodChannel('servis_takip/app_update');
  static final _latestRelease = Uri.parse(
    'https://api.github.com/repos/ssmustafaer/'
    'servis-takip-guncelleme/releases/latest',
  );

  static Future<String> updateIfAvailable() async {
    final client = HttpClient();
    try {
      final request = await client.getUrl(_latestRelease);
      request.headers.set(
        HttpHeaders.acceptHeader,
        'application/vnd.github+json',
      );
      request.headers.set(HttpHeaders.userAgentHeader, 'Servis-Takip-Updater');
      final response = await request.close();
      if (response.statusCode != HttpStatus.ok) {
        throw PlatformException(
          code: 'UPDATE_CHECK_FAILURE',
          message: 'Güncelleme bilgisi alınamadı (${response.statusCode}).',
        );
      }
      final json =
          jsonDecode(await response.transform(utf8.decoder).join())
              as Map<String, dynamic>;
      final tag = json['tag_name'] as String? ?? '';
      final latestBuild = int.tryParse(tag.split('-').last) ?? 0;
      final package = await PackageInfo.fromPlatform();
      final installedBuild = int.tryParse(package.buildNumber) ?? 0;
      if (latestBuild <= installedBuild) return 'up_to_date';

      final assets = json['assets'] as List<dynamic>? ?? const [];
      String apkUrl = '';
      for (final asset in assets.cast<Map<String, dynamic>>()) {
        if (asset['name'] == 'Servis_Takip.apk') {
          apkUrl = asset['browser_download_url'] as String? ?? '';
          break;
        }
      }
      if (apkUrl.isEmpty) {
        throw PlatformException(
          code: 'INVALID_URL',
          message: 'Yeni sürümün APK dosyası bulunamadı.',
        );
      }
      return await _channel.invokeMethod<String>('downloadAndInstall', {
            'url': apkUrl,
          }) ??
          'update_started';
    } finally {
      client.close(force: true);
    }
  }
}
