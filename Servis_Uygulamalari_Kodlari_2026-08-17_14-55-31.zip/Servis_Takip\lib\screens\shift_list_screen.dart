import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/attendance_record.dart';
import '../models/driver.dart';
import '../models/one_day_passenger.dart';
import '../models/personnel.dart';
import '../models/personnel_leave.dart';
import '../models/service_record.dart';
import '../models/stop.dart';
import '../models/institution.dart';
import '../models/vehicle.dart';
import '../models/shift_definition.dart';
import '../services/attendance_storage.dart';
import '../services/authorized_contact_storage.dart';
import '../services/company_cloud_storage.dart';
import '../services/driver_storage.dart';
import '../services/one_day_passenger_storage.dart';
import '../services/personnel_storage.dart';
import '../services/package_access_service.dart';
import '../services/personnel_leave_storage.dart';
import '../services/institution_storage.dart';
import '../services/service_record_storage.dart';
import '../services/shift_calculator.dart';
import '../services/shift_definition_storage.dart';
import '../services/shift_time_storage.dart';
import '../services/stop_storage.dart';
import '../services/vehicle_storage.dart';
import '../widgets/one_day_passenger_dialog.dart';
import 'personnel_form_screen.dart';

enum _EarlyStartChoice { inspect, start, cancel }

class ShiftListScreen extends StatefulWidget {
  const ShiftListScreen({
    super.key,
    this.isDistribution = false,
    this.allInstitutions = true,
    this.allowedInstitutionIds = const [],
    this.allVehicles = true,
    this.allowedVehicleIds = const [],
    this.preferredDriverId,
    this.preferredDriverName,
    this.initialInstitutionId,
    this.initialVehicleId,
    this.canEditPersonnel = true,
    this.groupByStops = false,
    this.showAllStops = false,
  });

  /// Toplama ekranında false, önceki vardiyanın eve bırakma ekranında true.
  final bool isDistribution;
  final bool allInstitutions;
  final List<String> allowedInstitutionIds;
  final bool allVehicles;
  final List<String> allowedVehicleIds;
  final String? preferredDriverId;
  final String? preferredDriverName;
  final String? initialInstitutionId;
  final String? initialVehicleId;
  final bool canEditPersonnel;
  final bool groupByStops;
  final bool showAllStops;

  @override
  State<ShiftListScreen> createState() => _ShiftListScreenState();
}

class _ShiftListScreenState extends State<ShiftListScreen>
    with WidgetsBindingObserver {
  static const _stopOverlayChannel = MethodChannel(
    'com.servis_takip/stop_overlay',
  );
  static const double _stopApproachThresholdMeters = 200;
  StreamSubscription<List<Personnel>>? _personnelSubscription;
  StreamSubscription<Position>? _routePositionSubscription;
  Timer? _criticalSyncTimer;
  final Set<String> _approachedStopKeys = {};
  List<String> _shifts = [];
  final Map<String, int> _shiftWorkdayOffsets = {};
  bool _loading = true;
  List<Personnel> _personnel = [];
  List<OneDayPassenger> _oneDayPassengers = [];
  List<AttendanceRecord> _attendanceRecords = [];
  List<PersonnelLeave> _personnelLeaves = [];
  List<Driver> _drivers = [];
  List<ServiceRecord> _serviceRecords = [];
  List<Institution> _allInstitutions = [];
  List<Institution> _institutions = [];
  List<Vehicle> _vehicles = [];
  List<Stop> _stops = [];
  final Set<String> _expandedPersonnelIds = {};
  final Set<String> _distributionReactivatedIds = {};
  final Set<String> _distributionExcludedIds = {};
  String? _lastAutoOpenedStopKey;
  bool _checkingNearbyStop = false;
  List<AuthorizedContact> _authorizedContacts = const [];
  String _selectedShift = '08 / 16';
  String? _selectedDriverId;
  String? _selectedInstitutionId;
  String? _selectedVehicleId;
  late DateTime _selectedDate;
  bool _openingMap = false;
  bool _openingWhatsApp = false;
  bool _startingService = false;
  bool _finishingService = false;

  @override
  void initState() {
    super.initState();
    _stopOverlayChannel.setMethodCallHandler(_handleOverlayMethod);
    WidgetsBinding.instance.addObserver(this);
    _setInitialShiftAndDate();
    _loadData();
    _watchPersonnel();
    _criticalSyncTimer = Timer.periodic(
      const Duration(seconds: 30),
      (_) => unawaited(_syncPendingCriticalRecords()),
    );
  }

  void _watchPersonnel() {
    _personnelSubscription = PersonnelStorage.watchAll().listen(
      (personnel) {
        if (!mounted) return;
        setState(() {
          _personnel = widget.allInstitutions
              ? personnel
              : personnel
                    .where(
                      (person) => widget.allowedInstitutionIds.contains(
                        person.institutionId,
                      ),
                    )
                    .toList();
        });
      },
      onError: (_) {
        // İlk okuma çalışmaya devam eder; bağlantı gelince ekran yeniden
        // açıldığında buluttaki güncel kayıtlar alınır.
      },
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _personnelSubscription?.cancel();
    _routePositionSubscription?.cancel();
    _criticalSyncTimer?.cancel();
    _stopOverlayChannel.setMethodCallHandler(null);
    _stopOverlayChannel.invokeMethod<void>('hideStopOverlay');
    super.dispose();
  }

  Future<dynamic> _handleOverlayMethod(MethodCall call) async {
    if (!mounted) return false;
    if (call.method == 'overlayStopCompleted') {
      final arguments = Map<String, dynamic>.from(call.arguments as Map? ?? {});
      final passengerIds = (arguments['passengerIds'] as List? ?? const [])
          .map((item) => item.toString())
          .toSet();
      final absentPassengerIds =
          (arguments['absentPassengerIds'] as List? ?? const [])
              .map((item) => item.toString())
              .toSet();
      for (final personId in passengerIds) {
        if (absentPassengerIds.contains(personId)) continue;
        final person = _personnel.cast<Personnel?>().firstWhere(
          (item) => item!.id == personId,
          orElse: () => null,
        );
        if (person != null && _attendanceByPerson[person.id] == null) {
          await _recordAttendance(person, 'Bindi');
        }
      }
      await _openRouteInGoogleMaps();
      return true;
    }
    if (call.method != 'overlayAttendance') return false;
    final arguments = Map<String, dynamic>.from(call.arguments as Map);
    final personId = arguments['personId'] as String?;
    final status = arguments['status'] as String?;
    if (personId == null || status == null) return false;
    final person = _personnel.cast<Personnel?>().firstWhere(
      (item) => item!.id == personId,
      orElse: () => null,
    );
    if (person != null && _isServiceActive) {
      return _recordAttendance(person, status);
    }
    return false;
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _openNearbyStopPassengers();
      unawaited(_syncPendingCriticalRecords());
    }
  }

  Future<void> _syncPendingCriticalRecords() async {
    if (_isServiceActive) return;
    try {
      await Future.wait([
        AttendanceStorage.syncPending(),
        ServiceRecordStorage.syncPending(),
      ]);
    } catch (_) {
      // İnternet hâlâ yoksa kayıtlar telefondaki kuyrukta korunur.
    }
  }

  void _setInitialShiftAndDate() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    const initialShifts = ['24 / 08', '08 / 16', '16 / 24'];
    ({String shift, DateTime workDate, DateTime serviceAt})? nearest;

    for (var dayOffset = -1; dayOffset <= 1; dayOffset++) {
      final workDate = today.add(Duration(days: dayOffset));
      for (final shift in initialShifts) {
        final parts = shift.split('/');
        final rawHour =
            int.tryParse(
              (widget.isDistribution ? parts.last : parts.first).trim(),
            ) ??
            0;
        final serviceAt = workDate.add(
          Duration(hours: widget.isDistribution ? rawHour : rawHour % 24),
        );
        final candidate = (
          shift: shift,
          workDate: workDate,
          serviceAt: serviceAt,
        );
        if (nearest == null ||
            serviceAt.difference(now).abs() <
                nearest.serviceAt.difference(now).abs() ||
            (serviceAt.difference(now).abs() ==
                    nearest.serviceAt.difference(now).abs() &&
                serviceAt.isAfter(nearest.serviceAt))) {
          nearest = candidate;
        }
      }
    }

    _selectedShift = nearest!.shift;
    _selectedDate = nearest.workDate;
  }

  Future<void> _loadData() async {
    try {
      final result = await Future.wait([
        PersonnelStorage.readAll(),
        AttendanceStorage.readAll(),
        AuthorizedContactStorage.readAll(),
        DriverStorage.readAll(),
        ServiceRecordStorage.readAll(),
        DriverStorage.readSelectedId(),
        ShiftDefinitionStorage.readAll(),
        OneDayPassengerStorage.readAll(),
        InstitutionStorage.readAll(),
        VehicleStorage.readAll(),
        PersonnelLeaveStorage.readAll(),
        StopStorage.readAll(),
        ShiftTimeStorage.readAll(),
      ]).timeout(const Duration(seconds: 8));
      final personnel = result[0] as List<Personnel>;
      final attendance = result[1] as List<AttendanceRecord>;
      final authorizedContacts = result[2] as List<AuthorizedContact>;
      if (!mounted) return;
      setState(() {
        _personnel = widget.allInstitutions
            ? personnel
            : personnel
                  .where(
                    (person) => widget.allowedInstitutionIds.contains(
                      person.institutionId,
                    ),
                  )
                  .toList();
        _attendanceRecords = attendance;
        _authorizedContacts = authorizedContacts;
        _drivers = [...result[3] as List<Driver>];
        _serviceRecords = result[4] as List<ServiceRecord>;
        final savedDriverId = result[5] as String?;
        _shifts = [];
        _shiftWorkdayOffsets.clear();
        final configuredShiftTimes = result[12] as List<ShiftTimeSlot>;
        for (final slot in configuredShiftTimes) {
          if (!_shifts.contains(slot.label)) _shifts.add(slot.label);
          _shiftWorkdayOffsets[slot.label] = slot.workdayOffset;
        }
        // Yeni vardiya saati kaydı henüz oluşturulmamış şirketlerde mevcut
        // vardiya sistemleri çalışmaya devam etsin.
        if (_shifts.isEmpty) {
          for (final definition in result[6] as List<ShiftDefinition>) {
            for (final slot in definition.slots) {
              if (!_shifts.contains(slot.label)) _shifts.add(slot.label);
              _shiftWorkdayOffsets[slot.label] = slot.workdayOffset;
            }
          }
        }
        _oneDayPassengers = result[7] as List<OneDayPassenger>;
        _allInstitutions = (result[8] as List<Institution>)
            .where((item) => item.active)
            .toList();
        _institutions = _allInstitutions
            .where(
              (item) =>
                  widget.allInstitutions ||
                  widget.allowedInstitutionIds.contains(item.id),
            )
            .toList();
        _vehicles = (result[9] as List<Vehicle>)
            .where(
              (item) =>
                  item.active &&
                  (widget.allVehicles ||
                      widget.allowedVehicleIds.contains(item.id)),
            )
            .toList();
        _personnelLeaves = result[10] as List<PersonnelLeave>;
        _stops = result[11] as List<Stop>;
        if (_institutions.any(
          (item) => item.id == widget.initialInstitutionId,
        )) {
          _selectedInstitutionId = widget.initialInstitutionId;
        } else if (_institutions.length == 1) {
          _selectedInstitutionId = _institutions.first.id;
        } else {
          for (final institution in _institutions) {
            if (institution.name.trim().toLowerCase() == 'anatolia') {
              _selectedInstitutionId = institution.id;
              break;
            }
          }
        }
        if (_vehicles.any((item) => item.id == widget.initialVehicleId)) {
          _selectedVehicleId = widget.initialVehicleId;
        } else if (_vehicles.length == 1) {
          _selectedVehicleId = _vehicles.first.id;
        }
        for (final record in _serviceRecords.reversed) {
          if (record.date == _selectedDateIso &&
              record.shift == _selectedShift &&
              record.serviceType == _selectedServiceType &&
              record.endedAt == null) {
            if (_institutions.any((item) => item.id == record.institutionId)) {
              _selectedInstitutionId = record.institutionId;
            }
            if (_vehicles.any((item) => item.id == record.vehicleId)) {
              _selectedVehicleId = record.vehicleId;
            }
            break;
          }
        }
        if (_shifts.isNotEmpty && !_shiftChoices.contains(_selectedShift)) {
          _selectedShift = _shifts.first;
        }
        final preferredId = widget.preferredDriverId;
        final preferredName = widget.preferredDriverName?.trim();
        Driver? preferredDriver;
        if (preferredId != null && preferredId.isNotEmpty) {
          for (final driver in _drivers) {
            if (driver.id == preferredId ||
                (preferredName != null &&
                    driver.name.trim().toLowerCase() ==
                        preferredName.toLowerCase())) {
              preferredDriver = driver;
              break;
            }
          }
          if (preferredDriver == null &&
              preferredName != null &&
              preferredName.isNotEmpty) {
            preferredDriver = Driver(id: preferredId, name: preferredName);
            _drivers.add(preferredDriver);
          }
        }
        _selectedDriverId =
            preferredDriver?.id ??
            (_drivers.any((driver) => driver.id == savedDriverId)
                ? savedDriverId
                : null);
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Buluta ulaşılamadı. Telefonda kayıtlı bilgiler gösteriliyor.',
          ),
        ),
      );
    }
  }

  DateTime get _defaultShownDate {
    final now = DateTime.now();
    return now.hour >= 20 ? now.add(const Duration(days: 1)) : now;
  }

  String get _shownDateText {
    final date = _selectedDate;
    return '${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}.${date.year}';
  }

  String get _serviceListLabel {
    final parts = _selectedShift.split('/');
    final rawHour = widget.isDistribution
        ? (parts.length > 1 ? parts[1] : '')
        : (parts.isNotEmpty ? parts[0] : '');
    final parsedHour = int.tryParse(
      rawHour.trim().split(RegExp(r'[.:]')).first,
    );
    final hour = (parsedHour ?? 0).toString().padLeft(2, '0');
    return widget.isDistribution ? '$hour dağıtımı' : '$hour toplaması';
  }

  bool get _hasSelectedShiftStarted {
    final startedAt = _shiftStartAt(_selectedDate, _selectedShift);
    return startedAt == null || !DateTime.now().isBefore(startedAt);
  }

  String get _selectedInstitutionName {
    for (final institution in _institutions) {
      if (institution.id == _selectedInstitutionId) return institution.name;
    }
    return 'Kurum seçilmedi';
  }

  List<String> get _shiftChoices => _shifts;

  int? _shiftStartMinute(String shift) {
    final firstPart = shift.split('/').first.trim();
    final normalized = firstPart.replaceAll(':', '.').replaceAll(',', '.');
    final pieces = normalized.split('.');
    final hour = int.tryParse(pieces.first);
    if (hour == null) return null;
    final minute = pieces.length > 1 ? int.tryParse(pieces[1]) ?? 0 : 0;
    return (hour == 24 ? 0 : hour) * 60 + minute;
  }

  int? _shiftStartHour(String shift) =>
      _shiftStartMinute(shift) == null ? null : _shiftStartMinute(shift)! ~/ 60;

  DateTime? _shiftStartAt(DateTime workDate, String shift) {
    final startMinute = _shiftStartMinute(shift);
    if (startMinute == null) return null;
    final day = DateTime(workDate.year, workDate.month, workDate.day);
    final workdayOffset = _shiftWorkdayOffsets[shift] ?? 0;
    return day
        .subtract(Duration(days: workdayOffset))
        .add(Duration(minutes: startMinute));
  }

  Future<void> _selectShift(String shift) async {
    if (_isServiceActive) {
      await showDialog<void>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Devam eden servis var'),
          content: Text(
            '$_selectedShift vardiyasında başlatılmış ve henüz bitirilmemiş '
            'bir servis bulunuyor.\n\n'
            'Yolcu listesini değiştirmek için önce mevcut servisi bitirin.',
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('TAMAM'),
            ),
          ],
        ),
      );
      return;
    }
    setState(() {
      _selectedShift = shift;
      _expandedPersonnelIds.clear();
      _distributionReactivatedIds.clear();
      _distributionExcludedIds.clear();
    });
    if (!widget.isDistribution &&
        ShiftCalculator.normalizeShift(shift) == '24 / 08') {
      final now = DateTime.now();
      final selectedDay = DateTime(now.year, now.month, now.day);
      final startedAt = _shiftStartAt(selectedDay, shift) ?? selectedDay;
      final elapsedMinutes = now.difference(startedAt).inMinutes;
      final elapsedHours = elapsedMinutes ~/ 60;
      final remainingMinutes = elapsedMinutes % 60;
      final elapsedText = remainingMinutes == 0
          ? '$elapsedHours saat'
          : '$elapsedHours saat $remainingMinutes dakika';
      final showTomorrow = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Vardiya başlangıç kontrolü'),
          content: Text(
            '24 / 08 vardiyası bugün saat 00.00’de başladı.\n\n'
            'Vardiyanın başlamasının üzerinden $elapsedText geçti. '
            'Bugünkü listeyle mi devam etmek, yoksa yarının listesini mi '
            'görmek istersiniz?',
          ),
          actions: [
            OutlinedButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('BU LİSTEYLE DEVAM ET'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('YARININ LİSTESİ'),
            ),
          ],
        ),
      );
      if (showTomorrow == null || !mounted) return;
      setState(
        () => _selectedDate = showTomorrow
            ? selectedDay.add(const Duration(days: 1))
            : selectedDay,
      );
      return;
    }
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          widget.isDistribution ? 'Dağıtım Bilgisi' : 'Toplama Bilgisi',
        ),
        content: Text(
          '$_shownDateText tarihinde\n'
          '$_serviceListLabel listesi gösteriliyor.'
          '${widget.isDistribution && !_hasSelectedShiftStarted ? '\n\nBu vardiya daha toplanmadı. Olası/kesin olmayan DAĞITIM listesini görüyorsunuz.' : ''}',
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('TAMAM'),
          ),
        ],
      ),
    );
  }

  List<Personnel> get _shiftPersonnel {
    final selectedInstitutionId = _selectedInstitutionId;
    final allowedInstitutionIds = selectedInstitutionId == null
        ? const <String>{}
        : Institution.subtreeIds(_institutions, selectedInstitutionId);
    final list = _personnel.where((person) {
      if (selectedInstitutionId == null ||
          !allowedInstitutionIds.contains(person.institutionId)) {
        return false;
      }
      final addedToSelectedShift = _oneDayPassengers.any(
        (assignment) =>
            assignment.personId == person.id &&
            assignment.date == _selectedDateIso &&
            assignment.shift == _selectedShift,
      );
      if (addedToSelectedShift) {
        return true;
      }
      // Özel servis alanı açık olsa bile gün seçilmemişse normal vardiya
      // hesabı devam eder. En az bir gün seçildiğinde özel gün/saat kuralı
      // normal vardiya hesabından önce gelir.
      if (person.customServiceParticipationEnabled &&
          person.fixedServiceWeekdays.isNotEmpty) {
        return person.serviceParticipationIncludes(
          _selectedDate,
          _selectedShift,
          isDistribution: widget.isDistribution,
        );
      }
      // Sabit personel yalnızca yukarıdaki özel servis gün/saat seçimiyle
      // toplama veya dağıtım listesine dahil edilir.
      if (person.workType == Personnel.fixedWorkType) return false;
      if (person.workType == Personnel.reliefWorkType) {
        final selectedShifts = person.reliefShiftsForDate(_selectedDate);
        return selectedShifts.contains(_selectedShift);
      }
      final status = ShiftCalculator.forDate(person, _selectedDate);
      return !status.isLeave && status.shift == _selectedShift;
    }).toList();
    if (widget.isDistribution) {
      list.removeWhere(
        (person) => _distributionExcludedIds.contains(person.id),
      );
      list.sort((a, b) => b.stopOrder.compareTo(a.stopOrder));
    } else {
      list.sort((a, b) => a.stopOrder.compareTo(b.stopOrder));
    }
    return list;
  }

  bool _isOneDayPassengerForSelection(Personnel person) =>
      _oneDayPassengers.any(
        (assignment) =>
            assignment.personId == person.id &&
            assignment.date == _selectedDateIso &&
            assignment.shift == _selectedShift,
      );

  bool _isIncludedBySpecialServiceRule(Personnel person) =>
      person.customServiceParticipationEnabled &&
      person.fixedServiceWeekdays.isNotEmpty &&
      person.serviceParticipationIncludes(
        _selectedDate,
        _selectedShift,
        isDistribution: widget.isDistribution,
      );

  PersonnelLeave? _leaveFor(Personnel person) {
    for (final leave in _personnelLeaves) {
      if (leave.personId == person.id && leave.includes(_selectedDate)) {
        return leave;
      }
    }
    return null;
  }

  List<Personnel> get _servicePersonnel => _shiftPersonnel.where((person) {
    if (_leaveFor(person) != null) return false;
    if (!widget.isDistribution) return true;
    return !_pickupAbsentPersonIds.contains(person.id) ||
        _distributionReactivatedIds.contains(person.id);
  }).toList();

  Set<String> get _pickupAbsentPersonIds {
    return _pickupAttendanceByPerson.entries
        .where((entry) => entry.value.status == 'Durakta Yok')
        .map((entry) => entry.key)
        .toSet();
  }

  Map<String, AttendanceRecord> get _pickupAttendanceByPerson {
    if (!widget.isDistribution) return const <String, AttendanceRecord>{};
    final pickupServiceIds = _serviceRecords
        .where(
          (record) =>
              record.date == _selectedDateIso &&
              record.shift == _selectedShift &&
              record.serviceType == ServiceRecord.pickupType &&
              (_selectedInstitutionId == null ||
                  record.institutionId.isEmpty ||
                  record.institutionId == _selectedInstitutionId),
        )
        .map((record) => record.id)
        .toSet();
    final records = _attendanceRecords.where(
      (record) =>
          record.serviceId != null &&
          pickupServiceIds.contains(record.serviceId),
    );
    return {for (final record in records) record.personId: record};
  }

  String get _selectedDateIso {
    final year = _selectedDate.year.toString().padLeft(4, '0');
    final month = _selectedDate.month.toString().padLeft(2, '0');
    final day = _selectedDate.day.toString().padLeft(2, '0');
    return '$year-$month-$day';
  }

  Map<String, AttendanceRecord> get _attendanceByPerson {
    final selectedService = _activeServiceRecord ?? _completedServiceRecord;
    if (selectedService == null) return {};
    final records = _attendanceRecords.where(
      (record) =>
          record.date == _selectedDateIso &&
          record.shift == _selectedShift &&
          record.serviceId == selectedService.id,
    );
    return {for (final record in records) record.personId: record};
  }

  String get _selectedServiceType => widget.isDistribution
      ? ServiceRecord.distributionType
      : ServiceRecord.pickupType;

  bool _recordMatchesSelection(ServiceRecord record) {
    final institutionMatches =
        record.institutionId.isEmpty ||
        _selectedInstitutionId == null ||
        record.institutionId == _selectedInstitutionId;
    final vehicleMatches =
        record.vehicleId.isEmpty ||
        _selectedVehicleId == null ||
        record.vehicleId == _selectedVehicleId;
    return record.date == _selectedDateIso &&
        record.shift == _selectedShift &&
        record.serviceType == _selectedServiceType &&
        institutionMatches &&
        vehicleMatches;
  }

  ServiceRecord? get _activeServiceRecord {
    for (final record in _serviceRecords.reversed) {
      if (_recordMatchesSelection(record) && record.endedAt == null) {
        return record;
      }
    }
    return null;
  }

  ServiceRecord? get _completedServiceRecord {
    for (final record in _serviceRecords.reversed) {
      if (_recordMatchesSelection(record) && record.endedAt != null) {
        return record;
      }
    }
    return null;
  }

  bool get _isServiceActive => _activeServiceRecord != null;

  bool get _isShiftReadOnly =>
      !_isServiceActive && _completedServiceRecord != null;

  String _timeText(String iso) {
    final time = DateTime.parse(iso);
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
  }

  DateTime? get _scheduledServiceTime {
    final shiftStart = _shiftStartAt(_selectedDate, _selectedShift);
    if (shiftStart == null || !widget.isDistribution) return shiftStart;
    final startHour = _shiftStartHour(_selectedShift);
    final durationHours = switch (startHour) {
      0 || 8 || 16 => 8,
      7 || 15 || 23 => 8,
      _ => null,
    };
    return durationHours == null
        ? shiftStart
        : shiftStart.add(Duration(hours: durationHours));
  }

  Future<bool> _confirmServiceStartWindow() async {
    final scheduledAt = _scheduledServiceTime;
    if (scheduledAt == null) return true;
    final now = DateTime.now();
    if (now.isAfter(scheduledAt.add(const Duration(hours: 2)))) {
      final scheduledTime =
          '${scheduledAt.hour.toString().padLeft(2, '0')}:'
          '${scheduledAt.minute.toString().padLeft(2, '0')}';
      await showDialog<void>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Servis başlatılamaz'),
          content: Text(
            '$_selectedShift ${widget.isDistribution ? 'dağıtım' : 'toplama'} '
            'servisinin planlanan saati $scheduledTime idi. Başlatma süresi '
            '2 saatten fazla geçtiği için yeni kayıt açılamaz. Personel '
            'listesini yalnızca kontrol edebilirsiniz.',
          ),
          actions: [
            FilledButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Tamam'),
            ),
          ],
        ),
      );
      return false;
    }
    if (!now.isBefore(scheduledAt.subtract(const Duration(hours: 2)))) {
      return true;
    }
    final result = await showDialog<_EarlyStartChoice>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Vardiyayı erken başlatıyorsunuz'),
        content: const Text(
          'Vardiyanın başlamasına 2 saatten fazla var. '
          'Personel listesini yalnızca kontrol etmek mi, yoksa gerçek '
          'vardiyayı şimdi başlatmak mı istiyorsunuz?',
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(dialogContext, _EarlyStartChoice.cancel),
            child: const Text('Vazgeç'),
          ),
          OutlinedButton(
            onPressed: () =>
                Navigator.pop(dialogContext, _EarlyStartChoice.inspect),
            child: const Text('Sadece kontrol et'),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(dialogContext, _EarlyStartChoice.start),
            child: const Text('Gerçek vardiyayı başlat'),
          ),
        ],
      ),
    );
    if (!mounted || result == null || result == _EarlyStartChoice.cancel) {
      return false;
    }
    if (result == _EarlyStartChoice.inspect) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Kontrol modu: Herhangi bir vardiya kaydı başlatılmadı.',
          ),
        ),
      );
      return false;
    }
    return true;
  }

  Future<void> _startService() async {
    final selectedDriverId = _selectedDriverId;
    final selectedInstitutionId = _selectedInstitutionId;
    final selectedVehicleId = _selectedVehicleId;
    if (mounted) setState(() => _loading = true);
    await _loadData();
    if (!mounted) return;
    setState(() {
      if (_drivers.any((item) => item.id == selectedDriverId)) {
        _selectedDriverId = selectedDriverId;
      }
      if (_institutions.any((item) => item.id == selectedInstitutionId)) {
        _selectedInstitutionId = selectedInstitutionId;
      }
      if (_vehicles.any((item) => item.id == selectedVehicleId)) {
        _selectedVehicleId = selectedVehicleId;
      }
    });
    if (_isServiceActive) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Bu servis zaten aktif.')));
      return;
    }
    final driverId = _selectedDriverId;
    final institutionId = _selectedInstitutionId;
    final vehicleId = _selectedVehicleId;
    if (driverId == null || institutionId == null || vehicleId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Önce şoför, kurum ve araç seçimini tamamlayın.'),
        ),
      );
      return;
    }
    if (!await _confirmServiceStartWindow() || !mounted) return;
    final driver = _drivers.firstWhere((item) => item.id == driverId);
    final institution = _institutions.firstWhere(
      (item) => item.id == institutionId,
    );
    final vehicle = _vehicles.firstWhere((item) => item.id == vehicleId);
    await DriverStorage.saveSelectedId(driver.id);
    final now = DateTime.now();
    final record = ServiceRecord(
      id: now.microsecondsSinceEpoch.toString(),
      date: _selectedDateIso,
      shift: _selectedShift,
      driverId: driver.id,
      driverName: driver.name,
      startedAt: now.toIso8601String(),
      institutionId: institution.id,
      institutionName: institution.name,
      vehicleId: vehicle.id,
      vehiclePlate: vehicle.plate,
      serviceType: _selectedServiceType,
    );
    final updated = [..._serviceRecords, record];
    await ServiceRecordStorage.saveAll(updated, syncNow: false);
    if (!mounted) return;
    setState(() {
      _serviceRecords = updated;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Vardiya ${_timeText(record.startedAt)} saatinde başlatıldı.'
          ' Kayıt servis bitene kadar telefonda tutulacak.',
        ),
      ),
    );
  }

  Future<void> _handleStartService() async {
    if (_startingService) return;
    setState(() => _startingService = true);
    try {
      await _startService();
    } finally {
      if (mounted) setState(() => _startingService = false);
    }
  }

  void _selectDriver(String? driverId) {
    if (driverId == null) return;
    setState(() => _selectedDriverId = driverId);
    DriverStorage.saveSelectedId(driverId);
  }

  Future<void> _finishService() async {
    final active = _activeServiceRecord;
    if (active == null) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Vardiya bitirilsin mi?'),
        content: const Text('Bittiğinde biniş ve yoklama kaydı kapatılır.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Vardiyayı Bitir'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await _routePositionSubscription?.cancel();
    _routePositionSubscription = null;
    _approachedStopKeys.clear();
    await _stopOverlayChannel.invokeMethod<void>('hideStopOverlay');

    final people = _servicePersonnel;
    final attendance = _attendanceByPerson;
    final driverBoardedCount = people
        .where((person) => attendance[person.id]?.status == 'Bindi')
        .length;
    final absentCount = people
        .where((person) => attendance[person.id]?.status == 'Durakta Yok')
        .length;
    final unmarkedPeople = people
        .where((person) => attendance[person.id] == null)
        .toList();
    final endedAt = DateTime.now();
    final automaticAttendance = [
      for (final person in unmarkedPeople)
        AttendanceRecord(
          personId: person.id,
          date: _selectedDateIso,
          shift: _selectedShift,
          status: 'Bindi',
          recordedAt: endedAt.toIso8601String(),
          latitude: 0,
          longitude: 0,
          serviceId: active.id,
          markedByDriver: false,
        ),
    ];
    final updatedAttendance = [..._attendanceRecords, ...automaticAttendance];
    final boardedCount = driverBoardedCount + unmarkedPeople.length;
    final finished = active.copyWith(
      endedAt: endedAt.toIso8601String(),
      boardedCount: boardedCount,
      absentCount: absentCount,
      expectedCount: people.length,
      unmarkedCount: unmarkedPeople.length,
    );
    final updated = _serviceRecords
        .map((record) => record.id == active.id ? finished : record)
        .toList();
    final syncResults = await Future.wait([
      ServiceRecordStorage.saveAll(updated),
      AttendanceStorage.saveAll(updatedAttendance),
    ]);
    if (!mounted) return;
    setState(() {
      _serviceRecords = updated;
      _attendanceRecords = updatedAttendance;
    });
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Vardiya bitti'),
        content: Text(
          'Şoför: ${finished.driverName}\n'
          'Başlama: ${_timeText(finished.startedAt)}\n'
          'Bitiş: ${_timeText(finished.endedAt!)}\n\n'
          'Binen: $boardedCount\n'
          'Yok: $absentCount\n'
          'Şoförün işaretlemediği: ${unmarkedPeople.length}'
          '${syncResults.every((synced) => synced) ? '' : '\n\nKayıtlar telefonda güvende; internet gelince buluta aktarılacak.'}',
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  Future<void> _handleFinishService() async {
    if (_finishingService) return;
    setState(() => _finishingService = true);
    try {
      await _finishService();
    } finally {
      if (mounted) setState(() => _finishingService = false);
    }
  }

  Future<void> _deleteSelectedCompletedService() async {
    final recordsToDelete = _serviceRecords
        .where(
          (record) => _recordMatchesSelection(record) && record.endedAt != null,
        )
        .toList();
    if (recordsToDelete.isEmpty) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Vardiya kaydı silinsin mi?'),
        content: Text(
          '$_selectedDateIso tarihli $_selectedShift '
          '${widget.isDistribution ? 'dağıtım' : 'toplama'} kaydı ve bu '
          'servise bağlı Bindi/Yok kayıtları silinecek.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Vazgeç'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(dialogContext, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
            icon: const Icon(Icons.delete_forever_rounded),
            label: const Text('Kaydı sil'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    final serviceIds = recordsToDelete.map((record) => record.id).toSet();
    final updatedServices = _serviceRecords
        .where((record) => !serviceIds.contains(record.id))
        .toList();
    final updatedAttendance = _attendanceRecords
        .where((record) => !serviceIds.contains(record.serviceId))
        .toList();
    await Future.wait([
      ServiceRecordStorage.saveAll(updatedServices),
      AttendanceStorage.saveAll(updatedAttendance),
    ]);
    if (!mounted) return;
    setState(() {
      _serviceRecords = updatedServices;
      _attendanceRecords = updatedAttendance;
      _expandedPersonnelIds.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Vardiya ve bağlı yoklama kayıtları silindi.'),
      ),
    );
  }

  Future<void> _handleMapButton() async {
    if (_openingMap) return;
    setState(() => _openingMap = true);
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('Harita açılıyor...')));
    try {
      await _openRouteInGoogleMaps();
      await Future<void>.delayed(const Duration(milliseconds: 700));
    } finally {
      if (mounted) setState(() => _openingMap = false);
    }
  }

  Future<void> _handleWhatsAppButton() async {
    if (_openingWhatsApp) return;
    setState(() => _openingWhatsApp = true);
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('WhatsApp açılıyor...')));
    try {
      await _shareShiftListOnWhatsApp();
      await Future<void>.delayed(const Duration(milliseconds: 700));
    } finally {
      if (mounted) setState(() => _openingWhatsApp = false);
    }
  }

  Future<void> _chooseDate() async {
    final selected = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2040),
      helpText: 'VARDİYA LİSTESİ TARİHİ',
    );
    if (selected != null) {
      setState(() {
        _selectedDate = selected;
        _distributionReactivatedIds.clear();
        _distributionExcludedIds.clear();
      });
    }
  }

  Future<bool> _ensureOverlayPermission() async {
    if (defaultTargetPlatform != TargetPlatform.android) return true;
    final allowed =
        await _stopOverlayChannel.invokeMethod<bool>('canDrawOverlays') ??
        false;
    if (allowed) return true;
    await _stopOverlayChannel.invokeMethod<void>('requestOverlayPermission');
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Servis Takip için “diğer uygulamaların üzerinde göster” iznini açın; ardından Harita Moduna tekrar dokunun.',
          ),
          duration: Duration(seconds: 8),
        ),
      );
    }
    return false;
  }

  Future<void> _startRouteMonitoring(
    List<({String key, String name, int order, double lat, double lng})> stops,
  ) async {
    await _routePositionSubscription?.cancel();
    _approachedStopKeys.clear();
    if (!_isServiceActive || stops.isEmpty) return;
    final LocationSettings settings =
        defaultTargetPlatform == TargetPlatform.android
        ? AndroidSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 20,
            intervalDuration: const Duration(seconds: 5),
            foregroundNotificationConfig: const ForegroundNotificationConfig(
              notificationTitle: 'Servis Takip harita modu',
              notificationText: 'Duraklara yaklaşma mesafesi izleniyor.',
              enableWakeLock: true,
            ),
          )
        : const LocationSettings(
            accuracy: LocationAccuracy.high,
            distanceFilter: 20,
          );
    _routePositionSubscription =
        Geolocator.getPositionStream(locationSettings: settings).listen((
          position,
        ) async {
          for (final stop in stops) {
            if (_approachedStopKeys.contains(stop.key)) continue;
            final distance = Geolocator.distanceBetween(
              position.latitude,
              position.longitude,
              stop.lat,
              stop.lng,
            );
            if (distance > _stopApproachThresholdMeters) continue;
            _approachedStopKeys.add(stop.key);
            await _showNativeStopOverlay(stop.name);
            break;
          }
        });
  }

  Future<void> _showNativeStopOverlay(String stopName) async {
    final normalizedStopName = stopName.trim().toLowerCase();
    final attendance = _attendanceByPerson;
    final passengers = _servicePersonnel
        .where(
          (person) =>
              person.stopName.trim().toLowerCase() == normalizedStopName &&
              _leaveFor(person) == null &&
              attendance[person.id] == null,
        )
        .map((person) => {'id': person.id, 'name': person.fullName})
        .toList();
    if (passengers.isEmpty) return;
    await _stopOverlayChannel.invokeMethod<void>('showStopOverlay', {
      'stopName': stopName,
      'passengers': passengers,
    });
  }

  Future<void> _openRouteInGoogleMaps() async {
    final passengers = _isServiceActive
        ? _servicePersonnel
              .where((person) => _attendanceByPerson[person.id] == null)
              .toList()
        : _servicePersonnel;
    if (passengers.isEmpty && (!_isServiceActive || widget.isDistribution)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Bu vardiyada rotaya eklenecek yolcu yok.'),
        ),
      );
      return;
    }

    var institution = _allInstitutions.cast<Institution?>().firstWhere(
      (item) => item!.id == _selectedInstitutionId,
      orElse: () => null,
    );
    final institutionsById = {
      for (final item in _allInstitutions) item.id: item,
    };
    final visitedInstitutionIds = <String>{};
    while (institution != null &&
        !institution.hasLocation &&
        institution.parentId != null &&
        visitedInstitutionIds.add(institution.id)) {
      institution = institutionsById[institution.parentId];
    }
    if (institution == null || !institution.hasLocation) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seçili kurumun kayıtlı konumu bulunmuyor.'),
        ),
      );
      return;
    }

    Position? currentPosition;
    if (!widget.isDistribution || _isServiceActive) {
      currentPosition = await _getCurrentLocation();
      if (currentPosition == null || !mounted) return;
    }

    final routeStops =
        <({String key, String name, int order, double lat, double lng})>[];
    final missingStopNames = <String>[];
    final seenStops = <String>{};

    for (final person in passengers) {
      final normalizedName = person.stopName.trim().toLowerCase();
      final matchingStop = _stops.cast<Stop?>().firstWhere(
        (stop) =>
            stop!.institutionId == person.institutionId &&
            stop.name.trim().toLowerCase() == normalizedName,
        orElse: () => null,
      );
      final key = matchingStop?.id.isNotEmpty == true
          ? matchingStop!.id
          : '${person.institutionId}:$normalizedName';
      if (!seenStops.add(key)) continue;

      final latitude = matchingStop?.latitude ?? person.stopLatitude;
      final longitude = matchingStop?.longitude ?? person.stopLongitude;
      final hasLocation =
          latitude != null &&
          longitude != null &&
          latitude >= -90 &&
          latitude <= 90 &&
          longitude >= -180 &&
          longitude <= 180 &&
          !(latitude == 0 && longitude == 0);
      if (!hasLocation) {
        missingStopNames.add(
          person.stopName.trim().isEmpty
              ? 'Adsız durak'
              : person.stopName.trim(),
        );
        continue;
      }

      routeStops.add((
        key: key,
        name: matchingStop?.name ?? person.stopName,
        order: matchingStop?.order ?? person.stopOrder,
        lat: latitude,
        lng: longitude,
      ));
    }

    routeStops.sort((a, b) {
      final orderComparison = a.order.compareTo(b.order);
      final result = orderComparison != 0
          ? orderComparison
          : a.name.compareTo(b.name);
      return widget.isDistribution ? -result : result;
    });

    if (missingStopNames.isNotEmpty && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Konumu bulunmayan duraklar rotaya eklenmedi: '
            '${missingStopNames.join(', ')}',
          ),
          duration: const Duration(seconds: 6),
        ),
      );
    }
    if (routeStops.isEmpty && (!_isServiceActive || widget.isDistribution)) {
      if (missingStopNames.isEmpty && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Rotaya eklenecek konumlu durak yok.')),
        );
      }
      return;
    }

    String coordinates(({double lat, double lng}) point) =>
        '${point.lat},${point.lng}';
    final origin = widget.isDistribution && !_isServiceActive
        ? (lat: institution.latitude!, lng: institution.longitude!)
        : (lat: currentPosition!.latitude, lng: currentPosition!.longitude);
    final destination = _isServiceActive
        ? routeStops.isNotEmpty
              ? (lat: routeStops.first.lat, lng: routeStops.first.lng)
              : (lat: institution.latitude!, lng: institution.longitude!)
        : widget.isDistribution
        ? (lat: routeStops.last.lat, lng: routeStops.last.lng)
        : (lat: institution.latitude!, lng: institution.longitude!);
    final waypointStops = _isServiceActive
        ? const <
            ({String key, String name, int order, double lat, double lng})
          >[]
        : widget.isDistribution
        ? routeStops.take(routeStops.length - 1)
        : routeStops;
    final query = <String, String>{
      'api': '1',
      'origin': coordinates(origin),
      'destination': coordinates(destination),
      'travelmode': 'driving',
      'dir_action': 'navigate',
      if (waypointStops.isNotEmpty)
        'waypoints': waypointStops
            .map((stop) => coordinates((lat: stop.lat, lng: stop.lng)))
            .join('|'),
    };
    try {
      final companyId = await CompanyCloudStorage.companyId();
      if (companyId == null || companyId.isEmpty) return;
      await PackageAccessService.consumeMap(
        companyId: companyId,
        serviceKey:
            '${_selectedDateIso}_${_selectedShift}_${widget.isDistribution ? 'distribution' : 'pickup'}_${_selectedInstitutionId ?? ''}',
      );
    } on PackageLimitException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
      return;
    }
    if (_isServiceActive && !await _ensureOverlayPermission()) return;
    await _startRouteMonitoring(
      _isServiceActive && routeStops.isNotEmpty
          ? [routeStops.first]
          : routeStops,
    );
    await _openExternal(
      Uri.https('www.google.com', '/maps/dir/', query),
      'Google Maps rotası',
    );
  }

  Future<void> _openNearbyStopPassengers() async {
    if (_checkingNearbyStop || !_isServiceActive || !mounted) return;
    _checkingNearbyStop = true;
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      if (!mounted) return;
      Stop? nearestStop;
      var nearestDistance = double.infinity;
      for (final person in _servicePersonnel) {
        final stop = _stops.cast<Stop?>().firstWhere(
          (item) =>
              item!.institutionId == person.institutionId &&
              item.name.trim().toLowerCase() ==
                  person.stopName.trim().toLowerCase(),
          orElse: () => null,
        );
        if (stop == null) continue;
        final distance = Geolocator.distanceBetween(
          position.latitude,
          position.longitude,
          stop.latitude,
          stop.longitude,
        );
        if (distance < nearestDistance) {
          nearestDistance = distance;
          nearestStop = stop;
        }
      }
      if (nearestStop == null ||
          nearestDistance > _stopApproachThresholdMeters) {
        _lastAutoOpenedStopKey = null;
        return;
      }

      final orderedStops = <Stop>[];
      final seenStopIds = <String>{};
      for (final person in _servicePersonnel) {
        final stop = _stops.cast<Stop?>().firstWhere(
          (item) =>
              item!.institutionId == person.institutionId &&
              item.name.trim().toLowerCase() ==
                  person.stopName.trim().toLowerCase(),
          orElse: () => null,
        );
        if (stop != null && seenStopIds.add(stop.id)) orderedStops.add(stop);
      }
      orderedStops.sort(
        (a, b) => widget.isDistribution
            ? b.order.compareTo(a.order)
            : a.order.compareTo(b.order),
      );
      final reachedIndex = orderedStops.indexWhere(
        (stop) => stop.id == nearestStop!.id,
      );
      final skippedStops = reachedIndex <= 0
          ? <Stop>[]
          : orderedStops.take(reachedIndex).where((stop) {
              final peopleAtStop = _servicePersonnel.where(
                (person) =>
                    person.institutionId == stop.institutionId &&
                    person.stopName.trim().toLowerCase() ==
                        stop.name.trim().toLowerCase(),
              );
              return peopleAtStop.any(
                (person) => _attendanceByPerson[person.id] == null,
              );
            }).toList();

      if (skippedStops.isNotEmpty && mounted) {
        final skippedNames = skippedStops.map((stop) => stop.name).join(', ');
        final goBack = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Durak geride kaldı'),
            content: Text(
              '$skippedNames durağını geride bıraktınız. '
              'Bu durağa gitmek ister misiniz?',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('HAYIR'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: const Text('EVET, DURAĞA GİT'),
              ),
            ],
          ),
        );
        if (!mounted) return;
        if (goBack == true) {
          _lastAutoOpenedStopKey = null;
          await _openRouteInGoogleMaps();
          return;
        }
        for (final skippedStop in skippedStops) {
          final unmarkedPeople = _servicePersonnel
              .where(
                (person) =>
                    person.institutionId == skippedStop.institutionId &&
                    person.stopName.trim().toLowerCase() ==
                        skippedStop.name.trim().toLowerCase() &&
                    _attendanceByPerson[person.id] == null,
              )
              .toList();
          for (final person in unmarkedPeople) {
            await _recordAttendance(person, 'Durakta Yok');
          }
        }
        if (!mounted) return;
      }
      final stopKey = '${_selectedDateIso}_${_selectedShift}_${nearestStop.id}';
      if (_lastAutoOpenedStopKey == stopKey) return;
      _lastAutoOpenedStopKey = stopKey;
      await _showStopPassengers(nearestStop);
    } catch (_) {
      // Konum alınamazsa servis listesi normal şekilde kullanılmaya devam eder.
    } finally {
      _checkingNearbyStop = false;
    }
  }

  Future<void> _showStopPassengers(Stop stop) async {
    final passengers = _servicePersonnel
        .where(
          (person) =>
              person.stopName.trim().toLowerCase() ==
              stop.name.trim().toLowerCase(),
        )
        .toList();
    if (passengers.isEmpty || !mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheetState) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                stop.name,
                style: Theme.of(
                  context,
                ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 8),
              ConstrainedBox(
                constraints: BoxConstraints(
                  maxHeight: MediaQuery.sizeOf(context).height * 0.55,
                ),
                child: ListView.separated(
                  shrinkWrap: true,
                  itemCount: passengers.length,
                  separatorBuilder: (_, _) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final person = passengers[index];
                    final attendance = _attendanceByPerson[person.id];
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(
                        person.fullName,
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                      trailing: FilledButton.icon(
                        onPressed: attendance?.status == 'Durakta Yok'
                            ? null
                            : () async {
                                await _recordAttendance(person, 'Durakta Yok');
                                if (context.mounted) setSheetState(() {});
                              },
                        style: FilledButton.styleFrom(
                          backgroundColor: Colors.red.shade700,
                        ),
                        icon: const Icon(Icons.close_rounded),
                        label: Text(
                          attendance?.status == 'Durakta Yok' ? 'YOK ✓' : 'YOK',
                        ),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(sheetContext);
                },
                icon: const Icon(Icons.navigation_rounded),
                label: const Text('HARİTAYA DÖN'),
                style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(48),
                  backgroundColor: const Color(0xFF1565C0),
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (!mounted) return;
    for (final person in passengers) {
      if (_attendanceByPerson[person.id] == null) {
        await _recordAttendance(person, 'Bindi');
      }
    }
    if (mounted) await _openRouteInGoogleMaps();
  }

  Future<void> _shareShiftListOnWhatsApp() async {
    final passengers = _shiftPersonnel;
    if (passengers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Bu vardiyada gönderilecek yolcu bulunmuyor.'),
        ),
      );
      return;
    }

    final buffer = StringBuffer()
      ..writeln('*SERVİS YOLCU LİSTESİ*')
      ..writeln('Kurum: $_selectedInstitutionName')
      ..writeln('Tarih: $_shownDateText')
      ..writeln('Vardiya: $_selectedShift')
      ..writeln('Toplam: ${passengers.length}')
      ..writeln(
        'İzinli: ${passengers.where((person) => _leaveFor(person) != null).length}',
      )
      ..writeln();
    for (var index = 0; index < passengers.length; index++) {
      final person = passengers[index];
      final stopName = person.stopName.trim();
      final isOnLeave = _leaveFor(person) != null;
      buffer.writeln(
        '${index + 1}. ${person.fullName}'
        '${isOnLeave
            ? ' — *İZİNLİ*'
            : stopName.isEmpty
            ? ''
            : ' — $stopName'}',
      );
    }

    final text = buffer.toString().trimRight();
    try {
      final companyId = await CompanyCloudStorage.companyId();
      if (companyId == null || companyId.isEmpty) return;
      await PackageAccessService.consumeWhatsApp(companyId: companyId);
    } on PackageLimitException catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text(error.message)));
      }
      return;
    }
    final appUri = Uri(
      scheme: 'whatsapp',
      host: 'send',
      queryParameters: {'text': text},
    );
    var opened = await launchUrl(appUri, mode: LaunchMode.externalApplication);
    if (!opened) {
      opened = await launchUrl(
        Uri.https('wa.me', '/', {'text': text}),
        mode: LaunchMode.externalApplication,
      );
    }
    if (!opened && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('WhatsApp açılamadı.')));
    }
  }

  Future<void> _openExternal(Uri uri, String actionName) async {
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened && mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('$actionName açılamadı.')));
    }
  }

  Future<void> _showEmergencyContacts() async {
    if (_authorizedContacts.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Önce Ayarlar bölümünden acil aranacak kişileri ekleyin.',
          ),
        ),
      );
      return;
    }

    var selectedIndex = 0;
    final contact = await showDialog<AuthorizedContact>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('Acil Aranacak Kişi'),
          contentPadding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
          content: SizedBox(
            width: 420,
            child: RadioGroup<int>(
              groupValue: selectedIndex,
              onChanged: (value) {
                if (value != null) {
                  setDialogState(() => selectedIndex = value);
                }
              },
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (
                    var index = 0;
                    index < _authorizedContacts.length;
                    index++
                  )
                    Card(
                      color: selectedIndex == index
                          ? const Color(0xFFEAF7EE)
                          : null,
                      child: RadioListTile<int>(
                        value: index,
                        title: Text(
                          '${index + 1}. ${_authorizedContacts[index].name}',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        subtitle: Text(_authorizedContacts[index].phone),
                        secondary: IconButton.filled(
                          tooltip: 'Ara',
                          onPressed: selectedIndex == index
                              ? () => Navigator.pop(
                                  dialogContext,
                                  _authorizedContacts[index],
                                )
                              : null,
                          icon: const Icon(Icons.phone_rounded),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('KAPAT'),
            ),
          ],
        ),
      ),
    );
    if (contact == null || !mounted) return;
    await _openExternal(Uri(scheme: 'tel', path: contact.phone), contact.name);
  }

  Future<void> _call(Personnel person) {
    return _openExternal(Uri(scheme: 'tel', path: person.phone), 'Telefon');
  }

  Future<void> _openWhatsApp(Personnel person) {
    final original = person.whatsApp.isEmpty ? person.phone : person.whatsApp;
    final digits = original.replaceAll(RegExp(r'[^0-9]'), '');
    final number = digits.startsWith('0')
        ? '90${digits.substring(1)}'
        : digits.startsWith('90')
        ? digits
        : digits;
    return _openExternal(Uri.parse('https://wa.me/$number'), 'WhatsApp');
  }

  Future<void> _openMap(Personnel person) {
    if (person.stopLatitude == null || person.stopLongitude == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Bu personel için durak konumu kayıtlı değil.'),
        ),
      );
      return Future<void>.value();
    }
    return _openExternal(
      Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=${person.stopLatitude},${person.stopLongitude}',
      ),
      'Harita',
    );
  }

  Future<void> _openStopMap(Stop stop) {
    return _openExternal(
      Uri.parse(
        'https://www.google.com/maps/search/?api=1&query=${stop.latitude},${stop.longitude}',
      ),
      'Harita',
    );
  }

  Future<Position?> _getCurrentLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Telefonun konum hizmetini açın.')),
        );
      }
      return null;
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Konum izni verilmedi.')));
      }
      return null;
    }

    try {
      return await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Konum alınamadı. Tekrar deneyin.')),
        );
      }
      return null;
    }
  }

  Future<bool> _recordAttendance(Personnel person, String status) async {
    var activeService = _activeServiceRecord;
    if (activeService == null) {
      await _startService();
      activeService = _activeServiceRecord;
    }
    if (activeService == null) return false;
    final position = await _getCurrentLocation();
    if (position == null) return false;

    final updated =
        _attendanceRecords
            .where(
              (record) =>
                  !(record.personId == person.id &&
                      record.date == _selectedDateIso &&
                      record.shift == _selectedShift),
            )
            .toList()
          ..add(
            AttendanceRecord(
              personId: person.id,
              date: _selectedDateIso,
              shift: _selectedShift,
              status: status,
              recordedAt: DateTime.now().toIso8601String(),
              latitude: position.latitude,
              longitude: position.longitude,
              serviceId: activeService.id,
            ),
          );
    final synced = await AttendanceStorage.saveAll(updated, syncNow: false);
    if (!mounted) return false;
    setState(() {
      _attendanceRecords = updated;
      _expandedPersonnelIds.remove(person.id);
    });
    if (!synced) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Kayıt telefona alındı; internet gelince buluta aktarılacak.',
          ),
          duration: Duration(seconds: 2),
        ),
      );
    }
    return true;
  }

  Future<void> _confirmAbsent(Personnel person) async {
    final now = DateTime.now();
    final time =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Personel binmedi'),
        content: Text(
          '${person.fullName}\nSaat: $time\n\nPersonel gelmeyecek mi?',
        ),
        actions: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              FilledButton(
                onPressed: () => Navigator.pop(context, false),
                style: FilledButton.styleFrom(
                  backgroundColor: const Color(0xFF0B6E4F),
                  minimumSize: const Size(0, 46),
                ),
                child: const Text(
                  'Beklemeye devam et',
                  maxLines: 1,
                  softWrap: false,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerRight,
                child: FilledButton(
                  onPressed: () => Navigator.pop(context, true),
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.red.shade700,
                    minimumSize: const Size(110, 46),
                  ),
                  child: const Text('Onayla', maxLines: 1),
                ),
              ),
            ],
          ),
        ],
      ),
    );
    if (confirmed == true) await _recordAttendance(person, 'Durakta Yok');
  }

  Future<void> _editPersonnel(Personnel person) async {
    final edited = await Navigator.of(context).push<Personnel>(
      MaterialPageRoute(builder: (_) => PersonnelFormScreen(personnel: person)),
    );
    if (edited == null) return;

    final updated =
        _personnel.map((item) => item.id == edited.id ? edited : item).toList()
          ..sort((a, b) => a.stopOrder.compareTo(b.stopOrder));

    try {
      await PersonnelStorage.saveOne(edited);
      if (!mounted) return;
      setState(() => _personnel = updated);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Yolcu bilgileri güncellendi.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Yolcu güncellenemedi: $error')));
    }
  }

  Future<void> _addPassengerToSelectedShift() async {
    final added = await OneDayPassengerDialog.show(
      context,
      initialDate: _selectedDate,
      initialShift: _selectedShift,
      institutionId: _selectedInstitutionId,
    );
    if (added != true) return;
    final assignments = await OneDayPassengerStorage.readAll();
    if (!mounted) return;
    setState(() => _oneDayPassengers = assignments);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Geçici yolcu listesi güncellendi.')),
    );
  }

  Future<void> _confirmExcludeFromDistribution(Personnel person) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Listeden çıkar'),
        content: Text('${person.fullName} dağıtım listesinden çıkarılsın mı?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red.shade700),
            child: const Text('ÇIKAR'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    setState(() {
      _distributionExcludedIds.add(person.id);
      _distributionReactivatedIds.remove(person.id);
      _expandedPersonnelIds.remove(person.id);
    });
  }

  Widget _personnelCard({
    required Personnel person,
    required int listNumber,
    required AttendanceRecord? attendance,
    required bool serviceActive,
    required bool readOnly,
    required PersonnelLeave? personnelLeave,
    bool pickupAbsent = false,
    bool pickupBoarded = false,
  }) {
    final isExpanded = _expandedPersonnelIds.contains(person.id);
    final isBoarded = attendance?.status == 'Bindi';
    final isOneDayPassenger = _isOneDayPassengerForSelection(person);
    final isSpecialService = _isIncludedBySpecialServiceRule(person);
    final cardColor = personnelLeave != null
        ? const Color(0xFFFFE0B2)
        : attendance != null
        ? attendance.status == 'Bindi'
              ? const Color(0xFFE8F5E9)
              : const Color(0xFFFFEBEE)
        : pickupAbsent
        ? const Color(0xFFFFEBEE)
        : pickupBoarded || readOnly
        ? const Color(0xFFE8F5E9)
        : const Color(0xFFE3F2FD);

    return Card(
      color: cardColor,
      child: Column(
        children: [
          InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: () {
              setState(() {
                if (isExpanded) {
                  _expandedPersonnelIds.remove(person.id);
                } else {
                  _expandedPersonnelIds.add(person.id);
                }
              });
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: Row(
                children: [
                  CircleAvatar(child: Text('$listNumber')),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          person.fullName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w800,
                            fontSize: 16,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          person.stopName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: Colors.grey.shade700,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        if (isOneDayPassenger || isSpecialService) ...[
                          const SizedBox(height: 4),
                          Text(
                            isOneDayPassenger
                                ? 'GEÇİCİ YOLCU KURALI'
                                : 'ÖZEL SERVİS KURALI',
                            style: const TextStyle(
                              color: Color(0xFF145A9C),
                              fontWeight: FontWeight.w900,
                              fontSize: 11,
                            ),
                          ),
                        ],
                        if (personnelLeave != null) ...[
                          const SizedBox(height: 4),
                          const Text(
                            'İZİNLİ',
                            style: TextStyle(
                              color: Color(0xFF8A4B08),
                              fontWeight: FontWeight.w900,
                              fontSize: 12,
                            ),
                          ),
                        ] else if (pickupAbsent) ...[
                          const SizedBox(height: 4),
                          const Text(
                            'TOPLAMADA GELMEDİ • DAĞITIM DIŞI',
                            style: TextStyle(
                              color: Color(0xFFB3261E),
                              fontWeight: FontWeight.w900,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  if (widget.isDistribution && personnelLeave == null)
                    IconButton(
                      onPressed: () => _confirmExcludeFromDistribution(person),
                      icon: const Icon(Icons.remove_circle_rounded, size: 19),
                      color: const Color(0xFFB3261E),
                      tooltip: 'Listeden çıkar',
                      visualDensity: VisualDensity.compact,
                    ),
                  if (personnelLeave != null)
                    const Icon(
                      Icons.beach_access_rounded,
                      color: Color(0xFFFF9800),
                    )
                  else if (pickupAbsent && attendance == null)
                    IconButton(
                      onPressed: () => setState(
                        () => _distributionReactivatedIds.add(person.id),
                      ),
                      icon: const Icon(Icons.person_add_alt_1_rounded),
                      color: const Color(0xFF0B6E4F),
                      tooltip: 'Dağıtım listesine dahil et',
                    )
                  else if (widget.isDistribution &&
                      pickupBoarded &&
                      attendance == null)
                    const Icon(
                      Icons.check_circle_rounded,
                      color: Color(0xFF0B6E4F),
                    )
                  else if (attendance != null)
                    Icon(
                      attendance.status == 'Bindi'
                          ? Icons.check_circle_rounded
                          : Icons.cancel_rounded,
                      color: attendance.status == 'Bindi'
                          ? const Color(0xFF0B6E4F)
                          : Colors.red.shade700,
                    ),
                  const SizedBox(width: 4),
                  Icon(
                    isExpanded
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                  ),
                ],
              ),
            ),
          ),
          if (isExpanded) ...[
            const Divider(height: 1),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: serviceActive && !readOnly && !isBoarded
                              ? () => _recordAttendance(person, 'Bindi')
                              : null,
                          icon: Icon(
                            isBoarded
                                ? Icons.check_rounded
                                : Icons.airport_shuttle_rounded,
                          ),
                          label: Text(
                            isBoarded
                                ? 'Tamam'
                                : widget.isDistribution
                                ? 'İndi'
                                : 'Bindi',
                          ),
                          style: FilledButton.styleFrom(
                            backgroundColor: const Color(0xFF0B6E4F),
                            disabledBackgroundColor: const Color(0xFF9CC9B8),
                            disabledForegroundColor: Colors.white,
                            minimumSize: const Size(0, 46),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: serviceActive
                              ? () => _confirmAbsent(person)
                              : null,
                          icon: const Icon(Icons.person_off_rounded),
                          label: const Text('Yok'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: Colors.red.shade700,
                            side: BorderSide(color: Colors.red.shade700),
                            minimumSize: const Size(0, 46),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                        onPressed: serviceActive
                            ? () => _openMap(person)
                            : null,
                        icon: const Icon(Icons.location_on_rounded),
                        color: person.stopLatitude == null
                            ? Colors.grey
                            : const Color(0xFF175DB3),
                        tooltip: 'Harita',
                      ),
                      IconButton(
                        onPressed: serviceActive ? () => _call(person) : null,
                        icon: const Icon(Icons.phone_rounded),
                        color: const Color(0xFF0B6E4F),
                        tooltip: 'Ara',
                      ),
                      IconButton(
                        onPressed: serviceActive
                            ? () => _openWhatsApp(person)
                            : null,
                        icon: const FaIcon(
                          FontAwesomeIcons.whatsapp,
                          color: Color(0xFF25D366),
                        ),
                        tooltip: 'WhatsApp',
                      ),
                      if (widget.canEditPersonnel && !readOnly)
                        IconButton(
                          onPressed: () => _editPersonnel(person),
                          icon: const Icon(Icons.edit_rounded),
                          color: const Color(0xFF8A4B08),
                          tooltip: 'Yolcu Bilgilerini Düzenle',
                        ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _stopGroupedList({
    required List<Personnel> personnel,
    required Map<String, AttendanceRecord> attendanceByPerson,
    required Map<String, PersonnelLeave> leaveByPerson,
    required bool serviceActive,
    required bool shiftReadOnly,
  }) {
    final entries =
        <({String name, int order, Stop? stop, List<Personnel> passengers})>[];
    if (widget.showAllStops) {
      final routeStops =
          _stops
              .where((stop) => stop.institutionId == _selectedInstitutionId)
              .toList()
            ..sort(
              (a, b) => widget.isDistribution
                  ? b.order.compareTo(a.order)
                  : a.order.compareTo(b.order),
            );
      for (final stop in routeStops) {
        final passengers = personnel
            .where(
              (person) =>
                  person.stopName.trim().toLowerCase() ==
                  stop.name.trim().toLowerCase(),
            )
            .toList();
        entries.add((
          name: stop.name,
          order: stop.order,
          stop: stop,
          passengers: passengers,
        ));
      }
    } else {
      final groups = <String, List<Personnel>>{};
      for (final person in personnel) {
        final key = '${person.stopOrder}\u0000${person.stopName}';
        groups.putIfAbsent(key, () => []).add(person);
      }
      for (final entry in groups.entries) {
        final name = entry.key.split('\u0000').last;
        final order = int.tryParse(entry.key.split('\u0000').first) ?? 0;
        Stop? matchedStop;
        for (final stop in _stops) {
          if (stop.institutionId == _selectedInstitutionId &&
              stop.name.trim().toLowerCase() == name.trim().toLowerCase()) {
            matchedStop = stop;
            break;
          }
        }
        entries.add((
          name: name,
          order: order,
          stop: matchedStop,
          passengers: entry.value,
        ));
      }
      entries.sort(
        (a, b) => widget.isDistribution
            ? b.order.compareTo(a.order)
            : a.order.compareTo(b.order),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: entries.length,
      separatorBuilder: (_, _) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final entry = entries[index];
        final passengers = entry.passengers;
        return Card(
          clipBehavior: Clip.antiAlias,
          child: ExpansionTile(
            leading: CircleAvatar(child: Text('${index + 1}')),
            title: Row(
              children: [
                Expanded(
                  child: Text(
                    entry.name,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Google Maps ile aç',
                  onPressed: entry.stop == null
                      ? null
                      : () => _openStopMap(entry.stop!),
                  icon: const Icon(
                    Icons.location_on_rounded,
                    color: Color(0xFF0B6E4F),
                  ),
                ),
              ],
            ),
            subtitle: Text(
              passengers.isEmpty ? 'Yolcu yok' : '${passengers.length} yolcu',
            ),
            enabled: passengers.isNotEmpty,
            children: [
              for (final person in passengers)
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                  child: _personnelCard(
                    person: person,
                    listNumber: personnel.indexOf(person) + 1,
                    attendance: attendanceByPerson[person.id],
                    serviceActive:
                        !shiftReadOnly && !leaveByPerson.containsKey(person.id),
                    readOnly:
                        shiftReadOnly || leaveByPerson.containsKey(person.id),
                    personnelLeave: leaveByPerson[person.id],
                    pickupAbsent:
                        widget.isDistribution &&
                        _pickupAbsentPersonIds.contains(person.id) &&
                        !_distributionReactivatedIds.contains(person.id),
                    pickupBoarded:
                        _pickupAttendanceByPerson[person.id]?.status == 'Bindi',
                  ),
                ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final selectedPersonnel = _shiftPersonnel;
    final leaveByPerson = <String, PersonnelLeave>{};
    for (final person in selectedPersonnel) {
      final leave = _leaveFor(person);
      if (leave != null) leaveByPerson[person.id] = leave;
    }
    final attendanceByPerson = _attendanceByPerson;
    final boardedCount = selectedPersonnel
        .where(
          (person) =>
              !leaveByPerson.containsKey(person.id) &&
              attendanceByPerson[person.id]?.status == 'Bindi',
        )
        .length;
    final absentCount = selectedPersonnel
        .where(
          (person) =>
              !leaveByPerson.containsKey(person.id) &&
              attendanceByPerson[person.id]?.status == 'Durakta Yok',
        )
        .length;
    final serviceActive = _isServiceActive;
    final serviceCompleted = !serviceActive && _completedServiceRecord != null;
    final shiftReadOnly = _isShiftReadOnly;
    final canStartService =
        !serviceActive &&
        _selectedDriverId != null &&
        _selectedInstitutionId != null &&
        _selectedVehicleId != null;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 8,
        title: Text(
          widget.isDistribution ? 'Dağıtım Listesi' : 'Toplama Listesi',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        ),
        actions: [
          SizedBox(
            width: 82,
            height: 38,
            child: TextButton.icon(
              onPressed: _showEmergencyContacts,
              icon: const Icon(Icons.phone_in_talk_rounded, size: 18),
              label: const Text('Acil'),
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.red.shade700,
                padding: const EdgeInsets.symmetric(horizontal: 6),
              ),
            ),
          ),
          const SizedBox(width: 5),
          SizedBox(
            width: 82,
            height: 38,
            child: TextButton.icon(
              onPressed: _addPassengerToSelectedShift,
              icon: const Icon(Icons.person_add_alt_1_rounded, size: 18),
              label: const Text(
                'Yolcu',
                maxLines: 1,
                overflow: TextOverflow.fade,
              ),
              style: TextButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: const Color(0xFF0B6E4F),
                padding: const EdgeInsets.symmetric(horizontal: 5),
              ),
            ),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Container(
                  width: double.infinity,
                  color: const Color(0xFFE6EEF7),
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 9,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFD6E7FA),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '$_selectedInstitutionName • $_shownDateText • $_serviceListLabel',
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Color(0xFF082A52),
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Visibility(
                        visible: false,
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: DropdownButtonFormField<String>(
                                    initialValue: _selectedInstitutionId,
                                    isExpanded: true,
                                    decoration: const InputDecoration(
                                      labelText: 'Kurum',
                                      border: OutlineInputBorder(),
                                      isDense: true,
                                    ),
                                    items: _institutions
                                        .map(
                                          (institution) => DropdownMenuItem(
                                            value: institution.id,
                                            child: Text(
                                              institution.name,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        )
                                        .toList(),
                                    onChanged: serviceActive
                                        ? null
                                        : (value) => setState(() {
                                            _selectedInstitutionId = value;
                                            _expandedPersonnelIds.clear();
                                            _distributionReactivatedIds.clear();
                                            _distributionExcludedIds.clear();
                                          }),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: DropdownButtonFormField<String>(
                                    initialValue: _selectedVehicleId,
                                    isExpanded: true,
                                    decoration: const InputDecoration(
                                      labelText: 'Araç',
                                      border: OutlineInputBorder(),
                                      isDense: true,
                                    ),
                                    items: _vehicles
                                        .map(
                                          (vehicle) => DropdownMenuItem(
                                            value: vehicle.id,
                                            child: Text(
                                              vehicle.plate,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        )
                                        .toList(),
                                    onChanged: serviceActive
                                        ? null
                                        : (value) => setState(
                                            () => _selectedVehicleId = value,
                                          ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                            Row(
                              children: [
                                Expanded(
                                  child: OutlinedButton.icon(
                                    onPressed: _selectedDriverId == null
                                        ? null
                                        : _chooseDate,
                                    style: OutlinedButton.styleFrom(
                                      minimumSize: const Size(0, 56),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                    ),
                                    icon: const Icon(
                                      Icons.calendar_month_rounded,
                                    ),
                                    label: Text(
                                      _shownDateText,
                                      style: const TextStyle(fontSize: 13),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: DropdownButtonFormField<String>(
                                    value: _selectedDriverId,
                                    isExpanded: true,
                                    decoration: const InputDecoration(
                                      labelText: 'Şoför',
                                      border: OutlineInputBorder(),
                                      isDense: true,
                                    ),
                                    items: _drivers
                                        .map(
                                          (driver) => DropdownMenuItem(
                                            value: driver.id,
                                            child: Text(
                                              driver.name,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        )
                                        .toList(),
                                    onChanged: _selectDriver,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            Visibility(
                              visible: false,
                              child: DropdownButtonFormField<String>(
                                value: _selectedDriverId,
                                isExpanded: true,
                                decoration: const InputDecoration(
                                  labelText: 'Şoför Seç',
                                  border: OutlineInputBorder(),
                                  isDense: true,
                                ),
                                items: _drivers
                                    .map(
                                      (driver) => DropdownMenuItem(
                                        value: driver.id,
                                        child: Text(
                                          driver.name,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    )
                                    .toList(),
                                onChanged: _selectDriver,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          SizedBox(
                            width: 46,
                            height: 48,
                            child: FilledButton(
                              onPressed: _openingWhatsApp
                                  ? null
                                  : _handleWhatsAppButton,
                              style: FilledButton.styleFrom(
                                backgroundColor: const Color(0xFF128C7E),
                                disabledBackgroundColor: const Color(
                                  0xFF8BC4BD,
                                ),
                                disabledForegroundColor: Colors.white,
                                padding: EdgeInsets.zero,
                              ),
                              child: _openingWhatsApp
                                  ? const Icon(Icons.check_rounded, size: 24)
                                  : const FaIcon(
                                      FontAwesomeIcons.whatsapp,
                                      size: 21,
                                    ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            flex: 2,
                            child: OutlinedButton.icon(
                              onPressed: _chooseDate,
                              icon: const Icon(
                                Icons.calendar_month_rounded,
                                size: 18,
                              ),
                              label: Text(
                                _shownDateText,
                                maxLines: 1,
                                softWrap: false,
                                style: const TextStyle(fontSize: 11),
                              ),
                              style: OutlinedButton.styleFrom(
                                minimumSize: const Size(0, 48),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                ),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(4),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            flex: 3,
                            child: DropdownButtonFormField<String>(
                              key: ValueKey('top-shift-$_selectedShift'),
                              value: _selectedShift,
                              isExpanded: true,
                              decoration: const InputDecoration(
                                labelText: 'Vardiya Seç',
                                border: OutlineInputBorder(),
                                isDense: true,
                              ),
                              items: _shiftChoices
                                  .map(
                                    (shift) => DropdownMenuItem(
                                      value: shift,
                                      child: Text(shift),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (value) {
                                if (value != null) _selectShift(value);
                              },
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: _openingMap ? null : _handleMapButton,
                              style: FilledButton.styleFrom(
                                backgroundColor: const Color(0xFF1565C0),
                                disabledBackgroundColor: const Color(
                                  0xFF90B7DF,
                                ),
                                disabledForegroundColor: Colors.white,
                                minimumSize: const Size(0, 62),
                                elevation: 8,
                                shadowColor: const Color(0xFF0B356A),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  side: const BorderSide(
                                    color: Color(0xFF5FA8F5),
                                  ),
                                ),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 4,
                                ),
                              ),
                              icon: _openingMap
                                  ? const Icon(Icons.check_rounded, size: 28)
                                  : SizedBox(
                                      width: 34,
                                      height: 34,
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.all(
                                          Radius.circular(8),
                                        ),
                                        child: Transform.scale(
                                          scale: 1.2,
                                          child: Image(
                                            image: AssetImage(
                                              'assets/icons/map_minibus_location.png',
                                            ),
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ),
                              label: const Text('Harita'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: canStartService && !_startingService
                                  ? _handleStartService
                                  : null,
                              icon: serviceActive || _startingService
                                  ? const Icon(Icons.check_rounded)
                                  : serviceCompleted
                                  ? const Icon(Icons.refresh_rounded)
                                  : const _ServiceActionAssetIcon(
                                      assetPath:
                                          'assets/icons/start_minibus.png',
                                    ),
                              label: Text(
                                serviceActive
                                    ? 'Başladı'
                                    : _startingService
                                    ? 'Başlıyor'
                                    : serviceCompleted
                                    ? 'Yeniden'
                                    : 'Başla',
                              ),
                              style: FilledButton.styleFrom(
                                minimumSize: const Size(0, 62),
                                backgroundColor: const Color(0xFF0B6E4F),
                                disabledBackgroundColor: serviceActive
                                    ? const Color(0xFF9CC9B8)
                                    : null,
                                disabledForegroundColor: Colors.white,
                                elevation: 8,
                                shadowColor: const Color(0xFF063D2C),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  side: const BorderSide(
                                    color: Color(0xFF4DBB91),
                                  ),
                                ),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 4,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: serviceActive && !_finishingService
                                  ? _handleFinishService
                                  : null,
                              icon: serviceCompleted
                                  ? const Icon(Icons.check_rounded)
                                  : const _ServiceActionAssetIcon(
                                      assetPath:
                                          'assets/icons/finish_minibus.png',
                                    ),
                              label: Text(
                                serviceCompleted
                                    ? 'Bitti'
                                    : _finishingService
                                    ? 'Bitiyor'
                                    : 'Bitir',
                              ),
                              style: FilledButton.styleFrom(
                                minimumSize: const Size(0, 62),
                                backgroundColor: Colors.red.shade700,
                                disabledBackgroundColor: serviceCompleted
                                    ? const Color(0xFF9CC9B8)
                                    : null,
                                disabledForegroundColor: Colors.white,
                                elevation: 8,
                                shadowColor: const Color(0xFF6E1111),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(14),
                                  side: const BorderSide(
                                    color: Color(0xFFFF7070),
                                  ),
                                ),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 4,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Toplam: ${selectedPersonnel.length}   •   Binen: $boardedCount   •   Yok: $absentCount   •   İzinli: ${leaveByPerson.length}',
                        style: const TextStyle(
                          color: Color(0xFF52657B),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                if (shiftReadOnly)
                  Container(
                    width: double.infinity,
                    color: const Color(0xFFFFE0B2),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 10,
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.lock_clock_rounded,
                          color: Color(0xFF8A4B08),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            widget.isDistribution
                                ? 'Dağıtım bitti. Kullanıcılar pasiftir.'
                                : 'Toplama bitti. Kullanıcılar pasiftir.',
                            style: const TextStyle(
                              color: Color(0xFF8A4B08),
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        TextButton.icon(
                          onPressed: _deleteSelectedCompletedService,
                          style: TextButton.styleFrom(
                            foregroundColor: Colors.red.shade800,
                            padding: const EdgeInsets.symmetric(horizontal: 6),
                          ),
                          icon: const Icon(Icons.delete_forever_rounded),
                          label: const Text('Kaydı Sil'),
                        ),
                      ],
                    ),
                  ),
                Expanded(
                  child: selectedPersonnel.isEmpty && !widget.showAllStops
                      ? const Center(
                          child: Text('Bu vardiyada kayıtlı personel yok.'),
                        )
                      : widget.groupByStops || widget.showAllStops
                      ? _stopGroupedList(
                          personnel: selectedPersonnel,
                          attendanceByPerson: attendanceByPerson,
                          leaveByPerson: leaveByPerson,
                          serviceActive: serviceActive,
                          shiftReadOnly: shiftReadOnly,
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.all(16),
                          itemCount: selectedPersonnel.length,
                          separatorBuilder: (_, _) =>
                              const SizedBox(height: 10),
                          itemBuilder: (context, index) {
                            return _personnelCard(
                              person: selectedPersonnel[index],
                              listNumber: index + 1,
                              attendance:
                                  attendanceByPerson[selectedPersonnel[index]
                                      .id],
                              serviceActive:
                                  !shiftReadOnly &&
                                  !leaveByPerson.containsKey(
                                    selectedPersonnel[index].id,
                                  ),
                              readOnly:
                                  shiftReadOnly ||
                                  leaveByPerson.containsKey(
                                    selectedPersonnel[index].id,
                                  ),
                              personnelLeave:
                                  leaveByPerson[selectedPersonnel[index].id],
                              pickupAbsent:
                                  widget.isDistribution &&
                                  _pickupAbsentPersonIds.contains(
                                    selectedPersonnel[index].id,
                                  ) &&
                                  !_distributionReactivatedIds.contains(
                                    selectedPersonnel[index].id,
                                  ),
                              pickupBoarded:
                                  _pickupAttendanceByPerson[selectedPersonnel[index]
                                          .id]
                                      ?.status ==
                                  'Bindi',
                            );
                            // Eski geniş kart kodu sonraki temizlikte kaldırılacak.
                            final person = selectedPersonnel[index];
                            final attendance = attendanceByPerson[person.id];
                            final cardColor = attendance == null
                                ? const Color(0xFFFFF8E1)
                                : attendance.status == 'Bindi'
                                ? const Color(0xFFE8F5E9)
                                : const Color(0xFFFFEBEE);
                            if (attendance != null) {
                              return Card(
                                color: cardColor,
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 14,
                                    vertical: 12,
                                  ),
                                  child: Text(
                                    '${index + 1}. ${person.fullName}',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                ),
                              );
                            }
                            return Card(
                              color: cardColor,
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    CircleAvatar(child: Text('${index + 1}')),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Text(
                                            person.fullName,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              fontWeight: FontWeight.w800,
                                              fontSize: 16,
                                            ),
                                          ),
                                          const SizedBox(height: 6),
                                          Text(
                                            person.stopName,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              color: Colors.grey.shade700,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                          const SizedBox(height: 10),
                                          Row(
                                            children: [
                                              Expanded(
                                                child: FilledButton.icon(
                                                  onPressed: serviceActive
                                                      ? () => _recordAttendance(
                                                          person,
                                                          'Bindi',
                                                        )
                                                      : null,
                                                  icon: const Icon(
                                                    Icons
                                                        .airport_shuttle_rounded,
                                                  ),
                                                  label: Text(
                                                    widget.isDistribution
                                                        ? 'İndi'
                                                        : 'Bindi',
                                                  ),
                                                  style: FilledButton.styleFrom(
                                                    backgroundColor:
                                                        const Color(0xFF0B6E4F),
                                                    minimumSize: const Size(
                                                      0,
                                                      46,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              Expanded(
                                                child: OutlinedButton.icon(
                                                  onPressed: serviceActive
                                                      ? () => _confirmAbsent(
                                                          person,
                                                        )
                                                      : null,
                                                  icon: const Icon(
                                                    Icons.person_off_rounded,
                                                  ),
                                                  label: const Text('Yok'),
                                                  style:
                                                      OutlinedButton.styleFrom(
                                                        foregroundColor:
                                                            Colors.red.shade700,
                                                        side: BorderSide(
                                                          color: Colors
                                                              .red
                                                              .shade700,
                                                        ),
                                                        minimumSize: const Size(
                                                          0,
                                                          46,
                                                        ),
                                                      ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                    Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        IconButton(
                                          onPressed: serviceActive
                                              ? () => _openMap(person)
                                              : null,
                                          icon: const Icon(
                                            Icons.location_on_rounded,
                                          ),
                                          color: person.stopLatitude == null
                                              ? Colors.grey
                                              : const Color(0xFF175DB3),
                                          tooltip: 'Harita',
                                          visualDensity: VisualDensity.compact,
                                        ),
                                        IconButton(
                                          onPressed: serviceActive
                                              ? () => _call(person)
                                              : null,
                                          icon: const Icon(Icons.phone_rounded),
                                          tooltip: 'Ara',
                                          visualDensity: VisualDensity.compact,
                                        ),
                                        IconButton(
                                          onPressed: serviceActive
                                              ? () => _openWhatsApp(person)
                                              : null,
                                          icon: const FaIcon(
                                            FontAwesomeIcons.whatsapp,
                                            color: Color(0xFF25D366),
                                          ),
                                          tooltip: 'WhatsApp',
                                          visualDensity: VisualDensity.compact,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

class _ServiceActionAssetIcon extends StatelessWidget {
  const _ServiceActionAssetIcon({required this.assetPath});

  final String assetPath;

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: 30,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(7),
        child: Transform.scale(
          scale: 1.2,
          child: Image.asset(assetPath, fit: BoxFit.cover),
        ),
      ),
    );
  }
}
