import 'package:flutter_test/flutter_test.dart';
import 'package:servis_takip/models/personnel.dart';
import 'package:servis_takip/services/shift_calculator.dart';

Personnel person({
  required String shift,
  required String pattern,
  String direction = Personnel.shiftBackward,
  int cycleDay = 1,
}) {
  return Personnel(
    id: 'test',
    fullName: 'Test',
    phone: '',
    whatsApp: '',
    stopName: 'Durak',
    stopOrder: 1,
    shift: shift,
    workType: Personnel.rotatingWorkType,
    leaveWeekdays: const [],
    leaveMode: Personnel.cycleLeaveMode,
    workDaysCount: 1,
    leaveDaysCount: 1,
    shiftDirection: direction,
    shiftSystem:
        pattern == Personnel.twoShiftStandardPattern ||
            pattern == Personnel.twoShiftEarlyPattern
        ? Personnel.twoShiftSystem
        : Personnel.threeShiftSystem,
    shiftPattern: pattern,
    institutionId: 'kurum',
    institutionName: 'Kurum',
    referenceDate: '2026-07-20',
    cycleDay: cycleDay,
    note: '',
  );
}

void main() {
  test('iki vardiya yalnızca seçilen iki vardiya arasında döner', () {
    final value = person(
      shift: '16 / 24',
      pattern: Personnel.twoShiftStandardPattern,
    );
    expect(
      ShiftCalculator.forDate(value, DateTime(2026, 7, 22)).shift,
      '08 / 16',
    );
  });

  test('erken üçlü vardiya ileri yönde doğru döner', () {
    final value = person(
      shift: '23 / 07',
      pattern: Personnel.threeShiftEarlyPattern,
      direction: Personnel.shiftForward,
    );
    expect(
      ShiftCalculator.forDate(value, DateTime(2026, 7, 22)).shift,
      '07 / 15',
    );
  });

  test('bugün kaçıncı çalışma günü bilgisi korunur', () {
    final value = person(
      shift: '08 / 16',
      pattern: Personnel.threeShiftStandardPattern,
      cycleDay: 5,
    );
    expect(
      ShiftCalculator.forDate(value, DateTime(2026, 7, 20)).workingDay,
      1,
    );
  });
}
