import 'package:flutter_test/flutter_test.dart';
import 'package:servis_takip/main.dart';

void main() {
  testWidgets('açılış ekranı uygulama adını gösterir', (tester) async {
    await tester.pumpWidget(const ServisTakipApp());

    expect(find.text('Servis Takip v1.1'), findsOneWidget);
    expect(find.text('GİRİŞ YAP'), findsOneWidget);
  });
}
