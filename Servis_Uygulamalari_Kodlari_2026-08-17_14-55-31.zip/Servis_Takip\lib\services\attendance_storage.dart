import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '../models/attendance_record.dart';
import 'company_cloud_storage.dart';

class AttendanceStorage {
  AttendanceStorage._();

  static const _key = 'attendance_records';
  static const _pendingKey = 'attendance_records_pending_sync';
  static const _storage = FlutterSecureStorage();

  static Future<List<AttendanceRecord>> readAll() async {
    final cached = await _readCache();
    if (await hasPendingSync()) {
      await syncPending();
      return cached;
    }
    try {
      final cloudData = await CompanyCloudStorage.readCollection('attendance');
      if (cloudData.isNotEmpty) {
        final records = cloudData.map(AttendanceRecord.fromJson).toList();
        await _writeCache(records);
        await CompanyCloudStorage.markCloudInitialized('attendance');
        return records;
      }
      if (await CompanyCloudStorage.isCloudInitialized('attendance')) {
        await _writeCache(const []);
        return [];
      }
    } catch (_) {
      return cached;
    }
    if (cached.isEmpty) {
      await CompanyCloudStorage.markCloudInitialized('attendance');
      return [];
    }
    if (await CompanyCloudStorage.canClaimLegacyData()) {
      await saveAll(cached);
    }
    await CompanyCloudStorage.markCloudInitialized('attendance');
    return cached;
  }

  static Future<bool> saveAll(
    List<AttendanceRecord> records, {
    bool syncNow = true,
  }) async {
    final previous = await _readCache();
    await _writeCache(records);
    await _queueChanges(
      previous: previous,
      current: records,
      deferred: !syncNow,
    );
    if (!syncNow) return true;
    try {
      await _syncQueuedChanges();
      await CompanyCloudStorage.markCloudInitialized('attendance');
      return true;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> hasPendingSync() async => !{null, '', 'false'}.contains(
    await _storage.read(key: await CompanyCloudStorage.cacheKey(_pendingKey)),
  );

  static Future<bool> syncPending() async {
    if (!await hasPendingSync()) return true;
    if (await _isDeferred()) return false;
    try {
      await _syncQueuedChanges();
      await CompanyCloudStorage.markCloudInitialized('attendance');
      return true;
    } catch (_) {
      return false;
    }
  }

  static String _documentId(AttendanceRecord record) => Uri.encodeComponent(
    '${record.personId}_${record.date}_${record.shift}_'
    '${record.serviceId ?? ''}_${record.recordedAt}',
  );

  static Map<String, dynamic> _cloudData(AttendanceRecord record) => {
    ...record.toJson(),
    'id': _documentId(record),
  };

  static Future<void> _queueChanges({
    required List<AttendanceRecord> previous,
    required List<AttendanceRecord> current,
    required bool deferred,
  }) async {
    final pending = await _readPending();
    final oldById = {for (final item in previous) _documentId(item): item};
    final newById = {for (final item in current) _documentId(item): item};
    final upserts = Map<String, dynamic>.from(pending['upserts'] as Map);
    final deletes = (pending['deletes'] as List<dynamic>)
        .map((item) => item.toString())
        .toSet();
    for (final entry in newById.entries) {
      final old = oldById[entry.key];
      if (old == null ||
          jsonEncode(old.toJson()) != jsonEncode(entry.value.toJson())) {
        upserts[entry.key] = _cloudData(entry.value);
        deletes.remove(entry.key);
      }
    }
    for (final id in oldById.keys.where((id) => !newById.containsKey(id))) {
      upserts.remove(id);
      deletes.add(id);
    }
    await _writePending(upserts: upserts, deletes: deletes, deferred: deferred);
  }

  static Future<void> _syncQueuedChanges() async {
    final key = await CompanyCloudStorage.cacheKey(_pendingKey);
    final queuedValue = await _storage.read(key: key);
    final pending = await _decodePending(queuedValue);
    final upserts = (pending['upserts'] as Map).map(
      (key, value) =>
          MapEntry(key.toString(), Map<String, dynamic>.from(value as Map)),
    );
    final deletes = (pending['deletes'] as List<dynamic>)
        .map((item) => item.toString())
        .toSet();
    await CompanyCloudStorage.applyDocumentChanges(
      collectionName: 'attendance',
      upserts: upserts,
      deletes: deletes,
    );
    if (await _storage.read(key: key) == queuedValue) {
      await _storage.delete(key: key);
    }
  }

  static Future<void> _writeCache(List<AttendanceRecord> records) async {
    await _storage.write(
      key: await CompanyCloudStorage.cacheKey(_key),
      value: jsonEncode(records.map((record) => record.toJson()).toList()),
    );
  }

  static Future<List<AttendanceRecord>> _readCache() async {
    final saved =
        await _storage.read(key: await CompanyCloudStorage.cacheKey(_key)) ??
        await _storage.read(key: _key);
    if (saved == null || saved.isEmpty) return [];
    return (jsonDecode(saved) as List<dynamic>)
        .map((item) => AttendanceRecord.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  static Future<Map<String, dynamic>> _readPending() async {
    final key = await CompanyCloudStorage.cacheKey(_pendingKey);
    return _decodePending(await _storage.read(key: key));
  }

  static Future<Map<String, dynamic>> _decodePending(String? value) async {
    if (value == null || value.isEmpty || value == 'false') {
      return {
        'upserts': <String, dynamic>{},
        'deletes': <String>[],
        'deferred': false,
      };
    }
    if (value == 'true') {
      final records = await _readCache();
      return {
        'upserts': {
          for (final record in records) _documentId(record): _cloudData(record),
        },
        'deletes': <String>[],
        'deferred': false,
      };
    }
    return Map<String, dynamic>.from(jsonDecode(value) as Map);
  }

  static Future<void> _writePending({
    required Map<String, dynamic> upserts,
    required Set<String> deletes,
    required bool deferred,
  }) async {
    final key = await CompanyCloudStorage.cacheKey(_pendingKey);
    if (upserts.isEmpty && deletes.isEmpty) {
      await _storage.delete(key: key);
      return;
    }
    await _storage.write(
      key: key,
      value: jsonEncode({
        'upserts': upserts,
        'deletes': deletes.toList(),
        'deferred': deferred,
      }),
    );
  }

  static Future<bool> _isDeferred() async {
    final pending = await _readPending();
    return pending['deferred'] == true;
  }
}
