import 'package:flutter/material.dart';

import '../models/personnel.dart';
import '../models/personnel_leave.dart';
import '../services/personnel_leave_storage.dart';
import '../services/personnel_storage.dart';
import '../services/shift_calculator.dart';

class PersonnelLeavesScreen extends StatefulWidget {
  const PersonnelLeavesScreen({required this.canManage, super.key});

  final bool canManage;

  @override
  State<PersonnelLeavesScreen> createState() => _PersonnelLeavesScreenState();
}

class _PersonnelLeavesScreenState extends State<PersonnelLeavesScreen> {
  bool _loading = true;
  List<Personnel> _personnel = [];
  List<PersonnelLeave> _leaves = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await Future.wait([
      PersonnelStorage.readAll(),
      PersonnelLeaveStorage.readAll(),
    ]);
    if (!mounted) return;
    setState(() {
      _personnel = result[0] as List<Personnel>;
      _leaves = result[1] as List<PersonnelLeave>;
      _loading = false;
    });
  }

  Future<void> _add() async {
    final leave = await showDialog<PersonnelLeave>(
      context: context,
      builder: (_) => _PersonnelLeaveDialog(personnel: _personnel),
    );
    if (leave == null) return;
    final updated = [..._leaves, leave]
      ..sort((a, b) => a.startDate.compareTo(b.startDate));
    await PersonnelLeaveStorage.saveOne(leave);
    if (mounted) setState(() => _leaves = updated);
  }

  Future<void> _delete(PersonnelLeave leave) async {
    final updated = _leaves.where((item) => item.id != leave.id).toList();
    await PersonnelLeaveStorage.deleteOne(leave.id);
    if (mounted) setState(() => _leaves = updated);
  }

  Future<void> _returnToWork(PersonnelLeave leave) async {
    final personIndex = _personnel.indexWhere(
      (person) => person.id == leave.personId,
    );
    if (personIndex < 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Personel kaydı bulunamadı.')),
      );
      return;
    }

    final person = _personnel[personIndex];
    final selectedShift = await showDialog<String>(
      context: context,
      builder: (_) => _ReturnToWorkDialog(person: person),
    );
    if (selectedShift == null) return;

    final todayText = _iso(_dateOnly(DateTime.now()));
    final updatedPerson = person.copyWith(
      shift: selectedShift,
      referenceDate: todayText,
      cycleDay: 1,
    );
    final updatedLeave = leave.copyWith(
      returnDate: todayText,
      returnShift: selectedShift,
    );

    await Future.wait([
      PersonnelStorage.saveOne(updatedPerson),
      PersonnelLeaveStorage.saveOne(updatedLeave),
    ]);
    if (!mounted) return;
    setState(() {
      _personnel[personIndex] = updatedPerson;
      final leaveIndex = _leaves.indexWhere((item) => item.id == leave.id);
      if (leaveIndex >= 0) _leaves[leaveIndex] = updatedLeave;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '${person.fullName}, $selectedShift vardiyasında işe başladı.',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final today = _dateOnly(DateTime.now());
    final visibleLeaves = _leaves
        .where(
          (leave) =>
              leave.returnDate.isEmpty &&
              !DateTime.parse(leave.endDate).isBefore(today),
        )
        .toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Personel İzinleri')),
      floatingActionButton: widget.canManage
          ? FloatingActionButton.extended(
              onPressed: _add,
              icon: const Icon(Icons.add_rounded),
              label: const Text('İzin Ekle'),
            )
          : null,
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : visibleLeaves.isEmpty
          ? const Center(child: Text('Aktif veya yaklaşan izin kaydı yok.'))
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
              itemCount: visibleLeaves.length,
              separatorBuilder: (_, _) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final leave = visibleLeaves[index];
                final start = DateTime.parse(leave.startDate);
                final active = !today.isBefore(start);
                final remaining = leave.remainingDays(today);
                return Card(
                  color: const Color(0xFFFFE0B2),
                  child: ListTile(
                    leading: const CircleAvatar(
                      backgroundColor: Color(0xFFFF9800),
                      child: Icon(
                        Icons.beach_access_rounded,
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      leave.personName,
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    subtitle: Text(
                      '${leave.institutionName}\n'
                      '${_displayDate(start)} - '
                      '${_displayDate(DateTime.parse(leave.endDate))}',
                    ),
                    isThreeLine: true,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          active
                              ? '$remaining gün\nkaldı'
                              : '${start.difference(today).inDays} gün\nsonra',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Color(0xFF8A4B08),
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        if (active && widget.canManage)
                          IconButton(
                            onPressed: () => _returnToWork(leave),
                            tooltip: 'İşe erken dönüş',
                            icon: const Icon(
                              Icons.keyboard_return_rounded,
                              color: Color(0xFF16853C),
                            ),
                          ),
                        if (widget.canManage)
                          IconButton(
                            onPressed: () => _delete(leave),
                            icon: const Icon(Icons.delete_outline_rounded),
                            color: Colors.red,
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }

  static DateTime _dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  static String _iso(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-'
      '${date.month.toString().padLeft(2, '0')}-'
      '${date.day.toString().padLeft(2, '0')}';

  static String _displayDate(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}.'
      '${date.month.toString().padLeft(2, '0')}.${date.year}';
}

class _ReturnToWorkDialog extends StatefulWidget {
  const _ReturnToWorkDialog({required this.person});

  final Personnel person;

  @override
  State<_ReturnToWorkDialog> createState() => _ReturnToWorkDialogState();
}

class _ReturnToWorkDialogState extends State<_ReturnToWorkDialog> {
  late String _shift =
      ShiftCalculator.defaultShifts.contains(
        ShiftCalculator.normalizeShift(widget.person.shift),
      )
      ? ShiftCalculator.normalizeShift(widget.person.shift)
      : ShiftCalculator.defaultShifts.first;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Row(
        children: [
          Icon(Icons.keyboard_return_rounded, color: Color(0xFF16853C)),
          SizedBox(width: 8),
          Text('İşe Erken Dönüş'),
        ],
      ),
      content: SizedBox(
        width: 420,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.person.fullName,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
            ),
            if (widget.person.institutionName.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(widget.person.institutionName),
            ],
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _shift,
              decoration: const InputDecoration(
                labelText: 'İzin dönüşü başlayacağı vardiya',
                border: OutlineInputBorder(),
              ),
              items: ShiftCalculator.defaultShifts
                  .map(
                    (shift) =>
                        DropdownMenuItem(value: shift, child: Text(shift)),
                  )
                  .toList(),
              onChanged: (value) {
                if (value != null) setState(() => _shift = value);
              },
            ),
            const SizedBox(height: 10),
            const Text(
              'Onaylandığında izin bugün sona erer ve personel seçilen '
              'vardiyada 1. çalışma gününden başlar.',
              style: TextStyle(color: Color(0xFF5B6472)),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton.icon(
          onPressed: () => Navigator.pop(context, _shift),
          icon: const Icon(Icons.check_rounded),
          label: const Text('İşe Başlat'),
        ),
      ],
    );
  }
}

class _PersonnelLeaveDialog extends StatefulWidget {
  const _PersonnelLeaveDialog({required this.personnel});

  final List<Personnel> personnel;

  @override
  State<_PersonnelLeaveDialog> createState() => _PersonnelLeaveDialogState();
}

class _PersonnelLeaveDialogState extends State<_PersonnelLeaveDialog> {
  Personnel? _person;
  DateTime _startDate = _dateOnly(DateTime.now());
  DateTime _endDate = _dateOnly(DateTime.now());
  final _noteController = TextEditingController();

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  Future<void> _chooseStart() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 730)),
    );
    if (date != null) {
      setState(() {
        _startDate = _dateOnly(date);
        if (_endDate.isBefore(_startDate)) _endDate = _startDate;
      });
    }
  }

  Future<void> _chooseEnd() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _endDate,
      firstDate: _startDate,
      lastDate: DateTime.now().add(const Duration(days: 730)),
    );
    if (date != null) setState(() => _endDate = _dateOnly(date));
  }

  void _save() {
    final person = _person;
    if (person == null) return;
    Navigator.pop(
      context,
      PersonnelLeave(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        personId: person.id,
        personName: person.fullName,
        institutionId: person.institutionId,
        institutionName: person.institutionName,
        startDate: _iso(_startDate),
        endDate: _iso(_endDate),
        note: _noteController.text.trim(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Personel İzni Ekle'),
      content: SizedBox(
        width: 430,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<Personnel>(
                initialValue: _person,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Personel',
                  border: OutlineInputBorder(),
                ),
                items: widget.personnel
                    .map(
                      (person) => DropdownMenuItem(
                        value: person,
                        child: Text(
                          person.fullName,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    )
                    .toList(),
                onChanged: (value) => setState(() => _person = value),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _chooseStart,
                      icon: const Icon(Icons.event_rounded),
                      label: Text('Başlangıç\n${_displayDate(_startDate)}'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _chooseEnd,
                      icon: const Icon(Icons.event_available_rounded),
                      label: Text('Bitiş\n${_displayDate(_endDate)}'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _noteController,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'Not (isteğe bağlı)',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Vazgeç'),
        ),
        FilledButton(
          onPressed: _person == null ? null : _save,
          child: const Text('Kaydet'),
        ),
      ],
    );
  }

  static DateTime _dateOnly(DateTime date) =>
      DateTime(date.year, date.month, date.day);

  static String _iso(DateTime date) =>
      '${date.year.toString().padLeft(4, '0')}-'
      '${date.month.toString().padLeft(2, '0')}-'
      '${date.day.toString().padLeft(2, '0')}';

  static String _displayDate(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}.'
      '${date.month.toString().padLeft(2, '0')}.${date.year}';
}
