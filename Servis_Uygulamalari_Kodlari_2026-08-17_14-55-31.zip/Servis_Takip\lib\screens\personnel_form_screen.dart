import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

import '../models/institution.dart';
import '../models/personnel.dart';
import '../models/shift_definition.dart';
import '../models/stop.dart';
import '../models/work_shift.dart';
import '../services/institution_storage.dart';
import '../services/stop_storage.dart';
import '../services/shift_calculator.dart';
import '../services/shift_definition_storage.dart';
import '../services/shift_storage.dart';
import 'map_picker_screen.dart';

class PersonnelFormScreen extends StatefulWidget {
  const PersonnelFormScreen({this.personnel, super.key});

  final Personnel? personnel;

  @override
  State<PersonnelFormScreen> createState() => _PersonnelFormScreenState();
}

class _PersonnelFormScreenState extends State<PersonnelFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _whatsAppController = TextEditingController();
  final _stopController = TextEditingController();
  final _stopOrderController = TextEditingController();
  final _noteController = TextEditingController();
  String _shift = '';
  bool _shiftSelectionTouched = false;
  String _workType = Personnel.rotatingWorkType;
  String _editingWorkType = Personnel.rotatingWorkType;
  Set<int> _leaveWeekdays = {};
  String _leaveMode = '';
  int _workDaysCount = 0;
  int _leaveDaysCount = 0;
  String _shiftDirection = Personnel.shiftBackward;
  String _shiftSystem = '';
  String _editingShiftSystem = '';
  String _shiftPattern = '';
  String _shiftDefinitionId = '';
  List<ShiftDefinition> _shiftDefinitions = [];
  Map<int, Set<String>> _reliefWeeklyShifts = {};
  Map<String, Set<String>> _reliefMonthlyShifts = {};
  Set<int> _fixedServiceWeekdays = {};
  Set<String> _fixedServiceShifts = {};
  Set<String> _serviceEntryTimes = {};
  Set<String> _serviceExitTimes = {};
  Map<int, Set<String>> _serviceEntryTimesByWeekday = {};
  Map<int, Set<String>> _serviceExitTimesByWeekday = {};
  bool _customServiceParticipationEnabled = false;
  late DateTime _reliefMonth;
  int _cycleDay = 1;
  double? _stopLatitude;
  double? _stopLongitude;
  bool _gettingLocation = false;
  bool _loadingStops = true;
  bool _loadingInstitutions = true;
  bool _loadingShifts = true;
  List<Institution> _institutions = [];
  List<Stop> _stops = [];
  List<String> _shifts = [];
  Stop? _selectedStop;
  Institution? _selectedInstitution;
  List<Institution> _selectedInstitutionPath = [];

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    _reliefMonth = DateTime(now.year, now.month);
    final person = widget.personnel;
    if (person == null) {
      _loadInstitutions();
      _loadStops();
      _loadShifts();
      return;
    }
    _nameController.text = person.fullName;
    _phoneController.text = person.phone;
    _whatsAppController.text = person.whatsApp;
    _stopController.text = person.stopName;
    _stopOrderController.text = person.stopOrder.toString();
    _noteController.text = person.note;
    final todayStatus = ShiftCalculator.forDate(person, now);
    _shift = todayStatus.isLeave || todayStatus.shift == null
        ? ShiftCalculator.normalizeShift(person.shift)
        : ShiftCalculator.normalizeShift(todayStatus.shift!);
    _workType = person.workType;
    _editingWorkType = person.workType;
    _leaveWeekdays = person.leaveWeekdays.toSet();
    _leaveMode = person.leaveMode;
    _workDaysCount = person.workDaysCount;
    _leaveDaysCount = person.leaveDaysCount;
    _shiftDirection = person.shiftDirection;
    _shiftSystem = person.shiftSystem;
    _editingShiftSystem = person.shiftSystem;
    _shiftPattern = person.shiftPattern;
    _shiftDefinitionId = person.shiftDefinitionId;
    _reliefWeeklyShifts = {
      for (final entry in person.reliefWeeklyShifts.entries)
        entry.key: entry.value.toSet(),
    };
    _reliefMonthlyShifts = {
      for (final entry in person.reliefMonthlyShifts.entries)
        entry.key: entry.value.toSet(),
    };
    _fixedServiceWeekdays = person.fixedServiceWeekdays.toSet();
    _fixedServiceShifts = person.fixedServiceShifts
        .map(ShiftCalculator.normalizeShift)
        .toSet();
    _serviceEntryTimes = person.serviceEntryTimes.toSet();
    _serviceExitTimes = person.serviceExitTimes.toSet();
    _serviceEntryTimesByWeekday = {
      for (final entry in person.serviceEntryTimesByWeekday.entries)
        entry.key: entry.value.toSet(),
    };
    _serviceExitTimesByWeekday = {
      for (final entry in person.serviceExitTimesByWeekday.entries)
        entry.key: entry.value.toSet(),
    };
    _customServiceParticipationEnabled =
        person.customServiceParticipationEnabled;
    for (final savedShift in person.fixedServiceShifts) {
      final parts = _shiftParts(savedShift);
      if (parts != null) {
        _serviceEntryTimes.add(parts.$1);
        _serviceExitTimes.add(parts.$2);
      }
    }
    if (_reliefMonthlyShifts.isEmpty && _reliefWeeklyShifts.isNotEmpty) {
      final daysInMonth = DateTime(
        _reliefMonth.year,
        _reliefMonth.month + 1,
        0,
      ).day;
      for (var day = 1; day <= daysInMonth; day++) {
        final date = DateTime(_reliefMonth.year, _reliefMonth.month, day);
        final shifts = _reliefWeeklyShifts[date.weekday];
        if (shifts != null && shifts.isNotEmpty) {
          _reliefMonthlyShifts[_dateToIso(date)] = {...shifts};
        }
      }
    }
    _cycleDay = person.cycleDay;
    _stopLatitude = person.stopLatitude;
    _stopLongitude = person.stopLongitude;
    _loadInstitutions();
    _loadStops();
    _loadShifts();
  }

  Future<void> _loadShifts() async {
    final result = await Future.wait([
      ShiftStorage.readAll(),
      ShiftDefinitionStorage.readAll(),
    ]);
    final savedShifts = result[0] as List<WorkShift>;
    final definitions = result[1] as List<ShiftDefinition>;
    final names = savedShifts
        .map((shift) => shift.name)
        .where((name) => !name.endsWith(' Sabit'))
        .toList();
    for (final definition in definitions) {
      for (final slot in definition.slots) {
        if (!names.contains(slot.label)) names.add(slot.label);
      }
    }
    if (!names.contains(ShiftCalculator.idleShift)) {
      names.add(ShiftCalculator.idleShift);
    }
    if (!names.contains(_shift) && _shift.trim().isNotEmpty) {
      names.add(_shift);
    }
    if (!mounted) return;
    setState(() {
      _shiftDefinitions = definitions;
      _shifts = names;
      if (_shift.isNotEmpty &&
          !_shifts.contains(_shift) &&
          _shifts.isNotEmpty) {
        _shift = _shifts.first;
      }
      _loadingShifts = false;
      _ensureServiceParticipationDefaults();
    });
  }

  void _ensureServiceParticipationDefaults({bool reset = false}) {
    if (!_customServiceParticipationEnabled) return;
    for (final day in _fixedServiceWeekdays) {
      if (reset || !_serviceEntryTimesByWeekday.containsKey(day)) {
        _serviceEntryTimesByWeekday[day] = {..._serviceEntryTimes};
      }
      if (reset || !_serviceExitTimesByWeekday.containsKey(day)) {
        _serviceExitTimesByWeekday[day] = {..._serviceExitTimes};
      }
    }
  }

  List<String> _availableParticipationShifts() {
    final values = <String>{
      for (final value in _shifts)
        if (value != ShiftCalculator.idleShift) value,
      for (final definition in _shiftDefinitions)
        for (final slot in definition.slots) slot.label,
    };
    return values.toList();
  }

  (String, String)? _shiftParts(String shift) {
    final values = shift.split('/').map((value) => value.trim()).toList();
    if (values.length != 2) return null;
    return (values.first, values.last);
  }

  ShiftDefinition? get _selectedShiftDefinition {
    for (final definition in _shiftDefinitions) {
      if (definition.id == _shiftDefinitionId) return definition;
    }
    return null;
  }

  String _workTypeForDefinition(ShiftDefinition definition) {
    final name = definition.name.trim().toLowerCase();
    if (name.contains('dinlendirici')) return Personnel.reliefWorkType;
    if (name.contains('misafir')) return Personnel.guestWorkType;
    if (definition.changeDirection == ShiftDefinition.fixed ||
        name.contains('sabit')) {
      return Personnel.fixedWorkType;
    }
    return Personnel.rotatingWorkType;
  }

  Widget _shiftDefinitionSelector() {
    return DropdownButtonFormField<String>(
      key: ValueKey('shift-definition-$_shiftDefinitionId'),
      initialValue: _shiftDefinitionId,
      isExpanded: true,
      decoration: const InputDecoration(
        labelText: 'Çalışma Şekli',
        prefixIcon: Icon(Icons.schedule_rounded),
        border: OutlineInputBorder(),
      ),
      items: [
        const DropdownMenuItem(
          value: '',
          enabled: false,
          child: Text('Çalışma şekli seçin'),
        ),
        if (_shiftDefinitionId.isNotEmpty &&
            !_shiftDefinitions.any(
              (definition) => definition.id == _shiftDefinitionId,
            ))
          DropdownMenuItem(
            value: _shiftDefinitionId,
            child: const Text('Kayıtlı vardiya sistemi'),
          ),
        for (final definition in _shiftDefinitions)
          DropdownMenuItem(
            value: definition.id,
            child: Text(
              '${definition.name} (${definition.slots.map((e) => e.label).join(' - ')})',
              overflow: TextOverflow.ellipsis,
            ),
          ),
      ],
      onChanged: _loadingShifts
          ? null
          : (id) {
              final selectedId = id ?? '';
              if (selectedId.isEmpty) {
                setState(() => _shiftDefinitionId = '');
                return;
              }
              final definition = _shiftDefinitions.firstWhere(
                (item) => item.id == selectedId,
              );
              final sequence = definition.slots
                  .map((slot) => slot.label)
                  .toList();
              final selectedWorkType = _workTypeForDefinition(definition);
              setState(() {
                _shiftDefinitionId = selectedId;
                _workType = selectedWorkType;
                _editingWorkType = selectedWorkType;
                _shiftDirection =
                    definition.changeDirection == ShiftDefinition.forward
                    ? Personnel.shiftForward
                    : Personnel.shiftBackward;
                _shiftSystem = '${sequence.length} Vardiya';
                _editingShiftSystem = _shiftSystem;
                _shiftPattern = '';
                if (!sequence.contains(_shift)) {
                  _shift = sequence.isEmpty ? '' : sequence.first;
                }
                if (_leaveMode.isEmpty) {
                  _leaveMode = Personnel.weeklyLeaveMode;
                }
                if (_customServiceParticipationEnabled) {
                  _fixedServiceWeekdays.clear();
                  _serviceEntryTimesByWeekday.clear();
                  _serviceExitTimesByWeekday.clear();
                }
              });
            },
    );
  }

  List<Widget> _buildCustomShiftFields() {
    final definition = _selectedShiftDefinition;
    if (definition == null) return const [];
    final sequence = definition.slots.map((slot) => slot.label).toList();
    return [
      DropdownButtonFormField<String>(
        initialValue: sequence.contains(_shift) ? _shift : null,
        decoration: const InputDecoration(
          labelText: 'Mevcut Vardiyası',
          prefixIcon: Icon(Icons.access_time_rounded),
          border: OutlineInputBorder(),
        ),
        items: [
          for (final shift in sequence)
            DropdownMenuItem(value: shift, child: Text(shift)),
        ],
        onChanged: (value) {
          if (value != null) {
            setState(() {
              _shift = value;
              _shiftSelectionTouched = true;
            });
          }
        },
      ),
      const SizedBox(height: 16),
      if (definition.changeDirection != ShiftDefinition.fixed) ...[
        InputDecorator(
          decoration: const InputDecoration(
            labelText: 'Vardiya Hesaplama',
            border: OutlineInputBorder(),
          ),
          child: SegmentedButton<String>(
            expandedInsets: EdgeInsets.zero,
            showSelectedIcon: false,
            segments: const [
              ButtonSegment(
                value: Personnel.weeklyLeaveMode,
                label: Text('İzin Günü ile'),
              ),
              ButtonSegment(
                value: Personnel.cycleLeaveMode,
                label: Text('Çalışma Günü ile'),
              ),
            ],
            selected: {_leaveMode},
            onSelectionChanged: (selection) {
              setState(() {
                _leaveMode = selection.first;
                if (_leaveMode == Personnel.weeklyLeaveMode) {
                  _workDaysCount = 0;
                  _leaveDaysCount = 0;
                } else {
                  _leaveWeekdays.clear();
                }
              });
            },
          ),
        ),
        const SizedBox(height: 16),
        if (_leaveMode == Personnel.weeklyLeaveMode)
          _weekdaySelector()
        else
          ..._cycleSelectors(),
        const SizedBox(height: 12),
      ],
      InputDecorator(
        decoration: const InputDecoration(
          labelText: 'Vardiya Değişim Kuralı',
          border: OutlineInputBorder(),
        ),
        child: Text(
          definition.directionLabel,
          style: const TextStyle(fontWeight: FontWeight.w700),
        ),
      ),
      const SizedBox(height: 16),
    ];
  }

  Future<void> _loadInstitutions() async {
    final institutions = await InstitutionStorage.readAll();
    if (!mounted) return;
    Institution? selected;
    for (final institution in institutions) {
      if (institution.id == widget.personnel?.institutionId) {
        selected = institution;
        break;
      }
    }
    setState(() {
      _institutions = institutions;
      _selectedInstitution = selected;
      _selectedInstitutionPath = selected == null
          ? []
          : _institutionPath(institutions, selected);
      _loadingInstitutions = false;
    });
  }

  List<Institution> _institutionPath(
    List<Institution> institutions,
    Institution institution,
  ) {
    final byId = {for (final item in institutions) item.id: item};
    final path = <Institution>[institution];
    var parentId = institution.parentId;
    final visited = <String>{institution.id};
    while (parentId != null && parentId.isNotEmpty && visited.add(parentId)) {
      final parent = byId[parentId];
      if (parent == null) break;
      path.insert(0, parent);
      parentId = parent.parentId;
    }
    return path;
  }

  List<Widget> _buildInstitutionSelectors() {
    if (_loadingInstitutions) return const [LinearProgressIndicator()];
    final roots = Institution.childrenOf(_institutions, null)
        .where(
          (item) =>
              item.active ||
              _selectedInstitutionPath.any(
                (selected) => selected.id == item.id,
              ),
        )
        .toList();
    if (roots.isEmpty) {
      return const [
        Padding(
          padding: EdgeInsets.only(bottom: 16),
          child: Text(
            'Önce Ayarlar > Kurumlar bölümünden kurum ekleyin.',
            style: TextStyle(color: Color(0xFFB3261E)),
          ),
        ),
      ];
    }

    final widgets = <Widget>[
      DropdownButtonFormField<String>(
        initialValue: _selectedInstitutionPath.isEmpty
            ? null
            : _selectedInstitutionPath.first.id,
        isExpanded: true,
        decoration: const InputDecoration(
          labelText: 'Çalıştığı Kurum',
          prefixIcon: Icon(Icons.domain_rounded),
          border: OutlineInputBorder(),
        ),
        items: roots
            .map(
              (institution) => DropdownMenuItem(
                value: institution.id,
                child: Text(
                  '${institution.name} (${institution.type})',
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            )
            .toList(),
        onChanged: (id) {
          if (id == null) return;
          final selected = roots.firstWhere((item) => item.id == id);
          setState(() {
            _selectedInstitutionPath = [selected];
            _selectedInstitution = selected;
          });
        },
        validator: (_) => _selectedInstitutionPath.isEmpty
            ? 'Personelin çalıştığı kurumu seçin.'
            : null,
      ),
      const SizedBox(height: 12),
    ];

    if (_selectedInstitutionPath.isEmpty) return widgets;
    var parent = _selectedInstitutionPath.first;
    var depth = 1;
    while (true) {
      final children = Institution.childrenOf(_institutions, parent.id)
          .where(
            (item) =>
                item.active ||
                _selectedInstitutionPath.any(
                  (selected) => selected.id == item.id,
                ),
          )
          .toList();
      if (children.isEmpty) break;
      final selectedChild = _selectedInstitutionPath.length > depth
          ? _selectedInstitutionPath[depth]
          : null;
      final level = depth;
      final currentParent = parent;
      widgets.add(
        DropdownButtonFormField<String>(
          initialValue: selectedChild?.id ?? '',
          isExpanded: true,
          decoration: InputDecoration(
            labelText: switch (depth) {
              1 => 'Çalışma Şekli',
              2 => 'Bölge',
              3 => 'Takım (isteğe bağlı)',
              _ => 'Alt Kayıt $depth',
            },
            prefixIcon: const Icon(Icons.account_tree_outlined),
            border: const OutlineInputBorder(),
          ),
          items: [
            DropdownMenuItem(
              value: '',
              child: Text(
                depth == 3
                    ? 'Takım seçilmedi'
                    : '${currentParent.name} kaydının kendisi',
                overflow: TextOverflow.ellipsis,
              ),
            ),
            for (final child in children)
              DropdownMenuItem(
                value: child.id,
                child: Text(child.name, overflow: TextOverflow.ellipsis),
              ),
          ],
          onChanged: (id) {
            final prefix = _selectedInstitutionPath.take(level).toList();
            if (id == null || id.isEmpty) {
              setState(() {
                _selectedInstitutionPath = prefix;
                _selectedInstitution = prefix.last;
              });
              return;
            }
            final child = children.firstWhere((item) => item.id == id);
            setState(() {
              _selectedInstitutionPath = [...prefix, child];
              _selectedInstitution = child;
            });
          },
        ),
      );
      widgets.add(const SizedBox(height: 12));
      if (selectedChild == null) break;
      parent = selectedChild;
      depth++;
    }
    // Bölgenin altında henüz takım oluşturulmamış olsa da takım alanını
    // görünür tutar. Takım seçimi isteğe bağlıdır.
    if (_selectedInstitutionPath.length == 3) {
      final region = _selectedInstitutionPath[2];
      final groups = Institution.childrenOf(
        _institutions,
        region.id,
      ).where((item) => item.active).toList();
      if (groups.isEmpty) {
        widgets.add(
          DropdownButtonFormField<String>(
            initialValue: '',
            isExpanded: true,
            decoration: const InputDecoration(
              labelText: 'Takım (isteğe bağlı)',
              prefixIcon: Icon(Icons.groups_2_outlined),
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: '', child: Text('Takım seçilmedi')),
            ],
            onChanged: null,
          ),
        );
        widgets.add(const SizedBox(height: 12));
      }
    }
    return widgets;
  }

  List<Institution> _regionsFor(Institution root) {
    return Institution.childrenOf(
      _institutions,
      root.id,
    ).where((item) => item.active).toList();
  }

  List<Widget> _buildSimpleInstitutionSelectors() {
    if (_loadingInstitutions) return const [LinearProgressIndicator()];
    final roots = Institution.childrenOf(
      _institutions,
      null,
    ).where((item) => item.active).toList();
    if (roots.isEmpty) return _buildInstitutionSelectors();

    final selectedRoot = _selectedInstitutionPath.isEmpty
        ? null
        : _selectedInstitutionPath.first;
    final regions = selectedRoot == null
        ? const <Institution>[]
        : _regionsFor(selectedRoot);
    Institution? selectedRegion;
    for (final item in _selectedInstitutionPath.skip(1)) {
      if (regions.any((region) => region.id == item.id)) selectedRegion = item;
    }
    final groups = selectedRegion == null
        ? const <Institution>[]
        : Institution.childrenOf(
            _institutions,
            selectedRegion.id,
          ).where((item) => item.active).toList();
    Institution? selectedGroup;
    for (final item in _selectedInstitutionPath) {
      if (groups.any((group) => group.id == item.id)) selectedGroup = item;
    }

    return [
      DropdownButtonFormField<String>(
        initialValue: selectedRoot?.id,
        isExpanded: true,
        decoration: const InputDecoration(
          labelText: 'Kurum',
          prefixIcon: Icon(Icons.domain_rounded),
          border: OutlineInputBorder(),
        ),
        items: [
          for (final root in roots)
            DropdownMenuItem(value: root.id, child: Text(root.name)),
        ],
        onChanged: (id) {
          if (id == null) return;
          final root = roots.firstWhere((item) => item.id == id);
          setState(() {
            _selectedInstitutionPath = [root];
            _selectedInstitution = root;
          });
        },
        validator: (_) => selectedRoot == null ? 'Kurum seçin.' : null,
      ),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(
        key: ValueKey(
          'simple-region-${selectedRoot?.id}-${selectedRegion?.id}',
        ),
        initialValue: selectedRegion?.id,
        isExpanded: true,
        decoration: const InputDecoration(
          labelText: 'Bölge',
          prefixIcon: Icon(Icons.map_outlined),
          border: OutlineInputBorder(),
        ),
        items: [
          for (final region in regions)
            DropdownMenuItem(value: region.id, child: Text(region.name)),
        ],
        onChanged: selectedRoot == null
            ? null
            : (id) {
                if (id == null) return;
                final region = regions.firstWhere((item) => item.id == id);
                setState(() {
                  _selectedInstitutionPath = _institutionPath(
                    _institutions,
                    region,
                  );
                  _selectedInstitution = region;
                });
              },
        validator: (_) => selectedRegion == null ? 'Bölge seçin.' : null,
      ),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(
        key: ValueKey(
          'simple-group-${selectedRegion?.id}-${selectedGroup?.id}',
        ),
        initialValue: selectedGroup?.id ?? '',
        isExpanded: true,
        decoration: const InputDecoration(
          labelText: 'Takım (isteğe bağlı)',
          prefixIcon: Icon(Icons.groups_2_outlined),
          border: OutlineInputBorder(),
        ),
        items: [
          const DropdownMenuItem(value: '', child: Text('Takım seçilmedi')),
          for (final group in groups)
            DropdownMenuItem(value: group.id, child: Text(group.name)),
        ],
        onChanged: selectedRegion == null
            ? null
            : (id) {
                setState(() {
                  if (id == null || id.isEmpty) {
                    _selectedInstitutionPath = _institutionPath(
                      _institutions,
                      selectedRegion!,
                    );
                    _selectedInstitution = selectedRegion;
                  } else {
                    final group = groups.firstWhere((item) => item.id == id);
                    _selectedInstitutionPath = _institutionPath(
                      _institutions,
                      group,
                    );
                    _selectedInstitution = group;
                  }
                });
              },
      ),
      const SizedBox(height: 12),
    ];
  }

  Future<void> _loadStops() async {
    final stops = await StopStorage.readAll();
    if (!mounted) return;
    Stop? selected;
    for (final stop in stops) {
      if (stop.name == _stopController.text &&
          stop.order == int.tryParse(_stopOrderController.text)) {
        selected = stop;
        break;
      }
    }
    setState(() {
      _stops = stops;
      _selectedStop = selected;
      _loadingStops = false;
    });
  }

  void _selectStop(Stop? stop) {
    if (stop == null) return;
    setState(() {
      _selectedStop = stop;
      _stopController.text = stop.name;
      _stopOrderController.text = stop.order.toString();
      _stopLatitude = stop.latitude;
      _stopLongitude = stop.longitude;
    });
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _whatsAppController.dispose();
    _stopController.dispose();
    _stopOrderController.dispose();
    _noteController.dispose();
    super.dispose();
  }

  Future<bool> _confirmWorkTypeChange() async {
    if (_editingWorkType == _workType) return true;
    final target = _editingWorkType;
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Çalışma şekli değiştirilsin mi?'),
        content: Text(
          'Personelin ${Personnel.rotatingWorkType}, ${Personnel.fixedWorkType}, '
          '${Personnel.reliefWorkType} veya ${Personnel.guestWorkType} '
          'düzenindeki mevcut bilgileri '
          'değişecektir.\n\n'
          'Çalışma şeklini “$target” olarak değiştirmek istiyor musunuz?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('EVET, DEĞİŞTİR'),
          ),
        ],
      ),
    );
    if (!mounted) return false;
    if (approved != true) {
      setState(() => _editingWorkType = _workType);
      return false;
    }
    setState(() {
      _workType = target;
      _shift = '';
      _shiftSystem = '';
      _editingShiftSystem = '';
      _shiftPattern = '';
      _leaveMode = '';
      _workDaysCount = 0;
      _leaveDaysCount = 0;
      _leaveWeekdays.clear();
      _reliefWeeklyShifts.clear();
      _reliefMonthlyShifts.clear();
      _shiftDirection = Personnel.shiftBackward;
    });
    return true;
  }

  Future<bool> _confirmShiftSystemChange() async {
    if (_editingShiftSystem == _shiftSystem) return true;
    final target = _editingShiftSystem;
    if (_shiftSystem.isEmpty) {
      setState(() => _shiftSystem = target);
      return true;
    }
    final approved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Vardiya sistemi değiştirilsin mi?'),
        content: Text(
          'Mevcut $_shiftSystem bilgileri temizlenecektir.\n\n'
          'Personeli $target sistemine geçirmek istiyor musunuz?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('VAZGEÇ'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('EVET, DEĞİŞTİR'),
          ),
        ],
      ),
    );
    if (!mounted) return false;
    if (approved != true) {
      setState(() => _editingShiftSystem = _shiftSystem);
      return false;
    }
    setState(() {
      _shiftSystem = target;
      _shiftPattern = '';
      _shift = '';
      _leaveMode = '';
      _leaveWeekdays.clear();
      _workDaysCount = 0;
      _leaveDaysCount = 0;
    });
    return true;
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;
    if (_editingWorkType != _workType ||
        (_workType == Personnel.rotatingWorkType &&
            _editingShiftSystem != _shiftSystem)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Yeni seçime bilgi girin veya önceki seçeneğe geri dönün.',
          ),
        ),
      );
      return;
    }
    if (_selectedStop == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Önce listeden bir durak seçin.')),
      );
      return;
    }
    if (_selectedInstitution == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Personelin çalıştığı kurumu seçin.')),
      );
      return;
    }
    if (_workType == Personnel.rotatingWorkType) {
      if ((_shiftDefinitionId.isEmpty &&
              (_shiftSystem.isEmpty || _shiftPattern.isEmpty)) ||
          _shift.isEmpty ||
          _leaveMode.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Vardiya seçeneklerinin tamamını seçin.'),
          ),
        );
        return;
      }
      if (_leaveMode == Personnel.weeklyLeaveMode && _leaveWeekdays.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('En az bir izin günü seçin.')),
        );
        return;
      }
      if (_leaveMode == Personnel.cycleLeaveMode &&
          (_workDaysCount < 1 || _leaveDaysCount < 1)) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Çalışılacak gün ve izinli gün sayısını seçin.'),
          ),
        );
        return;
      }
    }
    if (_workType == Personnel.reliefWorkType &&
        !_reliefMonthlyShifts.values.any((shifts) => shifts.isNotEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Dinlendirici için en az bir gün ve vardiya seçin.'),
        ),
      );
      return;
    }
    final phone = _phoneController.text.trim();
    final oldPerson = widget.personnel;
    final orderedLeaveDays = _leaveWeekdays.toList()..sort();
    final orderedFixedDays = _fixedServiceWeekdays.toList()..sort();
    final orderedFixedShifts = _fixedServiceShifts.toList()..sort();
    final orderedEntryTimes = _serviceEntryTimes.toList()..sort();
    final orderedExitTimes = _serviceExitTimes.toList()..sort();
    final orderedEntryTimesByDay = <int, List<String>>{
      for (final entry in _serviceEntryTimesByWeekday.entries)
        entry.key: (entry.value.toList()..sort()),
    };
    final orderedExitTimesByDay = <int, List<String>>{
      for (final entry in _serviceExitTimesByWeekday.entries)
        entry.key: (entry.value.toList()..sort()),
    };
    final scheduleChanged =
        oldPerson == null ||
        _shiftSelectionTouched ||
        oldPerson.workType != _workType ||
        oldPerson.leaveMode != _leaveMode ||
        oldPerson.workDaysCount != _workDaysCount ||
        oldPerson.leaveDaysCount != _leaveDaysCount ||
        oldPerson.shiftDirection != _shiftDirection ||
        oldPerson.shiftSystem != _shiftSystem ||
        oldPerson.shiftPattern != _shiftPattern ||
        oldPerson.shiftDefinitionId != _shiftDefinitionId ||
        !_sameMonthlyReliefSchedule(
          oldPerson.reliefMonthlyShifts,
          _reliefMonthlyShifts,
        ) ||
        oldPerson.cycleDay != _cycleDay ||
        !_sameDays(oldPerson.leaveWeekdays, orderedLeaveDays);
    Navigator.of(context).pop(
      Personnel(
        id:
            widget.personnel?.id ??
            DateTime.now().microsecondsSinceEpoch.toString(),
        fullName: _nameController.text.trim(),
        phone: phone,
        whatsApp: _whatsAppController.text.trim().isEmpty
            ? phone
            : _whatsAppController.text.trim(),
        stopName: _stopController.text.trim(),
        stopOrder: int.parse(_stopOrderController.text),
        shift: oldPerson != null && !scheduleChanged ? oldPerson.shift : _shift,
        workType: _workType,
        leaveWeekdays: orderedLeaveDays,
        leaveMode:
            _workType == Personnel.fixedWorkType ||
                _workType == Personnel.guestWorkType
            ? Personnel.weeklyLeaveMode
            : _leaveMode,
        workDaysCount: _workDaysCount,
        leaveDaysCount: _leaveDaysCount,
        shiftDirection: _shiftDirection,
        shiftSystem: _shiftSystem,
        shiftPattern: _shiftPattern,
        shiftDefinitionId: _shiftDefinitionId,
        customShiftSequence: _shiftDefinitionId.isEmpty
            ? const []
            : _selectedShiftDefinition?.slots
                      .map((slot) => slot.label)
                      .toList() ??
                  const [],
        reliefWeeklyShifts: const {},
        reliefMonthlyShifts: {
          for (final entry in _reliefMonthlyShifts.entries)
            if (entry.value.isNotEmpty) entry.key: entry.value.toList(),
        },
        fixedServiceWeekdays: orderedFixedDays,
        fixedServiceShifts: orderedFixedShifts,
        serviceEntryTimes: orderedEntryTimes,
        serviceExitTimes: orderedExitTimes,
        serviceEntryTimesByWeekday: orderedEntryTimesByDay,
        serviceExitTimesByWeekday: orderedExitTimesByDay,
        customServiceParticipationEnabled: _customServiceParticipationEnabled,
        institutionId: _selectedInstitution!.id,
        institutionName: Institution.pathLabel(
          _institutions,
          _selectedInstitution!,
        ),
        referenceDate: scheduleChanged
            ? _dateToIso(DateTime.now())
            : oldPerson.referenceDate,
        cycleDay: _cycleDay,
        stopLatitude: _stopLatitude,
        stopLongitude: _stopLongitude,
        note: _noteController.text.trim(),
      ),
    );
  }

  bool _sameDays(List<int> first, List<int> second) {
    if (first.length != second.length) return false;
    final firstSorted = [...first]..sort();
    final secondSorted = [...second]..sort();
    for (var index = 0; index < firstSorted.length; index++) {
      if (firstSorted[index] != secondSorted[index]) return false;
    }
    return true;
  }

  bool _sameMonthlyReliefSchedule(
    Map<String, List<String>> saved,
    Map<String, Set<String>> edited,
  ) {
    final keys = {...saved.keys, ...edited.keys};
    for (final key in keys) {
      final first = (saved[key] ?? const <String>[]).toSet();
      final second = edited[key] ?? <String>{};
      if (first.length != second.length || !first.containsAll(second)) {
        return false;
      }
    }
    return true;
  }

  Future<bool> _captureCurrentLocation() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Telefonun konum hizmetini açın.')),
        );
      }
      return false;
    }

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Konum izni verilmedi.')));
      }
      return false;
    }

    setState(() => _gettingLocation = true);
    try {
      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      if (!mounted) return false;
      setState(() {
        _stopLatitude = position.latitude;
        _stopLongitude = position.longitude;
      });
      return true;
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Konum alınamadı. Tekrar deneyin.')),
        );
      }
      return false;
    } finally {
      if (mounted) setState(() => _gettingLocation = false);
    }
  }

  Future<void> _chooseLocationOnMap() async {
    if (_stopLatitude == null || _stopLongitude == null) {
      final hasLocation = await _captureCurrentLocation();
      if (!hasLocation || _stopLatitude == null || _stopLongitude == null)
        return;
    }

    if (!mounted) return;
    final currentLocation = LatLng(_stopLatitude!, _stopLongitude!);
    final selected = await Navigator.of(context).push<LatLng>(
      MaterialPageRoute(
        builder: (_) => MapPickerScreen(
          initialLocation: currentLocation,
          selectedLocation: currentLocation,
        ),
      ),
    );
    if (selected == null || !mounted) return;
    setState(() {
      _stopLatitude = selected.latitude;
      _stopLongitude = selected.longitude;
    });
  }

  String _dateToIso(DateTime date) {
    final year = date.year.toString().padLeft(4, '0');
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '$year-$month-$day';
  }

  Future<void> _pickFromContacts() async {
    try {
      final permission = await FlutterContacts.permissions.request(
        PermissionType.read,
      );
      if (permission != PermissionStatus.granted) {
        if (!mounted) return;
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Rehber izni verilmedi.')));
        return;
      }

      final contact = await FlutterContacts.native.showPicker(
        properties: {ContactProperty.phone},
      );
      if (contact == null) return;

      final displayName = contact.displayName?.trim();
      if (displayName != null && displayName.isNotEmpty) {
        _nameController.text = displayName;
      }
      if (contact.phones.isNotEmpty) {
        final number = contact.phones.first.number;
        _phoneController.text = number;
        _whatsAppController.text = number;
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Rehber açılırken bir sorun oluştu. Tekrar deneyin.'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.personnel == null ? 'Personel Ekle' : 'Personel Düzenle',
        ),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const Text(
                'Personel bilgilerini girin.',
                style: TextStyle(color: Color(0xFF52657B)),
              ),
              const SizedBox(height: 14),
              OutlinedButton.icon(
                onPressed: _pickFromContacts,
                icon: const Icon(Icons.contact_phone_outlined),
                label: const Text('REHBERDEN KİŞİ SEÇ'),
              ),
              const SizedBox(height: 20),
              _field(
                controller: _nameController,
                label: 'Ad Soyad',
                icon: Icons.person_outline_rounded,
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Ad soyad girin.'
                    : null,
              ),
              _field(
                controller: _phoneController,
                label: 'Telefon Numarası',
                icon: Icons.phone_outlined,
                keyboardType: TextInputType.phone,
                validator: (value) => value == null || value.trim().isEmpty
                    ? 'Telefon numarası girin.'
                    : null,
              ),
              _field(
                controller: _whatsAppController,
                label: 'WhatsApp Numarası (isteğe bağlı)',
                icon: Icons.chat_outlined,
                keyboardType: TextInputType.phone,
              ),
              ..._buildSimpleInstitutionSelectors(),
              _shiftDefinitionSelector(),
              const SizedBox(height: 16),
              DropdownButtonFormField<Stop>(
                value: _selectedStop,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Durak Seç',
                  prefixIcon: Icon(Icons.location_on_outlined),
                  border: OutlineInputBorder(),
                ),
                items: _stops
                    .map(
                      (stop) => DropdownMenuItem(
                        value: stop,
                        child: Text('${stop.order}. ${stop.name}'),
                      ),
                    )
                    .toList(),
                onChanged: _loadingStops ? null : _selectStop,
                validator: (value) => value == null ? 'Durak seçin.' : null,
              ),
              const SizedBox(height: 8),
              if (_loadingStops)
                const LinearProgressIndicator()
              else if (_stops.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(bottom: 16),
                  child: Text(
                    'Önce ana menüdeki Duraklar bölümünden durak ekleyin.',
                    style: TextStyle(color: Color(0xFFB3261E)),
                  ),
                )
              else if (_selectedStop != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Text(
                    'Konum: ${_selectedStop!.latitude.toStringAsFixed(5)}, ${_selectedStop!.longitude.toStringAsFixed(5)}',
                    style: const TextStyle(
                      color: Color(0xFF0B6E4F),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              if (_shiftDefinitionId.isNotEmpty &&
                  _editingWorkType != Personnel.reliefWorkType)
                ..._buildCustomShiftFields(),
              if (_editingWorkType == Personnel.reliefWorkType)
                ..._buildReliefScheduleFields(),
              if (_shiftDefinitionId.isEmpty &&
                  _editingWorkType == Personnel.guestWorkType)
                const Padding(
                  padding: EdgeInsets.only(top: 4, bottom: 16),
                  child: Text(
                    'Misafir için vardiya bilgisi gerekmez. Yolcu Ekle '
                    'bölümünden istenen tarih ve vardiyaya eklenir.',
                    style: TextStyle(
                      color: Color(0xFF52657B),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              if (_workType == '__legacy_relief__') ...[
                InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'İzin Düzeni',
                    border: OutlineInputBorder(),
                  ),
                  child: SegmentedButton<String>(
                    expandedInsets: EdgeInsets.zero,
                    showSelectedIcon: false,
                    segments: const [
                      ButtonSegment(
                        value: Personnel.weeklyLeaveMode,
                        label: Text(
                          'İzin Günü\nİşaretle',
                          textAlign: TextAlign.center,
                        ),
                      ),
                      ButtonSegment(
                        value: Personnel.cycleLeaveMode,
                        label: Text(
                          'Vardiya Dönme\nAralığı',
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                    selected: {_leaveMode},
                    onSelectionChanged: (selection) =>
                        setState(() => _leaveMode = selection.first),
                  ),
                ),
                const SizedBox(height: 16),
              ],
              if (_editingWorkType == Personnel.fixedWorkType)
                InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'İzinli Günler',
                    prefixIcon: Icon(Icons.event_busy_rounded),
                    border: OutlineInputBorder(),
                  ),
                  child: Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final day in const [
                        (1, 'Pzt'),
                        (2, 'Sal'),
                        (3, 'Çar'),
                        (4, 'Per'),
                        (5, 'Cum'),
                        (6, 'Cmt'),
                        (7, 'Paz'),
                      ])
                        FilterChip(
                          label: Text(day.$2),
                          selected:
                              _editingWorkType == _workType &&
                              _leaveWeekdays.contains(day.$1),
                          onSelected: (selected) async {
                            if (!await _confirmWorkTypeChange()) return;
                            if (!mounted) return;
                            setState(() {
                              if (selected) {
                                _leaveWeekdays.add(day.$1);
                              } else {
                                _leaveWeekdays.remove(day.$1);
                              }
                            });
                          },
                        ),
                    ],
                  ),
                ),
              if (_workType == '__legacy_relief__' &&
                  _leaveMode == Personnel.cycleLeaveMode)
                Column(
                  children: [
                    DropdownButtonFormField<int>(
                      initialValue: _workDaysCount,
                      decoration: const InputDecoration(
                        labelText: 'Çalışılacak Gün Sayısı',
                        prefixIcon: Icon(Icons.work_history_rounded),
                        border: OutlineInputBorder(),
                      ),
                      items: [
                        for (var day = 1; day <= 6; day++)
                          DropdownMenuItem(value: day, child: Text('$day gün')),
                      ],
                      onChanged: (value) {
                        if (value != null) {
                          setState(() => _workDaysCount = value);
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<int>(
                      initialValue: _leaveDaysCount,
                      decoration: const InputDecoration(
                        labelText: 'İzinli Gün Sayısı',
                        prefixIcon: Icon(Icons.event_busy_rounded),
                        border: OutlineInputBorder(),
                      ),
                      items: [
                        for (var day = 1; day <= 7; day++)
                          DropdownMenuItem(value: day, child: Text('$day gün')),
                      ],
                      onChanged: (value) {
                        if (value != null) {
                          setState(() => _leaveDaysCount = value);
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      initialValue: _shiftDirection,
                      decoration: const InputDecoration(
                        labelText: 'Vardiya Değişim Yönü',
                        prefixIcon: Icon(Icons.sync_alt_rounded),
                        border: OutlineInputBorder(),
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: Personnel.shiftBackward,
                          child: Text('Vardiya 8 saat geri gidecek'),
                        ),
                        DropdownMenuItem(
                          value: Personnel.shiftForward,
                          child: Text('Vardiya 8 saat ileri gidecek'),
                        ),
                      ],
                      onChanged: (value) {
                        if (value != null) {
                          setState(() => _shiftDirection = value);
                        }
                      },
                    ),
                  ],
                ),
              if (_editingWorkType != Personnel.guestWorkType &&
                  (_workType == Personnel.fixedWorkType ||
                      _leaveMode == Personnel.cycleLeaveMode))
                Padding(
                  padding: const EdgeInsets.only(top: 6, bottom: 16),
                  child: Text(
                    _workType == Personnel.fixedWorkType
                        ? 'İzin günlerinde görünmez; sonrasında aynı vardiyada kalır.'
                        : 'Kayıt günü 1. çalışma günü kabul edilir. Çalışma ve izin aralığı sürekli tekrarlanır.',
                    style: const TextStyle(color: Color(0xFF52657B)),
                  ),
                ),
              if (_editingWorkType == Personnel.fixedWorkType)
                DropdownButtonFormField<String>(
                  value:
                      _editingWorkType == _workType && _shifts.contains(_shift)
                      ? _shift
                      : null,
                  decoration: const InputDecoration(
                    labelText: 'Vardiya',
                    prefixIcon: Icon(Icons.schedule_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: _shifts
                      .map(
                        (shift) => DropdownMenuItem(
                          value: shift,
                          child: Text(
                            shift == ShiftCalculator.idleShift
                                ? '-- / -- (Boşta)'
                                : shift,
                          ),
                        ),
                      )
                      .toList(),
                  onChanged: _loadingShifts
                      ? null
                      : (value) async {
                          if (value == null) return;
                          if (!await _confirmWorkTypeChange()) return;
                          if (!mounted) return;
                          setState(() {
                            _shift = value;
                            _shiftSelectionTouched = true;
                          });
                        },
                  validator: (value) =>
                      value == null ? 'Önce bir vardiya seçin.' : null,
                ),
              if (_loadingShifts) const LinearProgressIndicator(),
              const SizedBox(height: 16),
              if (_editingWorkType != Personnel.guestWorkType) ...[
                _buildServiceParticipationSection(),
                const SizedBox(height: 16),
              ],
              _field(
                controller: _noteController,
                label: 'Not (isteğe bağlı)',
                icon: Icons.note_alt_outlined,
                maxLines: 3,
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 54,
                child: FilledButton.icon(
                  onPressed: _save,
                  icon: const Icon(Icons.save_rounded),
                  label: Text(
                    widget.personnel == null
                        ? 'PERSONELİ KAYDET'
                        : 'DEĞİŞİKLİKLERİ KAYDET',
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildServiceParticipationSection() {
    return Card(
      margin: EdgeInsets.zero,
      color: const Color(0xFFF4F7FB),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            CheckboxListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 4),
              controlAffinity: ListTileControlAffinity.leading,
              title: const Text(
                'Özel Servise Katılım Kuralı',
                style: TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: const Text(
                'Altındaki günlerden en az biri seçilirse gün ve saat '
                'seçimleri önceliklidir. Sabit personel servise yalnızca '
                'bu seçimlerle katılır.',
              ),
              value: _customServiceParticipationEnabled,
              onChanged: (value) => setState(() {
                _customServiceParticipationEnabled = value == true;
                _fixedServiceWeekdays.clear();
                _fixedServiceShifts.clear();
                _serviceEntryTimes.clear();
                _serviceExitTimes.clear();
                _serviceEntryTimesByWeekday.clear();
                _serviceExitTimesByWeekday.clear();
              }),
            ),
            if (_customServiceParticipationEnabled) ...[
              const SizedBox(height: 4),
              _buildServiceParticipationTable(),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildServiceParticipationTable() {
    const weekdays = [
      (1, 'PAZARTESİ'),
      (2, 'SALI'),
      (3, 'ÇARŞAMBA'),
      (4, 'PERŞEMBE'),
      (5, 'CUMA'),
      (6, 'CUMARTESİ'),
      (7, 'PAZAR'),
    ];
    final entryTimes = <String>{};
    final exitTimes = <String>{};
    for (final shift in _availableParticipationShifts()) {
      final parts = _shiftParts(shift);
      if (parts != null) {
        entryTimes.add(parts.$1);
        exitTimes.add(parts.$2);
      }
    }
    return Card(
      margin: EdgeInsets.zero,
      color: const Color(0xFFFFFFFF),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Gün ve Saat Seçimleri',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
            ),
            const SizedBox(height: 4),
            const Text(
              'Her gün için kullanılacak giriş ve çıkış servislerini seçin.',
              style: TextStyle(color: Color(0xFF52657B)),
            ),
            const SizedBox(height: 10),
            for (final day in weekdays)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: const Color(0xFFD5DEEA)),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CheckboxListTile(
                      contentPadding: EdgeInsets.zero,
                      dense: true,
                      controlAffinity: ListTileControlAffinity.leading,
                      title: Text(
                        day.$2,
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      value: _fixedServiceWeekdays.contains(day.$1),
                      onChanged: (selected) => setState(() {
                        if (selected == true) {
                          _fixedServiceWeekdays.add(day.$1);
                          _serviceEntryTimesByWeekday.putIfAbsent(
                            day.$1,
                            () => <String>{},
                          );
                          _serviceExitTimesByWeekday.putIfAbsent(
                            day.$1,
                            () => <String>{},
                          );
                        } else {
                          _fixedServiceWeekdays.remove(day.$1);
                        }
                      }),
                    ),
                    _weekdayTimeRow(
                      label: 'Girişler',
                      day: day.$1,
                      times: entryTimes,
                      selections: _serviceEntryTimesByWeekday,
                    ),
                    const SizedBox(height: 5),
                    _weekdayTimeRow(
                      label: 'Çıkışlar',
                      day: day.$1,
                      times: exitTimes,
                      selections: _serviceExitTimesByWeekday,
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _weekdayTimeRow({
    required String label,
    required int day,
    required Set<String> times,
    required Map<int, Set<String>> selections,
  }) {
    final enabled = _fixedServiceWeekdays.contains(day);
    final selectedTimes = selections.putIfAbsent(day, () => <String>{});
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 58,
          child: Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(label, style: const TextStyle(fontSize: 12)),
          ),
        ),
        Expanded(
          child: Wrap(
            spacing: 4,
            runSpacing: 4,
            children: [
              for (final time in times)
                FilterChip(
                  visualDensity: VisualDensity.compact,
                  label: Text(time),
                  selected: enabled && selectedTimes.contains(time),
                  onSelected: enabled
                      ? (selected) => setState(() {
                          selected
                              ? selectedTimes.add(time)
                              : selectedTimes.remove(time);
                        })
                      : null,
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildServiceParticipationRule() {
    const weekdays = [
      (1, 'Pzt'),
      (2, 'Sal'),
      (3, 'Çar'),
      (4, 'Per'),
      (5, 'Cum'),
      (6, 'Cmt'),
      (7, 'Paz'),
    ];
    final availableShifts = _availableParticipationShifts();
    final entryTimes = <String>{};
    final exitTimes = <String>{};
    for (final shift in availableShifts) {
      final parts = _shiftParts(shift);
      if (parts != null) {
        entryTimes.add(parts.$1);
        exitTimes.add(parts.$2);
      }
    }
    return Card(
      margin: EdgeInsets.zero,
      color: const Color(0xFFF4F7FB),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Personel Servise Katılım Kuralı',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16),
            ),
            const SizedBox(height: 4),
            const Text(
              'Servisi kullanacağı günleri ve vardiya saatlerini seçin.',
              style: TextStyle(color: Color(0xFF52657B)),
            ),
            const SizedBox(height: 12),
            const Text('Günler', style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final day in weekdays)
                  FilterChip(
                    label: Text(day.$2),
                    selected: _fixedServiceWeekdays.contains(day.$1),
                    onSelected: (selected) => setState(() {
                      selected
                          ? _fixedServiceWeekdays.add(day.$1)
                          : _fixedServiceWeekdays.remove(day.$1);
                    }),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            const Text(
              'Vardiya Giriş Saatleri',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final time in entryTimes)
                  FilterChip(
                    label: Text(time),
                    selected: _serviceEntryTimes.contains(time),
                    onSelected: (selected) => setState(() {
                      selected
                          ? _serviceEntryTimes.add(time)
                          : _serviceEntryTimes.remove(time);
                    }),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            const Text(
              'Vardiya Çıkış Saatleri',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final time in exitTimes)
                  FilterChip(
                    label: Text(time),
                    selected: _serviceExitTimes.contains(time),
                    onSelected: (selected) => setState(() {
                      selected
                          ? _serviceExitTimes.add(time)
                          : _serviceExitTimes.remove(time);
                    }),
                  ),
              ],
            ),
            if (_fixedServiceWeekdays.isEmpty ||
                _serviceEntryTimes.isEmpty ||
                _serviceExitTimes.isEmpty) ...[
              const SizedBox(height: 8),
              const Text(
                'Boş bırakılan bölüm vardiya hesabını kısıtlamaz.',
                style: TextStyle(fontSize: 12, color: Color(0xFF7A5A00)),
              ),
            ],
          ],
        ),
      ),
    );
  }

  List<Widget> _buildReliefScheduleFields() {
    final shifts =
        _selectedShiftDefinition?.slots.map((slot) => slot.label).toList() ??
        Personnel.threeShiftStandard;
    const monthNames = [
      'OCAK',
      'ŞUBAT',
      'MART',
      'NİSAN',
      'MAYIS',
      'HAZİRAN',
      'TEMMUZ',
      'AĞUSTOS',
      'EYLÜL',
      'EKİM',
      'KASIM',
      'ARALIK',
    ];
    const weekdayNames = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
    final daysInMonth = DateTime(
      _reliefMonth.year,
      _reliefMonth.month + 1,
      0,
    ).day;

    return [
      Container(
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFF7A8796)),
          borderRadius: BorderRadius.circular(8),
        ),
        padding: const EdgeInsets.fromLTRB(8, 10, 8, 12),
        child: Column(
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Dinlendirici Çalışma Günleri',
                    style: TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Önceki ay',
                  onPressed: () => setState(() {
                    _reliefMonth = DateTime(
                      _reliefMonth.year,
                      _reliefMonth.month - 1,
                    );
                  }),
                  icon: const Icon(Icons.chevron_left_rounded),
                ),
                Text(
                  '${monthNames[_reliefMonth.month - 1]} ${_reliefMonth.year}',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF082A52),
                  ),
                ),
                IconButton(
                  visualDensity: VisualDensity.compact,
                  tooltip: 'Sonraki ay',
                  onPressed: () => setState(() {
                    _reliefMonth = DateTime(
                      _reliefMonth.year,
                      _reliefMonth.month + 1,
                    );
                  }),
                  icon: const Icon(Icons.chevron_right_rounded),
                ),
              ],
            ),
            const Text(
              'Her tarih için en fazla 2 vardiya seçilebilir.',
              style: TextStyle(fontSize: 12, color: Color(0xFF52657B)),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const SizedBox(
                  width: 38,
                  child: Text(
                    'Tarih',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                const SizedBox(
                  width: 42,
                  child: Text(
                    'Gün',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                for (final shift in shifts)
                  Expanded(
                    child: Text(
                      shift,
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
              ],
            ),
            const Divider(),
            for (var day = 1; day <= daysInMonth; day++)
              Builder(
                builder: (context) {
                  final date = DateTime(
                    _reliefMonth.year,
                    _reliefMonth.month,
                    day,
                  );
                  final dateKey = _dateToIso(date);
                  final weekend = date.weekday >= DateTime.saturday;
                  return Container(
                    color: weekend ? const Color(0xFFF7F1E5) : null,
                    child: Row(
                      children: [
                        SizedBox(
                          width: 38,
                          child: Text(
                            '$day',
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                        ),
                        SizedBox(
                          width: 42,
                          child: Text(
                            weekdayNames[date.weekday - 1],
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              color: weekend ? const Color(0xFF9A5A00) : null,
                            ),
                          ),
                        ),
                        for (final shift in shifts)
                          Expanded(
                            child: Center(
                              child: Checkbox(
                                value:
                                    _reliefMonthlyShifts[dateKey]?.contains(
                                      shift,
                                    ) ??
                                    false,
                                onChanged: (selected) async {
                                  if (!await _confirmWorkTypeChange()) return;
                                  if (!mounted) return;
                                  final dayShifts =
                                      _reliefMonthlyShifts[dateKey] ??
                                      <String>{};
                                  if (selected == true &&
                                      !dayShifts.contains(shift) &&
                                      dayShifts.length >= 2) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          '$day ${monthNames[_reliefMonth.month - 1]} için en fazla 2 vardiya seçebilirsiniz.',
                                        ),
                                      ),
                                    );
                                    return;
                                  }
                                  setState(() {
                                    final updated = {...dayShifts};
                                    if (selected == true) {
                                      updated.add(shift);
                                    } else {
                                      updated.remove(shift);
                                    }
                                    if (updated.isEmpty) {
                                      _reliefMonthlyShifts.remove(dateKey);
                                    } else {
                                      _reliefMonthlyShifts[dateKey] = updated;
                                    }
                                  });
                                },
                              ),
                            ),
                          ),
                      ],
                    ),
                  );
                },
              ),
          ],
        ),
      ),
      const SizedBox(height: 16),
    ];
  }

  List<Widget> _buildRotatingShiftFields() {
    final patterns = _editingShiftSystem == Personnel.threeShiftSystem
        ? const [
            Personnel.threeShiftStandardPattern,
            Personnel.threeShiftEarlyPattern,
          ]
        : _editingShiftSystem == Personnel.twoShiftSystem
        ? const [
            Personnel.twoShiftStandardPattern,
            Personnel.twoShiftEarlyPattern,
          ]
        : const <String>[];
    final displayedPattern = patterns.contains(_shiftPattern)
        ? _shiftPattern
        : '';
    final patternShifts = displayedPattern.isEmpty
        ? const <String>[]
        : Personnel.shiftsForPattern(displayedPattern);

    return [
      InputDecorator(
        decoration: const InputDecoration(
          labelText: 'Vardiya Sistemi',
          border: OutlineInputBorder(),
        ),
        child: SegmentedButton<String>(
          expandedInsets: EdgeInsets.zero,
          showSelectedIcon: false,
          emptySelectionAllowed: true,
          segments: const [
            ButtonSegment(
              value: Personnel.threeShiftSystem,
              label: Text('3 Vardiya'),
            ),
            ButtonSegment(
              value: Personnel.twoShiftSystem,
              label: Text('2 Vardiya'),
            ),
          ],
          selected: _editingShiftSystem.isEmpty
              ? const {}
              : {_editingShiftSystem},
          onSelectionChanged: (selection) {
            if (selection.isEmpty) return;
            setState(() => _editingShiftSystem = selection.first);
          },
        ),
      ),
      const SizedBox(height: 16),
      if (_editingShiftSystem.isNotEmpty)
        DropdownButtonFormField<String>(
          key: ValueKey('pattern_$_editingShiftSystem'),
          initialValue: displayedPattern.isEmpty ? null : displayedPattern,
          isExpanded: true,
          decoration: const InputDecoration(
            labelText: 'Vardiya Saatleri',
            prefixIcon: Icon(Icons.schedule_rounded),
            border: OutlineInputBorder(),
          ),
          items: [
            for (final pattern in patterns)
              DropdownMenuItem(
                value: pattern,
                child: Text(
                  Personnel.patternLabel(pattern),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
          ],
          onChanged: (value) async {
            if (value == null) return;
            final targetSystem = _editingShiftSystem;
            if (!await _confirmWorkTypeChange()) return;
            if (!mounted) return;
            setState(() => _editingShiftSystem = targetSystem);
            if (!await _confirmShiftSystemChange()) return;
            if (!mounted) return;
            setState(() {
              _shiftPattern = value;
              _shift = '';
              _leaveMode = '';
              _leaveWeekdays.clear();
              _workDaysCount = 0;
              _leaveDaysCount = 0;
            });
          },
        ),
      if (_editingShiftSystem.isNotEmpty) const SizedBox(height: 16),
      if (displayedPattern.isNotEmpty)
        DropdownButtonFormField<String>(
          key: ValueKey('starting_shift_$displayedPattern'),
          initialValue: patternShifts.contains(_shift) ? _shift : null,
          decoration: const InputDecoration(
            labelText: 'Mevcut Vardiyası',
            prefixIcon: Icon(Icons.access_time_rounded),
            border: OutlineInputBorder(),
          ),
          items: [
            for (final shift in patternShifts)
              DropdownMenuItem(value: shift, child: Text(shift)),
          ],
          onChanged: (value) {
            if (value != null) {
              setState(() {
                _shift = value;
                _shiftSelectionTouched = true;
              });
            }
          },
        ),
      if (displayedPattern == Personnel.threeShiftEarlyPattern)
        const Padding(
          padding: EdgeInsets.only(top: 8),
          child: Text(
            '23 / 07 vardiyası saat 23.00’te başlar ve ertesi günün çalışması sayılır.',
            style: TextStyle(
              color: Color(0xFF9A5A00),
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      const SizedBox(height: 16),
      if (displayedPattern.isNotEmpty)
        InputDecorator(
          decoration: const InputDecoration(
            labelText: 'Vardiya Hesaplama',
            border: OutlineInputBorder(),
          ),
          child: SegmentedButton<String>(
            expandedInsets: EdgeInsets.zero,
            showSelectedIcon: false,
            emptySelectionAllowed: true,
            segments: const [
              ButtonSegment(
                value: Personnel.weeklyLeaveMode,
                label: Text('İzin Günü ile'),
              ),
              ButtonSegment(
                value: Personnel.cycleLeaveMode,
                label: Text('Çalışma Günü ile'),
              ),
            ],
            selected: _leaveMode.isEmpty ? const {} : {_leaveMode},
            onSelectionChanged: (selection) {
              if (selection.isEmpty) return;
              setState(() {
                _leaveMode = selection.first;
                if (_leaveMode == Personnel.weeklyLeaveMode) {
                  _workDaysCount = 0;
                  _leaveDaysCount = 0;
                } else {
                  _leaveWeekdays.clear();
                }
              });
            },
          ),
        ),
      if (_leaveMode.isNotEmpty) const SizedBox(height: 16),
      if (_leaveMode == Personnel.weeklyLeaveMode)
        _weekdaySelector()
      else if (_leaveMode == Personnel.cycleLeaveMode)
        ..._cycleSelectors(),
      if (_leaveMode.isNotEmpty) const SizedBox(height: 12),
      if (_leaveMode.isNotEmpty) _directionSelector(),
      const SizedBox(height: 16),
    ];
  }

  Widget _weekdaySelector() {
    return InputDecorator(
      decoration: const InputDecoration(
        labelText: 'İzinli Günler',
        prefixIcon: Icon(Icons.event_busy_rounded),
        border: OutlineInputBorder(),
      ),
      child: Wrap(
        spacing: 6,
        runSpacing: 6,
        children: [
          for (final day in const [
            (1, 'Pzt'),
            (2, 'Sal'),
            (3, 'Çar'),
            (4, 'Per'),
            (5, 'Cum'),
            (6, 'Cmt'),
            (7, 'Paz'),
          ])
            FilterChip(
              label: Text(day.$2),
              selected: _leaveWeekdays.contains(day.$1),
              onSelected: (selected) {
                setState(() {
                  selected
                      ? _leaveWeekdays.add(day.$1)
                      : _leaveWeekdays.remove(day.$1);
                });
              },
            ),
        ],
      ),
    );
  }

  List<Widget> _cycleSelectors() {
    return [
      DropdownButtonFormField<int>(
        initialValue: _workDaysCount == 0 ? null : _workDaysCount,
        decoration: const InputDecoration(
          labelText: 'Çalışılacak Gün Sayısı',
          prefixIcon: Icon(Icons.work_history_rounded),
          border: OutlineInputBorder(),
        ),
        items: [
          for (var day = 1; day <= 7; day++)
            DropdownMenuItem(value: day, child: Text('$day gün')),
        ],
        onChanged: (value) {
          if (value != null) setState(() => _workDaysCount = value);
        },
      ),
      const SizedBox(height: 12),
      DropdownButtonFormField<int>(
        initialValue: _leaveDaysCount == 0 ? null : _leaveDaysCount,
        decoration: const InputDecoration(
          labelText: 'İzinli Gün Sayısı',
          prefixIcon: Icon(Icons.event_busy_rounded),
          border: OutlineInputBorder(),
        ),
        items: [
          for (var day = 1; day <= 7; day++)
            DropdownMenuItem(value: day, child: Text('$day gün')),
        ],
        onChanged: (value) {
          if (value != null) setState(() => _leaveDaysCount = value);
        },
      ),
      const SizedBox(height: 12),
      DropdownButtonFormField<int>(
        initialValue: _cycleDay.clamp(1, 6),
        decoration: const InputDecoration(
          labelText: 'Bugün Kaçıncı Çalışma Günü?',
          prefixIcon: Icon(Icons.today_rounded),
          border: OutlineInputBorder(),
        ),
        items: [
          for (var day = 1; day <= 6; day++)
            DropdownMenuItem(value: day, child: Text('$day. çalışma günü')),
        ],
        onChanged: (value) {
          if (value != null) setState(() => _cycleDay = value);
        },
      ),
    ];
  }

  Widget _directionSelector() {
    return DropdownButtonFormField<String>(
      initialValue: _shiftDirection,
      isExpanded: true,
      decoration: const InputDecoration(
        labelText: 'Vardiya Değişim Yönü',
        prefixIcon: Icon(Icons.sync_alt_rounded),
        border: OutlineInputBorder(),
      ),
      items: const [
        DropdownMenuItem(
          value: Personnel.shiftBackward,
          child: Text('Vardiya 8 saat geri gidecek'),
        ),
        DropdownMenuItem(
          value: Personnel.shiftForward,
          child: Text('Vardiya 8 saat ileri gidecek'),
        ),
      ],
      onChanged: (value) {
        if (value != null) setState(() => _shiftDirection = value);
      },
    );
  }

  Widget _field({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
    int maxLines = 1,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        inputFormatters: inputFormatters,
        validator: validator,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon),
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}
