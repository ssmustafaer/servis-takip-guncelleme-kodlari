class WorkShift {
  const WorkShift({required this.id, required this.name, required this.order});

  final String id;
  final String name;
  final int order;

  WorkShift copyWith({String? name, int? order}) {
    return WorkShift(
      id: id,
      name: name ?? this.name,
      order: order ?? this.order,
    );
  }

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'order': order};

  factory WorkShift.fromJson(Map<String, dynamic> json) {
    return WorkShift(
      id: json['id'] as String,
      name: json['name'] as String,
      order: json['order'] as int,
    );
  }
}
