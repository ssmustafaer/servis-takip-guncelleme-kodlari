import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class CompanyCloudStorage {
  CompanyCloudStorage._();

  static final _auth = FirebaseAuth.instance;
  static final _firestore = FirebaseFirestore.instance;
  static const _localStorage = FlutterSecureStorage();

  static String? _cachedUserId;
  static String? _cachedCompanyId;
  static bool _cachedAllInstitutions = true;
  static List<String> _cachedAllowedInstitutionIds = const [];
  static String? _emergencyCompanyId;

  static void setEmergencyCompany(String? companyId) {
    _emergencyCompanyId = companyId;
    _cachedCompanyId = null;
    _cachedUserId = null;
    _cachedAllInstitutions = true;
    _cachedAllowedInstitutionIds = const [];
  }

  static Future<String?> companyId() async {
    if (_emergencyCompanyId?.isNotEmpty == true) return _emergencyCompanyId;
    final user = _auth.currentUser;
    if (user == null) return null;
    if (_cachedUserId == user.uid && _cachedCompanyId != null) {
      return _cachedCompanyId;
    }
    final localCompanyKey = 'last_company_id_${user.uid}';
    try {
      final profile = await _firestore.collection('users').doc(user.uid).get();
      final id = profile.data()?['companyId'] as String?;
      final profileData = profile.data() ?? const <String, dynamic>{};
      _cachedUserId = user.uid;
      _cachedCompanyId = id;
      _cachedAllInstitutions = profileData['allInstitutions'] as bool? ?? true;
      _cachedAllowedInstitutionIds =
          (profileData['allowedInstitutionIds'] as List<dynamic>? ?? const [])
              .map((value) => value.toString())
              .toList();
      if (id?.isNotEmpty == true) {
        await _localStorage.write(key: localCompanyKey, value: id);
      }
      return id;
    } catch (_) {
      final localId = await _localStorage.read(key: localCompanyKey);
      _cachedUserId = user.uid;
      _cachedCompanyId = localId;
      return localId;
    }
  }

  static Future<List<Map<String, dynamic>>> readCollection(
    String collectionName,
  ) async {
    final id = await companyId();
    if (id == null || id.isEmpty) return const [];
    final collection = _firestore
        .collection('companies')
        .doc(id)
        .collection(collectionName);
    if ((collectionName == 'personnel' ||
            collectionName == 'oneDayPassengers' ||
            collectionName == 'personnelLeaves') &&
        !_cachedAllInstitutions) {
      if (_cachedAllowedInstitutionIds.isEmpty) return const [];
      final data = <Map<String, dynamic>>[];
      for (
        var start = 0;
        start < _cachedAllowedInstitutionIds.length;
        start += 30
      ) {
        final end = (start + 30 < _cachedAllowedInstitutionIds.length)
            ? start + 30
            : _cachedAllowedInstitutionIds.length;
        final snapshot = await _readQuery(
          collection.where(
            'institutionId',
            whereIn: _cachedAllowedInstitutionIds.sublist(start, end),
          ),
        );
        data.addAll(snapshot.docs.map((document) => document.data()));
      }
      return data;
    }
    final snapshot = await _readQuery(collection);
    return snapshot.docs.map((document) => document.data()).toList();
  }

  static Future<QuerySnapshot<Map<String, dynamic>>> _readQuery(
    Query<Map<String, dynamic>> query,
  ) async {
    try {
      return await query.get().timeout(const Duration(seconds: 4));
    } catch (_) {
      return query.get(const GetOptions(source: Source.cache));
    }
  }

  static Stream<List<Map<String, dynamic>>> watchCollection(
    String collectionName,
  ) async* {
    final id = await companyId();
    if (id == null || id.isEmpty) {
      yield const [];
      return;
    }
    Query<Map<String, dynamic>> query = _firestore
        .collection('companies')
        .doc(id)
        .collection(collectionName);
    if (collectionName == 'personnel' && !_cachedAllInstitutions) {
      if (_cachedAllowedInstitutionIds.isEmpty) {
        yield const [];
        return;
      }
      query = query.where(
        'institutionId',
        whereIn: _cachedAllowedInstitutionIds.take(30).toList(),
      );
    }
    await for (final snapshot in query.snapshots()) {
      yield snapshot.docs.map((document) => document.data()).toList();
    }
  }

  static Future<void> replaceCollection({
    required String collectionName,
    required List<Map<String, dynamic>> items,
    String? limitField,
    String? usageField,
    int? usageCount,
  }) async {
    final id = await companyId();
    if (id == null || id.isEmpty) {
      throw StateError('Şirket oturumu bulunamadı.');
    }
    final companyReference = _firestore.collection('companies').doc(id);
    final companySnapshot = await companyReference.get();
    final companyData = companySnapshot.data();
    if (companyData == null || companyData['active'] != true) {
      throw StateError('Şirket hesabı aktif değil.');
    }

    final effectiveUsageCount = usageCount ?? items.length;
    if (limitField != null) {
      final limits = companyData['limits'] as Map<String, dynamic>? ?? const {};
      final limit = (limits[limitField] as num?)?.toInt() ?? 0;
      final usage = companyData['usage'] as Map<String, dynamic>? ?? const {};
      final currentUsage = usageField == null
          ? 0
          : (usage[usageField] as num?)?.toInt() ?? 0;
      if (limit > 0 &&
          effectiveUsageCount > limit &&
          effectiveUsageCount > currentUsage) {
        throw StateError(
          'Paket sınırı aşıldı: $effectiveUsageCount/$limit kayıt.',
        );
      }
    }

    final collection = companyReference.collection(collectionName);
    final existing = await collection.get();
    final batch = _firestore.batch();
    final incomingIds = <String>{};
    for (final item in items) {
      final itemId = item['id'] as String?;
      if (itemId == null || itemId.isEmpty) continue;
      incomingIds.add(itemId);
      batch.set(collection.doc(itemId), {
        ...item,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
    for (final document in existing.docs) {
      final isDeletedArchive =
          (collectionName == 'personnel' || collectionName == 'stops') &&
          document.id.startsWith('_deleted_');
      if (!incomingIds.contains(document.id) && !isDeletedArchive) {
        batch.delete(document.reference);
      }
    }
    if (usageField != null) {
      batch.update(companyReference, {
        'usage.$usageField': usageCount ?? incomingIds.length,
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();
  }

  static Future<void> syncUsageCount({
    required String usageField,
    required int count,
  }) async {
    final id = await companyId();
    if (id == null || id.isEmpty) return;
    final companyReference = _firestore.collection('companies').doc(id);
    DocumentSnapshot<Map<String, dynamic>> snapshot;
    try {
      snapshot = await companyReference.get().timeout(
        const Duration(seconds: 4),
      );
    } catch (_) {
      return;
    }
    final data = snapshot.data();
    if (data == null || data['active'] != true) return;
    final usage = data['usage'] as Map<String, dynamic>? ?? const {};
    final currentCount = (usage[usageField] as num?)?.toInt() ?? 0;
    if (currentCount == count) return;
    try {
      await companyReference
          .update({
            'usage.$usageField': count,
            'updatedAt': FieldValue.serverTimestamp(),
          })
          .timeout(const Duration(seconds: 4));
    } catch (_) {
      // Sayaç yardımcı bilgidir; bulut geçici olarak kullanılamadığında
      // ana ekranın açılmasını engellemez.
    }
  }

  static Future<Map<String, dynamic>?> readDocument({
    required String collectionName,
    required String documentId,
  }) async {
    final id = await companyId();
    if (id == null || id.isEmpty) return null;
    final reference = _firestore
        .collection('companies')
        .doc(id)
        .collection(collectionName)
        .doc(documentId);
    DocumentSnapshot<Map<String, dynamic>> document;
    try {
      document = await reference.get().timeout(const Duration(seconds: 4));
    } catch (_) {
      document = await reference.get(const GetOptions(source: Source.cache));
    }
    return document.data();
  }

  static Future<void> writeDocument({
    required String collectionName,
    required String documentId,
    required Map<String, dynamic> data,
  }) async {
    final id = await companyId();
    if (id == null || id.isEmpty) {
      throw StateError('Şirket oturumu bulunamadı.');
    }
    await _firestore
        .collection('companies')
        .doc(id)
        .collection(collectionName)
        .doc(documentId)
        .set({...data, 'updatedAt': FieldValue.serverTimestamp()});
  }

  static Future<void> applyDocumentChanges({
    required String collectionName,
    required Map<String, Map<String, dynamic>> upserts,
    required Set<String> deletes,
  }) async {
    final id = await companyId();
    if (id == null || id.isEmpty) {
      throw StateError('Şirket oturumu bulunamadı.');
    }
    final collection = _firestore
        .collection('companies')
        .doc(id)
        .collection(collectionName);
    final operations = <({String id, Map<String, dynamic>? data})>[
      for (final entry in upserts.entries) (id: entry.key, data: entry.value),
      for (final documentId in deletes)
        if (!upserts.containsKey(documentId)) (id: documentId, data: null),
    ];
    for (var start = 0; start < operations.length; start += 450) {
      final end = (start + 450 < operations.length)
          ? start + 450
          : operations.length;
      final batch = _firestore.batch();
      for (final operation in operations.sublist(start, end)) {
        final reference = collection.doc(operation.id);
        final data = operation.data;
        if (data == null) {
          batch.delete(reference);
        } else {
          batch.set(reference, {
            ...data,
            'updatedAt': FieldValue.serverTimestamp(),
          });
        }
      }
      await batch.commit();
    }
  }

  static Future<void> deleteDocument({
    required String collectionName,
    required String documentId,
  }) async {
    final id = await companyId();
    if (id == null || id.isEmpty) {
      throw StateError('Şirket oturumu bulunamadı.');
    }
    await _firestore
        .collection('companies')
        .doc(id)
        .collection(collectionName)
        .doc(documentId)
        .delete();
  }

  static Future<String> cacheKey(String baseKey) async {
    final id = await companyId();
    return id == null || id.isEmpty ? baseKey : '${baseKey}_$id';
  }

  static Future<bool> isCloudInitialized(String collectionName) async {
    final id = await companyId();
    if (id == null || id.isEmpty) return false;
    return await _localStorage.read(
          key: 'cloud_initialized_${id}_$collectionName',
        ) ==
        'true';
  }

  static Future<void> markCloudInitialized(String collectionName) async {
    final id = await companyId();
    if (id == null || id.isEmpty) return;
    await _localStorage.write(
      key: 'cloud_initialized_${id}_$collectionName',
      value: 'true',
    );
  }

  static Future<bool> canClaimLegacyData() async {
    final id = await companyId();
    if (id == null || id.isEmpty) return false;
    final claimed = await _localStorage.read(key: 'legacy_claimed_company');
    if (claimed == null || claimed.isEmpty) {
      await _localStorage.write(key: 'legacy_claimed_company', value: id);
      return true;
    }
    return claimed == id;
  }
}
