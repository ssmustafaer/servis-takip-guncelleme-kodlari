class PersonnelLeave {
  const PersonnelLeave({
    required this.id,
    required this.personId,
    required this.personName,
    required this.institutionId,
    required this.institutionName,
    required this.startDate,
    required this.endDate,
    this.note = '',
    this.returnDate = '',
    this.returnShift = '',
  });

  final String id;
  final String personId;
  final String personName;
  final String institutionId;
  final String institutionName;
  final String startDate;
  final String endDate;
  final String note;
  final String returnDate;
  final String returnShift;

  bool includes(DateTime date) {
    final day = DateTime(date.year, date.month, date.day);
    if (returnDate.isNotEmpty) {
      final returned = DateTime.parse(returnDate);
      if (!day.isBefore(returned)) return false;
    }
    final start = DateTime.parse(startDate);
    final end = DateTime.parse(endDate);
    return !day.isBefore(start) && !day.isAfter(end);
  }

  int remainingDays(DateTime today) {
    final day = DateTime(today.year, today.month, today.day);
    final end = DateTime.parse(endDate);
    if (end.isBefore(day)) return 0;
    return end.difference(day).inDays + 1;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'personId': personId,
    'personName': personName,
    'institutionId': institutionId,
    'institutionName': institutionName,
    'startDate': startDate,
    'endDate': endDate,
    'note': note,
    'returnDate': returnDate,
    'returnShift': returnShift,
  };

  PersonnelLeave copyWith({String? returnDate, String? returnShift}) {
    return PersonnelLeave(
      id: id,
      personId: personId,
      personName: personName,
      institutionId: institutionId,
      institutionName: institutionName,
      startDate: startDate,
      endDate: endDate,
      note: note,
      returnDate: returnDate ?? this.returnDate,
      returnShift: returnShift ?? this.returnShift,
    );
  }

  factory PersonnelLeave.fromJson(Map<String, dynamic> json) => PersonnelLeave(
    id: json['id'] as String,
    personId: json['personId'] as String,
    personName: json['personName'] as String? ?? 'Personel',
    institutionId: json['institutionId'] as String? ?? '',
    institutionName: json['institutionName'] as String? ?? '',
    startDate: json['startDate'] as String,
    endDate: json['endDate'] as String,
    note: json['note'] as String? ?? '',
    returnDate: json['returnDate'] as String? ?? '',
    returnShift: json['returnShift'] as String? ?? '',
  );
}
