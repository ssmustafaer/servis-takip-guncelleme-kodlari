import 'package:flutter/material.dart';

import '../models/driver.dart';
import '../models/institution.dart';
import '../models/vehicle.dart';
import '../services/driver_storage.dart';
import '../services/institution_storage.dart';
import '../services/service_preference_storage.dart';
import '../services/vehicle_storage.dart';
import 'shift_list_screen.dart';

class ServiceSetupScreen extends StatefulWidget {
  const ServiceSetupScreen({
    required this.isDistribution,
    required this.allInstitutions,
    required this.allowedInstitutionIds,
    required this.allVehicles,
    required this.allowedVehicleIds,
    required this.canEditPersonnel,
    this.preferredDriverId,
    this.preferredDriverName,
    super.key,
  });

  final bool isDistribution;
  final bool allInstitutions;
  final List<String> allowedInstitutionIds;
  final bool allVehicles;
  final List<String> allowedVehicleIds;
  final String? preferredDriverId;
  final String? preferredDriverName;
  final bool canEditPersonnel;

  @override
  State<ServiceSetupScreen> createState() => _ServiceSetupScreenState();
}

class _ServiceSetupScreenState extends State<ServiceSetupScreen> {
  static const _personnelMode = 'personnel';
  static const _stopMode = 'stops';
  static const _allStopsMode = 'allStops';
  bool _loading = true;
  List<Driver> _drivers = [];
  List<Vehicle> _vehicles = [];
  List<Institution> _institutions = [];
  String? _driverId;
  String? _vehicleId;
  String? _institutionId;
  String? _rootInstitutionId;
  String? _childInstitutionId;
  String? _grandchildInstitutionId;
  String? _groupInstitutionId;
  String _listMode = _personnelMode;

  bool _canUseInstitution(String id) {
    return widget.allInstitutions || widget.allowedInstitutionIds.contains(id);
  }

  bool _branchIsVisible(Institution institution) {
    if (widget.allInstitutions) return true;
    final subtree = Institution.subtreeIds(_institutions, institution.id);
    return subtree.any(widget.allowedInstitutionIds.contains);
  }

  List<Institution> _visibleChildren(String? parentId) {
    return Institution.childrenOf(
      _institutions,
      parentId,
    ).where((item) => item.active && _branchIsVisible(item)).toList();
  }

  bool _isLegacyWorkStyle(Institution item) {
    final name = item.name.toLowerCase();
    return name.contains('vardiya') ||
        name.contains('memur') ||
        name.contains('güvenlik') ||
        name.contains('sabit') ||
        name.contains('dinlendirici');
  }

  List<Institution> _visibleRegions(String rootId) {
    // Yeni kurum ağacı: Kurum -> Bölge -> Takım.
    // Bölgenin adında "Vardiya" geçse bile bölge atlanmamalıdır.
    return _visibleChildren(
      rootId,
    ).where((item) => !_looksLikeTeam(item)).toList();
  }

  bool _looksLikeTeam(Institution item) {
    final name = item.name.trim().toLowerCase();
    return name.contains('takım') ||
        name.contains('takim') ||
        name.contains('grubu') ||
        RegExp(r'^[a-zçğıöşü]\s*grup$').hasMatch(name);
  }

  List<Institution> _institutionPath(Institution institution) {
    final byId = {for (final item in _institutions) item.id: item};
    final path = <Institution>[institution];
    var parentId = institution.parentId;
    final visited = <String>{institution.id};
    while (parentId != null && parentId.isNotEmpty && visited.add(parentId)) {
      final parent = byId[parentId];
      if (parent == null) break;
      path.insert(0, parent);
      parentId = parent.parentId;
    }
    return path;
  }

  void _restoreInstitutionSelection(String? savedInstitution) {
    Institution? saved;
    for (final item in _institutions) {
      if (item.id == savedInstitution && _canUseInstitution(item.id)) {
        saved = item;
        break;
      }
    }
    if (saved != null) {
      final path = _institutionPath(saved);
      _rootInstitutionId = path.isNotEmpty ? path[0].id : null;
      final regions = _rootInstitutionId == null
          ? const <Institution>[]
          : _visibleRegions(_rootInstitutionId!);
      Institution? region;
      for (final item in path.skip(1)) {
        if (regions.any((candidate) => candidate.id == item.id)) region = item;
      }
      _childInstitutionId = region?.id;
      final groups = region == null
          ? const <Institution>[]
          : _visibleChildren(region.id);
      Institution? group;
      for (final item in path) {
        if (groups.any((candidate) => candidate.id == item.id)) group = item;
      }
      _grandchildInstitutionId = group?.id;
      _groupInstitutionId = null;
      final representedSelection = group ?? region ?? path.first;
      _institutionId = _canUseInstitution(representedSelection.id)
          ? representedSelection.id
          : null;
      return;
    }

    final roots = _visibleChildren(null);
    if (roots.length != 1) return;
    _rootInstitutionId = roots.first.id;
    final children = _visibleChildren(_rootInstitutionId);
    if (children.length != 1) {
      if (children.isEmpty && _canUseInstitution(roots.first.id)) {
        _institutionId = roots.first.id;
      }
      return;
    }
    _childInstitutionId = children.first.id;
    final grandchildren = _visibleChildren(_childInstitutionId);
    if (grandchildren.length == 1) {
      _grandchildInstitutionId = grandchildren.first.id;
      _institutionId = grandchildren.first.id;
    } else if (grandchildren.isEmpty && _canUseInstitution(children.first.id)) {
      _institutionId = children.first.id;
    }
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final result = await Future.wait([
      DriverStorage.readAll(),
      VehicleStorage.readAll(),
      InstitutionStorage.readAll(),
      ServicePreferenceStorage.read('driver'),
      ServicePreferenceStorage.read('vehicle'),
      ServicePreferenceStorage.read('institution'),
      ServicePreferenceStorage.read('listMode'),
    ]);
    if (!mounted) return;
    final drivers = [...result[0] as List<Driver>];
    final vehicles = (result[1] as List<Vehicle>)
        .where(
          (item) =>
              item.active &&
              (widget.allVehicles ||
                  widget.allowedVehicleIds.contains(item.id)),
        )
        .toList();
    final institutions = result[2] as List<Institution>;

    final preferredId = widget.preferredDriverId;
    if (preferredId != null &&
        !drivers.any((driver) => driver.id == preferredId)) {
      drivers.add(
        Driver(id: preferredId, name: widget.preferredDriverName ?? 'Şoför'),
      );
    }
    final savedDriver = result[3] as String?;
    final savedVehicle = result[4] as String?;
    final savedInstitution = result[5] as String?;
    final savedListMode = result[6] as String?;
    setState(() {
      _drivers = drivers;
      _vehicles = vehicles;
      _institutions = institutions;
      _driverId =
          preferredId ??
          (drivers.any((item) => item.id == savedDriver)
              ? savedDriver
              : (drivers.length == 1 ? drivers.first.id : null));
      _vehicleId = vehicles.any((item) => item.id == savedVehicle)
          ? savedVehicle
          : (vehicles.length == 1 ? vehicles.first.id : null);
      _restoreInstitutionSelection(savedInstitution);
      _listMode =
          {_personnelMode, _stopMode, _allStopsMode}.contains(savedListMode)
          ? savedListMode!
          : _personnelMode;
      _loading = false;
    });
  }

  void _selectRoot(String? value) {
    setState(() {
      _rootInstitutionId = value;
      _childInstitutionId = null;
      _grandchildInstitutionId = null;
      _groupInstitutionId = null;
      _institutionId = null;
      if (value == null) return;
      final children = _visibleRegions(value);
      if (children.length == 1) {
        _childInstitutionId = children.first.id;
        _institutionId = _canUseInstitution(children.first.id)
            ? children.first.id
            : null;
        return;
      }
      if (children.isEmpty && _canUseInstitution(value)) {
        _institutionId = value;
      }
    });
  }

  void _selectChild(String? value) {
    setState(() {
      _childInstitutionId = value;
      _grandchildInstitutionId = null;
      _groupInstitutionId = null;
      _institutionId = null;
      if (value == null) return;
      _institutionId = _canUseInstitution(value) ? value : null;
    });
  }

  void _selectGrandchild(String? value) {
    setState(() {
      _grandchildInstitutionId = value == null || value.isEmpty ? null : value;
      _groupInstitutionId = null;
      final selected = _grandchildInstitutionId ?? _childInstitutionId;
      _institutionId = selected != null && _canUseInstitution(selected)
          ? selected
          : null;
    });
  }

  void _selectGroup(String? value) {
    setState(() {
      _groupInstitutionId = value == null || value.isEmpty ? null : value;
      final selected = _groupInstitutionId ?? _grandchildInstitutionId;
      _institutionId = selected != null && _canUseInstitution(selected)
          ? selected
          : null;
    });
  }

  Future<void> _continue() async {
    final driverId = _driverId;
    final vehicleId = _vehicleId;
    final institutionId = _institutionId;
    if (driverId == null || vehicleId == null || institutionId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Şoför, araç ve kurum seçimini tamamlayın.'),
        ),
      );
      return;
    }
    await ServicePreferenceStorage.save(
      driverId: driverId,
      vehicleId: vehicleId,
      institutionId: institutionId,
      listMode: _listMode,
    );
    if (!mounted) return;
    await Navigator.of(context).pushReplacement(
      MaterialPageRoute<void>(
        builder: (_) => ShiftListScreen(
          isDistribution: widget.isDistribution,
          allInstitutions: widget.allInstitutions,
          allowedInstitutionIds: widget.allowedInstitutionIds,
          allVehicles: widget.allVehicles,
          allowedVehicleIds: widget.allowedVehicleIds,
          preferredDriverId: driverId,
          preferredDriverName: _drivers
              .firstWhere((item) => item.id == driverId)
              .name,
          initialInstitutionId: institutionId,
          initialVehicleId: vehicleId,
          canEditPersonnel: widget.canEditPersonnel,
          groupByStops: _listMode == _stopMode,
          showAllStops: _listMode == _allStopsMode,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final roots = _visibleChildren(null);
    final children = _rootInstitutionId == null
        ? <Institution>[]
        : _visibleRegions(_rootInstitutionId!);
    final grandchildren = _childInstitutionId == null
        ? <Institution>[]
        : _visibleChildren(_childInstitutionId);
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.isDistribution
              ? 'Dağıtım Servisi Hazırlığı'
              : 'Toplama Servisi Hazırlığı',
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Text(
                  'Servis Bilgileri',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.w800,
                    color: const Color(0xFF082A52),
                  ),
                ),
                const SizedBox(height: 20),
                DropdownButtonFormField<String>(
                  initialValue: _driverId,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Şoförün Adı',
                    prefixIcon: Icon(Icons.badge_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: _drivers
                      .map(
                        (item) => DropdownMenuItem(
                          value: item.id,
                          child: Text(item.name),
                        ),
                      )
                      .toList(),
                  onChanged: widget.preferredDriverId != null
                      ? null
                      : (value) => setState(() => _driverId = value),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  initialValue: _vehicleId,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: 'Araç Plakası',
                    prefixIcon: Icon(Icons.directions_bus_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: _vehicles
                      .map(
                        (item) => DropdownMenuItem(
                          value: item.id,
                          child: Text(item.plate),
                        ),
                      )
                      .toList(),
                  onChanged: (value) => setState(() => _vehicleId = value),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  key: ValueKey('institution-root-$_rootInstitutionId'),
                  initialValue: _rootInstitutionId,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: '1. Kurum Seçimi',
                    prefixIcon: Icon(Icons.domain_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: roots
                      .map(
                        (item) => DropdownMenuItem(
                          value: item.id,
                          child: Text(item.name),
                        ),
                      )
                      .toList(),
                  onChanged: _selectRoot,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  key: ValueKey(
                    'institution-child-$_rootInstitutionId-$_childInstitutionId',
                  ),
                  initialValue: _childInstitutionId,
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: '2. Bölge Seçimi',
                    prefixIcon: Icon(Icons.account_tree_rounded),
                    border: OutlineInputBorder(),
                  ),
                  items: children
                      .map(
                        (item) => DropdownMenuItem(
                          value: item.id,
                          child: Text(item.name),
                        ),
                      )
                      .toList(),
                  onChanged: children.isEmpty ? null : _selectChild,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  key: ValueKey(
                    'institution-grandchild-$_childInstitutionId-$_grandchildInstitutionId',
                  ),
                  initialValue: _grandchildInstitutionId ?? '',
                  isExpanded: true,
                  decoration: const InputDecoration(
                    labelText: '3. Takım Seçimi (isteğe bağlı)',
                    prefixIcon: Icon(Icons.groups_2_outlined),
                    border: OutlineInputBorder(),
                  ),
                  items: [
                    const DropdownMenuItem(
                      value: '',
                      child: Text('Tüm Takımlar / Takım seçilmedi'),
                    ),
                    ...grandchildren.map(
                      (item) => DropdownMenuItem(
                        value: item.id,
                        child: Text(item.name),
                      ),
                    ),
                  ],
                  onChanged: _childInstitutionId == null
                      ? null
                      : _selectGrandchild,
                ),
                const SizedBox(height: 24),
                const Text(
                  'Listeleme Şekli',
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 10),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(
                      value: _personnelMode,
                      icon: Icon(Icons.people_alt_rounded),
                      label: Text(
                        'Personel\nİsmine Göre',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 10),
                      ),
                    ),
                    ButtonSegment(
                      value: _stopMode,
                      icon: Icon(Icons.location_on_rounded),
                      label: Text(
                        'Durak\nSırasına Göre',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 10),
                      ),
                    ),
                    ButtonSegment(
                      value: _allStopsMode,
                      icon: Icon(Icons.alt_route_rounded),
                      label: Text(
                        'Tüm Duraklara\nUğra',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 10),
                      ),
                    ),
                  ],
                  selected: {_listMode},
                  onSelectionChanged: (selection) =>
                      setState(() => _listMode = selection.first),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  height: 54,
                  child: FilledButton.icon(
                    onPressed: _continue,
                    icon: const Icon(Icons.arrow_forward_rounded),
                    label: const Text('VARDİYA LİSTESİNİ AÇ'),
                  ),
                ),
              ],
            ),
    );
  }
}
