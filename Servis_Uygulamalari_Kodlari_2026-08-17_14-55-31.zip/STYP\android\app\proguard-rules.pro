# Firebase App Distribution, AndroidX WorkManager'i uygulama açılmadan önce
# başlatır. Room veritabanı uygulaması isimle bulunduğu için R8'in sınıf
# adını değiştirmesine veya sınıfı kaldırmasına izin verilmemelidir.
-keepnames class * extends androidx.room.RoomDatabase
-keep class androidx.work.impl.WorkDatabase_Impl { *; }
-keep class **_Impl extends androidx.room.RoomDatabase { *; }

# Room tarafından oluşturulan alan ve metot açıklamalarını koru.
-keepattributes *Annotation*
